/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Nodo.cpp
 * Author: Jeremy Lopez Galindo
 * 
 * Created on 4 de diciembre de 2023, 06:53 PM
 */

#include "Nodo.h"

Nodo::Nodo() {
    anterior = nullptr;
    siguiente = nullptr;
}

//Nodo::Nodo(const Nodo& orig) {
//}

Nodo::~Nodo() {

}

