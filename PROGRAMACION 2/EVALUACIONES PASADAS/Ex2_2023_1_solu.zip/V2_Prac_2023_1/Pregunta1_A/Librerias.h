
/* 
 * File:   Librerias.h
 * Author: Jeremy Lopez Galindo
 *
 * Created on 4 de diciembre de 2023, 06:40 PM
 */

#ifndef LIBRERIAS_H
#define LIBRERIAS_H

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
#include <list>
#include <vector>
#include <map>
#include <iterator>
#include <algorithm>
using namespace std;

#endif /* LIBRERIAS_H */

