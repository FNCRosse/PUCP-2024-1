/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.cc to edit this template
 */

/* 
 * File:   EstantePsicologo.cpp
 * Author: home
 * 
 * Created on 29 de mayo de 2024, 18:19
 */

#include "EstantePsicologo.hpp"

EstantePsicologo::EstantePsicologo(){
    codPsicologo=0;
}

void EstantePsicologo::SetCodPsicologo(int codPsicologo) {
    this->codPsicologo = codPsicologo;
}

int EstantePsicologo::GetCodPsicologo() const {
    return codPsicologo;
}

void EstantePsicologo::leer(ifstream&arch){
    Estante::leer(arch);//ahorro codigo xq generico;
    arch>>codPsicologo;
    arch.get();
}

bool EstantePsicologo::operator+=(LibroMotivacional & libroM){
    if(GetAltura()<libroM.GetAlto())return false;
    int cantColumsLibres=Estante::cantidadColumnasSobrantes();
    if(cantColumsLibres<libroM.GetAncho())return false;
    Estante::pintar(libroM.GetAncho(),libroM.GetAlto(),cantColumsLibres);
    return true;
}


void operator<<(ofstream &arch,EstantePsicologo &estPsi){
    estPsi.imp(arch);
}

void EstantePsicologo::imp(ofstream &arch){
    Estante::imp(arch);
    arch<<"CodPsi: "<<codPsicologo<<endl<<endl;
}