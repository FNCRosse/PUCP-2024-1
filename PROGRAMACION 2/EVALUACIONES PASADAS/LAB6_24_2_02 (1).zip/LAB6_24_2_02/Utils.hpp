/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Utils.hpp
 * Author: home
 *
 * Created on 29 de mayo de 2024, 18:23
 */

#ifndef UTILS_HPP
#define UTILS_HPP

#include <fstream>
#include <cstring>
#include <iomanip>
#include <cmath>
using namespace std;

#endif /* UTILS_HPP */

