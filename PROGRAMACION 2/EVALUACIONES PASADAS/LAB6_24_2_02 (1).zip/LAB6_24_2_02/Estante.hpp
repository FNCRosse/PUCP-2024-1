/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.h to edit this template
 */

/* 
 * File:   Estante.hpp
 * Author: home
 *
 * Created on 29 de mayo de 2024, 18:18
 */

#ifndef ESTANTE_HPP
#define ESTANTE_HPP
#include "Espacio.hpp"
#include "Utils.hpp"
class Estante{
private:
    char* codigo;
    int anchura;
    int altura;
    Espacio* espacios;
public:
    Estante();
    void SetAltura(int altura);
    int GetAltura() const;
    void SetAnchura(int anchura);
    int GetAnchura() const;
    void SetCodigo(const char* codigo);
    void GetCodigo(char*) const;
    void leer(ifstream &);
    int cantidadColumnasSobrantes();
    void pintar(int ,int ,int );
    void imp(ofstream &);
};

#endif /* ESTANTE_HPP */
