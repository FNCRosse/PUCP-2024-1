/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.h to edit this template
 */

/* 
 * File:   EstantePsicologo.hpp
 * Author: home
 *
 * Created on 29 de mayo de 2024, 18:19
 */

#ifndef ESTANTEPSICOLOGO_HPP
#define ESTANTEPSICOLOGO_HPP

#include "Estante.hpp"
#include "LibroMotivacional.hpp"

class EstantePsicologo:public Estante{
private:
    int codPsicologo;
public:
    EstantePsicologo();
    void SetCodPsicologo(int codPsicologo);
    int GetCodPsicologo() const;
    void leer(ifstream &);
    bool operator+=(LibroMotivacional &);
    int contarCantColumnasLibres();
    void imp(ofstream &);
};
void operator<<(ofstream &,EstantePsicologo &);
#endif /* ESTANTEPSICOLOGO_HPP */
