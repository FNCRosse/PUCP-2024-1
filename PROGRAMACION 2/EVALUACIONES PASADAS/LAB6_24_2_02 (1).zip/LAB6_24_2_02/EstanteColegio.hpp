/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.h to edit this template
 */

/* 
 * File:   EstanteColegio.hpp
 * Author: home
 *
 * Created on 29 de mayo de 2024, 18:19
 */

#ifndef ESTANTECOLEGIO_HPP
#define ESTANTECOLEGIO_HPP

#include "Estante.hpp"
#include "LibroEducativo.hpp"

class EstanteColegio:public Estante{
private:
    int codEmpresa;
public:
    EstanteColegio();
    void SetCodEmpresa(int codEmpresa);
    int GetCodEmpresa() const;
    void leer(ifstream &);
    bool operator+=(LibroEducativo &);
    int cantidadColumnasSobrantes();
    void pintar(LibroEducativo &,int );
    void imp(ofstream &);
};
void operator<<(ofstream &,EstanteColegio &);

#endif /* ESTANTECOLEGIO_HPP */
