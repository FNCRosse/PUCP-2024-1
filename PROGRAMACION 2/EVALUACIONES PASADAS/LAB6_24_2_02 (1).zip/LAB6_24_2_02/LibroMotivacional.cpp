/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.cc to edit this template
 */

/* 
 * File:   LibroMotivacional.cpp
 * Author: home
 * 
 * Created on 29 de mayo de 2024, 18:18
 */

#include "LibroMotivacional.hpp"

LibroMotivacional::LibroMotivacional(){
    calificacion=0;
}

void LibroMotivacional::SetCalificacion(int calificacion) {
    this->calificacion = calificacion;
}

int LibroMotivacional::GetCalificacion() const {
    return calificacion;
}

void LibroMotivacional::leer(ifstream&arch){
    Libro::leer(arch);//leí la parte generica ahorrando codigo
    arch>>calificacion;
    arch.get();
}

void LibroMotivacional::imp(ofstream &arch){
    Libro::imp(arch);
    arch<<"Calificacion: "<<calificacion<<endl;
}