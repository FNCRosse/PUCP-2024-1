/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.cc to edit this template
 */

/* 
 * File:   Estante.cpp
 * Author: home
 * 
 * Created on 29 de mayo de 2024, 18:18
 */

#include "Estante.hpp"

Estante::Estante(){
    altura=0;
    anchura=0;
    codigo=nullptr;
    espacios=nullptr;
}

void Estante::SetAltura(int altura) {
    this->altura = altura;
}

int Estante::GetAltura() const {
    return altura;
}

void Estante::SetAnchura(int anchura) {
    this->anchura = anchura;
}

int Estante::GetAnchura() const {
    return anchura;
}

void Estante::SetCodigo(const char* codigo) {
    if(this->codigo != nullptr)delete this->codigo;
    this->codigo=new char[strlen(codigo)+1]{};
    strcpy(this->codigo,codigo);
}

void Estante::GetCodigo(char*buffer) const {
    if(this->codigo==nullptr)buffer[0]='0';
    else strcpy(buffer,this->codigo);
}

void Estante::leer(ifstream&arch){
    char cod[20]{},c;
    arch.getline(cod,20,',');
    arch>>altura>>c>>anchura>>c;
    SetCodigo(cod);
    espacios=new Espacio[altura*anchura]{};
}

int Estante::cantidadColumnasSobrantes(){
    int arr_columnas[anchura]{};
    for(int i=altura-1;i>=0;i--){
        for(int j=0;j<anchura;j++){
            int pos=i*anchura+j;
            Espacio esp;
            esp=espacios[pos];
            if(esp.GetContenido()=='*'){
                arr_columnas[pos%anchura]=1;
            }
        }
    }
    int columnasLibres=0;
    for(int i=0;i<anchura;i++){
        if(arr_columnas[i]==0)columnasLibres++;
    }
    return columnasLibres;
}

void Estante::pintar(int anchoLib,int altoLib,int cantidadColumnasLibres){
    int columnaPintar=anchura-cantidadColumnasLibres;
    for(int i=1;i<=anchoLib;i++){
        int alturaPintado=0;
        for(int i=altura-1;i>=0;i--){
            for(int j=0;j<anchura;j++){
                int pos=i*anchura+j;

                if(pos%anchura==columnaPintar){
                    Espacio esp;
                    esp.SetContenido('*');
                    espacios[pos]=esp;
                    alturaPintado++;
                    if(alturaPintado==altoLib)break;
                }
            }
            if(alturaPintado==altoLib)break;
        }
        columnaPintar++;
    }
}

void Estante::imp(ofstream &arch){
    //aqui al imprimi es alrevés
    for(int i=0;i<altura;i++){
        for(int j=0;j<anchura;j++){
            int pos=i*anchura+j;
            Espacio esp;
            esp=espacios[pos];
            arch<<"["<<esp.GetContenido()<<"]";
        }
        arch<<endl;
    }
    arch<<endl<<endl;
}