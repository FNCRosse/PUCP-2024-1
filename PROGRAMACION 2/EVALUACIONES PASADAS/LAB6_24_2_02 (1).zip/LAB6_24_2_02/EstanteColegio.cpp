/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.cc to edit this template
 */

/* 
 * File:   EstanteColegio.cpp
 * Author: home
 * 
 * Created on 29 de mayo de 2024, 18:19
 */

#include "EstanteColegio.hpp"

EstanteColegio::EstanteColegio(){
    codEmpresa=0;
}

void EstanteColegio::SetCodEmpresa(int codEmpresa) {
    this->codEmpresa = codEmpresa;
}

int EstanteColegio::GetCodEmpresa() const {
    return codEmpresa;
}

void EstanteColegio::leer(ifstream&arch){
    Estante::leer(arch);//leo la parte generico
    //ahorro code
    arch>>codEmpresa;
    arch.get();
}

bool EstanteColegio::operator+=(LibroEducativo &libroE){
    if(libroE.GetAlto()>GetAltura())return false;
    int cantidadColumnasLibres=Estante::cantidadColumnasSobrantes();
    if(cantidadColumnasLibres<libroE.GetAncho())return false;
    Estante::pintar(libroE.GetAncho(),libroE.GetAlto(),cantidadColumnasLibres);
    return true;
}

void operator<<(ofstream &arch,EstanteColegio &estCol){
    estCol.imp(arch);
}

void EstanteColegio::imp(ofstream &arch){
    Estante::imp(arch);
    arch<<"CodEmp: "<<codEmpresa<<endl<<endl;
}