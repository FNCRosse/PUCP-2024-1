/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.cc to edit this template
 */

/* 
 * File:   Libro.cpp
 * Author: home
 * 
 * Created on 29 de mayo de 2024, 18:18
 */

#include "Libro.hpp"

Libro::Libro(){
    alto=0;
    ancho=0;
    codigo=nullptr;
    colocado=false;
    nombre=nullptr;
}

void Libro::SetColocado(bool colocado) {
    this->colocado = colocado;
}

bool Libro::IsColocado() const {
    return colocado;
}

void Libro::SetAlto(int alto) {
    this->alto = alto;
}

int Libro::GetAlto() const {
    return alto;
}

void Libro::SetAncho(int ancho) {
    this->ancho = ancho;
}

int Libro::GetAncho() const {
    return ancho;
}

void Libro::SetNombre(const char* nombre) {
    if(this->nombre != nullptr)delete this->nombre;
    this->nombre=new char[strlen(nombre)+1]{};
    strcpy(this->nombre,nombre);
}

void Libro::GetNombre(char*buffer) const {
    if(this->nombre==nullptr)buffer[0]='0';
    else strcpy(buffer,this->nombre);
}

void Libro::SetCodigo(const char* codigo) {
    if(this->codigo != nullptr)delete this->codigo;
    this->codigo=new char[strlen(codigo)+1]{};
    strcpy(this->codigo,codigo);
}

void Libro::GetCodigo(char*buffer) const {
    if(this->codigo==nullptr)buffer[0]='0';
    else strcpy(buffer,this->codigo);
}

void Libro::leer(ifstream&arch){
    char cod[20]{},nomb[100]{},c;
    arch.getline(cod,20,',');
    arch.getline(nomb,100,',');
    arch>>ancho>>c>>alto>>c;
    SetCodigo(cod);
    SetNombre(nomb);
}

void Libro::imp(ofstream &arch){
    char cod[20]{},nomb[100]{};
    GetCodigo(cod);
    GetNombre(nomb);
    arch<<left<<setw(10)<<cod<<setw(80)<<nomb<<setw(5)<<ancho<<setw(5)<<alto<<endl;
}