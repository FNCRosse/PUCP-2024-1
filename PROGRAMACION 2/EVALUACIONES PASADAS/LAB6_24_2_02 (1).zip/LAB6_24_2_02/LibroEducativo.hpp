/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.h to edit this template
 */

/* 
 * File:   LibroEducativo.hpp
 * Author: home
 *
 * Created on 29 de mayo de 2024, 18:18
 */

#ifndef LIBROEDUCATIVO_HPP
#define LIBROEDUCATIVO_HPP

#include "Libro.hpp"

class LibroEducativo:public Libro{
private:
    char* materia;
public:
    LibroEducativo();
    void SetMateria(const char* materia);
    void GetMateria(char*) const;
    void leer(ifstream &);
    void imp(ofstream &);
};

#endif /* LIBROEDUCATIVO_HPP */
