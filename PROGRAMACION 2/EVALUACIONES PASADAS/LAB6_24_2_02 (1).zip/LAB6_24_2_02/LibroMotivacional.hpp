/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.h to edit this template
 */

/* 
 * File:   LibroMotivacional.hpp
 * Author: home
 *
 * Created on 29 de mayo de 2024, 18:18
 */

#ifndef LIBROMOTIVACIONAL_HPP
#define LIBROMOTIVACIONAL_HPP

#include "Libro.hpp"


class LibroMotivacional:public Libro{
private:
    int calificacion;
public:
    LibroMotivacional();
    void SetCalificacion(int calificacion);
    int GetCalificacion() const;
    void leer(ifstream &);
    void imp(ofstream &);
};

#endif /* LIBROMOTIVACIONAL_HPP */
