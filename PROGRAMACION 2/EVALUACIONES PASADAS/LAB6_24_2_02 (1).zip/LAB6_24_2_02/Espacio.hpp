/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.h to edit this template
 */

/* 
 * File:   Espacio.hpp
 * Author: home
 *
 * Created on 29 de mayo de 2024, 18:18
 */

#ifndef ESPACIO_HPP
#define ESPACIO_HPP

class Espacio{
private:
    char contenido;
    int posx;
    int posy;
public:
    Espacio();
    void SetPosy(int posy);
    int GetPosy() const;
    void SetPosx(int posx);
    int GetPosx() const;
    void SetContenido(char contenido);
    char GetContenido() const;
};

#endif /* ESPACIO_HPP */
