/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.cc to edit this template
 */

/* 
 * File:   LibroEducativo.cpp
 * Author: home
 * 
 * Created on 29 de mayo de 2024, 18:18
 */

#include "LibroEducativo.hpp"

LibroEducativo::LibroEducativo(){
    materia=nullptr;
}

void LibroEducativo::SetMateria(const char* materia) {
    if(this->materia != nullptr)delete this->materia;
    this->materia=new char[strlen(materia)+1]{};
    strcpy(this->materia,materia);
}

void LibroEducativo::GetMateria(char*buffer) const {
    if(this->materia==nullptr)buffer[0]='0';
    else strcpy(buffer,this->materia);
}

void LibroEducativo::leer(ifstream&arch){
    Libro::leer(arch);//leo la parte generica d elibro
    //ahorro codigo
    char mater[20]{};
    arch.getline(mater,20,'\n');
    SetMateria(mater);
}

void LibroEducativo::imp(ofstream &arch){
    Libro::imp(arch);
    //ahora imprime la parte de esta clase
    char mater[20]{};
    GetMateria(mater);
    arch<<mater<<endl;
    
}