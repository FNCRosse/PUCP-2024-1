/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: home
 *
 * Created on 29 de mayo de 2024, 18:17
 */

#include "Biblioteca.hpp"
#include "Utils.hpp"

/*
 * 
 */
int main(int argc, char** argv) {

    Biblioteca b1;
    b1.cargar_libros();
    b1.cargar_estantes();
    b1.ubicar_Libros();
    b1.mostrar();
    return 0;
}

