/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.cc to edit this template
 */

/* 
 * File:   Biblioteca.cpp
 * Author: home
 * 
 * Created on 29 de mayo de 2024, 18:19
 */

#include "Biblioteca.hpp"

Biblioteca::Biblioteca(){
    cantidad_estantes_cole=0;
    cantidad_estantes_psico=0;
    cantidad_libros_edu=0;
    cantidad_libros_mot=0;
}

void Biblioteca::SetCantidad_libros_mot(int cantidad_libros_mot) {
    this->cantidad_libros_mot = cantidad_libros_mot;
}

int Biblioteca::GetCantidad_libros_mot() const {
    return cantidad_libros_mot;
}

void Biblioteca::SetCantidad_libros_edu(int cantidad_libros_edu) {
    this->cantidad_libros_edu = cantidad_libros_edu;
}

int Biblioteca::GetCantidad_libros_edu() const {
    return cantidad_libros_edu;
}

void Biblioteca::SetCantidad_estantes_psico(int cantidad_estantes_psico) {
    this->cantidad_estantes_psico = cantidad_estantes_psico;
}

int Biblioteca::GetCantidad_estantes_psico() const {
    return cantidad_estantes_psico;
}

void Biblioteca::SetCantidad_estantes_cole(int cantidad_estantes_cole) {
    this->cantidad_estantes_cole = cantidad_estantes_cole;
}

int Biblioteca::GetCantidad_estantes_cole() const {
    return cantidad_estantes_cole;
}

void Biblioteca::cargar_libros(){
    ifstream arch("libros.csv",ios::in);
    char tipo[20]{};
    while(1){
        char tipo[20]{};
        arch.getline(tipo,20,',');
        if(arch.eof())break;
        if(strcmp(tipo,"educativo")==0){
            LibroEducativo eduL;
            eduL.leer(arch);
            librosEdu[cantidad_libros_edu]=eduL;
            cantidad_libros_edu++;
        }else if(strcmp(tipo,"motivacional")==0){
            LibroMotivacional eduM;
            eduM.leer(arch);
            librosMot[cantidad_libros_mot]=eduM;
            cantidad_libros_mot++;
        }
    }
    
}

void Biblioteca::cargar_estantes(){
    ifstream arch("estantes.csv",ios::in);
    while(1){
        char tipo[20]{};
        arch.getline(tipo,20,',');
        if(arch.eof())break;
        if(strcmp(tipo,"empresa")==0){
            EstanteColegio esCol;
            esCol.leer(arch);
            estantesCole[cantidad_estantes_cole]=esCol;
            cantidad_estantes_cole++;
        }else if(strcmp(tipo,"psicologo")==0){
            EstantePsicologo esPsi;
            esPsi.leer(arch);
            estantesPsico[cantidad_estantes_psico]=esPsi;
            cantidad_estantes_psico++;
        }
    }
}

void Biblioteca::ubicar_Libros(){
    for(int i=0;i<cantidad_estantes_cole;i++){
        EstanteColegio estCol;
        estCol=estantesCole[i];
        for(int j=0;j<cantidad_libros_edu;j++){
            
            LibroEducativo libEd;
            libEd=librosEdu[j];
            if(estCol+=libEd)estantesCole[i]=estCol;
        }
        
        
    }
    //incorrecto en variables campos
    for(int i=0;i<cantidad_estantes_psico;i++){
        EstantePsicologo estPsi;
        estPsi=estantesPsico[i];
        for(int j=0;j<cantidad_libros_mot;j++){
            
            LibroMotivacional libMot;
            libMot=librosMot[j];
            if(estPsi+=libMot)estantesPsico[i]=estPsi;
        }
        
        
    }
}

void Biblioteca::mostrar(){
    ofstream arch("reporte.txt",ios::out);
    for(int i=0;i<cantidad_estantes_cole;i++){
        EstanteColegio estCol;
        estCol=estantesCole[i];
        arch<<estCol;
        for(int j=0;j<cantidad_libros_edu;j++){
            
            LibroEducativo libEd;
            libEd=librosEdu[j];
            libEd.imp(arch);
        }
        
        
    }
    arch<<endl<<endl;
    //Incorrecto: me equivoqué aquí en las variables
    for(int i=0;i<cantidad_estantes_psico;i++){
        EstantePsicologo estPsi;
        estPsi=estantesPsico[i];
        arch<<estPsi;
        for(int j=0;j<cantidad_libros_mot;j++){
            
            LibroMotivacional libMot;
            libMot=librosMot[j];
            libMot.imp(arch);
        }
        
        
    }
}