/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.h to edit this template
 */

/* 
 * File:   Biblioteca.hpp
 * Author: home
 *
 * Created on 29 de mayo de 2024, 18:19
 */

#ifndef BIBLIOTECA_HPP
#define BIBLIOTECA_HPP
#include "EstanteColegio.hpp"
#include "EstantePsicologo.hpp"
#include "LibroEducativo.hpp"
#include "LibroMotivacional.hpp"
class Biblioteca{
private:
    EstanteColegio estantesCole[300]{};
    int cantidad_estantes_cole;
    EstantePsicologo estantesPsico[300]{};
    int cantidad_estantes_psico;
    LibroEducativo librosEdu[300]{};
    int cantidad_libros_edu;
    LibroMotivacional librosMot[300]{};
    int cantidad_libros_mot;
public:
    Biblioteca();
    void SetCantidad_libros_mot(int cantidad_libros_mot);
    int GetCantidad_libros_mot() const;
    void SetCantidad_libros_edu(int cantidad_libros_edu);
    int GetCantidad_libros_edu() const;
    void SetCantidad_estantes_psico(int cantidad_estantes_psico);
    int GetCantidad_estantes_psico() const;
    void SetCantidad_estantes_cole(int cantidad_estantes_cole);
    int GetCantidad_estantes_cole() const;
    void cargar_libros();
    void cargar_estantes();
    void ubicar_Libros();
    void mostrar();
};

#endif /* BIBLIOTECA_HPP */
