/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   bibliotecas.h
 * Author: Usuario
 *
 * Created on 11 de junio de 2024, 09:26 PM
 */

#ifndef BIBLIOTECAS_H
#define BIBLIOTECAS_H

#include <fstream>
#include <iostream>
#include <cstring>
#include <iomanip>

using namespace std;

#endif /* BIBLIOTECAS_H */

