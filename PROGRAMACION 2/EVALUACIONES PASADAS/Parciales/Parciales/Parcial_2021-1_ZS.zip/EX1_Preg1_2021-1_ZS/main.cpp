

/* 
 * File:   main.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 11 de mayo de 2023, 11:06 PM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#include "funciones.h"
/*
 * 
 */
int main(int argc, char** argv) {
    
    ifstream archPlatosPreparar("PlatosAPreparar.txt",ios::in);
    if(not archPlatosPreparar.is_open()){
        cout<<"ERROR al abrir el archivo de PlatosAPreparar"<<endl;
        exit(1);
    }
    ifstream archPlatos("Platos.txt",ios::in);
    if(not archPlatos.is_open()){
        cout<<"ERROR al abrir el archivo de Platos"<<endl;
        exit(1);
    }
    ifstream archListaProductos("ListaDePrecios.txt",ios::in);
    if(not archListaProductos.is_open()){
        cout<<"ERROR al abrir el archivo de ListaDePrecios"<<endl;
        exit(1);
    }
    ofstream archReporte("ReporteCostoPlatos.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR al abrir el archivo de ReporteCostoPlatos"<<endl;
        exit(1);
    }
    
    emiteReporte(archPlatosPreparar,archPlatos,archListaProductos,archReporte);
    
    
    return 0;
}

