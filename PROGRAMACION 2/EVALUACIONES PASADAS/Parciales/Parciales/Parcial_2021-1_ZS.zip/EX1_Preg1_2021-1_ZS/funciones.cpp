

/* 
 * File:   funciones.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 12 de mayo de 2023, 10:17 AM
 */


#include <iostream>
#include <fstream>
#include <iomanip>


using namespace std;

#define MAX_NOMBRE 30
#define MAX_LINE 150
#include "funciones.h"

void emiteReporte(ifstream &archPlatosPreparar,ifstream &archPlatos,
        ifstream &archListaProductos,ofstream &archReporte){
    
    int codigo_plato,cantidad_elaborar,ingredienteNoEncontrado=0,
            contador_platos=0;
    double costoPlato,costoTotal,costoAbsoluto=0;
    imprimeEncabezado(archReporte);
    archReporte<<setprecision(2);
    archReporte<<fixed;
    while(true){
        leeObtieneDatosPlato(codigo_plato,cantidad_elaborar,
                archPlatosPreparar,archReporte);
        if(archPlatosPreparar.eof())break;
        ingredienteNoEncontrado=verificarIngredientes(
                codigo_plato,archPlatos,archListaProductos);
        contador_platos++;
        if(!ingredienteNoEncontrado){/*Si no hay ingredientes faltantes*/
            archReporte<<setw(5)<<contador_platos<<".- ";
            buscaImprimePlato(codigo_plato,archPlatos,archReporte);
            archReporte<<setw(10)<<' '<<setw(4)<<cantidad_elaborar;
            costoPlato=calcularCostoPlato(codigo_plato,archPlatos,archListaProductos);
            archReporte<<setw(20)<<' '<<setw(8)<<costoPlato<<setw(10)<<' ';
            costoTotal=costoPlato*cantidad_elaborar;
            archReporte<<setw(15)<<costoTotal<<endl;
            costoAbsoluto+=costoTotal;
        }else if(ingredienteNoEncontrado){/*Si falta un ingrediente*/
            archReporte<<setw(5)<<contador_platos<<".- ";
            buscaImprimePlato(codigo_plato,archPlatos,archReporte);
            archReporte<<"No se pudo calcular por falta del producto: "
                    <<ingredienteNoEncontrado<<endl;
        }
    }
    imprimeLinea('-',MAX_LINE,archReporte);
    archReporte<<setw(6)<<' '<<"Costo Total: "<<setw(12)<<costoAbsoluto<<endl;
    imprimeLinea('=',MAX_LINE,archReporte);
}

double calcularCostoPlato(int codigo_plato,ifstream &archPlatos,
        ifstream &archListaProductos){
    
    archPlatos.clear();
    archPlatos.seekg(0,ios::beg);
    
    int plato_leido,ingrediente;
    double cant_ingrediente,costo_plato=0,precio_ingrediente;
    while(true){
        archPlatos>>plato_leido;
        if(archPlatos.eof())break;
        while(archPlatos.get()!=')');
        archPlatos.get();
        if(plato_leido==codigo_plato){
            while(true){
                archPlatos>>ingrediente>>cant_ingrediente;
                precio_ingrediente=buscarPrecioIngrediente(ingrediente,
                        archListaProductos);
                costo_plato+=precio_ingrediente*cant_ingrediente;
                if(archPlatos.get()=='\n')break;
            }
        }else while(archPlatos.get()!='\n');
    }
    return costo_plato;
}

double buscarPrecioIngrediente(int ingrediente,ifstream &archListaProductos){
    archListaProductos.clear();
    archListaProductos.seekg(0,ios::beg);
    
    int ingredienteLeido;
    double precio_ingrediente;
    while(archListaProductos.get()!='\n');
    
    while(true){
        archListaProductos>>ingredienteLeido;
        if(archListaProductos.eof())break;
        if(ingredienteLeido==ingrediente){
            while(archListaProductos.get()!=']');
            archListaProductos.get();
            archListaProductos>>precio_ingrediente;
            return precio_ingrediente;
        }else while(archListaProductos.get()!='\n');
    }
}

void buscaImprimePlato(int codigo_plato,ifstream &archPlatos,
        ofstream &archReporte){
    
    archPlatos.clear();
    archPlatos.seekg(0,ios::beg);
    
    int codPlato_evaluar;
    while(true){
        archPlatos>>codPlato_evaluar;
        if(archPlatos.eof())break;
        if(codPlato_evaluar==codigo_plato){
            imprimeNombrePlato(archPlatos,archReporte);
        }else while(archPlatos.get()!='\n');
    }
}

void imprimeNombrePlato(ifstream &archPlatos,ofstream &archReporte){
    char plato;
    int numCar=0;
    while(archPlatos.get()!='o');
    archPlatos.get();
    while(true){
        plato=archPlatos.get();
        if(plato==')')break;
        archReporte.put(plato);
        numCar++;
    }
    
    for(int i=0;i<MAX_NOMBRE-numCar;i++)archReporte.put(' ');
}

int verificarIngredientes(int codigo_plato,ifstream &archPlatos,
        ifstream &archListaProductos){
    
    archPlatos.clear();
    archPlatos.seekg(0,ios::beg);
    
    int codigoPlato_evaluar,codigo_ingrediente;
    int ingredienteEncontrado;
    double cantidad_requerida;
    while(true){
        archPlatos>>codigoPlato_evaluar;
        if(archPlatos.eof())break;
        while(archPlatos.get()!=')');
        archPlatos.get();
        if(codigoPlato_evaluar==codigo_plato){
            while(true){
                archPlatos>>codigo_ingrediente>>cantidad_requerida;
                ingredienteEncontrado=buscaIngredienteFaltante(codigo_ingrediente,
                        archListaProductos);
                if(!ingredienteEncontrado)return codigo_ingrediente;
                if(archPlatos.get()=='\n')break;
            }
        }else while(archPlatos.get()!='\n');
    }
    return 0;
}

int buscaIngredienteFaltante(int codigo_ingrediente, ifstream &archListaProductos){
    
    archListaProductos.clear();
    archListaProductos.seekg(0,ios::beg);
    
    while(archListaProductos.get()!='\n');
    
    int codIngred_evaluar,existeIngrediente;
    
    while(true){
        archListaProductos>>codIngred_evaluar;
        if(archListaProductos.eof())break;
        if(codIngred_evaluar==codigo_ingrediente){
            return existeIngrediente=1;
        }else while(archListaProductos.get()!='\n');
    }
    
    return existeIngrediente=0;
}

void leeObtieneDatosPlato(int &codigo_plato,int &cantidad_elaborar,
        ifstream &archPlatosPreparar,ofstream &archReporte){
    
    archPlatosPreparar>>codigo_plato;
    if(archPlatosPreparar.eof())return;
    archPlatosPreparar>>cantidad_elaborar;
    
}

void imprimeEncabezado(ofstream &archReporte){
    archReporte<<"COSTOS DE LOS PLATOS OFRECIDOS"<<endl;
    imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<"Proveedor: Bodega 2000 S.A."<<endl;
    imprimeLinea('-',MAX_LINE,archReporte);
    archReporte<<setw(10)<<' '<<"Plato"<<setw(25)<<' '<<"Cantidad a elaborar"
            <<setw(10)<<' '<<"Costo por plato"<<setw(10)<<' '
            <<"Costo total"<<endl;
}

void imprimeLinea(char caracter, int cantidad, ofstream &archRep){
    for(int i=0;i<cantidad;i++)archRep.put(caracter);
    archRep.put('\n');
}

