

/* 
 * File:   funciones.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 12 de mayo de 2023, 10:18 AM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void emiteReporte(ifstream &archPlatosPreparar,ifstream &archPlatos,
        ifstream &archListaProductos,ofstream &archReporte);
double calcularCostoPlato(int codigo_plato,ifstream &archPlatos,
        ifstream &archListaProductos);
double buscarPrecioIngrediente(int ingrediente,ifstream &archListaProductos);
void buscaImprimePlato(int codigo_plato,ifstream &archPlatos,
        ofstream &archReporte);
void imprimeNombrePlato(ifstream &archPlatos,ofstream &archReporte);
int verificarIngredientes(int codigo_plato,ifstream &archPlatos,
        ifstream &archListaProductos);
int buscaIngredienteFaltante(int codigo_ingrediente, ifstream &archListaProductos);
void leeObtieneDatosPlato(int &codigo_plato,int &cantidad_elaborar,
        ifstream &archPlatosPreparar,ofstream &archReporte);
void imprimeEncabezado(ofstream &archReporte);
void imprimeLinea(char caracter, int cantidad, ofstream &archRep);

#endif /* FUNCIONES_H */

