

/* 
 * File:   funciones.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 12 de mayo de 2023, 09:35 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void leerProductos(int *arrProductos,double *arrPrecioProductos,
        int &numProductos);
void leerProductosAlmacenados(int *arrProdAlmacen,double *arrCantProdAlmacen,
        double *arrPrecioProdAlmacen,double *arrSubTotalProdAlmacen,
        int &numProdAlmacen,int *arrProductos,double *arrPrecioProductos,
        int numProductos);
void ordenarProductos(int *arrProdAlmacen,double *arrCantProdAlmacen,
        double *arrPrecioProdAlmacen,double *arrSubTotalProdAlmacen,
        int numProdAlmacen);
void interCambiarInt(int* arreglo, int i, int j);
void interCambiarDouble(double* arreglo, int i, int j);
void leerPlatosPreparar(int *arrPlatosPreparar,int *arrCantidadPreparar,
        int &numPlatosPreparar);
void leerPlatos(int *arrPlatoNoPreparar,int *arrCantNoPreparar,
        double *arrPrecioPlatoNoPreparado,double *arrSubTotalPlatoNoPreprar,
        int *arrPlatosPreparar,
        int *arrCantidadPreparar,int numPlatosPreparar,
        int *arrProdAlmacen,double *arrPrecioProdAlmacen,int numProdAlmacen);
void ordenarPlatos(int *arrPlatosPreparar,int *arrNoEsPlatoPreparable,
        int *arrCantidadPreparar,double *arrPrecioPlatoNoPreparado,
        double *arrSubTotalPlatoNoPreprar,int numPlatosPreparar);
void emiteReporte(int *arrProdAlmacen,double *arrCantProdAlmacen,
        double *arrPrecioProdAlmacen,double *arrSubTotalProdAlmacen,
        int numProdAlmacen,int *arrProductos,double *arrPrecioProductos,
        int numProductos,int *arrPlatoNoPreparar,int *arrCantNoPreparar,
        double *arrPrecioPlatoNoPreparado,double *arrSubTotalPlatoNoPreprar,
        int *arrPlatosPreparar,int *arrCantidadPreparar,int numPlatosPreparar);
void imprimeEncabezado(ofstream &archReporte);
int buscarPosicion(int* arreglo, int elemento, int numDatos);
void imprimeLinea(char caracter, int cantidad, ofstream& archRep);

#endif /* FUNCIONES_H */

