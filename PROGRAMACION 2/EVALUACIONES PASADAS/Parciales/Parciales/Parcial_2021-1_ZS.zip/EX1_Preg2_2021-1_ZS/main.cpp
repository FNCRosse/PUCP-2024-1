

/* 
 * File:   main.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 11 de mayo de 2023, 11:06 PM
 */

#include <iostream>
#include <fstream>
#include <iomanip>


using namespace std;

#define MAX_PLATOS 100
#define MAX_PRODUCTOS 300

#include "funciones.h"
/*
 * 
 */
int main(int argc, char** argv) {
    
    int arrProdAlmacen[MAX_PRODUCTOS],numProdAlmacen;
    double arrCantProdAlmacen[MAX_PRODUCTOS],arrPrecioProdAlmacen[MAX_PRODUCTOS],
            arrSubTotalProdAlmacen[MAX_PRODUCTOS];
    
    int arrProductos[MAX_PRODUCTOS],numProductos;
    double arrPrecioProductos[MAX_PRODUCTOS];
    
    int arrNoEsPlatoPreparable[MAX_PLATOS]{},arrCantNoPreparar[MAX_PLATOS];
    double arrPrecioPlatoNoPreparado[MAX_PLATOS]{},
            arrSubTotalPlatoNoPreprar[MAX_PLATOS];
    
    int arrPlatosPreparar[MAX_PLATOS],arrCantidadPreparar[MAX_PLATOS],
            numPlatosPreparar;
    
    leerProductos(arrProductos,arrPrecioProductos,numProductos);
    leerProductosAlmacenados(arrProdAlmacen,arrCantProdAlmacen,
            arrPrecioProdAlmacen,arrSubTotalProdAlmacen,numProdAlmacen,
            arrProductos,arrPrecioProductos,numProductos);
    ordenarProductos(arrProdAlmacen,arrCantProdAlmacen,arrPrecioProdAlmacen,
            arrSubTotalProdAlmacen,numProdAlmacen);
    
    leerPlatosPreparar(arrPlatosPreparar,arrCantidadPreparar,numPlatosPreparar);
    
    leerPlatos(arrNoEsPlatoPreparable,arrCantNoPreparar,arrPrecioPlatoNoPreparado,
            arrSubTotalPlatoNoPreprar,arrPlatosPreparar,
            arrCantidadPreparar,numPlatosPreparar,arrProdAlmacen,
            arrPrecioProdAlmacen,numProdAlmacen);
    
    ordenarPlatos(arrPlatosPreparar,arrNoEsPlatoPreparable,arrCantidadPreparar,
            arrPrecioPlatoNoPreparado,arrSubTotalPlatoNoPreprar,numPlatosPreparar);
    
    emiteReporte(arrProdAlmacen,arrCantProdAlmacen,
            arrPrecioProdAlmacen,arrSubTotalProdAlmacen,numProdAlmacen,
            arrProductos,arrPrecioProductos,numProductos,arrNoEsPlatoPreparable,
            arrCantNoPreparar,arrPrecioPlatoNoPreparado,
            arrSubTotalPlatoNoPreprar,arrPlatosPreparar,
            arrCantidadPreparar,numPlatosPreparar);
    
    /*
     Dos análisis para el segundo reporte de platos que no se podran entregar
     
     - Hallar los productos descompuestos, multiplicarlos por las cantidades
     * respectivas y luego multiplicarlos por la cantidad de veces/pedidos
     * que se hace un plato como se ve en el archivo de platosApreparar
     * 
     - El dato de cantidad almacenada en el archivo de productosAlmacenados.txt
     * no sirve para el dicho reporte, solamente el codigo de los productos 
     * que está en este archivo, de modo que si se requiere hacer un 
     * plato que tenga un ingrediente almacenado (o descompuesto) no se 
     * puede hacer ningún plato
     
     */
    return 0;
}

