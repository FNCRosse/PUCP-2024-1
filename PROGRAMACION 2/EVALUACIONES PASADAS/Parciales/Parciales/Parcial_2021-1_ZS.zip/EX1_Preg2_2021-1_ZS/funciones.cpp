

/* 
 * File:   funciones.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 12 de mayo de 2023, 09:34 PM
 */


#include <iostream>
#include <fstream>
#include <iomanip>
#include <set>



using namespace std;


#define MAX_LINE 150
#define NO_ENCONTRADO -1
#include "funciones.h"


void leerProductos(int *arrProductos,double *arrPrecioProductos,
        int &numProductos){
    
    ifstream archProductos("ListaDePrecios.txt",ios::in);
    if(not archProductos.is_open()){
        cout<<"ERROR al abrir el archivo de ListaDePrecios"<<endl;
        exit(1);
    }
    
    int cod_producto;
    double precio_producto;
    numProductos=0;
    
    while(archProductos.get()!='\n');
    
    while(true){
        archProductos>>cod_producto;
        if(archProductos.eof())break;
        while(archProductos.get()!=']');
        archProductos.get();
        
        archProductos>>precio_producto;
        
        arrProductos[numProductos]=cod_producto;
        arrPrecioProductos[numProductos]=precio_producto;
        
        numProductos++;
    }
}

void leerProductosAlmacenados(int *arrProdAlmacen,double *arrCantProdAlmacen,
        double *arrPrecioProdAlmacen,double *arrSubTotalProdAlmacen,
        int &numProdAlmacen,int *arrProductos,double *arrPrecioProductos,
        int numProductos){
    
    ifstream archProdAlmacenados("productosAlmacenados.txt",ios::in);
    if(not archProdAlmacenados.is_open()){
        cout<<"ERROR al abrir el archivo de productosAlmacenados"<<endl;
        exit(1);
    }
    
    int codigo_almacenado,posProducto;
    double cantidad_almacenada;
    numProdAlmacen=0;
    while(true){
        archProdAlmacenados>>codigo_almacenado;
        if(archProdAlmacenados.eof())break;
        archProdAlmacenados>>cantidad_almacenada;
        
        posProducto=buscarPosicion(arrProductos,codigo_almacenado,numProductos);
        if(posProducto!=NO_ENCONTRADO){
            arrProdAlmacen[numProdAlmacen]=codigo_almacenado;
            arrCantProdAlmacen[numProdAlmacen]=cantidad_almacenada;
            arrPrecioProdAlmacen[numProdAlmacen]=arrPrecioProductos[posProducto];
            arrSubTotalProdAlmacen[numProdAlmacen]=
                    arrPrecioProductos[posProducto]*cantidad_almacenada;
            numProdAlmacen++;
        }
    }
}

void ordenarProductos(int *arrProdAlmacen,double *arrCantProdAlmacen,
        double *arrPrecioProdAlmacen,double *arrSubTotalProdAlmacen,
        int numProdAlmacen){
    
    for(int i=0;i<numProdAlmacen-1;i++)
        for(int k=i+1;k<numProdAlmacen;k++)
            if(arrSubTotalProdAlmacen[i]<arrSubTotalProdAlmacen[k]){
                interCambiarInt(arrProdAlmacen,i,k);
                interCambiarDouble(arrCantProdAlmacen,i,k);
                interCambiarDouble(arrPrecioProdAlmacen,i,k);
                interCambiarDouble(arrSubTotalProdAlmacen,i,k);
            }
}


void leerPlatosPreparar(int *arrPlatosPreparar,int *arrCantidadPreparar,
        int &numPlatosPreparar){
    
    
    ifstream archPlatosPreparar("PlatosAPreparar.txt",ios::in);
    if(not archPlatosPreparar.is_open()){
        cout<<"ERROR al abrir el archivo de PlatosAPreparar"<<endl;
        exit(1);
    }
    
    int codPlato_preparar,cantidad_preparar;
    numPlatosPreparar=0;
    while(true){
        archPlatosPreparar>>codPlato_preparar;
        if(archPlatosPreparar.eof())break;
        archPlatosPreparar>>cantidad_preparar;
        
        arrPlatosPreparar[numPlatosPreparar]=codPlato_preparar;
        arrCantidadPreparar[numPlatosPreparar]=cantidad_preparar;
        
        numPlatosPreparar++;
    }
}

void leerPlatos(int *arrNoEsPlatoPreparable,int *arrCantNoPreparar,
        double *arrPrecioPlatoNoPreparado,double *arrSubTotalPlatoNoPreprar,
        int *arrPlatosPreparar,
        int *arrCantidadPreparar,int numPlatosPreparar,
        int *arrProdAlmacen,double *arrPrecioProdAlmacen,int numProdAlmacen){

    ifstream archPlatos("Platos.txt",ios::in);
    if(not archPlatos.is_open()){
        cout<<"ERROR al abrir el archivo de Platos"<<endl;
        exit(1);
    }
    
    int cod_plato,cod_producto,posPlato,posProducto;
    double cantProd_requerida;
    while(true){
        archPlatos>>cod_plato;
        if(archPlatos.eof())break;
        while(archPlatos.get()!=')');
        archPlatos.get();
        posPlato=buscarPosicion(arrPlatosPreparar,cod_plato,numPlatosPreparar);
        if(posPlato!=NO_ENCONTRADO){
            while(true){
                archPlatos>>cod_producto;
                archPlatos>>cantProd_requerida;
                posProducto=buscarPosicion(arrProdAlmacen,cod_producto,
                        numProdAlmacen);
                if(posProducto!=NO_ENCONTRADO){/*Si se encuentra en los 
                                                productos descompuestos*/
                    arrNoEsPlatoPreparable[posPlato]=1;/*Arreglo que
                                                        guarda valores de 1 o 0
                                                        representando se puede
                                                        preparar o no*/             
                    arrPrecioPlatoNoPreparado[posPlato]+=
                            arrPrecioProdAlmacen[posProducto]*cantProd_requerida;
                    arrSubTotalPlatoNoPreprar[posPlato]=
                            arrCantidadPreparar[posPlato]*
                            arrPrecioPlatoNoPreparado[posPlato];
                }
                if(archPlatos.get()=='\n')break;
            }
        }else while(archPlatos.get()!='\n');
    }   
}

void ordenarPlatos(int *arrPlatosPreparar,int *arrNoEsPlatoPreparable,
        int *arrCantidadPreparar,double *arrPrecioPlatoNoPreparado,
        double *arrSubTotalPlatoNoPreprar,int numPlatosPreparar){
    
    for(int i=0;i<numPlatosPreparar-1;i++)
        for(int k=i+1;k<numPlatosPreparar;k++)
            if(arrCantidadPreparar[i]>arrCantidadPreparar[k] or 
                    arrCantidadPreparar[i]==arrCantidadPreparar[k] and
                    arrSubTotalPlatoNoPreprar[i]<arrSubTotalPlatoNoPreprar[k]){
                interCambiarInt(arrPlatosPreparar,i,k);
                interCambiarInt(arrNoEsPlatoPreparable,i,k);
                interCambiarInt(arrCantidadPreparar,i,k);
                interCambiarDouble(arrPrecioPlatoNoPreparado,i,k);
                interCambiarDouble(arrSubTotalPlatoNoPreprar,i,k);
            }
}

void emiteReporte(int *arrProdAlmacen,double *arrCantProdAlmacen,
        double *arrPrecioProdAlmacen,double *arrSubTotalProdAlmacen,
        int numProdAlmacen,int *arrProductos,double *arrPrecioProductos,
        int numProductos,int *arrNoEsPlatoPreparable,int *arrCantNoPreparar,
        double *arrPrecioPlatoNoPreparado,double *arrSubTotalPlatoNoPreprar,
        int *arrPlatosPreparar,int *arrCantidadPreparar,int numPlatosPreparar){
    
    ofstream archReporte("ReportedePerdidas.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR al abrir el archivo de ReportedePerdidas"<<endl;
        exit(1);
    }
    imprimeEncabezado(archReporte);
    archReporte<<setprecision(2);
    archReporte<<fixed;
    int posProd,contador_productos=0,contador_platosNo=0;;
    double cosTotal=0,costoPedidosTotal=0;
    for(int i=0;i<numProdAlmacen;i++){
        posProd=buscarPosicion(arrProductos,arrProdAlmacen[i],numProductos);
        if(posProd!=NO_ENCONTRADO){
            contador_productos++;
            archReporte<<setw(4)<<contador_productos<<')'<<setw(7)
                    <<arrProdAlmacen[i]<<setw(10)<<' '<<setw(6)
                    <<arrCantProdAlmacen[i]<<setw(10)<<' '
                    <<setw(6)<<arrPrecioProdAlmacen[i]<<setw(22)<<' '
                    <<setw(8)<<arrSubTotalProdAlmacen[i]<<endl;
            cosTotal+=arrSubTotalProdAlmacen[i];
        }
    }
    imprimeLinea('-',MAX_LINE,archReporte);
    archReporte<<"Costo total de productos perdidos: S/."<<setw(12)<<
            cosTotal<<endl;
    imprimeLinea('=',MAX_LINE,archReporte);
    imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<"PLATOS QUE NO SE PODRAN PREPARAR"<<endl;
    imprimeLinea('-',MAX_LINE,archReporte);
    archReporte<<setw(3)<<' '<<"Pedido"<<setw(10)<<' '<<"Cantidad"<<setw(10)<<' '
            <<"Precio Productos(S/.)"<<setw(10)<<' '<<"Sub-total(S/.)"<<endl;
    for(int i=0;i<numPlatosPreparar;i++){
        if(arrNoEsPlatoPreparable[i]==1){
            contador_platosNo++;
            archReporte<<setw(4)<<contador_platosNo<<')'
                    <<arrPlatosPreparar[i]<<setw(10)<<' '
                    <<setw(4)<<arrCantidadPreparar[i]
                    <<setw(20)<<' '<<setw(8)<<arrPrecioPlatoNoPreparado[i]
                    <<setw(16)<<' '<<setw(10)<<arrSubTotalPlatoNoPreprar[i]<<endl;
            costoPedidosTotal+=arrSubTotalPlatoNoPreprar[i];
        }
    }
    imprimeLinea('-',MAX_LINE,archReporte);
    archReporte<<"Monto total de pedidos sin preparar: S/."
            <<setw(12)<<costoPedidosTotal<<endl;
}

void imprimeEncabezado(ofstream &archReporte){
    
    imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<"PRODUCTOS PERDIDOS"<<endl;
    imprimeLinea('-',MAX_LINE,archReporte);
    archReporte<<"Producto"<<setw(13)<<' '<<"Cantidad"<<setw(5)
            <<' '<<"Precio Unitario(S/.)"<<setw(10)<<' '
            <<"Sub-total(S/.)"<<endl;
    
}

void interCambiarInt(int *arreglo,int i,int j){
    int aux = arreglo[i];
    
    arreglo[i]=arreglo[j];
    arreglo[j]=aux;
}

void interCambiarDouble(double *arreglo,int i,int j){
    
    double aux = arreglo[i];
    
    arreglo[i]=arreglo[j];
    arreglo[j]=aux;
}

int buscarPosicion(int *arreglo,int elemento, int numDatos){
    
    for(int i=0;i<numDatos;i++)
        if(arreglo[i]==elemento)return i;
    
    return NO_ENCONTRADO;
}

void imprimeLinea(char caracter, int cantidad, ofstream &archRep){
    
    for(int i=0;i<cantidad;i++)archRep.put(caracter);
    archRep.put('\n');
}