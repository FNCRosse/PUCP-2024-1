/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: margo
 *
 * Created on 28 de mayo de 2024, 16:35
 */

#include <cstdlib>
#include <fstream>
#include <iostream>

using namespace std;
#include "Biblioteca.h"
#include "Libro.h"
#include "Estante.h"
/*
 * 
 */
int main(int argc, char** argv) {

    Libro lib[10]{};
    ifstream LibLec("libros.csv", ios::in);
    if (not LibLec.is_open()){
        cout<<"error con la aperura del archivo: "<<"libros.csv"<<endl;
        exit(1);
    }
    ofstream LibImp("impresion.txt", ios::out);
    if (not LibImp.is_open()){
        cout<<"error con la aperura del archivo: "<<"impresion.csv"<<endl;
        exit(1);
    }
    Estante est[10]{};
    ifstream LibEst("estantes.csv", ios::in);
    if (not LibEst.is_open()){
        cout<<"error con la aperura del archivo: "<<"libros.csv"<<endl;
        exit(1);
    }
    int i=0;
    while(true){
        LibLec>>lib[i];
        if (LibLec.eof()) break;
        i++;
    }
    int k=0;
//    while(lib[k].GetAncho()){
//        LibImp<<lib[k];
//        k++ ;
//    }
    int y=0;
    while(true){
        LibEst>>est[y];
        if (LibEst.eof()) break;
        y++;
    }
    est[0]+=lib[0];
    est[0]+=lib[1];
    est[0]+=lib[2];
    est[0]+=lib[3];
    est[0]+=lib[4];
    est[0]+=lib[5];
    LibImp<<est[0];
//    int t=0;
//    while(lib[t].GetAncho()){
//        LibImp<<lib[t];
//        t++ ;
//    }
//    
    return 0;
}

