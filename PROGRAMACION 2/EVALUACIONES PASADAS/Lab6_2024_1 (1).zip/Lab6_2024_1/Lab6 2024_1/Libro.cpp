/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Libro.cpp
 * Author: margo
 * 
 * Created on 28 de mayo de 2024, 16:38
 */

#include "Libro.h"
#include <cstring>
#include <iomanip>
using namespace std;
Libro::Libro() {
    codigo=nullptr;
    nombre=nullptr;
    ancho=0;
    alto=0;
    colocado=false;
}

Libro::~Libro() {
    if (codigo!=nullptr)delete codigo;
    if (nombre!=nullptr)delete nombre;
}
Libro::Libro(const Libro& orig) {
    
}
void Libro::SetAlto(int alto) {
    this->alto = alto;
}

int Libro::GetAlto() const {
    return alto;
}

void Libro::SetAncho(int ancho) {
    this->ancho = ancho;
}

int Libro::GetAncho() const {
    return ancho;
}

void Libro::SetNombre(const char* nomb) {
    if (nombre !=nullptr) delete nombre;
    nombre = new char [strlen(nomb)+1]{};
    strcpy(nombre, nomb);
}

void Libro::GetNombre(char *nomb) const {
    if (nombre ==nullptr) nomb[0]=0;
    else strcpy(nomb, nombre);
}

void Libro::SetCodigo(const char* cod) {
    if (codigo !=nullptr) delete codigo;
    codigo = new char [strlen(cod)+1]{};
    strcpy(codigo, cod);
}

void Libro::GetCodigo(char *cod) const {
    if (codigo ==nullptr) cod[0]=0;
    else strcpy(cod, codigo);
}

void Libro::SetColocado(bool colocado) {
    this->colocado = colocado;
}

bool Libro::IsColocado() const {
    return colocado;
}

void operator >>(ifstream &arch, class Libro &lib){
    //ABC123, El libro de la Selva, 1, 3
    char cod[7]{}, nombre[100]{};
    arch.getline(cod, 7, ',');
    if (arch.eof()) return;
    arch.getline(nombre, 100, ',');
    int an, alt;
    arch>>an;
    arch.get();
    arch>>alt;
    arch.get();
    lib.SetAlto(alt);
    lib.SetAncho(an);
    lib.SetCodigo(cod);
    lib.SetNombre(nombre);
}
void operator <<(ofstream &arch, class Libro &lib){
    char nombre[60]{}, cod[10]{};
    lib.GetCodigo(cod);
    lib.GetNombre(nombre);
    arch<<right<<setw(10)<<cod<<setw(5)<<' '<<nombre<<setw(60-strlen(nombre))<<' '
            <<lib.GetAncho()<<setw(10)<<lib.GetAlto()<<endl;
}

