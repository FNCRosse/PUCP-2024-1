/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Biblioteca.h
 * Author: margo
 *
 * Created on 28 de mayo de 2024, 16:58
 */

#ifndef BIBLIOTECA_H
#define BIBLIOTECA_H

#include "Estante.h"
#include "Libro.h"


class Biblioteca {
private:
    Estante  estantes[20];
    int cantidad_estantes;
    Libro libros[20];
    int cantidad_libros;
public:
    Biblioteca();
//    Biblioteca(const Biblioteca& orig);
    virtual ~Biblioteca();
    void SetCantidad_libros(int cantidad_libros);
    int GetCantidad_libros() const;
    void SetCantidad_estantes(int cantidad_estantes);
    int GetCantidad_estantes() const;
    void cargarLibros(ifstream &);
};
#endif /* BIBLIOTECA_H */

