/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Estante.h
 * Author: margo
 *
 * Created on 28 de mayo de 2024, 16:48
 */

#ifndef ESTANTE_H
#define ESTANTE_H

#include "Espacio.h"
#include "Libro.h"

#include <fstream>
using namespace std;
class Estante {
private:
    char *codigo;
    int anchura;
    int altura;
    Libro libros[100];
    Espacio *espacios;
    int cantidad_libros;
    
public:
    Estante();
//    Estante(const Estante& orig);
    virtual ~Estante();
    void SetCantidad_libros(int cantidad_libros);
    int GetCantidad_libros() const;
    void SetAltura(int altura);
    int GetAltura() const;
    void SetAnchura(int anchura);
    int GetAnchura() const;
    void SetCodigo(const char *codigo);
    void GetCodigo(char *) const;
    void impresionLibros(ofstream &);
    void operator +=(Libro &);
    void impresionEstante(ofstream &);
    bool HayEspacio(int&, int , int);   
    
//    void impresionEst(ofstream &);
};
void operator>>(ifstream &arch, class Estante &);
void operator <<(ofstream &arch, class Estante &est);
void impresionLinea(ofstream &arch, int cant,char sig);
#endif /* ESTANTE_H */

