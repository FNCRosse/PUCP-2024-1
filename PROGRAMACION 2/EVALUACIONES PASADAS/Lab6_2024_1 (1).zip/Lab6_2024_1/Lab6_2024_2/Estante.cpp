/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Estante.cpp
 * Author: margo
 * 
 * Created on 28 de mayo de 2024, 16:48
 */

#include "Estante.h"
#include <cstring>
#include <iomanip>
#include <iostream>
#define LINEA 100
using namespace std;
Estante::Estante() {
    anchura=0;
    anchura=0;
    cantidad_libros=0;
    espacios=nullptr;
    codigo = nullptr;
}

//Estante::Estante(const Estante& orig) {
//}

Estante::~Estante() {
    if (codigo!=nullptr) delete codigo;
}

void Estante::SetCantidad_libros(int cantidad_libros) {
    this->cantidad_libros = cantidad_libros;
}

int Estante::GetCantidad_libros() const {
    return cantidad_libros;
}

void Estante::SetAltura(int altura) {
    this->altura = altura;
}

int Estante::GetAltura() const {
    return altura;
}

void Estante::SetAnchura(int anchura) {
    this->anchura = anchura;
}

int Estante::GetAnchura() const {
    return anchura;
}

void Estante::SetCodigo(const char* cod) {
    if (codigo !=nullptr) delete codigo;
    codigo = new char [strlen(cod)+1]{};
    strcpy(codigo, cod);
}

void Estante::GetCodigo(char *cod) const {
    if (codigo==nullptr) cod[0]=0;
    else strcpy(cod, codigo);
}

void operator>>(ifstream &arch, class Estante &est){
    //AAA, 6, 4
    char cod[4]{};
    int anchura, altura;
    arch.getline(cod, 10, ',');
    if (arch.eof()) return;
    arch>>anchura;
    arch.get();
    arch>>altura;
    est.SetAltura(altura);
    est.SetAnchura(anchura);
    est.SetCodigo(cod);
}
void operator <<(ofstream &arch, class Estante &est){
    char cod[4]{};
    est.GetCodigo(cod);
    arch<<"Codigo estante: "<<cod<<setw(10)<<' '<<"Cantidad de Libros: "<<est.GetCantidad_libros()<<endl;
    arch<<"Anchura del estante: "<<est.GetAnchura()<<setw(10)<<' '<<"Altura del estante "<<est.GetAltura()<<endl;
    impresionLinea(arch, LINEA,'=');
    est.impresionEstante(arch);
    arch<<setw(15)<<right<<"CODIGO"<<setw(15)<<right<<"NOMBRE"<<setw(30)<<"ANCHO"<<setw(15)<<"ALTO"<<endl;
    impresionLinea(arch, LINEA,'.');
    est.impresionLibros(arch);
}
void impresionLinea(ofstream &arch, int cant,char sig){
    for(int i=0;i<cant;i++) arch<<sig<<' ';
    arch<<endl;
}

void Estante::impresionEstante(ofstream&arch) {
    
    for(int i=(anchura*altura);i>0;){
        i-=anchura;
        int k=0;
        for(int j=i;k<anchura;j++){
            char tip=espacios[j].GetContenido();
            arch<<'['<<tip<<']'<<' ';
            k++;
        }
        arch<<endl;
    }
    arch<<endl;
}

void Estante::impresionLibros(ofstream&arch) {
    for(int i=0;i<cantidad_libros;i++){
        arch<<libros[i];
    }
    arch<<endl;
}

bool Estante::operator+=(Libro& lib) {
    if (cantidad_libros==0) espacios = new Espacio [altura*anchura]{};
    int cont1=lib.GetAlto();
    int cont2=lib.GetAncho();
    int pos=0, i;
    
    if (HayEspacio(pos, cont2, cont1)){
        if (pos>=anchura) return false;
        i=pos;
        while(i<=altura*anchura){
                cont1--;
                espacios[i].SetContenido('*');
                cout<<espacios[i].GetContenido();
                if (cont1==0){
                    pos++;
                    i=pos;
                    cout<<endl;
                    cont2--;
                }
                if (cont1==0 and cont2!=0) cont1=lib.GetAlto();
                if (cont1!=lib.GetAlto())i+=anchura;
                if (cont1==0 and cont2==0) break;
        }
        cout<<endl;
        char codigo[10]{}, nombre[100]{};
        lib.GetCodigo(codigo);
        lib.GetNombre(nombre);
        libros[cantidad_libros].SetCodigo(codigo);
        libros[cantidad_libros].SetNombre(nombre);
        libros[cantidad_libros].SetAlto(lib.GetAlto());
        libros[cantidad_libros].SetAncho(lib.GetAncho());
        libros[cantidad_libros].SetColocado(true);
        cantidad_libros++;
        return true;
    }
    return false;
    
}

bool Estante::HayEspacio(int &pos, int ancho, int alto) {
    int cont1=alto;
    int cont2=ancho;
    int i;
    pos=0;
    int siEntra=0;
    if (alto>altura or ancho>anchura) return false;
    if (cantidad_libros==0) return true;
    for( i=0;i<anchura;i++){
        if (espacios[i].GetContenido()==' ') break;
    }
    pos=i;
    for(int i=pos;i<=altura*anchura;i+=anchura){
        cont1--;
        if (i>0 and i==altura*anchura) break;
        if (cont1==0){
            pos++;
            cont2--;
            if(pos>=anchura and cont2!=0) break;
            i=pos;
        }
        if (cont1==0 and cont2!=0) cont1=alto;
        if (cont1==0 and cont2==0) {
            siEntra=1;
            break;
        }
    }
    if (siEntra) {
        pos-=ancho;
        cout<<pos<<endl;
        return true;
    }else{
        return false;
    }
}



