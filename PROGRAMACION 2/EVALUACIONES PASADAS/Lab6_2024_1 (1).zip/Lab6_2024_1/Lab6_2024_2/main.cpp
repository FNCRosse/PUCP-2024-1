/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: margo
 *
 * Created on 28 de mayo de 2024, 16:35
 */

#include <cstdlib>
#include <fstream>
#include <iostream>

using namespace std;
#include "Biblioteca.h"
#include "Libro.h"
#include "Estante.h"
/*
 * 
 */
int main(int argc, char** argv) {
    
    ifstream LibLec("libros.csv", ios::in);
    if (not LibLec.is_open()){
        cout<<"error con la aperura del archivo: "<<"libros.csv"<<endl;
        exit(1);
    }
    ofstream LibImp("impresion.txt", ios::out);
    if (not LibImp.is_open()){
        cout<<"error con la aperura del archivo: "<<"impresion.csv"<<endl;
        exit(1);
    }
    ifstream LibEst("estantes.csv", ios::in);
    if (not LibEst.is_open()){
        cout<<"error con la aperura del archivo: "<<"libros.csv"<<endl;
        exit(1);
    }
    
    Biblioteca biblioteca;
    biblioteca.cargarLibros(LibLec);
    biblioteca.cargarEstantes(LibEst);
    biblioteca.posicionar_libros();
    biblioteca.mostrar_datos(LibImp);
    return 0;
}

