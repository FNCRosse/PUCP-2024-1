

/* 
 * File:   funciones.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 20 de abril de 2023, 12:15 AM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void emiteReporte(ifstream &archPacientes,ifstream &archAtenciones,
        ifstream &archMedicos,ofstream &archReporte);
void leeImprimeRelaciones(int cod_pacieente,double &montoParcial,
        ifstream &archMedicos,ifstream &archAtenciones,ofstream &archReporte);
void imprimeRelaciones(int dd,int mm,int aa,int horaIng,int minIng,int segIng,
        int horaSal,int minSal,int segSal,int duracionMinutos,
        int duracionSegundos,int cod_medico,ofstream &archReporte);
void calculaImprimeMonto(double tarifa,int duracionMinutos,int duracionSegundos,
        double &monto,ofstream &archRep);
void buscaImprimeTarifaMedico(int cod_medico,ifstream &archMedicos,
        double &tarifa,ofstream &archRep);
void imprimeEncabezadoRelaciones(ofstream &archReporte);
void calculaDuracion(int horaIng,int minIng,int segIng,int horaSal,int minSal,
        int segSal,int &duracionMinutos,int &duracionSegundos);
void leerHora(ifstream &archAtenciones,int &hora,int &minuto,int &segundo);
void leeImprimeDatosPaciente(int &codigo,ifstream &archPacientes,ofstream &archReporte);
void imprimeNombrePaciente(ifstream &archPacientes,ofstream &archReporte);
void imprimeNombreDistrito(ifstream &archPacientes,ofstream &archReporte);
void imprimeTitulo(ofstream &archReporte);
void imprimeLinea(char caracter, int cantidad, ofstream &archRep);
#endif /* FUNCIONES_H */

