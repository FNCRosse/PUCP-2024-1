

/* 
 * File:   main.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 12 de abril de 2023, 12:58 PM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#include "funciones.h"

/*
 * 
 */
int main(int argc, char** argv) {
    
    
    ifstream archPacientes("Pacientes.txt",ios::in);
    if(not archPacientes.is_open()){
        cout<<"ERROR al abrir el archivo de pacientes.txt"<<endl;
        exit(1);
    }
    ifstream archAtenciones("AtencionesMedicas.txt",ios::in);
    if(not archAtenciones.is_open()){
        cout<<"ERROR al abrir el archivo de AtencionesMedicas.txt"<<endl;
        exit(1);
    }
    ifstream archMedicos("Medicos.txt",ios::in);
    if(not archMedicos.is_open()){
        cout<<"ERROR al abrir el archivo de Medicos.txt"<<endl;
        exit(1);
    }
    ofstream archReporte("ReporteDePagos.txt",ios::out);
    if(not archPacientes.is_open()){
        cout<<"ERROR al abrir el archivo de ReporteDePagos.txt"<<endl;
        exit(1);
    }
    
    emiteReporte(archPacientes,archAtenciones,archMedicos,archReporte);
    return 0;
}

