

/* 
 * File:   funciones.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 20 de abril de 2023, 12:15 AM
 */


#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#define MAX_LINE 150
#define MAX_NOMB 50
#define MAX_DIS 30
#include "funciones.h"

void emiteReporte(ifstream &archPacientes,ifstream &archAtenciones,
        ifstream &archMedicos,ofstream &archReporte){
    imprimeTitulo(archReporte);
    int cod_paciente;
    double montoParcial,montoTotal=0;
    archReporte<<setprecision(2);
    archReporte<<fixed;
    while(true){
        leeImprimeDatosPaciente(cod_paciente,archPacientes,archReporte);
        if(archPacientes.eof())break;
        imprimeEncabezadoRelaciones(archReporte);
        leeImprimeRelaciones(cod_paciente,montoParcial,archMedicos,
                archAtenciones,archReporte);
        archReporte<<"PAGO TOTAL REALIZADO: S/."<<setw(15)<<montoParcial<<endl;
        montoTotal+=montoParcial;
    }
    imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<"TOTAL DE PAGOS DE LOS PACIENTES: S/."<<setw(15)<<montoTotal
            <<endl;
    imprimeLinea('=',MAX_LINE,archReporte);
}

void leeImprimeRelaciones(int cod_pacieente,double &montoParcial,
        ifstream &archMedicos,ifstream &archAtenciones,ofstream &archReporte){
    
    int cod_medico,dd,mm,aa,codPaciente_evaluar,horaIng,minIng,segIng,horaSal,
            minSal,segSal,duracionMinutos,duracionSegundos;
    char c;
    double tarifa,monto;
    archAtenciones.clear();
    archAtenciones.seekg(0,ios::beg);
    montoParcial=0;
    while(true){
        archAtenciones>>cod_medico;
        if(archAtenciones.eof())break;
        archAtenciones>>dd>>c>>mm>>c>>aa;
        while(true){
            archAtenciones>>codPaciente_evaluar;
            leerHora(archAtenciones,horaIng,minIng,segIng);
            leerHora(archAtenciones,horaSal,minSal,segSal);
            calculaDuracion(horaIng,minIng,segIng,horaSal,minSal,segSal,
                    duracionMinutos,duracionSegundos);
            if(codPaciente_evaluar==cod_pacieente){
                imprimeRelaciones(dd,mm,aa,horaIng,minIng,segIng,horaSal,
                        minSal,segSal,duracionMinutos,duracionSegundos,
                        cod_medico,archReporte);
                buscaImprimeTarifaMedico(cod_medico,archMedicos,tarifa,archReporte);
                calculaImprimeMonto(tarifa,duracionMinutos,duracionSegundos,
                        monto,archReporte);
                montoParcial+=monto;
            }
            if(archAtenciones.get()=='\n')break;
        }
    }
}

void imprimeRelaciones(int dd,int mm,int aa,int horaIng,int minIng,int segIng,
        int horaSal,int minSal,int segSal,int duracionMinutos,
        int duracionSegundos,int cod_medico,ofstream &archReporte){
    
    archReporte<<setw(5)<<' '<<setfill('0')<<setw(2)<<dd<<'/'<<setw(2)<<mm
            <<setw(4)<<aa<<setfill(' ');
    archReporte<<setw(10)<<' '<<setfill('0')<<setw(2)<<horaIng<<':'
            <<setw(2)<<minIng<<':'<<setw(2)<<segIng<<setfill(' ');
    archReporte<<setw(10)<<' '<<setfill('0')<<setw(2)<<horaSal<<':'
            <<setw(2)<<minSal<<':'<<setw(2)<<segSal<<setfill(' ');
    archReporte<<setw(10)<<' '<<setfill('0')<<setw(2)<<duracionMinutos
            <<':'<<setw(2)<<duracionSegundos<<setfill(' ');
    archReporte<<setw(10)<<' '<<cod_medico;
            
}

void calculaImprimeMonto(double tarifa,int duracionMinutos,int duracionSegundos,
        double &monto,ofstream &archRep){
    
    monto= tarifa*duracionMinutos;
    if(duracionSegundos>0)monto=tarifa*(duracionMinutos+1);
    archRep<<setw(15)<<' '<<monto<<endl;
}

void buscaImprimeTarifaMedico(int cod_medico,ifstream &archMedicos,
        double &tarifa,ofstream &archRep){
    
    archMedicos.clear();
    archMedicos.seekg(0,ios::beg);
    
    int codMed_evaluar;
    while(true){
        archMedicos>>codMed_evaluar;
        if(archMedicos.eof())break;
        if(codMed_evaluar==cod_medico){
            archMedicos>>ws;
            while(archMedicos.get()!=' ');
            archMedicos>>tarifa;
            archRep<<setw(10)<<' '<<tarifa;
            archMedicos>>ws;
            while(archMedicos.get()!='\n');
        }else
            while(archMedicos.get()!='\n');
    }
    
}

void imprimeEncabezadoRelaciones(ofstream &archReporte){
    archReporte<<setw(7)<<' '<<"FECHA"<<setw(13)<<' '<<"INGRESO"
            <<setw(11)<<' '<<"SALIDA"<<setw(9)<<' '<<"DURACION"
            <<setw(8)<<' '<<"MEDICO"<<setw(10)<<' '<<"TARIFA"
            <<setw(10)<<' '<<"MONTO PAGADO"<<endl;
}

void calculaDuracion(int horaIng,int minIng,int segIng,int horaSal,int minSal,
        int segSal,int &duracionMinutos,int &duracionSegundos){
    
    int duracionTotal =(horaSal*3600+minSal*60+segSal)-
    (horaIng*3600+minIng*60+segIng);
    
    duracionMinutos=duracionTotal/60;
    duracionSegundos=(duracionTotal%60);
}

void leerHora(ifstream &archAtenciones,int &hora,int &minuto,int &segundo){
    char c;
    archAtenciones>>hora;
    c=archAtenciones.get();
    if(c!=':'){
        if(c=='\n')archAtenciones.unget();
        minuto=0;
        segundo=0;
    }else {
        archAtenciones>>minuto;
        c=archAtenciones.get();
        if(c!=':'){
            if(c=='\n')archAtenciones.unget();
            segundo=0;
        }else archAtenciones>>segundo;
    }
}

void leeImprimeDatosPaciente(int &cod_paciente,ifstream &archPacientes,
        ofstream &archReporte){
    
    
    archPacientes>>cod_paciente;
    if(archPacientes.eof())return;
    imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<setw(5)<<' '<<"Nombre:"<<setw(10)<<' ';
    imprimeNombrePaciente(archPacientes,archReporte);
    archReporte<<"Codigo:"<<setw(9)<<cod_paciente<<endl;
    archReporte<<setw(5)<<' '<<"Distrito:"<<setw(8)<<' ';
    imprimeNombreDistrito(archPacientes,archReporte);
    imprimeLinea('-',MAX_LINE,archReporte);
}

void imprimeNombrePaciente(ifstream &archPacientes,ofstream &archReporte){
    
    char paciente;
    int numCarac=0,primeraLetra=1;;
    
    while(archPacientes.get()!='[');
    while(true){
        paciente=archPacientes.get();
        if(paciente==']')break;
        
        if(paciente!=' ' and primeraLetra)primeraLetra=0;
        else if(paciente!=' ' and !primeraLetra)paciente+='a'-'A';
        else if(paciente==' ')primeraLetra=1;
        archReporte.put(paciente);
        numCarac++;
    }
    for(int i=0;i<MAX_NOMB-numCarac;i++)archReporte.put(' ');
}

void imprimeNombreDistrito(ifstream &archPacientes,ofstream &archReporte){
    char distrito;
    int numCarac=0;
    archPacientes>>ws;
    while(true){
        distrito=archPacientes.get();
        if(distrito=='\n')break;
        if(distrito==' ')distrito='_';
        distrito-=(distrito>='a' and distrito<='z')?('a'-'A'):0;
        archReporte.put(distrito);
        numCarac++;        
    }
    for(int i=0;i<MAX_DIS-numCarac;i++)archReporte.put(' ');
    archReporte.put('\n');
}

void imprimeTitulo(ofstream &archReporte){
    archReporte<<setw(50)<<' '<<"EMPRESA PRESTADORA DE SALUD"<<endl;
    archReporte<<setw(46)<<' '<<"LISTADOS DE PAGOS DE LOS PACIENTES"<<endl;
}

void imprimeLinea(char caracter, int cantidad, ofstream &archRep){
    for(int i=0;i<cantidad;i++)archRep.put(caracter);
    archRep.put('\n');
}