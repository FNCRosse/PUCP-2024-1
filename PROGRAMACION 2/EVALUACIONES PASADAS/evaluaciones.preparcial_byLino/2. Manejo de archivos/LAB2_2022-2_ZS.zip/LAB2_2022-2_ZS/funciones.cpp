

/* 
 * File:   funciones.cpp
 * Author: chupetin
 *
 * Created on 22 de abril de 2023, 08:06 PM
 */


#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#include "funciones.h"
#define MAX_LINE 150
#define MAX_CAR 60
#define MAX_CAR_PACIENTE 35

void emiteReporte(ifstream &archMedicos,ifstream &archCitas,
        ifstream &archPaciente,ofstream &archReporte){
    
    imprimeTitulo(archReporte);
    archReporte<<setprecision(2);
    archReporte<<fixed;
    int codigo_medico;
    double tarifa,montoParcial,montoRecaudado=0;
    while(true){
        leeImprimeMedicos(codigo_medico,tarifa,archMedicos,archReporte);
        if(archMedicos.eof())break;
        imprimeEncabezado(archReporte);
        imprimeEncabezadoCitas(archReporte);
        leeImprimeCitas(codigo_medico,tarifa,montoParcial,
                archCitas,archPaciente,archReporte);
        archReporte<<setw(5)<<' '<<"Total de gastos por citas:"
                <<setw(50)<<' '<<setw(15)<<montoParcial<<endl;
        montoRecaudado+=montoParcial;
    }
    imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<"TOTAL RECAUDADO POR LA CLINICA:"<<setw(15)<<montoRecaudado
            <<endl;
}

void leeImprimeCitas(int codigo_medico,double tarifa,double &montoParcial,
        ifstream &archCitas,ifstream &archPaciente,ofstream &archReporte){
    
    int dni_paciente,codMed_atendido,dd,mm,aa,horaIng,minIng,segIng,horaSal,
            minSal,segSal;
    double minDuracion,monto;
    char c;
    montoParcial=0;
    archCitas.clear();
    archCitas.seekg(0,ios::beg);
    while(true){
        archCitas>>dni_paciente;
        if(archCitas.eof())break;
        archCitas>>codMed_atendido;
        if(codMed_atendido==codigo_medico){
            archCitas>>dd>>c>>mm>>c>>aa;
            archCitas>>horaIng>>c>>minIng>>c>>segIng;
            archCitas>>horaSal>>c>>minSal>>c>>segSal;
            transFormarTiempoMinuto(horaIng,minIng,segIng,horaSal,minSal,segSal,
                    minDuracion);
            monto=tarifa*(minDuracion/60);
            imprimeCitas(dni_paciente,dd,mm,aa,horaIng,minIng,segIng,horaSal,
                    minSal,segSal,minDuracion,monto,archPaciente,archReporte);
            montoParcial+=monto;
        }else
            while(archCitas.get()!='\n');
    }
    imprimeLinea('-',MAX_LINE,archReporte);
}

void imprimeCitas(int dni_paciente,int dd,int mm,int aa,int horaIng,int minIng,
        int segIng,int horaSal,int minSal,int segSal,double minDuracion,
        double monto,ifstream &archPaciente,ofstream &archReporte){
    archReporte<<setw(5)<<' '<<setfill('0')<<setw(2)<<dd<<'/'<<setw(2)
            <<mm<<'/'<<setw(4)<<aa<<setfill(' ');
    archReporte<<setw(5)<<' '<<dni_paciente<<" - ";
    buscaDatosImprimePaciente(dni_paciente,archPaciente,archReporte);
    archReporte<<setw(4)<<' '<<setfill('0')<<setw(2)<<horaIng<<':'
            <<setw(2)<<minIng<<':'<<setw(2)<<segIng<<setfill(' ');
    archReporte<<setw(3)<<' '<<setfill('0')<<setw(2)<<horaSal<<':'
            <<setw(2)<<minSal<<':'<<setw(2)<<segSal<<setfill(' ');
    archReporte<<setw(7)<<' '<<setw(6)<<minDuracion<<setw(10)<<' '
            <<setw(10)<<monto<<endl; 
}

void buscaDatosImprimePaciente(int dni_paciente,ifstream &archPaciente,
        ofstream &archReporte){
    archPaciente.clear();
    archPaciente.seekg(0,ios::beg);
    int paciente_evaluar,telefono;
    while(true){
        archPaciente>>paciente_evaluar;
        if(archPaciente.eof())break;
        if(paciente_evaluar==dni_paciente){
            imprimeNombrePaciente(archPaciente,archReporte);
            archPaciente>>telefono;
            archReporte<<setw(3)<<' '<<telefono;
        }else
            while(archPaciente.get()!='\n');
    }
}

void imprimeNombrePaciente(ifstream &archPaciente,ofstream &archReporte){
    char paciente;
    int numCar=0;
    while(archPaciente.get()!='[');
    while(true){
        paciente=archPaciente.get();
        if(paciente==']')break;
        paciente-=(paciente>='a' and paciente<='z')?('a'-'A'):0;
        archReporte.put(paciente);
        numCar++;
    }
    for(int i=0;i<MAX_CAR_PACIENTE-numCar;i++)archReporte.put(' ');
}

void transFormarTiempoMinuto(int horaIng,int minIng,int segIng,int horaSal,
        int minSal,int segSal,double &minDuracion){
    
    double duracionSegundos=(horaSal*3600+minSal*60+segSal)-
    (horaIng*3600+minIng*60+segIng);
    
    minDuracion=(double)(duracionSegundos/60);
}

void leeImprimeMedicos(int &codigo_medico,double &tarifa,ifstream &archMedicos,ofstream &archReporte){
    
    archMedicos>>codigo_medico;
    if(archMedicos.eof())return;
    archReporte<<setw(5)<<' '<<codigo_medico<<setw(10)<<' ';
    impriemNombreMedico(archMedicos,archReporte);
    archMedicos>>tarifa;
    archReporte<<setw(8)<<tarifa<<endl;
}

void impriemNombreMedico(ifstream &archMedicos,ofstream &archReporte){
    char medico;
    int numCar=0;
    archMedicos>>ws;
    
    while(true){
        medico=archMedicos.get();
        if(medico==' ')break;
        if(medico=='_')medico=' ';
        archReporte.put(medico);
        numCar++;
    }
    for(int i=0;i<MAX_CAR-numCar;i++)archReporte.put(' ');
}

void imprimeEncabezadoCitas(ofstream &archReporte){
    archReporte<<endl;
    archReporte<<setw(5)<<' '<<"CITAS ATENDIDAS:"<<endl;
    imprimeLinea('-',MAX_LINE,archReporte);
    archReporte<<setw(5)<<' '<<"FECHA"<<setw(20)<<' '<<"DNI - PACIENTE"
            <<setw(26)<<' '<<"TELEFONO"<<setw(5)<<' '<<"LLEGADA"
            <<setw(5)<<' '<<"SALIDA"<<setw(5)<<' '<<"TIEMPO(minutos)"
            <<setw(8)<<' '<<"PAGO"<<endl;
}

void imprimeEncabezado(ofstream &archReporte){
    imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<setw(5)<<' '<<"Codigo"<<setw(10)<<' '<<"Medico"
            <<setw(52)<<' '<<"Tarifa por hora"<<endl;
}

void imprimeTitulo(ofstream &archRep){
    archRep<<setw(50)<<' '<<"CLINICA PSICOLOGICA TP."<<endl;
    archRep<<setw(47)<<' '<<"RELACION DE CITAS POR MEDICO"<<endl;
}

void imprimeLinea(char caracter,int cantidad, ofstream &archRep){
    for(int i=0;i<cantidad;i++)archRep.put(caracter);
    archRep.put('\n');
}

