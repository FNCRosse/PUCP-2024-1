

/* 
 * File:   main.cpp
 * Author: chupetin
 *
 * Created on 22 de abril de 2023, 08:02 PM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#include "funciones.h"

/*
 * 
 */
int main(int argc, char** argv) {
    
    ifstream archMedicos("Medicos.txt",ios::in);
    if(not archMedicos.is_open()){
        cout<<"ERROR al abrir el archivo de medicos"<<endl;
        exit(1);
    }
    ifstream archCitas("Citas.txt",ios::in);
    if(not archMedicos.is_open()){
        cout<<"ERROR al abrir el archivo de medicos"<<endl;
        exit(1);
    }
    ifstream archPaciente("Pacientes.txt",ios::in);
    if(not archMedicos.is_open()){
        cout<<"ERROR al abrir el archivo de medicos"<<endl;
        exit(1);
    }
    ofstream archReporte("ReporteDeCitasPorMedico.txt",ios::out);
    if(not archMedicos.is_open()){
        cout<<"ERROR al abrir el archivo de reporte"<<endl;
        exit(1);
    }
    
    emiteReporte(archMedicos,archCitas,archPaciente,archReporte);
    
    return 0;
}

