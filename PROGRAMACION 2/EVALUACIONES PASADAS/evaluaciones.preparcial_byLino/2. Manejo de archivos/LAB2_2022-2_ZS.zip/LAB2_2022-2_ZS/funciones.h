

/* 
 * File:   funciones.h
 * Author: chupetin
 *
 * Created on 22 de abril de 2023, 08:06 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void emiteReporte(ifstream &archMedicos,ifstream &archCitas,
        ifstream &archPaciente,ofstream &archReporte);
void leeImprimeCitas(int codigo_medico,double tarifa,double &montoParcial,
        ifstream &archCitas,ifstream &archPaciente,ofstream &archReporte);
void imprimeCitas(int dni_paciente,int dd,int mm,int aa,int horaIng,int minIng,
        int segIng,int horaSal,int minSal,int segSal,double minDuracion,
        double monto,ifstream &archPaciente,ofstream &archReporte);
void buscaDatosImprimePaciente(int dni_paciente,ifstream &archPaciente,
        ofstream &archReporte);
void imprimeNombrePaciente(ifstream &archPaciente,ofstream &archReporte);
void transFormarTiempoMinuto(int horaIng,int minIng,int segIng,int horaSal,
        int minSal,int segSal,double &minDuracion);
void leeImprimeMedicos(int &codigo_medico,double &tarifa,ifstream &archMedicos,
        ofstream &archReporte);
void impriemNombreMedico(ifstream &archMedicos,ofstream &archReporte);
void imprimeEncabezadoCitas(ofstream &archReporte);
void imprimeEncabezado(ofstream &archReporte);
void imprimeTitulo(ofstream &archRep);
void imprimeLinea(char caracter,int cantidad, ofstream &archRep);

#endif /* FUNCIONES_H */

