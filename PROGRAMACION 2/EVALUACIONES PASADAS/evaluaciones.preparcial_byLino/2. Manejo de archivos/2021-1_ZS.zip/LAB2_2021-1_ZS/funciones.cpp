

/* 
 * File:   funciones.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 19 de abril de 2023, 10:43 AM
 */


#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#include "funciones.h"
#define MAX_LINE 150
#define MAX_CAR 50

void emiteReporte(ifstream &archCursos,ifstream &archAlumnos,
        ofstream &archReporte){
    
    imprimeEncabezado(archReporte);
    int cant_cursos=0,cod_especialidad,cod_curso,cantAlumnos,notaMayor,
            notaMenor,cantAprob,cantDesaprob,codMayor,cod_CursoMayor;
    double creditos,mayorPorcenAprob=0;
    archReporte<<setprecision(2);
    archReporte<<fixed;
    while(true){
        imprimeLinea('=',MAX_LINE,archReporte);
        leeImprimeCursos(cant_cursos,cod_especialidad,cod_curso,creditos,
                archCursos,archReporte);
        if(archCursos.eof())break;
        leeImprimeRelaciones(cantAlumnos,notaMayor,notaMenor,cantAprob,
                cantDesaprob,cod_especialidad,cod_curso,mayorPorcenAprob,
                codMayor,cod_CursoMayor,archAlumnos,archReporte);
        imprimeResumen(cantAlumnos,notaMayor,notaMenor,cantAprob,cantDesaprob,
                archReporte);
    }
    
    imprimeCursoMasAprob(cant_cursos,mayorPorcenAprob,codMayor,cod_CursoMayor,
            archCursos,archReporte);
}

void imprimeCursoMasAprob(int cant_cursos,double mayorPorcenAprob,int codMayor,
        int cod_CursoMayor,ifstream &archCursos,ofstream &archReporte){
    imprimeLinea('*',MAX_LINE,archReporte);
    archReporte<<setw(5)<<' '<<"Total de cursos registrados:"
            <<setw(5)<<cant_cursos<<endl;
    archReporte<<setw(5)<<' '<<"CURSO CON MAYOR PORCENTAJE DE APROBADOS: "
            <<mayorPorcenAprob<<'%'<<endl;
    archReporte<<setw(7)<<' ';
    buscaImprimeCurso(archCursos,codMayor,cod_CursoMayor,archReporte);
    archReporte<<"Especialidad:"<<setw(4)<<codMayor;
    archReporte<<setw(10)<<' '<<"Codigo:"<<setw(6)<<cod_CursoMayor<<endl;
    imprimeLinea('*',MAX_LINE,archReporte);
    
}

void buscaImprimeCurso(ifstream &archCursos,int codMayor,int cod_CursoMayor,
        ofstream &archReporte){
    int espec_evaluar,codCurso_evaluar;
    double creditos;
    archCursos.clear();
    archCursos.seekg(0,ios::beg);
    while(true){
        archCursos>>espec_evaluar;
        if(archCursos.eof())break;
        archCursos>>codCurso_evaluar>>creditos;
        if(espec_evaluar==codMayor and codCurso_evaluar==cod_CursoMayor){
            imprimeNombreCurso(archCursos,archReporte);
        }else
            while(archCursos.get()!='\n');
    }
}

void imprimeResumen(int cantAlumnos,int notaMayor,int notaMenor,int cantAprob,
        int cantDesaprob,ofstream &archReporte){
    imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<setw(8)<<' '<<"RESUMEN:"<<endl;
    archReporte<<setw(8)<<' '<<"Alumnos matriculads en la especialidad:"
            <<setw(10)<<cantAlumnos<<endl;
    archReporte<<setw(8)<<' '<<"Aprobados:"<<setw(39)<<cantAprob<<setw(5)<<' '
            <<setw(8)<<((double)cantAprob/cantAlumnos)*100<<'%'<<endl;
    archReporte<<setw(8)<<' '<<"Desaprobados:"<<setw(36)<<cantDesaprob
            <<setw(5)<<' '<<setw(8)<<((double)cantDesaprob/cantAlumnos)*100
            <<'%'<<endl;
    archReporte<<setw(8)<<' '<<"Relacion de aprobados/desaprobados:"
            <<setw(26)<<(double)cantAprob/cantDesaprob<<endl;
    archReporte<<setw(8)<<' '<<"Nota maxima:"<<setw(35)<<' '<<setfill('0')
            <<setw(2)<<notaMayor<<setfill(' ')<<endl;
    archReporte<<setw(8)<<' '<<"Nota minima:"<<setw(35)<<' '<<setfill('0')
            <<setw(2)<<notaMenor<<setfill(' ')<<endl;
}

void leeImprimeRelaciones(int &cantAlumnos,int &notaMayor,int &notaMenor,
        int &cantAprob,int &cantDesaprob,int cod_especialidad,int cod_curso,
        double &mayorPorcenAprob,int &codMayor,int &cod_CursoMayor,
        ifstream &archAlumnos,ofstream &archReporte){
    
    int anio_ingreso,codEspec_alumno,cod_alumno,codEsp_curso,codCurso_evaluar,
            nota,dd,mm,aa;
    double porcenAprob;
    cantAprob=0,cantDesaprob=0,notaMayor=0,notaMenor=21,cantAlumnos=0;
    char c;
    archAlumnos.clear();
    archAlumnos.seekg(0,ios::beg);
    imprimeSubTitulo(archReporte);    
    while(true){
        archAlumnos>>anio_ingreso;
        if(archAlumnos.eof())break;
        archAlumnos>>codEspec_alumno>>cod_alumno;
        while(archAlumnos.get()!='\n');
        while(true){
            archAlumnos>>codEsp_curso;
            if(codEsp_curso==0)break;
            archAlumnos>>codCurso_evaluar;
            archAlumnos>>nota;
            archAlumnos>>dd>>c>>mm>>c>>aa;
            if(anio_ingreso<=aa and codEspec_alumno==cod_especialidad){
                if(codCurso_evaluar==cod_curso){
                    cantAlumnos++;
                    imprimeDatosAlumno(cantAlumnos,anio_ingreso,cod_alumno,nota,
                            aa,mm,dd,archReporte);
                    analizaAprobadosYdesaprobados(nota,cantAprob,cantDesaprob);
                    analizaNotaMaxYmin(nota,notaMayor,notaMenor);
                }
            }
        }
    }
    porcenAprob=((double)cantAprob/cantAlumnos) *100;
    analizaCursoMayorAprob(codEspec_alumno,cod_curso,codMayor,cod_CursoMayor,
            porcenAprob,mayorPorcenAprob);
}

void analizaCursoMayorAprob(int codEspec_alumno,int cod_curso,int &codMayor,
        int &cod_CursoMayor,double porcenAprob,double &mayorPorcenAprob){
    
    if(porcenAprob>mayorPorcenAprob){
        mayorPorcenAprob=porcenAprob;
        codMayor=codEspec_alumno;
        cod_CursoMayor=cod_curso;
    }
}

void analizaNotaMaxYmin(int nota,int &notaMayor,int &notaMenor){
    
    if(nota>notaMayor)notaMayor=nota;
    
    if(nota<notaMenor)notaMenor=nota;
}

void analizaAprobadosYdesaprobados(int nota,int &cantAprob,int &cantDesaprob){
    
    if(nota>10)cantAprob++;
    else if(nota<=10)cantDesaprob++;
}

void imprimeDatosAlumno(int cantAlumnos,int anio_ingreso,int cod_alumno,
        int nota,int aa,int mm,int dd,ofstream &archReporte){
    archReporte<<setw(8)<<' '<<setfill('0')<<setw(3)<<cantAlumnos
            <<setfill(' ')<<setw(5)<<' '<<anio_ingreso<<setw(4)
            <<left<<cod_alumno<<setfill(' ');
    archReporte<<right;
    archReporte<<setw(20)<<' '<<setfill('0')<<setw(2)<<nota<<setfill(' ')
            <<setw(4)<<' '<<aa<<'/'<<setfill('0')<<setw(2)<<mm<<'/'
            <<setw(2)<<dd<<setfill(' ')<<endl;
    
}
void imprimeSubTitulo(ofstream &archReporte){
    archReporte<<setw(8)<<' '<<"RELACION DE ALUMNOS:"<<endl;
    archReporte<<setw(8)<<' '<<"No."<<setw(5)<<' '<<"CODIGO DEL ALUMNO"
            <<setw(10)<<' '<<"NOTA"<<setw(5)<<' '<<"FECHA"<<endl;
    imprimeLinea('-',MAX_LINE,archReporte);
}

void leeImprimeCursos(int &cant_cursos,int &cod_especialidad,int &cod_curso,
        double &creditos,ifstream &archCursos,ofstream &archReporte){
    
    archCursos>>cod_especialidad;
    if(archCursos.eof())return;
    archCursos>>cod_curso;
    archCursos>>creditos;
    cant_cursos++;
    archReporte<<setfill('0')<<setw(2)<<cant_cursos<<')'<<setfill(' ');
    archReporte<<setw(5)<<' '<<"Curso: ";
    imprimeNombreCurso(archCursos,archReporte);
    archReporte<<"Especialidad:"<<setw(4)<<cod_especialidad;
    archReporte<<setw(10)<<' '<<"Codigo:"<<setw(6)<<cod_curso;
    archReporte<<setw(10)<<' '<<"Creditos:"<<setw(6)<<creditos<<endl;
    imprimeLinea('-',MAX_LINE,archReporte);
}

void imprimeNombreCurso(ifstream &archCursos,ofstream &archReporte){
    
    char curso;
    int cantCaracteres=0;    
    archCursos>>ws;
    while(true){
        curso=archCursos.get();
        if(curso=='\n')break;
        archReporte.put(curso);
        cantCaracteres++;
    }
    for(int i=0;i<MAX_CAR-cantCaracteres;i++)archReporte.put(' ');
}

void imprimeEncabezado(ofstream &archReporte){
    archReporte<<setw(50)<<' '<<"INFORMACION ACADEMICA"<<endl;
    archReporte<<setw(35)<<' '<<"RELACION DE ALUMNOS QUE SE MATRICULAN POR"
            "CURSO"<<endl;
}

void imprimeLinea(char caracter,int cantidad, ofstream &archReporte){
    for(int i=0;i<cantidad;i++)archReporte.put(caracter);
    archReporte.put('\n');
}