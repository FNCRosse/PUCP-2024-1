

/* 
 * File:   main.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 12 de abril de 2023, 12:53 PM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#include "funciones.h"

/*
 * 
 */
int main(int argc, char** argv) {
    
    ifstream archCursos("Cursos.txt",ios::in);
    if(not archCursos.is_open()){
        cout<<"No se pudo abrir el archivo de cursos"<<endl;
        exit(1);
    }
    ifstream archAlumnos("Alumnos-Notas.txt",ios::in);
    if(not archAlumnos.is_open()){
        cout<<"No se pudo abrir el archivo de Alumnos"<<endl;
        exit(1);
    }
    ofstream archReporte("reporte.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"No se pudo abrir el archivo de reporte"<<endl;
        exit(1);
    }
    
    emiteReporte(archCursos,archAlumnos,archReporte);
    
    return 0;
}

