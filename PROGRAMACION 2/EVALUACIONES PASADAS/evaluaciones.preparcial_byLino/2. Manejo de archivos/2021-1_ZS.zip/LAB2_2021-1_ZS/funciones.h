

/* 
 * File:   funciones.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 19 de abril de 2023, 10:43 AM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void emiteReporte(ifstream &archCursos,ifstream &archAlumnos,
        ofstream &archReporte);
void imprimeCursoMasAprob(int cant_cursos,double mayorPorcenAprob,int codMayor,
        int cod_CursoMayor,ifstream &archCursos,ofstream &archReporte);
void buscaImprimeCurso(ifstream &archCursos,int codMayor,int cod_CursoMayor,
        ofstream &archReporte);
void imprimeResumen(int cantAlumnos,int notaMayor,int notaMenor,int cantAprob,
        int cantDesaprob,ofstream &archReporte);
void imprimeResumen(int cantAlumnos,int notaMayor,int notaMenor,int cantAprob,
        int cantDesaprob,ofstream &archReporte);
void leeImprimeRelaciones(int &cantAlumnos,int &notaMayor,int &notaMenor,
        int &cantAprob,int &cantDesaprob,int cod_especialidad,int cod_curso,
        double &mayorPorcenAprob,int &codMayor,int &cod_CursoMayor,
        ifstream &archAlumnos,ofstream &archReporte);
void analizaCursoMayorAprob(int codEspec_alumno,int cod_curso,int &codMayor,
        int &cod_CursoMayor,double porcenAprob,double &mayorPorcenAprob);
void analizaNotaMaxYmin(int nota,int &notaMayor,int &notaMenor);
void analizaAprobadosYdesaprobados(int nota,int &cantAprob,int &cantDesaprob);
void imprimeDatosAlumno(int cantAlumnos,int anio_ingreso,int cod_alumno,
        int nota,int aa,int mm,int dd,ofstream &archReporte);
void imprimeSubTitulo(ofstream &archReporte);
void leeImprimeCursos(int &cant_cursos,int &cod_especialidad,int &cod_curso,
        double &creditos,ifstream &archCursos,ofstream &archReporte);
void imprimeNombreCurso(ifstream &archCursos,ofstream &archReporte);
void imprimeEncabezado(ofstream &archReporte);
void imprimeLinea(char caracter,int cantidad, ofstream &archReporte);


#endif /* FUNCIONES_H */

