

/* 
 * File:   funciones.cpp
 * Author: chupetin
 *
 * Created on 16 de abril de 2023, 06:17 PM
 */


#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#include "funciones.h"
#define MAX_LINE 200
#define MAX_CAR 60
#define CAR_PAIS 10

void emiteReporte(ifstream &archProd,ifstream &archPedid,ifstream &archCli,
        ifstream &archCateg,ifstream &archImpu,ofstream &archRep){
    
    int cod_prod;
    double desc_prod,precUni,subTotal,totalAbsoluto=0;
    imprimeTitulos(archRep);
    archRep<<setprecision(2);
    archRep<<fixed;
    while(true){
        leeImprimeProductos(cod_prod,precUni,desc_prod,archProd,archRep);
        if(archProd.eof())break;
        leeImprimeListadoPedidos(cod_prod,precUni,desc_prod,subTotal,
                archPedid,archCli,archCateg,archImpu,archRep);
        imprimeLinea('-',MAX_LINE,archRep);
        totalAbsoluto+=subTotal;
        archRep<<"Total por producto:"<<setw(12)<<subTotal<<endl;
    }
    imprimeLinea('=',MAX_LINE,archRep);
    archRep<<"TOTAL DE PEDIDOS:"<<setw(15)<<totalAbsoluto<<endl;
    imprimeLinea('=',MAX_LINE,archRep);
}

void leeImprimeListadoPedidos(int cod_prod,double precUni,double desc_prod,
        double &subTotal,ifstream &archPedid,ifstream &archCli,ifstream &archCateg,
        ifstream &archImpu,ofstream &archRep){
    
    int cod_pedido,dni,codProd_evaluar,id_pais;
    double cantidad,descuento_categoria,impuesto,total;
    char categoria;
    archPedid.clear();
    archPedid.seekg(0,ios::beg);
    imprimeEncabezado(archRep);
    subTotal=0;
    while(true){
        archPedid>>cod_pedido;
        if(archPedid.eof())break;
        archPedid>>dni;
        while(true){
            archPedid>>codProd_evaluar;
            archPedid>>cantidad;
            if(codProd_evaluar==cod_prod){
                archRep<<setw(4)<<' '<<cod_pedido;
                leeImprimeDatosCliente(dni,categoria,id_pais,archCli,archRep); 
                leeImprimeDescuento(categoria,descuento_categoria,archCateg,archRep);
                leeImprimePais(id_pais,impuesto,archImpu,archRep);
                archRep<<setw(10)<<' '<<setw(6)<<cantidad;
                calculaImprimeTotal(descuento_categoria,desc_prod,impuesto,
                        precUni,cantidad,total,archRep);
                subTotal+=total;
            }
            if(archPedid.get()=='\n')break;
        }
    }
}

void calculaImprimeTotal(double descuento_categoria,double desc_prod,
        double impuesto,double precUni,double cantidad,double &total,
        ofstream &archRep){
    
    total = precUni*cantidad;
    total = total-(total)*(descuento_categoria+desc_prod); 
    total = total + (total)*(impuesto);
    archRep<<setw(10)<<' '<<setw(8)<<total<<endl;
}

void leeImprimePais(int id_pais,double &impuesto,ifstream &archImpu,ofstream &archRep){
    archImpu.clear();
    archImpu.seekg(0,ios::beg);
    
    int id_evaluar;
    while(true){
        archImpu>>id_evaluar;
        if(archImpu.eof())break;
        if(id_evaluar==id_pais){
            archRep<<setw(4)<<' '<<id_pais<<'-';
            leeImprimePais(archImpu,archRep);
            archImpu>>impuesto;
            archRep<<impuesto*100;
        }else
            while(archImpu.get()!='\n');
    }
}

void leeImprimePais(ifstream &archImpu,ofstream &archRep){
    char pais;
    int cantCarac=0;
    archImpu>>ws;
    while(true){
        pais=archImpu.get();
        if(pais==' ')break;
        archRep.put(pais);
        cantCarac++;
    }
    for(int i=0;i<CAR_PAIS-cantCarac;i++)archRep.put(' ');
}

void leeImprimeDescuento(char categoria,double &descuento_categoria,
        ifstream &archCateg,ofstream &archRep){
    
    archCateg.clear();
    archCateg.seekg(0,ios::beg);
    
    char categoria_evauar;
    while(true){
        archCateg>>categoria_evauar;
        if(archCateg.eof())break;
        if(categoria==categoria_evauar){
            archCateg>>ws;
            while(archCateg.get()!=' ');
            archCateg>>descuento_categoria;
            archRep<<setw(20)<<' '<<descuento_categoria*100;
        }else
            while(archCateg.get()!='\n');
    }
}

void leeImprimeDatosCliente(int dni,char &categoria,int &id_pais,
        ifstream &archCli,ofstream &archRep){
    
    archCli.clear();
    archCli.seekg(0,ios::beg);
    
    int dni_evaluar,ciudad,num_telef,dd,mm,aa;
    char c;
    while(true){
        archCli>>dni_evaluar;
        if(archCli.eof())break;
        if(dni_evaluar==dni){
            archRep<<setw(4)<<' '<<dni<<"-";
            leeImprimeCliente(archCli,archRep);
            archCli>>ciudad>>id_pais>>num_telef;
            archCli>>dd>>c>>mm>>c>>aa;
            archCli>>categoria;
            archRep<<categoria;
        }else
            while(archCli.get()!='\n');
    }
}

void leeImprimeCliente(ifstream &archCli,ofstream &archRep){
    char nombre;
    int numCarac=0;
    
    archCli>>ws;
    while(true){
        nombre=archCli.get();
        if(nombre==' ')break;
        if(nombre=='_')nombre=' ';
        archRep.put(nombre);
        numCarac++;
    }
    for(int i=0;i<MAX_CAR-numCarac;i++)archRep.put(' ');
}

void leeImprimeProductos(int &cod_prod,double &precUni,double &desc_prod,
        ifstream &archProd,ofstream &archRep){
    
    
    imprimeLinea('=',MAX_LINE,archRep);
    archProd>>cod_prod;
    if(archProd.eof())return;
    archRep<<setw(5)<<' '<<"Producto:"<<setw(5)<<cod_prod<<" - ";
    imprimeNombreProducto(archProd,archRep);
    archProd>>precUni>>desc_prod;
    archRep<<setw(10)<<' '<<"Precio Unitario:"<<setw(7)<<precUni;
    archRep<<setw(10)<<' '<<"Descuento:"<<setw(6)<<desc_prod*100<<'%'<<endl;
}

void imprimeEncabezado(ofstream &archRep){
    imprimeLinea('-',MAX_LINE,archRep);
    archRep<<setw(5)<<' '<<"LISTADO DE PEDIDOS"<<endl;
    archRep<<setw(4)<<' '<<"Codigo"<<setw(10)<<' '<<"Cliente"<<setw(52)
            <<' '<<"Categoria"<<setw(10)<<' '<<"%Descuento"<<setw(5)
            <<' '<<"Pais"<<setw(5)<<' '<<"%Impuesto"<<setw(7)
            <<' '<<"Cantidad"<<setw(12)
            <<' '<<"Total"<<endl;
    imprimeLinea('-',MAX_LINE,archRep);
}

void imprimeNombreProducto(ifstream &archProd, ofstream &archRep){
    
    char producto;
    int cantCarac=0;
    
    while(archProd.get()!='"');
    
    while(true){
        producto=archProd.get();
        if(producto=='"')break;
        producto-=(producto<='z' and producto>='a')?'a'-'A':0;
        archRep.put(producto);
        cantCarac++;
    }
    
    for(int i=0;i<MAX_CAR-cantCarac;i++)
        archRep.put(' ');
}

void imprimeTitulos(ofstream &archRep){
    archRep<<setw(50)<<' '<<"EMPRESA COMERCIALIZADORA ABC S.A."<<endl;
    archRep<<setw(55)<<' '<<"PEDIDOS POR PRODUCTO"<<endl;
}

void imprimeLinea(char caracter,int cantidad, ofstream &archRep){
    for(int i=0;i<cantidad;i++)archRep.put(caracter);
    archRep.put('\n');
}