

/* 
 * File:   funciones.h
 * Author: chupetin
 *
 * Created on 16 de abril de 2023, 06:18 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void emiteReporte(ifstream &archProd,ifstream &archPedid,ifstream &archCli,
        ifstream &archCateg,ifstream &archImpu,ofstream &archRep);
void leeImprimeListadoPedidos(int cod_prod,double precUni,double desc_prod,
        double &subTotal,ifstream &archPedid,ifstream &archCli,ifstream &archCateg,
        ifstream &archImpu,ofstream &archRep);
void calculaImprimeTotal(double descuento_categoria,double desc_prod,
        double impuesto,double precUni,double cantidad,double &total,
        ofstream &archRep);
void leeImprimePais(int id_pais,double &impuesto,ifstream &archImpu,ofstream &archRep);
void leeImprimePais(ifstream &archImpu,ofstream &archRep);
void leeImprimeDescuento(char categoria,double &descuento_categoria,
        ifstream &archCateg,ofstream &archRep);
void leeImprimeDatosCliente(int dni,char &categoria,int &id_pais,
        ifstream &archCli,ofstream &archRep);
void leeImprimeCliente(ifstream &archCli,ofstream &archRep);
void leeImprimeProductos(int &cod_prod,double &precUni,double &desc_prod,
        ifstream &archProd,ofstream &archRep);
void imprimeEncabezado(ofstream &archRep);
void imprimeNombreProducto(ifstream &archProd, ofstream &archRep);
void imprimeTitulos(ofstream &archRep);
void imprimeLinea(char caracter,int cantidad, ofstream &archRep);


#endif /* FUNCIONES_H */

