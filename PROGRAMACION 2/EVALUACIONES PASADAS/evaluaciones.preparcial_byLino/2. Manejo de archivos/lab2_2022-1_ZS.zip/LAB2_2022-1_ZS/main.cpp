

/* 
 * File:   main.cpp
 * Author: chupetin
 *
 * Created on 12 de abril de 2023, 01:01 PM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#include "funciones.h"
/*
 * 
 */
int main(int argc, char** argv) {
    
    ifstream archCli("Clientes.txt",ios::in);
    if(not archCli.is_open()){
        cout<<"ERROR al abrir el archivo clientes"<<endl;
        exit(1);
    }
    ifstream archProd("Productos.txt",ios::in);
    if(not archProd.is_open()){
        cout<<"ERROR al abrir el archivo Productos"<<endl;
        exit(1);
    }
    ifstream archPedid("Pedidos.txt",ios::in);
    if(not archPedid.is_open()){
        cout<<"ERROR al abrir el archivo Pedidos"<<endl;
        exit(1);
    }
    ifstream archCateg("Categorias.txt",ios::in);
    if(not archCateg.is_open()){
        cout<<"ERROR al abrir el archivo Categorias"<<endl;
        exit(1);
    }
    ifstream archImpu("Impuestos.txt",ios::in);
    if(not archImpu.is_open()){
        cout<<"ERROR al abrir el archivo Impuestos"<<endl;
        exit(1);
    }
    ofstream archRep("ReportePorProducto.txt",ios::out);
    if(not archRep.is_open()){
        cout<<"ERROR al abrir el archivo ReportePorProducto"<<endl;
        exit(1);
    }
    
    emiteReporte(archProd,archPedid,archCli,archCateg,archImpu,archRep);
    return 0;
}

