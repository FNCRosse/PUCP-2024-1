

/* 
 * File:   main.cpp
 * Author: chupetin
 *
 * Created on 12 de abril de 2023, 01:00 PM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;


#include "funciones.h"
/*
 * 
 */
int main(int argc, char** argv) {
    
    ifstream archAtenciones("AtencionesMedicas.txt",ios::in);
    if(not archAtenciones.is_open()){
        cout<<"ERROR en el archivo de atenciones"<<endl;
        exit(1);
    }
    ifstream archMedicos("Medicos.txt",ios::in);
    if(not archMedicos.is_open()){
        cout<<"ERROR en el archivo de Medicos"<<endl;
        exit(1);
    }
    ofstream archReporte("ReporteDeIngresos.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR en el archivo de ReporteDeIngresos"<<endl;
        exit(1);
    }
    
    emiteReporte(archMedicos,archAtenciones,archReporte);
    
    return 0;
}

