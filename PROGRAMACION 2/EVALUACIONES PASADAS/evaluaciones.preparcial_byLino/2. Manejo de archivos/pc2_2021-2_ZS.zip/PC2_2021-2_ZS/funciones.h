

/* 
 * File:   funciones.h
 * Author: chupetin
 *
 * Created on 12 de abril de 2023, 04:54 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H


void emiteReporte(ifstream &archMedicos,ifstream &archAtenciones,
        ofstream &archReporte);
void imprimeResumenFinal(double remuneracionTotal,double impuestoTotal,
        ofstream &archReporte);
void leeImprimeDatosConsultas(int codigo_medico,double tarifa,
        double &remuneracionParcial,double &impuestoParcial,
        ifstream &archAtenciones,ofstream &archReporte);
void calculaImpuesto(double remuneracionParcial,double &impuestoParcial);
void calculaImprimeMonto(int duracionMinuto,int duracionSegundo,double &monto,
        double tarifa,ofstream &archReporte);
void imprimeDatosConsultas(int dd,int mm,int aa,int hhIng,int mmIng,int ssIng,
        int hhSal,int mmSal,int ssSal,int duracionMinuto,int duracionSegundo,
        int cod_paciente,ofstream &archRep);
void calculaDuraciones(int hhIng,int mmIng,int ssIng,int hhSal,int mmSal,
        int ssSal,int &duracionMinuto,int &duracionSegundo);
void leerHora(ifstream &archAtenciones,int &hora,int &minuto,int &segundo);
void imprimeEncabezado(ofstream &archReporte);
void leeImprimeDatosMedico(int &codigo_medico,double &tarifa,
        ifstream &archMedicos,ofstream &archReporte);
void imprimeDatosConsultas(int dd,int mm,int aa,int hhIng,int mmIng,int ssIng,
        int hhSal,int mmSal,int ssSal,int duracionMinuto,int duracionSegundo,
        int cod_paciente,ofstream &archRep);
void imprimeNombreEspecialidad(ifstream &archMedicos,ofstream &archReporte);
void imprimeNombreMedico(ifstream &archMedicos,ofstream &archReporte);
void imprimeTitulos(ofstream &archReporte);
void imprimeLinea(char caracter,int cantidad, ofstream &archReporte);


#endif /* FUNCIONES_H */

