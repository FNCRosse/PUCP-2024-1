

/* 
 * File:   funciones.cpp
 * Author: chupetin
 *
 * Created on 12 de abril de 2023, 04:54 PM
 */


#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

#include "funciones.h"
#define MAX_LINE 150
#define MAX_CAR 50

void emiteReporte(ifstream &archMedicos,ifstream &archAtenciones,
        ofstream &archReporte){
    imprimeTitulos(archReporte);
    
    int codigo_medico;
    double tarifa,remuneracionParcial,remuneracionTotal=0,impuestoParcial,
            impuestoTotal=0;
    archReporte<<setprecision(2);
    archReporte<<fixed;
    while(true){
        imprimeLinea('=',MAX_LINE,archReporte);
        leeImprimeDatosMedico(codigo_medico,tarifa,archMedicos,archReporte);
        if(archMedicos.eof())break;
        imprimeLinea('-',MAX_LINE,archReporte);
        imprimeEncabezado(archReporte);
        imprimeLinea('-',MAX_LINE,archReporte);
        leeImprimeDatosConsultas(codigo_medico,tarifa,remuneracionParcial,
                impuestoParcial,archAtenciones,archReporte);
        remuneracionTotal+=remuneracionParcial;
        imprimeLinea('-',MAX_LINE,archReporte);
        impuestoTotal+=impuestoParcial;
        archReporte<<"REMUNERACION TOTAL RECIBIDA:"<<setw(10)<<' '<<"S/."
                <<setw(10)<<remuneracionParcial<<endl;
        archReporte<<"IMPUESTO A PAGAR:"<<setw(21)<<' '<<"S/."
                <<setw(10)<<impuestoParcial<<endl;
    }
    imprimeResumenFinal(remuneracionTotal,impuestoTotal,archReporte);
}

void imprimeResumenFinal(double remuneracionTotal,double impuestoTotal,
        ofstream &archReporte){
    archReporte<<"INGRESO TOTAL DE TODOS LOS MEDICOS:"<<setw(12)<<' '<<"S/."
        <<setw(15)<<remuneracionTotal<<endl;
    archReporte<<"IMPUESTO A PAGAR:"<<setw(30)<<' '<<"S/."<<setw(15)
            <<impuestoTotal<<endl;
    imprimeLinea('=',MAX_LINE,archReporte);
}

void leeImprimeDatosConsultas(int codigo_medico,double tarifa,
        double &remuneracionParcial,double &impuestoParcial,
        ifstream &archAtenciones,ofstream &archReporte){
    
    archAtenciones.clear();
    archAtenciones.seekg(0,ios::beg);
    
    int codMed_evaluar,dd,mm,aa,cod_paciente,hhIng,mmIng,ssIng,hhSal,mmSal,
            ssSal,duracionMinuto,duracionSegundo;
    double monto;
    remuneracionParcial=0,impuestoParcial=0;    
    char c;
    while(true){
        archAtenciones>>codMed_evaluar;
        if(archAtenciones.eof())break;
        archAtenciones>>dd>>c>>mm>>c>>aa;
        if(codMed_evaluar==codigo_medico){
            while(true){
                archAtenciones>>cod_paciente;
                leerHora(archAtenciones,hhIng,mmIng,ssIng);
                leerHora(archAtenciones,hhSal,mmSal,ssSal);
                calculaDuraciones(hhIng,mmIng,ssIng,hhSal,mmSal,ssSal,
                        duracionMinuto,duracionSegundo);
                imprimeDatosConsultas(dd,mm,aa,hhIng,mmIng,ssIng,hhSal,mmSal,ssSal,
                        duracionMinuto,duracionSegundo,cod_paciente,archReporte);
                calculaImprimeMonto(duracionMinuto,duracionSegundo,monto,tarifa,
                        archReporte);
                remuneracionParcial+=monto;
                if(archAtenciones.get()=='\n')break;
            }
        }else
            while(archAtenciones.get()!='\n');
    }
    calculaImpuesto(remuneracionParcial,impuestoParcial);
}

void calculaImpuesto(double remuneracionParcial,double &impuestoParcial){
    
    if(remuneracionParcial<=5575.25){
        impuestoParcial= (remuneracionParcial*15.5)/100;
    }else if(remuneracionParcial>=5575.25 and remuneracionParcial<=15685.83){
        impuestoParcial = (5575.25*15.5)/100 +
                ((remuneracionParcial-5575.25)*23.20/100);
    }else if(remuneracionParcial>=15685.83){
        impuestoParcial =(5575.25*15.5)/100 +
                ((15685.83-5575.25)*23.2)/100 + 
                ((remuneracionParcial-15685.83)*35.7)/100;
    }
}

void calculaImprimeMonto(int duracionMinuto,int duracionSegundo,double &monto,
        double tarifa,ofstream &archReporte){
    
    monto=tarifa*duracionMinuto;
    if(duracionSegundo>0)monto=tarifa*(duracionMinuto+1);
    
    archReporte<<setw(12)<<' '<<setw(8)<<monto<<endl;
}

void imprimeDatosConsultas(int dd,int mm,int aa,int hhIng,int mmIng,int ssIng,
        int hhSal,int mmSal,int ssSal,int duracionMinuto,int duracionSegundo,
        int cod_paciente,ofstream &archRep){
    archRep<<setw(7)<<' '<<setfill('0')<<setw(2)<<dd<<'/'<<setw(2)<<mm<<'/'
            <<setw(4)<<aa<<setfill(' ');
    archRep<<setw(7)<<' '<<setfill('0')<<setw(2)<<hhIng<<':'<<setw(2)<<mmIng
            <<':'<<setw(2)<<ssIng<<setfill(' ');
    archRep<<setw(9)<<' '<<setfill('0')<<setw(2)<<hhSal<<':'<<setw(2)<<mmSal
            <<':'<<setw(2)<<ssSal<<setfill(' ');
    archRep<<setw(11)<<' '<<setfill('0')<<setw(2)<<duracionMinuto<<':'
            <<setw(2)<<duracionSegundo<<setfill(' ');
    archRep<<setw(11)<<' '<<cod_paciente;
}

void calculaDuraciones(int hhIng,int mmIng,int ssIng,int hhSal,int mmSal,
        int ssSal,int &duracionMinuto,int &duracionSegundo){
    int duracionTotal = (hhSal*3600+mmSal*60+ssSal)-
    (hhIng*3600+mmIng*60+ssIng);
    
    duracionMinuto=duracionTotal/60;
    duracionSegundo=(duracionTotal%60);
}

void leerHora(ifstream &archAtenciones,int &hora,int &minuto,int &segundo){
    
    char c;
    archAtenciones>>hora;
    c=archAtenciones.get();
    if(c!=':'){
        if(c=='\n')archAtenciones.unget();
        minuto=0;
        segundo=0;
    }else{
        archAtenciones>>minuto;
        c=archAtenciones.get();
        if(c!=':'){
            if(c=='\n')archAtenciones.unget();
            segundo=0;
        }else
            archAtenciones>>segundo;
    }
}

void imprimeEncabezado(ofstream &archReporte){
    archReporte<<setw(40)<<' '<<"RELACION DE CONSULTAS REALIZADAS"<<endl;
    archReporte<<setw(10)<<' '<<"FECHA"<<setw(10)<<' '<<"INGRESO"
            <<setw(10)<<' '<<"SALIDA"<<setw(10)<<' '<<"DURACION"
            <<setw(10)<<' '<<"PACIENTE"<<setw(10)<<' '<<"MONTO PAGADO"<<endl;
}

void leeImprimeDatosMedico(int &codigo_medico,double &tarifa,
        ifstream &archMedicos,ofstream &archReporte){
    
    archMedicos>>codigo_medico;
    if(archMedicos.eof())return;
    archReporte<<setw(5)<<' '<<"Nombre:       ";
    imprimeNombreMedico(archMedicos,archReporte);
    archReporte<<"Codigo:"<<setw(6)<<codigo_medico<<endl;
    archMedicos>>tarifa;
    archReporte<<setw(5)<<' '<<"Especialidad: ";
    imprimeNombreEspecialidad(archMedicos,archReporte);
    archReporte<<"Tarifa: S/."<<setw(6)<<tarifa<<" por minuto o fraccion"<<endl;
}

void imprimeNombreEspecialidad(ifstream &archMedicos,ofstream &archReporte){
    
    char especialidad;
    int numCar=0;
    archMedicos>>ws;
    while(true){
        especialidad=archMedicos.get();
        if(especialidad=='\n')break;
        archReporte.put(especialidad);
        numCar++;
    }
    for(int i=0;i<MAX_CAR-numCar;i++)archReporte.put(' ');
}

void imprimeNombreMedico(ifstream &archMedicos,ofstream &archReporte){
    
    char medico;
    int numCar=0,primeraLetra=1;
    archMedicos>>ws;
    while(true){
        medico=archMedicos.get();
        if(medico==' ')break;
        
        if(medico!='_' and primeraLetra)primeraLetra=0;
        else if(medico!='_' and !primeraLetra)medico+='a'-'A';
        else if(medico=='_'){
            medico=' ';
            primeraLetra=1;
        }
        archReporte.put(medico);
        numCar++;
    }
    for(int i=0;i<MAX_CAR-numCar;i++)archReporte.put(' ');
}

void imprimeTitulos(ofstream &archReporte){
    archReporte<<setw(50)<<' '<<"EMPRESA PRESTADORA DE SALUD"<<endl;
    archReporte<<setw(35)<<' '<<"LISTADOS DE INGRESOS DE LOS MEDICOS"
            "E IMPUESTOS QUE DEBEN PAGAR"<<endl;
}

void imprimeLinea(char caracter,int cantidad, ofstream &archReporte){
    for(int i=0;i<cantidad;i++)archReporte.put(caracter);
    archReporte.put('\n');
}

