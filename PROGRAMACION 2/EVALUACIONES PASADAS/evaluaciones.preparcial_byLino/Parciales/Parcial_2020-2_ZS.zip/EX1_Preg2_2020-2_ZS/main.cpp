

/* 
 * File:   main.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 13 de mayo de 2023, 08:33 AM
 */

#include <iostream>
#include <fstream>
#include <iomanip>


using namespace std;

#define MAX_AUTORES 100
#define MAX_LIBROS 300
#include "funciones.h"

/*
 * 
 */
int main(int argc, char** argv) {
    
    int arrCodAutores[MAX_AUTORES],arrLibrosPorAutor[MAX_AUTORES]{},
            numAutores;
    double arrRegalias[MAX_AUTORES]{};
    
    int arrCodLibro[MAX_LIBROS],arrLibrosVendidos[MAX_LIBROS]{},numLibros;
    double arrPrecioLibro[MAX_LIBROS],arrRecaudadoLibros[MAX_LIBROS]{};
    
    leerAutores(arrCodAutores,numAutores);
    
    leerLibros(arrCodLibro,arrPrecioLibro,numLibros);
    
    leerVentas(arrCodAutores,arrLibrosPorAutor,arrRegalias,numAutores,
            arrCodLibro,arrLibrosVendidos,arrPrecioLibro,arrRecaudadoLibros,
            numLibros);
    
    ordenarLibros(arrCodLibro,arrLibrosVendidos,arrPrecioLibro,
            arrRecaudadoLibros,numLibros);
    
    emiteReporte(arrCodAutores,arrLibrosPorAutor,arrRegalias,numAutores,
            arrCodLibro,arrLibrosVendidos,arrPrecioLibro,arrRecaudadoLibros,
            numLibros);
    return 0;
}

