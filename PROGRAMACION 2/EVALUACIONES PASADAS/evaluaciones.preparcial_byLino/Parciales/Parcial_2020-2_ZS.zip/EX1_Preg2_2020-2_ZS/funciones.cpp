

/* 
 * File:   funciones.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 13 de mayo de 2023, 02:15 PM
 */


#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;


#define MAX_NOMBRE 50
#define MAX_LINE 120
#define NO_ENCONTRADO -1
#include "funciones.h"

void leerAutores(int *arrCodAutores,int &numAutores){
    
    ifstream archAutores("Autores.txt",ios::in);
    if(not archAutores.is_open()){
        cout<<"ERROR al abrir el archivo de autores"<<endl;
        exit(1);
    }
    
    int codigo_autor;
    numAutores=0;
    
    while(true){
        archAutores>>codigo_autor;
        if(archAutores.eof())break;
        archAutores>>ws;
        while(archAutores.get()!='\n');
        
        arrCodAutores[numAutores]=codigo_autor;
        numAutores++;
    }
}

void leerLibros(int *arrCodLibro,double *arrPrecioLibro,int &numLibros){
    
    ifstream archLibros("Libros.txt",ios::in);
    if(not archLibros.is_open()){
        cout<<"ERROR al abrir el archivo de Libros"<<endl;
        exit(1);
    }
    
    int codLibro;
    double precioLibro;
    numLibros=0;
    
    while(true){
        archLibros>>codLibro;
        if(archLibros.eof())break;
        archLibros>>ws;
        while(archLibros.get()!=' ');
        archLibros>>precioLibro;
        
        arrCodLibro[numLibros]=codLibro;
        arrPrecioLibro[numLibros]=precioLibro;
        
        numLibros++;
    }
}

void leerVentas(int *arrCodAutores,int *arrLibrosPorAutor,double *arrRegalias,
        int numAutores,int *arrCodLibro,int *arrLibrosVendidos,
        double *arrPrecioLibro,double *arrRecaudadoLibros,int numLibros){
    
    ifstream archVentas("Ventas.txt",ios::in);
    if(not archVentas.is_open()){
        cout<<"ERROR al abrir el archivo de Ventas"<<endl;
        exit(1);
    }
    
    int codigo_libreria,codLibro_evaluar,cantidadLibro_vendida,
            codigoAutor_evaluar,posLibro,posAutor;
    double porcentaje_regalia;
    
    while(true){
        archVentas>>codigo_libreria;
        if(archVentas.eof())break;
        archVentas>>codLibro_evaluar;
        archVentas>>cantidadLibro_vendida;
        posLibro=buscarPosicion(arrCodLibro,codLibro_evaluar,numLibros);
        if(posLibro!=NO_ENCONTRADO){
            arrLibrosVendidos[posLibro]+=cantidadLibro_vendida;
            arrRecaudadoLibros[posLibro]=arrLibrosVendidos[posLibro]*
                    arrPrecioLibro[posLibro];
            while(true){
                archVentas>>codigoAutor_evaluar;
                archVentas>>porcentaje_regalia;
                posAutor=buscarPosicion(arrCodAutores,codigoAutor_evaluar,numAutores);
                if(posAutor!=NO_ENCONTRADO){
                    arrLibrosPorAutor[posAutor]+=cantidadLibro_vendida;
                    arrRegalias[posAutor]=(porcentaje_regalia*
                            arrLibrosPorAutor[posAutor])/100;
                }
                if(archVentas.get()=='\n')break;
            }
        }else while(archVentas.get()!='\n');
    }
}

void ordenarLibros(int *arrCodLibro,int *arrLibrosVendidos,double *arrPrecioLibro,
            double *arrRecaudadoLibros,int numLibros){
    for(int i=0;i<numLibros-1;i++)
        for(int k=i+1;k<numLibros;k++)
            if(arrLibrosVendidos[i]>arrLibrosVendidos[k] or 
                    arrLibrosVendidos[i]==arrLibrosVendidos[k] and
                    arrRecaudadoLibros[i]<arrRecaudadoLibros[k]){
                interCambiarInt(arrCodLibro,i,k);
                interCambiarInt(arrLibrosVendidos,i,k);
                interCambiarDouble(arrPrecioLibro,i,k);
                interCambiarDouble(arrRecaudadoLibros,i,k);
            }
}

void emiteReporte(int *arrCodAutores,int *arrLibrosPorAutor,double *arrRegalias,
        int numAutores,int *arrCodLibro,int *arrLibrosVendidos,
        double *arrPrecioLibro,double *arrRecaudadoLibros,int numLibros){
    
    ofstream archReporte("ReporteDeIngresosYPagos.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR al abrir el archivo de ReporteDeIngresosYPagos"<<endl;
        exit(1);
    }
    archReporte<<setw(50)<<' '<<"EDITORIAL TP Horario 0431"<<endl;
    archReporte<<setprecision(2);
    archReporte<<fixed;
    archReporte<<"PAGO A LOS AUTORES:"<<endl;
    imprimeLinea('-',MAX_LINE,archReporte);
    archReporte<<"CODIGO"<<setw(6)<<' '<<"NOMBRE"<<setw(40)<<' '
            <<"LIBROS VENDIDOS"<<setw(10)<<' '<<"REGALIAS"<<endl;
    imprimeLinea('-',MAX_LINE,archReporte);
    double totalRegalias=0,totalRecaudadoLibros=0;
    for(int i=0;i<numAutores;i++){
        archReporte<<arrCodAutores[i]<<setw(6)<<' ';
        buscaNombreAutor(arrCodAutores[i],archReporte);
        archReporte<<setw(5)<<arrLibrosPorAutor[i]<<setw(14)<<' '<<setw(10)
                <<arrRegalias[i]<<endl;
        totalRegalias+=arrRegalias[i];
    }
    imprimeLinea('-',MAX_LINE,archReporte);
    archReporte<<"Total a pagar por regalias: "<<setw(15)<<totalRegalias<<endl;
    imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<"RECAUDACION POR LIBROS VENDIDOS:"<<endl;
    imprimeLinea('-',MAX_LINE,archReporte);
    archReporte<<"CODIGO"<<setw(10)<<' '<<"LIBROS VENDIDOS"<<setw(10)
            <<' '<<"TOTAL RECAUDADO"<<endl;
    imprimeLinea('-',MAX_LINE,archReporte);
    for(int i=0;i<numLibros;i++){
        archReporte<<arrCodLibro[i]<<setw(10)<<' '<<setw(5)<<arrLibrosVendidos[i]
                <<setw(18)<<' '<<setw(12)<<arrRecaudadoLibros[i]<<endl;
        totalRecaudadoLibros+=arrRecaudadoLibros[i];
    }
    imprimeLinea('-',MAX_LINE,archReporte);
    archReporte<<"Total de recaudado: "<<setw(12)<<totalRecaudadoLibros<<endl;
}

void buscaNombreAutor(int codigo_autor,ofstream &archReporte){
    
    ifstream archAutores("Autores.txt",ios::in);
    if(not archAutores.is_open()){
        cout<<"ERROR al abrir el archivo de autores"<<endl;
        exit(1);
    }
    
    int autor;
    
        while(true){
        archAutores>>autor;
        if(archAutores.eof())break;
        if(autor==codigo_autor){
            imprimeNombre(archAutores,archReporte);
        }else while(archAutores.get()!='\n');
    }
}

void imprimeNombre(ifstream &archAutores,ofstream &archReporte){
    
    char autor;
    int numCar=0;
    archAutores>>ws;
    while(true){
        autor=archAutores.get();
        if(autor=='\n')break;
        archReporte.put(autor);
        numCar++;
    }
    
    for(int i=0;i<MAX_NOMBRE-numCar;i++)archReporte<<' ';
}

int buscarPosicion(int *arreglo,int elemento,int numDatos){
    for(int i=0;i<numDatos;i++)
        if(arreglo[i]==elemento)return i;
    
    return NO_ENCONTRADO;
}

void interCambiarInt(int *arreglo,int i,int j){
    int aux = arreglo[i];
    arreglo[i]=arreglo[j];
    arreglo[j]=aux;
}

void interCambiarDouble(double *arreglo,int i,int j){
    double aux = arreglo[i];
    arreglo[i]=arreglo[j];
    arreglo[j]=aux;
}

void imprimeLinea(char caracter, int cantidad, ofstream &archRep){
    for(int i=0;i<cantidad;i++)archRep<<caracter;
    archRep<<endl;
}