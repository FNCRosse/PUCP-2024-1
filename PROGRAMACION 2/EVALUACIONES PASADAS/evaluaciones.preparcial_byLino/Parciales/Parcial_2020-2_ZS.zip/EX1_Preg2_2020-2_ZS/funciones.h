

/* 
 * File:   funciones.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 13 de mayo de 2023, 02:15 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void leerAutores(int *arrCodAutores,int &numAutores);
void leerLibros(int *arrCodLibro, double *arrPrecioLibro, int &numLibros);
void leerVentas(int* arrCodAutores, int* arrLibrosPorAutor, double* arrRegalias,
        int numAutores, int* arrCodLibro, int* arrLibrosVendidos, 
        double* arrPrecioLibro, double* arrRecaudadoLibros, int numLibros);
void ordenarLibros(int *arrCodLibro,int *arrLibrosVendidos,double *arrPrecioLibro,
            double *arrRecaudadoLibros,int numLibros);
void emiteReporte(int *arrCodAutores,int *arrLibrosPorAutor,double *arrRegalias,
        int numAutores,int *arrCodLibro,int *arrLibrosVendidos,
        double *arrPrecioLibro,double *arrRecaudadoLibros,int numLibros);
void buscaNombreAutor(int codigo_autor, ofstream& archReporte);
void imprimeNombre(ifstream &archAutores,ofstream &archReporte);
int buscarPosicion(int *arreglo,int elemento,int numDatos);
void interCambiarInt(int *arreglo,int i,int j);
void interCambiarDouble(double *arreglo, int i, int j);
void imprimeLinea(char caracter, int cantidad, ofstream &archRep);

#endif /* FUNCIONES_H */

