

/* 
 * File:   funciones.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 13 de mayo de 2023, 08:33 AM
 */


#include <iostream>
#include <fstream>
#include <iomanip>


using namespace std;


#define MAX_LINE 150
#include "funciones.h"


void emiteReporte(int dia,int mes,int anio,ifstream &archPeliculas,
        ifstream &archSalas,ifstream &archVentasOcupacion,ofstream &archReporte){
    
    
    int fechaLeida;
    archReporte<<setprecision(1);
    archReporte<<fixed;
    fechaLeida=juntarFecha(dia,mes,anio);
    while(true){
        leeValidaObtieneDatosPelicula(fechaLeida,archPeliculas,
                archSalas,archVentasOcupacion,archReporte);
        if(archPeliculas.eof())break;
    }
}


void leeValidaObtieneDatosPelicula(int fechaLeida,
        ifstream &archPeliculas,ifstream &archSalas,
        ifstream &archVentasOcupacion,ofstream &archReporte){
    
    int cod_pelicula,fechaIni_pelicula,fechaFin_pelicula,diaIni,mesIni,anioIni,
            diaFin,mesFin,anioFin;
    double ventasTotales,ocupacionTotales,recaudacionTotal;
    char c;
    archPeliculas>>cod_pelicula;
    if(archPeliculas.eof())return;
    archPeliculas>>diaIni>>c>>mesIni>>c>>anioIni;
    archPeliculas>>diaFin>>c>>mesFin>>c>>anioFin;
    fechaIni_pelicula=juntarFecha(diaIni,mesIni,anioIni);
    fechaFin_pelicula=juntarFecha(diaFin,mesFin,anioFin);
    if(fechaLeida>=fechaIni_pelicula and fechaLeida<=fechaFin_pelicula){
        imprimeLinea('=',MAX_LINE,archReporte);
        archReporte<<"Codigo"<<setw(10)<<' '<<"Pelicula"<<endl;
        archReporte<<cod_pelicula<<setw(10)<<' ';
        imprimeNombrePelicula(archPeliculas,archReporte);
        imprimeLinea('-',MAX_LINE,archReporte);
        archReporte<<"Detalle de Funciones"<<endl;
        archReporte<<"Sala"<<setw(5)<<' '<<"Hora"<<setw(8)<<' '
                <<"Butacas Disponibles"<<setw(5)<<' '<<"Butacas Vendidas"
                <<setw(5)<<' '<<"Butacas Ocupadas"<<setw(5)<<' '
                <<"%Venta"<<setw(5)<<' '<<"%Ocupacion"<<setw(5)<<' '
                <<"Recaudacion(S/.)"<<endl;
        leerSalaHorasPelicula(fechaLeida,ventasTotales,ocupacionTotales,recaudacionTotal,
                archPeliculas,archSalas,archVentasOcupacion,archReporte);
        imprimeResumen(ventasTotales,ocupacionTotales,recaudacionTotal,archReporte);
    }else while(archPeliculas.get()!='\n');
}

void imprimeResumen(double ventasTotales,double ocupacionTotales,double recaudacionTotal,
        ofstream &archReporte){
    imprimeLinea('-',MAX_LINE,archReporte);
    archReporte<<"%Ventas total por pelicula: "<<setw(11)<<ventasTotales<<'%'
            <<endl;
    archReporte<<"%Ocupacion total por pelicula: "<<setw(8)<<ocupacionTotales
            <<'%'<<endl;
    archReporte<<"Recaudacion total por pelicula: "<<setw(8)<<recaudacionTotal
            <<endl;
}

void leerSalaHorasPelicula(int fechaLeida,double &ventasTotales,
        double &ocupacionTotales,double &recaudacionTotal,
        ifstream &archPeliculas,ifstream &archSalas,
        ifstream &archVentasOcupacion,ofstream &archReporte){
    recaudacionTotal=0;
    int sala,hora,minuto,butacas;
    char c;
    while(true){
        archPeliculas>>sala;
        butacas=buscarButacas(sala,archSalas);
        if(butacas!=-1){
            while(true){
                archPeliculas>>hora;
                if(hora<7){
                    archPeliculas.unget();
                    break;
                }else {
                    c=archPeliculas.get();
                    if(c==' '){
                        archPeliculas.unget();
                        break;    
                    }else if(c!='\n'){
                        archPeliculas>>minuto;
                        c=archPeliculas.get();
                        if(c=='\n'){
                            archPeliculas.unget();
                            break;
                        }
                        else archPeliculas.unget();
                    }else if(c=='\n')break;
                }
                buscaImprmeDatosFuncion(fechaLeida,sala,hora,minuto,butacas,
                        ventasTotales,ocupacionTotales,recaudacionTotal,
                        archVentasOcupacion,archReporte);
            }
            if(archPeliculas.get()=='\n')break;
            else archPeliculas.unget();
        }else archReporte<<"No existe sala"<<endl;
    }
}

void buscaImprmeDatosFuncion(int fechaLeida,int sala,int hora,int minuto,
        int butacas,double &ventasTotales,double &ocupacionTotales,
        double &recaudacionTotal,ifstream &archVentasOcupacion,ofstream &archReporte){
    archVentasOcupacion.clear();
    archVentasOcupacion.seekg(0,ios::beg);
    int sala_leida,dia_leido,mes_leido,anio_leido,hora_leida,min_leido,
            butacas_vendidas,fecha_evaluar,columna,butacasOcupadas,cantSalas=0;
    double montoRecaudado,porcentaje_ocupacion,porcentaje_ventas,
            sumaVentas=0,sumaOcupacion=0;
    char c;
    while(true){
        archVentasOcupacion>>sala_leida;
        if(archVentasOcupacion.eof())break;
        archVentasOcupacion>>dia_leido>>c>>mes_leido>>c>>anio_leido;
        archVentasOcupacion>>hora_leida>>c>>min_leido;
        archVentasOcupacion>>montoRecaudado>>butacas_vendidas;
        fecha_evaluar=juntarFecha(dia_leido,mes_leido,anio_leido);
        if(fecha_evaluar==fechaLeida and sala_leida==sala and 
                hora_leida==hora and min_leido==minuto){
            butacasOcupadas=0;
            while(true){
                archVentasOcupacion>>c>>columna;
                butacasOcupadas++;
                if(archVentasOcupacion.get()=='\n')break;
            }
            cantSalas++;
            porcentaje_ventas=((double)butacas_vendidas/butacas)*100;
            porcentaje_ocupacion=((double)butacasOcupadas/butacas)*100;
            imprimeDatosFunciones(sala,hora,minuto,butacas,butacas_vendidas,
                    butacasOcupadas,porcentaje_ventas,porcentaje_ocupacion,
                    montoRecaudado,archReporte);
            sumaVentas+=porcentaje_ventas;
            sumaOcupacion+=porcentaje_ocupacion;
            ventasTotales=sumaVentas/cantSalas;
            ocupacionTotales=sumaOcupacion/cantSalas;
            recaudacionTotal+=montoRecaudado;
        }else while(archVentasOcupacion.get()!='\n');
    }
}

void imprimeDatosFunciones(int sala,int hora,int minuto,int butacas,
        int butacas_vendidas,int butacasOcupadas,double porcentaje_ventas,
        double porcentaje_ocupacion,double montoRecaudado,ofstream &archReporte){
    archReporte<<setfill('0')<<setw(2)<<sala<<setfill(' ')<<setw(6)
        <<' '<<setfill('0')<<setw(2)<<hora
        <<':'<<setw(2)<<minuto<<setfill(' ')<<setw(16)<<' '<<setw(3)
        <<butacas<<setw(20)<<' '<<setw(3)<<butacas_vendidas<<setw(17)
        <<' '<<butacasOcupadas<<setw(14)<<' '
        <<porcentaje_ventas<<'%'<<setw(8)<<' '<<porcentaje_ocupacion<<'%'<<setw(10)
        <<' '<<setw(8)<<montoRecaudado<<endl;
}

int buscarButacas(int sala, ifstream &archSalas){
    
    archSalas.clear();
    archSalas.seekg(0,ios::beg);
    
    int sala_evaluar,butacas;
    while(true){
        archSalas>>sala_evaluar;
        if(archSalas.eof())break;
        if(sala_evaluar==sala){
            archSalas>>butacas;
            return butacas;
        }else while(archSalas.get()!='\n');
    }
    
    return -1;
}

void imprimeNombrePelicula(ifstream &archPeliculas,ofstream &archReporte){
    
    char pelicula;
    
    archPeliculas.get();
    while(true){
        pelicula=archPeliculas.get();
        if(pelicula==' ')break;
        if(pelicula=='/')pelicula=' ';
        else pelicula-=(pelicula>='a' and pelicula<='z')?'a'-'A':0;
        archReporte.put(pelicula);  
    }
    archReporte<<endl;
}

int juntarFecha(int dia,int mes,int anio){
    
    int fechaJuntada = anio*10000 + mes*100+ dia;
    return fechaJuntada;
}

void imprimeLinea(char caracter, int cantidad, ofstream &archReporte){
    for(int i=0;i<cantidad;i++)archReporte<<caracter;
    archReporte.put('\n');
}