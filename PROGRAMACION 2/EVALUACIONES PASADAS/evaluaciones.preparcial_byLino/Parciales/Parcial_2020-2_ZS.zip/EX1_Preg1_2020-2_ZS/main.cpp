

/* 
 * File:   main.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 13 de mayo de 2023, 08:33 AM
 */

#include <iostream>
#include <fstream>
#include <iomanip>


using namespace std;

#include "funciones.h"
/*
 * 
 */
int main(int argc, char** argv) {
    
    
    ifstream archPeliculas("peliculas.txt",ios::in);
    if(not archPeliculas.is_open()){
        cout<<"ERROR al abrir el archivo de peliculas"<<endl;
        exit(1);
    }
    
    ifstream archSalas("salas.txt",ios::in);
    if(not archSalas.is_open()){
        cout<<"ERROR al abrir el archivo de salas"<<endl;
        exit(1);
    }
    
    ifstream archVentasOcupacion("ventas_y_ocupacion.txt",ios::in);
    if(not archVentasOcupacion.is_open()){
        cout<<"ERROR al abrir el archivo de ventas_y_ocupacion"<<endl;
        exit(1);
    }
    ofstream archReporte("ReporteDeVentasyOcupacion.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR al abrir el archivo de ReporteDeVentasyOcupacion"<<endl;
        exit(1);
    }
    
    int dia,mes,anio;
    dia=1,mes=5,anio=2019;
    
    emiteReporte(dia,mes,anio,archPeliculas,archSalas,archVentasOcupacion,
            archReporte);
    return 0;
}

