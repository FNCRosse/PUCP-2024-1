

/* 
 * File:   funciones.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 13 de mayo de 2023, 08:34 AM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void emiteReporte(int dia,int mes,int anio,ifstream &archPeliculas,
        ifstream &archSalas,ifstream &archVentasOcupacion,ofstream &archReporte);
void leeValidaObtieneDatosPelicula(int fechaLeida,
        ifstream &archPeliculas,ifstream &archSalas,
        ifstream &archVentasOcupacion,ofstream &archReporte);
void imprimeResumen(double ventasTotales,double ocupacionTotales,double recaudacionTotal,
        ofstream &archReporte);
void leerSalaHorasPelicula(int fechaLeida,double &ventasTotales,
        double &ocupacionTotales,double &recaudacionTotal,
        ifstream &archPeliculas,ifstream &archSalas,
        ifstream &archVentasOcupacion,ofstream &archReporte);
void buscaImprmeDatosFuncion(int fechaLeida,int sala,int hora,int minuto,
        int butacas,double &ventasTotales,double &ocupacionTotales,
        double &recaudacionTotal,ifstream &archVentasOcupacion,ofstream &archReporte);
void imprimeDatosFunciones(int sala,int hora,int minuto,int butacas,
        int butacas_vendidas,int butacasOcupadas,double porcentaje_ventas,
        double porcentaje_ocupacion,double montoRecaudado,ofstream &archReporte);
int buscarButacas(int sala, ifstream &archSalas);
void imprimeNombrePelicula(ifstream &archPeliculas,ofstream &archReporte);
int juntarFecha(int dia,int mes,int anio);
void imprimeLinea(char caracter, int cantidad, ofstream &archReporte);

#endif /* FUNCIONES_H */

