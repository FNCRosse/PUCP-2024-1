

/* 
 * File:   funciones.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 10 de mayo de 2023, 08:53 AM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void leerAlumnos(int *arrCodAlumno,double *arrCredAprob,double *arrCredDesaprob,
        double *arrCredFaltantes,int &numAlumnos);
void leerCursos(int *arrCodCurso,double *arrCredCurso,int &numCursos);
void leerProcesarNotas(int *arrCodAlumno,int *arrCantCursosAlumno,
        int *arrCursosAprob,int *arrCursosDesaprob,double *arrCredAprob,
        double *arrCredDesaprob,double *arrCredFaltantes,
        double *arrCredAprobCiclo,int numAlumnos,int *arrCodCurso,
        double *arrCredCurso,int numCursos);
void ordenarArreglos(int *arrCodAlumno,int *arrCantCursosAlumno,
        int *arrCursosAprob,int *arrCursosDesaprob,double *arrCredAprob,
        double *arrCredDesaprob,double *arrCredFaltantes,
        double *arrCredAprobCiclo,int numAlumnos);
void emiteReporte(int *arrCodAlumno,int *arrCantCursosAlumno,
        int *arrCursosAprob,int *arrCursosDesaprob,double *arrCredAprob,
        double *arrCredDesaprob,double *arrCredFaltantes,
        double *arrCredAprobCiclo,int numAlumnos,int *arrCodCurso,
        double *arrCredCurso,int numCursos);
void imprimeResumen(int cantAlumnos_facu,int cantAlumnos_noFacu,
        int numAlumnos,int cantAlumnos_sinNota,ofstream &archReporte);
void imprimeEncabezado(ofstream &archReporte);
void intercambiarInt(int *arreglo,int i,int j);
void intercambiarDouble(double* arreglo, int i, int j);
int buscarPosicion(int *arreglo,int elemento,int numDatos);
void imprimeLinea(char caracter, int cantidad, ofstream &archRep);

#endif /* FUNCIONES_H */

