

/* 
 * File:   funciones.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 10 de mayo de 2023, 08:53 AM
 */


#include <iostream>
#include <fstream>
#include <iomanip>
#include <ios>

using namespace std;

#define NO_ENCONTRADO -1
#define MAX_LINE 150
#include "funciones.h"

void leerAlumnos(int *arrCodAlumno,double *arrCredAprob,double *arrCredDesaprob,
        double *arrCredFaltantes,int &numAlumnos){
    
    ifstream archAlumnos("alumnos.txt",ios::in);
    if(not archAlumnos.is_open()){
        cout<<"ERROR al abrir el archivo de alumnos"<<endl;
        exit(1);
    }
    
    int cod_alumno;
    double creditos_aprobados,creditos_desaprobados,creditos_faltantes;
    numAlumnos=0;
    
    while(true){
        archAlumnos>>cod_alumno;
        if(archAlumnos.eof())break;
        archAlumnos>>ws;
        while(archAlumnos.get()!=' ');
        archAlumnos>>creditos_aprobados;
        archAlumnos>>creditos_desaprobados;
        archAlumnos>>creditos_faltantes;
        
        arrCodAlumno[numAlumnos]=cod_alumno;
        arrCredAprob[numAlumnos]=creditos_aprobados;
        arrCredDesaprob[numAlumnos]=creditos_desaprobados;
        arrCredFaltantes[numAlumnos]=creditos_faltantes;
        
        numAlumnos++;
    }
}

void leerCursos(int *arrCodCurso,double *arrCredCurso,int &numCursos){
    
    ifstream archCursos("Cursos.txt",ios::in);
    if(not archCursos.is_open()){
        cout<<"ERROR al abrir el archivo de Cursos"<<endl;
        exit(1);
    }
    
    int cod_curso;
    double cred_curso;
    numCursos=0;
    
    while(true){
        archCursos>>cod_curso;
        if(archCursos.eof())break;
        while(archCursos.get()!='}');
        archCursos.get();
        archCursos>>cred_curso;
        arrCodCurso[numCursos]=cod_curso;
        arrCredCurso[numCursos]=cred_curso;
        numCursos++;
    }
    
}

void leerProcesarNotas(int *arrCodAlumno,int *arrCantCursosAlumno,
        int *arrCursosAprob,int *arrCursosDesaprob,double *arrCredAprob,
        double *arrCredDesaprob,double *arrCredFaltantes,
        double *arrCredAprobCiclo,int numAlumnos,int *arrCodCurso,
        double *arrCredCurso,int numCursos){
    
    ifstream archNotas("notas.txt",ios::in);
    if(not archNotas.is_open()){
        cout<<"ERROR al abrir el archivo de notas"<<endl;
        exit(1);
    }
    
    int codAlumno_evaluar,codCurso_evaluar,nota,posAlumno,posCurso;
    
    while(true){
        archNotas>>codCurso_evaluar;
        if(archNotas.eof())break;
        posCurso=buscarPosicion(arrCodCurso,codCurso_evaluar,numCursos);
        if(posCurso!=NO_ENCONTRADO){
            archNotas>>codAlumno_evaluar;
            archNotas>>nota;
            posAlumno=buscarPosicion(arrCodAlumno,codAlumno_evaluar,numAlumnos);
            if(posAlumno!=NO_ENCONTRADO){
                if(nota>10){
                    arrCursosAprob[posAlumno]++;
                    arrCredAprob[posAlumno]+=arrCredCurso[posCurso];
                    arrCredAprobCiclo[posAlumno]+=arrCredCurso[posCurso];
                    arrCredFaltantes[posAlumno]-=arrCredCurso[posCurso];
                }else if(nota<=10){
                    arrCursosDesaprob[posAlumno]++;
                    arrCredDesaprob[posAlumno]+=arrCredCurso[posCurso];
                }
                arrCantCursosAlumno[posAlumno]++;
            }
            if(archNotas.get()=='\n')break;
        }
    }
}

void ordenarArreglos(int *arrCodAlumno,int *arrCantCursosAlumno,
        int *arrCursosAprob,int *arrCursosDesaprob,double *arrCredAprob,
        double *arrCredDesaprob,double *arrCredFaltantes,
        double *arrCredAprobCiclo,int numAlumnos){
    
    for(int i=0;i<numAlumnos-1;i++){
        for(int k=i+1;k<numAlumnos;k++){
            if(arrCursosAprob[i]<arrCursosAprob[k] or 
                    (arrCursosAprob[i]==arrCursosAprob[k] and 
                    arrCodAlumno[i]>arrCodAlumno[k])){
                intercambiarInt(arrCodAlumno,i,k);
                intercambiarInt(arrCursosAprob,i,k);
                intercambiarInt(arrCursosDesaprob,i,k);
                intercambiarInt(arrCantCursosAlumno,i,k);
                intercambiarDouble(arrCredAprob,i,k);
                intercambiarDouble(arrCredDesaprob,i,k);
                intercambiarDouble(arrCredFaltantes,i,k);
                intercambiarDouble(arrCredAprobCiclo,i,k);
            }
        }
    }
}

void emiteReporte(int *arrCodAlumno,int *arrCantCursosAlumno,
        int *arrCursosAprob,int *arrCursosDesaprob,double *arrCredAprob,
        double *arrCredDesaprob,double *arrCredFaltantes,
        double *arrCredAprobCiclo,int numAlumnos,int *arrCodCurso,
        double *arrCredCurso,int numCursos){
    ofstream archReporte("ReportedeConsolidadoResultados.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR al abrir el archivo"<<endl;
        exit(1);
    }    
    imprimeEncabezado(archReporte);
    archReporte<<setprecision(2);
    archReporte<<fixed;
    int contAlumnos=0,cantAlumnos_facu=0,cantAlumnos_noFacu=0,
            cantAlumnos_sinNota=0;
    for(int i=0;i<numAlumnos;i++){
        if(arrCantCursosAlumno[i]>0){
            contAlumnos++;
            archReporte<<setfill(' ')<<setw(3)<<contAlumnos<<") "
                    <<arrCodAlumno[i]<<setw(15)<<' '<<arrCursosAprob[i]
                    <<setw(20)<<' '<<arrCursosDesaprob[i]<<setw(15)<<' '
                    <<setw(8)<<arrCredAprob[i]<<setw(12)<<' '<<setw(8)
                    <<arrCredDesaprob[i];
            if(arrCredAprobCiclo[i]>=arrCredFaltantes[i]){
                archReporte<<setw(13)<<' '<<"Pasara a Facultad"<<endl;
                cantAlumnos_facu++;
            }else if(arrCredAprobCiclo[i]<arrCredFaltantes[i]){
                archReporte<<setw(13)<<' '<<"No pasara a Facultad, faltan "
                        <<setw(8)<<arrCredFaltantes[i]<<" creditos"<<endl;
                cantAlumnos_noFacu++;
            }
        }else cantAlumnos_sinNota++;
    }
    imprimeResumen(cantAlumnos_facu,cantAlumnos_noFacu,numAlumnos,
            cantAlumnos_sinNota,archReporte);
}

void imprimeResumen(int cantAlumnos_facu,int cantAlumnos_noFacu,
        int numAlumnos,int cantAlumnos_sinNota,ofstream &archReporte){
   
    imprimeLinea('-',MAX_LINE,archReporte);
    archReporte<<"Cantidad de alumnos que pasaran a Facultad: "
            <<setw(6)<<cantAlumnos_facu<<endl;
    archReporte<<"Cantidad de alumnos que no pasaran a Facultad: "
            <<setw(3)<<cantAlumnos_noFacu<<endl;
    imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<"TOTAL DE ALUMNOS MATRICULADOS EN EL CICLO: "
            <<setw(7)<<numAlumnos-cantAlumnos_sinNota<<endl;
}

void imprimeEncabezado(ofstream &archReporte){
    archReporte<<setw(50)<<' '<<"INSTITUCION EDUCATIVA LIMA"<<endl;
    archReporte<<setw(48)<<' '<<"CONSOLIDADO DE ALUMNOS"<<endl;
    imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<setw(4)<<' '<<"CODIGO"<<setw(10)<<' '<<"CURSOS APROB."
            <<setw(10)<<' '<<"CURSOS DESA."<<setw(10)<<' '<<"CRED APROB."
            <<setw(10)<<' '<<"CRED DESA."<<setw(10)<<' '<<"OBSERVACION"<<endl;
    imprimeLinea('-',MAX_LINE,archReporte);
}

void intercambiarInt(int *arreglo,int i,int j){
    int aux;
    aux=arreglo[i];
    arreglo[i]=arreglo[j];
    arreglo[j]=aux;
}

void intercambiarDouble(double *arreglo,int i,int j){
    double aux;
    aux=arreglo[i];
    arreglo[i]=arreglo[j];
    arreglo[j]=aux;
}

int buscarPosicion(int *arreglo,int elemento,int numDatos){
    for(int i=0;i<numDatos;i++)
        if(arreglo[i]==elemento)return i;
    
    return NO_ENCONTRADO;
}

void imprimeLinea(char caracter, int cantidad, ofstream &archRep){
    for(int i=0;i<cantidad;i++)archRep.put(caracter);
    archRep.put('\n');
}


