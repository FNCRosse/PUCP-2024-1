

/* 
 * File:   main.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 10 de mayo de 2023, 08:53 AM
 */

#include <iostream>
#include <fstream>
#include <iomanip>


using namespace std;


#define MAX_CURSOS 30
#define MAX_ALUMNOS 200
#include "funciones.h"
/*
 * 
 */
int main(int argc, char** argv) {
    
    int arrCodAlumno[MAX_ALUMNOS],arrCursosAprob[MAX_ALUMNOS]{},
            arrCursosDesaprob[MAX_ALUMNOS]{},arrCantCursosAlumno[MAX_ALUMNOS]{},
            numAlumnos;
    double arrCredAprob[MAX_ALUMNOS],arrCredDesaprob[MAX_ALUMNOS],
            arrCredFaltantes[MAX_ALUMNOS],arrCredAprobCiclo[MAX_ALUMNOS]{};
    
    int arrCodCurso[MAX_CURSOS],numCursos;
    double arrCredCurso[MAX_CURSOS];
    
    leerAlumnos(arrCodAlumno,arrCredAprob,arrCredDesaprob,arrCredFaltantes,
            numAlumnos);  
    leerCursos(arrCodCurso,arrCredCurso,numCursos);

    leerProcesarNotas(arrCodAlumno,arrCantCursosAlumno,arrCursosAprob,
            arrCursosDesaprob,arrCredAprob,arrCredDesaprob,arrCredFaltantes,
            arrCredAprobCiclo,numAlumnos,arrCodCurso,arrCredCurso,numCursos);
    
    ordenarArreglos(arrCodAlumno,arrCantCursosAlumno,arrCursosAprob,
            arrCursosDesaprob,arrCredAprob,arrCredDesaprob,arrCredFaltantes,
            arrCredAprobCiclo,numAlumnos);
    emiteReporte(arrCodAlumno,arrCantCursosAlumno,arrCursosAprob,
            arrCursosDesaprob,arrCredAprob,arrCredDesaprob,arrCredFaltantes,
            arrCredAprobCiclo,numAlumnos,arrCodCurso,arrCredCurso,numCursos);
    return 0;
}

