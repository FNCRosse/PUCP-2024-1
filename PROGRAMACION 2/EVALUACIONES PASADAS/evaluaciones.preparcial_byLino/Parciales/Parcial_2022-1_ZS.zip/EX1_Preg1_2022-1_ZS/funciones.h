

/* 
 * File:   funciones.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 10 de mayo de 2023, 08:53 AM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void emiteReporte(ifstream &archAlumnos,ifstream &archCursos,ifstream &archNotas,
        ofstream &archReporte);
void imprimeResumenAlumno(double credAprob,double credDesaprob,
        double credFaltantes,int cantNotas,double promedioPonderado,
        double credAcumulativos,ofstream &archReporte);
void leeImprimeDatosCursos(int codigoAlumno,int &canAlumnosNoMatriculados,
        int &cantNotas,double &credAprob,double &credDesaprob,
        double &credFaltantes,double &promedioPonderado,double &credAcumulativos,
        ifstream &archNotas,ifstream &archCursos,
        ofstream &archReporte);

void buscaImprimeDatosCurso(int &codigoCurso,double &creditos,
        ifstream &archCursos,ofstream &archReporte);
void imprimeCurso(ifstream &archCursos,ofstream &archReporte);
void imprimeEncabezadoNotas(ofstream &archReporte);
void leeImprimeDatosAlumnos(int &cont_AlumnosMatric,int &codigoAlumno,
        double &credAprob,double &credDesaprob,
        double &credFaltantes,ifstream &archAlumnos,ofstream &archReporte);
void imprimeNombre(ifstream &archAlumnos,ofstream &archReporte);
void imprimeTitulo(ofstream &archReporte);
void imprimeLinea(char caracter, int cantidad, ofstream &archRep);


#endif /* FUNCIONES_H */

