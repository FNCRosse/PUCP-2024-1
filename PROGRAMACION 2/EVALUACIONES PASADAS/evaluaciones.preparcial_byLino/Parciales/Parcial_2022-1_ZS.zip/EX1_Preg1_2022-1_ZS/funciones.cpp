

/* 
 * File:   funciones.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 10 de mayo de 2023, 08:53 AM
 */


#include <iostream>
#include <fstream>
#include <iomanip>
#include <ios>
using namespace std;

#define MAX_CUR 50
#define MAX_ALUM 50
#define MAX_LINE 150
#include "funciones.h"

void emiteReporte(ifstream &archAlumnos,ifstream &archNotas,ifstream &archCursos,
        ofstream &archReporte){
    
    imprimeTitulo(archReporte);
    int codigoAlumno,cont_Alumnos=0,cantAlumnosMatriculados,cantNotas,
            canAlumnosNoMatriculados=0;
    double credAprob,credDesaprob,credFaltantes,promedioPonderado,
            credAcumulativos;
    archReporte<<setprecision(2);
    archReporte<<fixed;
    while(true){
        imprimeLinea('=',MAX_LINE,archReporte);
        leeImprimeDatosAlumnos(cont_Alumnos,codigoAlumno,credAprob,
                credDesaprob,credFaltantes,archAlumnos,archReporte);
        if(archAlumnos.eof())break;
        imprimeEncabezadoNotas(archReporte);
        leeImprimeDatosCursos(codigoAlumno,canAlumnosNoMatriculados,
                cantNotas,credAprob,credDesaprob,credFaltantes,
                promedioPonderado,credAcumulativos,archNotas,archCursos,
                archReporte);
        imprimeLinea('-',MAX_LINE,archReporte);
        imprimeResumenAlumno(credAprob,credDesaprob,credFaltantes,cantNotas,
                promedioPonderado,credAcumulativos,archReporte);
    }
    cantAlumnosMatriculados=cont_Alumnos-canAlumnosNoMatriculados;
    imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<"TOTAL DE ALUMNOS MATRICULADOS EN EL CICLO: "
            <<cantAlumnosMatriculados<<endl;
    imprimeLinea('=',MAX_LINE,archReporte);
}

void imprimeResumenAlumno(double credAprob,double credDesaprob,
        double credFaltantes,int cantNotas,double promedioPonderado,
        double credAcumulativos,ofstream &archReporte){
    archReporte<<"Promedio ponderado en el ciclo: "<<setw(17)
            <<promedioPonderado<<endl;
    archReporte<<"Creditos aprobados acumulados: "<<setw(18)<<credAprob<<endl;
    archReporte<<"Creditos desaprobados acumulados: "<<setw(15)<<credDesaprob<<endl;
    if(credFaltantes<0)archReporte<<"Creditos que faltan para pasar a facultad: "
            <<setw(2)<<' '<<"0.00";
    else archReporte<<"Creditos que faltan para pasar a facultad: "
            <<setw(6)<<credFaltantes;
    if(cantNotas==0)archReporte<<setw(20)<<' '<<"Alumno no Matriculado"<<endl;
    else if(cantNotas>0){
        if(credAcumulativos>=credFaltantes)archReporte<<setw(20)<<' '
                <<"Alumno pasara a la Facultad"<<endl;
        else archReporte<<setw(20)<<' '<<"Alumno no pasara a la Facultad"<<endl;
    }
}

void leeImprimeDatosCursos(int codigoAlumno,int &canAlumnosNoMatriculados,
        int &cantNotas,double &credAprob,double &credDesaprob,
        double &credFaltantes,double &promedioPonderado,double &credAcumulativos,
        ifstream &archNotas,ifstream &archCursos,
        ofstream &archReporte){
    archNotas.clear();
    archNotas.seekg(0,ios::beg);
    int codigoCurso,codAlumno_evaluar,nota,sumaNotas=0;
    double creditos,sumaCred=0;
    credAcumulativos=0;
    cantNotas=0;
    while(true){
        archNotas>>codigoCurso;
        if(archNotas.eof())break;
        while(true){
            archNotas>>codAlumno_evaluar;
            archNotas>>nota;
            if(codAlumno_evaluar==codigoAlumno){
                cantNotas++;
                archReporte<<setw(4)<<' '<<codigoCurso<<" - ";
                buscaImprimeDatosCurso(codigoCurso,creditos,archCursos,archReporte);
                archReporte<<setw(2)<<nota<<setw(10)<<' ';
                if(nota>=11){
                    credAcumulativos+=creditos;
                    archReporte<<"Aprobado"<<endl;
                    credFaltantes-=creditos;
                    credAprob+=creditos;
                }else if(nota<=10){
                    archReporte<<"Desaprobado"<<endl;
                    credDesaprob+=creditos;
                }
                sumaNotas+=nota*creditos;
                sumaCred+=creditos;
                promedioPonderado=(double)sumaNotas/sumaCred;
            }
            if(archNotas.get()=='\n')break;
        }
    }
    if(cantNotas==0)canAlumnosNoMatriculados++;
}

void buscaImprimeDatosCurso(int &codigoCurso,double &creditos,
        ifstream &archCursos,ofstream &archReporte){
    archCursos.clear();
    archCursos.seekg(0,ios::beg);
    
    int codCurso_evaluar;
    while(true){
        archCursos>>codCurso_evaluar;
        if(archCursos.eof())break;
        if(codCurso_evaluar==codigoCurso){
            imprimeCurso(archCursos,archReporte);
            archCursos>>creditos;
            archReporte<<setw(6)<<creditos<<setw(10)<<' ';
        }else while(archCursos.get()!='\n');
    }
}

void imprimeCurso(ifstream &archCursos,ofstream &archReporte){
    
    char curso;
    int numCar=0;
    archCursos>>ws;
    archCursos.get();
    while(true){
        curso=archCursos.get();
        if(curso=='}')break;
        archReporte.put(curso);
        numCar++;
    }
    
    for(int i=0;i<MAX_CUR-numCar;i++)archReporte.put(' ');
}

void imprimeEncabezadoNotas(ofstream &archReporte){
    imprimeLinea('-',MAX_LINE,archReporte);
    archReporte<<setw(4)<<' '<<"NOTAS EN EL CICLO"<<endl;
    archReporte<<setw(4)<<' '<<"Curso"<<setw(54)<<' '<<"Creditos"
            <<setw(7)<<' '<<"Nota"<<setw(9)<<' '<<"Mencion"<<endl;
    imprimeLinea('-',MAX_LINE,archReporte);
}

void leeImprimeDatosAlumnos(int &cont_Alumnos,int &codigoAlumno,
        double &credAprob,double &credDesaprob,
        double &credFaltantes,ifstream &archAlumnos,ofstream &archReporte){
    
    archAlumnos>>codigoAlumno;
    if(archAlumnos.eof())return;
    cont_Alumnos++;
    archReporte<<setw(4)<<cont_Alumnos<<')'<<"Alumno: "<<codigoAlumno
            <<" - ";
    imprimeNombre(archAlumnos,archReporte);
    archAlumnos>>credAprob;
    archAlumnos>>credDesaprob;
    archAlumnos>>credFaltantes;
}

void imprimeNombre(ifstream &archAlumnos,ofstream &archReporte){
    char alumno;
    int numCar=0,primeraLetra=1;
    
    archAlumnos>>ws;
    while(true){
        alumno=archAlumnos.get();
        if(alumno==' ')break;
        
        if(alumno!='_' and primeraLetra)primeraLetra=0;
        else if(alumno!='_' and !primeraLetra){
            alumno+=(alumno>='A' and alumno<='Z')?('a'-'A'):0;
        }else if(alumno=='_'){
            alumno=' ';
            primeraLetra=1;
        }
        archReporte.put(alumno);
        numCar++;
    }
    
    for(int i=0;i<MAX_ALUM-numCar;i++)archReporte.put(' ');
    archReporte.put('\n');
}
void imprimeTitulo(ofstream &archReporte){
    archReporte<<setw(50)<<' '<<"INSTITUCION EDUCATIVA LIMA"<<endl;
    archReporte<<setw(55)<<' '<<"NOTAS POR ALUMNO"<<endl;
}

void imprimeLinea(char caracter, int cantidad, ofstream &archRep){
    for(int i=0;i<cantidad;i++)archRep.put(caracter);
    archRep.put('\n');
}

