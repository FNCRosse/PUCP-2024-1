

/* 
 * File:   main.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 10 de mayo de 2023, 08:52 AM
 */

#include <iostream>
#include <fstream>
#include <iomanip>


using namespace std;
#include "funciones.h"

/*
 * 
 */
int main(int argc, char** argv) {
    
    
    ifstream archAlumnos("alumnos.txt",ios::in);
    if(not archAlumnos.is_open()){
        cout<<"ERROR al abrir el archivo de alumnos"<<endl;
        exit(1);
    }
    ifstream archCursos("Cursos.txt",ios::in);
    if(not archCursos.is_open()){
        cout<<"ERROR al abrir el archivo de Cursos"<<endl;
        exit(1);
    }
    ifstream archNotas("notas.txt",ios::in);
    if(not archNotas.is_open()){
        cout<<"ERROR al abrir el archivo de notas"<<endl;
        exit(1);
    }
    ofstream archReporte("ReportePorAlumno.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR al abrir el archivo de ReportePorAlumno"<<endl;
        exit(1);
    }
    
    emiteReporte(archAlumnos,archNotas,archCursos,archReporte);
    return 0;
}

