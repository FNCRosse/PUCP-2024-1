

/* 
 * File:   main.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 14 de mayo de 2023, 01:53 AM
 */

#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

#include "funciones.h"
/*
 * 
 */
int main(int argc, char** argv) {
    
    ifstream archProfesores("Profesores.txt",ios::in);
    if(not archProfesores.is_open()){
        cout<<"ERROR al abrir el archivo de Profesores"<<endl;
        exit(1);
    }
    ifstream archSesiones("Sesiones.txt",ios::in);
    if(not archSesiones.is_open()){
        cout<<"ERROR al abrir el archivo de Sesiones"<<endl;
        exit(1);
    }
    ifstream archCursos("Cursos.txt",ios::in);
    if(not archCursos.is_open()){
        cout<<"ERROR al abrir el archivo de Cursos"<<endl;
        exit(1);
    }
    ofstream archReporte("ReporteHorariosAsignados.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR al abrir el archivo de ReporteHorariosAsignados"<<endl;
        exit(1);
    }
    
    
    emiteReporte(archProfesores,archSesiones,archCursos,archReporte);
    
    return 0;
}

