

/* 
 * File:   funciones.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 14 de mayo de 2023, 01:53 AM
 */


#include <iostream>
#include <fstream>
#include <iomanip>


using namespace std;


#define MAX_NOMBRE 50
#define MAX_LINE 150
#include "funciones.h"

void emiteReporte(ifstream &archProfesores,ifstream &archSesiones,
        ifstream &archCursos,ofstream &archReporte){
    
    archReporte<<setw(50)<<' '<<"CARGA HORARIA DE PROFESORES"<<endl;
    imprimeLinea('=',MAX_LINE,archReporte);
    
    int codigo_profesor,tiempoDictadoTotal,totalAlumnosAcargo,
            horaTotalDictado,minTotalDictado;
    while(true){
        leeImprimeObtieneDatosProfesor(codigo_profesor,archProfesores,
                archReporte);
        if(archProfesores.eof())break;
        archReporte<<"Horarios asignados:"<<endl;
        leeBuscaImprimeHorarios(codigo_profesor,tiempoDictadoTotal,
                totalAlumnosAcargo,archSesiones,archCursos,archReporte);
        separarHora(tiempoDictadoTotal,horaTotalDictado,minTotalDictado);
        imprimeLinea('-',MAX_LINE,archReporte);
        archReporte<<"Total de horas asignadas por semana: "<<setfill('0')
                <<setw(2)<<horaTotalDictado<<':'<<setw(2)<<minTotalDictado
                <<setfill(' ')<<endl;
        archReporte<<"Total de alumnos a su cargo: "<<setw(6)
                <<totalAlumnosAcargo<<endl;
        imprimeLinea('=',MAX_LINE,archReporte);
    }
   
}

void leeBuscaImprimeHorarios(int codigo_profesor,int &tiempoDictadoTotal,
        int &totalAlumnosAcargo,ifstream &archSesiones,
        ifstream &archCursos,ofstream &archReporte){  
    archSesiones.clear();
    archSesiones.seekg(0,ios::beg);   
    int codigo_curso,codigo_horario,alumnos_matriculados,profesor_evaluar,
            contadorCursos=0,dia,horaIni,minIni,horaFin,minFin,aula,
            contador_sesiones,tiempoDictado,horaDictado,minDictado;
    char caracter_aula,c;
    totalAlumnosAcargo=tiempoDictadoTotal=0;
    while(true){
        archSesiones>>codigo_curso;
        if(archSesiones.eof())break;
        archSesiones>>codigo_horario>>alumnos_matriculados>>profesor_evaluar;
        if(profesor_evaluar==codigo_profesor){
            archReporte<<"No."<<setw(3)<<' '<<"Curso"<<setw(50)<<' '<<"Codigo"
            <<setw(8)<<' '<<"Especialidad"<<setw(8)<<' '<<"Horario"
            <<setw(8)<<' '<<"Matriculados"<<endl;
            contadorCursos++;
            buscaImprimeDatosCurso(contadorCursos,codigo_curso,codigo_horario,
                    alumnos_matriculados,archCursos,archReporte);
            totalAlumnosAcargo+=alumnos_matriculados;
            contador_sesiones=0,tiempoDictado=0;
            archReporte<<setw(6)<<' '<<"Sesiones"<<setw(12)<<' '
            <<"Hora"<<setw(13)<<' '<<"Aula"<<endl;
            while(true){
                contador_sesiones++;
                archSesiones>>dia;
                archSesiones>>horaIni>>c>>minIni;
                archSesiones>>horaFin>>c>>minFin;
                archSesiones>>caracter_aula>>aula;
                tiempoDictado+=calcularTiempo(horaIni,minIni,horaFin,minFin);
                imprimeDatoSesiones(dia,horaIni,minIni,horaFin,minFin,
                        caracter_aula,aula,contador_sesiones,archReporte);
                if(archSesiones.get()=='\n')break;
            }
            tiempoDictadoTotal+=tiempoDictado;
            separarHora(tiempoDictado,horaDictado,minDictado);
            archReporte<<setw(6)<<' '<<"Horas dictadas: "<<setw(5)<<' '<<setfill('0')
                    <<setw(2)<<horaDictado<<':'<<setw(2)<<minDictado
                    <<setfill(' ')<<endl<<endl;
        }else while(archSesiones.get()!='\n');
    }
}

void separarHora(int tiempoDictado,int &horaDictado,int &minDictado){
    
    horaDictado=(tiempoDictado/3600);
    minDictado=(tiempoDictado%3600)/60;
}

int calcularTiempo(int horaIni,int minIni,int horaFin,int minFin){
    int duracionSegundos= (horaFin*3600 + minFin*60)-(horaIni*3600 + minIni*60);
    return duracionSegundos;
}

void imprimeDatoSesiones(int dia,int horaIni,int minIni,int horaFin,int minFin,
        char caracter_aula,int aula,int contador_sesiones,ofstream &archReporte){
    archReporte<<setw(6)<<' '<<contador_sesiones<<')';
    analizaDia(dia,archReporte);
    archReporte<<setw(5)<<' '<<setfill('0')<<setw(2)<<horaIni<<':'
            <<setw(2)<<minIni<<setfill(' ')<<" - "<<setfill('0')<<setfill('0')
            <<setw(2)<<horaFin<<':'<<setw(2)<<minFin<<setfill(' ')<<setw(8)
            <<' '<<caracter_aula<<aula<<endl;
}

void analizaDia(int dia,ofstream &archReporte){
    
    if(dia==1)archReporte<<"Domingo  ";
    else if(dia==2)archReporte<<"Lunes    ";
    else if(dia==3)archReporte<<"Martes   ";
    else if(dia==4)archReporte<<"Miercoles";
    else if(dia==5)archReporte<<"Jueves   ";
    else if(dia==6)archReporte<<"Viernes  ";
    else if(dia==7)archReporte<<"Sabado   ";
}

void buscaImprimeDatosCurso(int contadorCursos,int codigo_curso,int codigo_horario,
        int alumnos_matriculados,ifstream &archCursos,ofstream &archReporte){
    archCursos.clear();
    archCursos.seekg(0,ios::beg);
    
    int curso_evaluar;
    double creditos;
    while(true){
        archCursos>>curso_evaluar;
        if(archCursos.eof())break;
        if(curso_evaluar==codigo_curso){
            archCursos>>creditos;
            archReporte<<setfill(' ')<<setw(2)<<contadorCursos<<')'
                    <<setw(3)<<' ';
            imprimeNombreCurso(archCursos,archReporte);
            archReporte<<setw(5)<<' '<<codigo_curso<<setw(8)<<' ';
            imprimeEspecialidad(archCursos,archReporte);
            archReporte<<setw(7)<<' '<<setfill('0')<<setw(4)<<codigo_horario
                    <<setfill(' ');
            archReporte<<setw(15)<<' '<<alumnos_matriculados<<endl;
        }else while(archCursos.get()!='\n');
    }
}

void imprimeNombreCurso(ifstream &archCursos,ofstream &archReporte){
    char curso;
    int numCar=0;
    
    archCursos>>ws;
    while(true){
        curso=archCursos.get();
        if(curso==' ')break;
        archReporte<<curso;
        numCar++;
    }
    for(int i=0;i<MAX_NOMBRE-numCar;i++)archReporte<<' ';
}

void imprimeEspecialidad(ifstream &archCursos,ofstream &archReporte){
    char especialidad;
    int numCar=0;
    while(archCursos.get()!='(');
    while(true){
        especialidad=archCursos.get();
        if(especialidad==')')break;
        archReporte<<especialidad;
        numCar++;
    }
    for(int i=0;i<15-numCar;i++)archReporte<<' ';
}

void leeImprimeObtieneDatosProfesor(int &codigo_profesor,
        ifstream &archProfesores,ofstream &archReporte){
    
    archProfesores>>codigo_profesor;
    if(archProfesores.eof())return;
    archReporte<<"Codigo: "<<codigo_profesor;
    archReporte<<setw(10)<<' '<<"Nombre: ";
    imprimeNombreProfesor(archProfesores,archReporte);
    archReporte<<"Categoria: ";
    imprimeCategoria(archProfesores,archReporte);
    archReporte<<"Dedicacion: ";
    imprimeDedicacion(archProfesores,archReporte);
    imprimeLinea('-',MAX_LINE,archReporte);
    
}

void imprimeNombreProfesor(ifstream &archProfesores,ofstream &archReporte){
    
    char profesor;
    int numCar=0;
    archProfesores>>ws;
    
    while(true){
        profesor=archProfesores.get();
        if(profesor==' ')break;
        if(profesor!='/' and profesor!='-')
            profesor-=(profesor>='a' and profesor<='z')?'a'-'A':0;
        archReporte.put(profesor);
        numCar++;
    }
    
    for(int i=0;i<MAX_NOMBRE-numCar;i++)archReporte<<' ';
}

void imprimeCategoria(ifstream &archProfesores,ofstream &archReporte){
    
    char categoria;
    int numCar=0;
    while(archProfesores.get()!='(');
    while(true){
        categoria=archProfesores.get();
        if(categoria==')')break;
        archReporte<<categoria;
        numCar++;
    }
    
    for(int i=0;i<15-numCar;i++)archReporte<<' ';
}

void imprimeDedicacion(ifstream &archProfesores,ofstream &archReporte){
    
    char dedicacion;
    int numCar=0;
    while(archProfesores.get()!='[');
    while(true){
        dedicacion=archProfesores.get();
        if(dedicacion==']')break;
        archReporte<<dedicacion;
        numCar++;
    }
    archReporte<<endl;
}

void imprimeLinea(char caracter, int cantidad, ofstream &archRep){
    for(int i=0;i<cantidad;i++)archRep<<caracter;
    archRep<<endl;
}