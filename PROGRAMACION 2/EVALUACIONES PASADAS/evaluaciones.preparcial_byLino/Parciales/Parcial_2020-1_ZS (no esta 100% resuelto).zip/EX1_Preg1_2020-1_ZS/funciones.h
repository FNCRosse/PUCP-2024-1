

/* 
 * File:   funciones.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 14 de mayo de 2023, 01:53 AM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void emiteReporte(ifstream &archProfesores,ifstream &archSesiones,
        ifstream &archCursos,ofstream &archReporte);
void leeBuscaImprimeHorarios(int codigo_profesor,int &tiempoDictadoTotal,
        int &totalAlumnosAcargo,ifstream &archSesiones,
        ifstream &archCursos,ofstream &archReporte);
void separarHora(int tiempoDictado, int& horaDictado, int& minDictado);
int calcularTiempo(int horaIni, int minIni, int horaFin, int minFin);
void imprimeDatoSesiones(int dia,int horaIni,int minIni,int horaFin,int minFin,
        char caracter_aula,int aula,int contador_sesiones,ofstream &archReporte);
void analizaDia(int dia, ofstream& archReporte);
void buscaImprimeDatosCurso(int contadorCursos,int codigo_curso,int codigo_horario,
        int alumnos_matriculados,ifstream &archCursos,ofstream &archReporte);
void imprimeNombreCurso(ifstream &archCursos,ofstream &archReporte);
void imprimeEspecialidad(ifstream& archCursos, ofstream& archReporte);
void leeImprimeObtieneDatosProfesor(int &codigo_profesor,
        ifstream &archProfesores,ofstream &archReporte);
void imprimeNombreProfesor(ifstream &archProfesores,ofstream &archReporte);
void imprimeCategoria(ifstream &archProfesores,ofstream &archReporte);
void imprimeDedicacion(ifstream &archProfesores,ofstream &archReporte);
void imprimeLinea(char caracter, int cantidad, ofstream &archRep);


#endif /* FUNCIONES_H */

