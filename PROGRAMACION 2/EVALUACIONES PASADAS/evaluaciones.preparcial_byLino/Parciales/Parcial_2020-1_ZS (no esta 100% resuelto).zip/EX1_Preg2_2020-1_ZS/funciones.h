

/* 
 * File:   funciones.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 14 de mayo de 2023, 02:10 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void leerAsistencias(int anio,int ciclo,int *arrCodCurso,int *arrCantAlumnosCurso,
        int *arrCantHorarios,double *arrPorcenAsistencia,int &numCursos);
void leeLlenaEncuestas(int anio, int ciclo, int* arrCodCurso, 
        int* arrCantAlumnosCurso, int* arrCantHorarios, 
        double* arrPorcenAsistencia, int numCursos, double* arrEncuestaReal,
        double* arrEncuestaAjustada);
void calcularEncuestaAjustada(double* arrEncuestaAjustada, 
        double* arrPorcenAsistencia, int numCursos);
void emiteReporte1(int anio, int ciclo, int* arrCodCurso, 
        int* arrCantAlumnosCurso, int* arrCantHorarios,
        double* arrPorcenAsistencia, int numCursos, double* arrEncuestaReal,
        double* arrEncuestaAjustada);
void emiteReporte2(int anio,int ciclo,double *arrEncuestaReal,
        double *arrEncuestaAjustada,int *arrFrecuenciaEncuestaReal,
        int *arrFrecuenciaEncuestaAjustada,int numCursos);
int calcularMaximo(int *arreglo,int numDatos);
int buscarPosicion(int* arreglo, int elemento, int numDatos);
void imprimeLinea(char caracter, int cantidad, ofstream& archRep);

#endif /* FUNCIONES_H */

