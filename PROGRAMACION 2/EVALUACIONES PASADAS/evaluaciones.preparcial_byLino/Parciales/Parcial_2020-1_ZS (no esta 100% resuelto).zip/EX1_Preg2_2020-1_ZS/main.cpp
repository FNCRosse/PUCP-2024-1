

/* 
 * File:   main.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 14 de mayo de 2023, 01:53 AM
 */

#include <iostream>
#include <fstream>
#include <iomanip>


using namespace std;

#define MAX_CURSOS 100
#include "funciones.h"
/*
 * 
 */
int main(int argc, char** argv) {
    
    int arrCodCurso[MAX_CURSOS],arrCantAlumnosCurso[MAX_CURSOS]{},
            arrCantHorarios[MAX_CURSOS]{},numCursos;
    double arrPorcenAsistencia[MAX_CURSOS]{};
    
    double arrEncuestaReal[MAX_CURSOS]{},arrEncuestaAjustada[MAX_CURSOS];
    int arrFrecuenciaEncuestaReal[10]{},arrFrecuenciaEncuestaAjustada[10]{};
    int anio=2019,ciclo=1;
    
    leerAsistencias(anio,ciclo,arrCodCurso,arrCantAlumnosCurso,arrCantHorarios,
            arrPorcenAsistencia,numCursos);
    
    leeLlenaEncuestas(anio,ciclo,arrCodCurso,arrCantAlumnosCurso,arrCantHorarios,
            arrPorcenAsistencia,numCursos,arrEncuestaReal,arrEncuestaAjustada);
    calcularEncuestaAjustada(arrEncuestaAjustada,arrPorcenAsistencia,numCursos);
    emiteReporte1(anio,ciclo,arrCodCurso,arrCantAlumnosCurso,arrCantHorarios,
            arrPorcenAsistencia,numCursos,arrEncuestaReal,arrEncuestaAjustada);
    emiteReporte2(anio,ciclo,arrEncuestaReal,arrEncuestaAjustada,
            arrFrecuenciaEncuestaReal,arrFrecuenciaEncuestaAjustada,numCursos);
    return 0;
}

