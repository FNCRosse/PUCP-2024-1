

/* 
 * File:   funciones.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 14 de mayo de 2023, 02:10 PM
 */


#include <iostream>
#include <fstream>
#include <iomanip>


using namespace std;

#define MAX_BARRA 30
#define MAX_LINE 150
#define NO_ENCONTRADO -1
#include "funciones.h"


void leerAsistencias(int anio,int ciclo,int *arrCodCurso,int *arrCantAlumnosCurso,
        int *arrCantHorarios,double *arrPorcenAsistencia,int &numCursos){
    
    
    ifstream archAsistencias("Asistencia_clases.txt",ios::in);
    if(not archAsistencias.is_open()){
        cout<<"ERROR al abrir el archivo de Asistencia_clases"<<endl;
        exit(1);
    }
    
    int anio_evaluar,ciclo_evaluar,cod_curso,cod_horario,alumnos_matriculados,
            posCurso;
    double porcentaje_asistencia;
    numCursos=0;
    while(true){
        archAsistencias>>anio_evaluar;
        if(archAsistencias.eof())break;
        archAsistencias>>ciclo_evaluar;
        archAsistencias>>cod_curso>>cod_horario>>alumnos_matriculados;
        archAsistencias>>porcentaje_asistencia;
        if(anio_evaluar==anio and ciclo_evaluar==ciclo){
            posCurso=buscarPosicion(arrCodCurso,cod_curso,numCursos);
            if(posCurso==NO_ENCONTRADO){ /*Si el curso no es repetido*/
                arrCodCurso[numCursos]=cod_curso;
                arrCantHorarios[numCursos]++;
                arrCantAlumnosCurso[numCursos]+=alumnos_matriculados;
                arrPorcenAsistencia[numCursos]+=porcentaje_asistencia*
                        alumnos_matriculados;
                numCursos++;
            }else if(posCurso!=NO_ENCONTRADO){/*Si el curso ya se registró*/
                arrCantHorarios[posCurso]++;
                arrCantAlumnosCurso[posCurso]+=alumnos_matriculados;
                arrPorcenAsistencia[posCurso]+=porcentaje_asistencia*
                        alumnos_matriculados;
            }
        }   
    }
    for(int i=0;i<numCursos;i++)
        arrPorcenAsistencia[i]=arrPorcenAsistencia[i]/arrCantAlumnosCurso[i];
    
//    for(int i=0;i<numCursos;i++)
//        cout<<arrCodCurso[i]<<' '<<arrCantAlumnosCurso[i]<<' '
//                <<arrCantHorarios[i]<<' '<<arrPorcenAsistencia[i]<<endl;
}

void leeLlenaEncuestas(int anio,int ciclo,int *arrCodCurso,int *arrCantAlumnosCurso,
        int *arrCantHorarios,double *arrPorcenAsistencia,int numCursos,
        double *arrEncuestaReal,double *arrEncuestaAjustada){
    
    ifstream archEncuestas("Encuestas_Alumnos.txt",ios::in);
    if(not archEncuestas.is_open()){
        cout<<"ERROR al abrir el archivo de Encuestas_Alumnos"<<endl;
        exit(1);
    }   
    int anio_leido,ciclo_leido,codCurso_leido,codHorario_leido,dd,mm,aa,
            posCurso,cantValores;
    char c;
    double valores,sumaValores;
    while(true){
        archEncuestas>>anio_leido;
        if(archEncuestas.eof())break;
        archEncuestas>>ciclo_leido;
        archEncuestas>>codCurso_leido>>codHorario_leido;
        archEncuestas>>dd>>c>>mm>>c>>aa;
        if(anio_leido==anio and ciclo_leido==ciclo){
            posCurso=buscarPosicion(arrCodCurso,codCurso_leido,numCursos);
            if(posCurso!=NO_ENCONTRADO){
                cantValores=0;
                sumaValores=0;
                while(true){
                    archEncuestas>>valores;
                    sumaValores+=valores;
                    cantValores++;
                    if(archEncuestas.get()=='\n')break;
                }
                arrEncuestaReal[posCurso]+=sumaValores/cantValores;
            }else while(archEncuestas.get()!='\n');
        }else while(archEncuestas.get()!='\n');
    }
    for(int i=0;i<numCursos;i++)
        arrEncuestaReal[i]=arrEncuestaReal[i]/arrCantHorarios[i];
}

void calcularEncuestaAjustada(double *arrEncuestaAjustada,
        double *arrPorcenAsistencia,int numCursos){
    
    for(int i=0;i<numCursos;i++){
        if(arrPorcenAsistencia[i]>=90)
            arrEncuestaAjustada[i]=arrPorcenAsistencia[i]*1;
        else if(arrPorcenAsistencia[i]<90 and arrPorcenAsistencia[i]>=80)
            arrEncuestaAjustada[i]=arrPorcenAsistencia[i]*1.05;
        else if(arrPorcenAsistencia[i]<80 and arrPorcenAsistencia[i]>=70)
            arrEncuestaAjustada[i]=arrPorcenAsistencia[i]*1.08;
        else if(arrPorcenAsistencia[i]<70 and arrPorcenAsistencia[i]>=60)
            arrEncuestaAjustada[i]=arrPorcenAsistencia[i]*1.11;
        else if(arrPorcenAsistencia[i]<60 and arrPorcenAsistencia[i]>=50)
            arrEncuestaAjustada[i]=arrPorcenAsistencia[i]*1.13;
        else if(arrPorcenAsistencia[i]<50)
            arrEncuestaAjustada[i]=arrPorcenAsistencia[i]*0;
    }
}

void emiteReporte1(int anio,int ciclo,int *arrCodCurso,int *arrCantAlumnosCurso,
        int *arrCantHorarios,double *arrPorcenAsistencia,int numCursos,
        double *arrEncuestaReal,double *arrEncuestaAjustada){
    
    ofstream archReporte("Resumen_Asistencia_Encuesta.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR al abrir el archivo de Resumen_Asistencia_Encuesta"<<endl;
        exit(1);
    }
    archReporte<<setprecision(1);
    archReporte<<fixed;
    archReporte<<"RESUMEN DE LA ASISTENCIA Y ENCUESTA DE ALUMNOS POR CURSO"<<endl;
    archReporte<<"ANIO: "<<anio<<setw(5)<<' '<<"CICLO: "<<ciclo<<endl;
    imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<"CURSO"<<setw(5)<<' '<<"ALUMNOS"<<setw(5)<<' '
            <<"HORARIOS"<<setw(5)<<' '<<"ASISTENCIA (%)"<<setw(5)<<' '
            <<"ENCUESTA REAL (%)"<<setw(5)<<' '<<"ENCUESTA AJUSTADA (%)"<<endl;
    imprimeLinea('=',MAX_LINE,archReporte);
    for(int i=0;i<numCursos;i++){
        archReporte<<arrCodCurso[i]<<setw(8)<<' '<<setw(4)<<arrCantAlumnosCurso[i]
                <<setw(10)<<' '<<setw(2)<<arrCantHorarios[i]<<setw(10)<<' '
                <<setw(6)<<arrPorcenAsistencia[i]<<'%'<<setw(15)<<' '
                <<setw(6)<<arrEncuestaReal[i]<<'%'<<setw(15)<<' '
                <<setw(6)<<arrEncuestaAjustada[i]<<'%'<<endl;
    }
    imprimeLinea('=',MAX_LINE,archReporte);
        
}

void emiteReporte2(int anio,int ciclo,double *arrEncuestaReal,
        double *arrEncuestaAjustada,int *arrFrecuenciaEncuestaReal,
        int *arrFrecuenciaEncuestaAjustada,int numCursos){
    
    ofstream archReporte("Estadistica_Encuesta.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR al abrir el archivo de Estadistica_Encuesta"<<endl;
        exit(1);
    }
    archReporte<<"GRAFICO DE DISTRIBUCION DE ENCUESTAS"<<endl;
    archReporte<<"ANIO: "<<anio<<setw(5)<<' '<<"CICLO: "<<ciclo<<endl;
    imprimeLinea('=',MAX_LINE,archReporte);
    for(int i=0;i<numCursos;i++){
        if(arrEncuestaReal[i]>=90 and arrEncuestaReal[i]<100)
            arrFrecuenciaEncuestaReal[9]++;
        else if(arrEncuestaReal[i]>=80 and arrEncuestaReal[i]<90)
            arrFrecuenciaEncuestaReal[8]++;
        else if(arrEncuestaReal[i]>=70 and arrEncuestaReal[i]<80)
            arrFrecuenciaEncuestaReal[7]++;
        else if(arrEncuestaReal[i]>=60 and arrEncuestaReal[i]<70)
            arrFrecuenciaEncuestaReal[6]++;
        else if(arrEncuestaReal[i]>=50 and arrEncuestaReal[i]<60)
            arrFrecuenciaEncuestaReal[5]++;
        else if(arrEncuestaReal[i]>=40 and arrEncuestaReal[i]<50)
            arrFrecuenciaEncuestaReal[4]++;
        else if(arrEncuestaReal[i]>=30 and arrEncuestaReal[i]<40)
            arrFrecuenciaEncuestaReal[3]++;
        else if(arrEncuestaReal[i]>=20 and arrEncuestaReal[i]<30)
            arrFrecuenciaEncuestaReal[2]++;
        else if(arrEncuestaReal[i]>=10 and arrEncuestaReal[i]<20)
            arrFrecuenciaEncuestaReal[1]++;
        else if(arrEncuestaReal[i]>=0 and arrEncuestaReal[i]<10)
            arrFrecuenciaEncuestaReal[0]++;
    }
    
    for(int i=0;i<numCursos;i++){
        if(arrEncuestaAjustada[i]>=90 and arrEncuestaAjustada[i]<100)
            arrFrecuenciaEncuestaAjustada[9]++;
        else if(arrEncuestaAjustada[i]>=80 and arrEncuestaAjustada[i]<90)
            arrFrecuenciaEncuestaAjustada[8]++;
        else if(arrEncuestaAjustada[i]>=70 and arrEncuestaAjustada[i]<80)
            arrFrecuenciaEncuestaAjustada[7]++;
        else if(arrEncuestaAjustada[i]>=60 and arrEncuestaAjustada[i]<70)
            arrFrecuenciaEncuestaAjustada[6]++;
        else if(arrEncuestaAjustada[i]>=50 and arrEncuestaAjustada[i]<60)
            arrFrecuenciaEncuestaAjustada[5]++;
        else if(arrEncuestaAjustada[i]>=40 and arrEncuestaAjustada[i]<50)
            arrFrecuenciaEncuestaAjustada[4]++;
        else if(arrEncuestaAjustada[i]>=30 and arrEncuestaAjustada[i]<40)
            arrFrecuenciaEncuestaAjustada[3]++;
        else if(arrEncuestaAjustada[i]>=20 and arrEncuestaAjustada[i]<30)
            arrFrecuenciaEncuestaAjustada[2]++;
        else if(arrEncuestaAjustada[i]>=10 and arrEncuestaAjustada[i]<20)
            arrFrecuenciaEncuestaAjustada[1]++;
        else if(arrEncuestaAjustada[i]>=0 and arrEncuestaAjustada[i]<10)
            arrFrecuenciaEncuestaAjustada[0]++;
    }
    int posicion;
    int maxFrecuenciaReal=calcularMaximo(arrFrecuenciaEncuestaReal,10);
    int maxFrecuenciaAjustada=calcularMaximo(arrFrecuenciaEncuestaAjustada,10);
    int a=100,numCar;
    for(int i=11;i>0;i--){
        posicion=i-2;
        archReporte<<setw(6)<<' '<<setw(3)<<a<<' ';
        numCar=arrFrecuenciaEncuestaReal[posicion]*MAX_BARRA/maxFrecuenciaReal;
        if(posicion>=0){
            if(arrFrecuenciaEncuestaReal[posicion]>0){
                archReporte<<'|';
                for(int j=0;j<numCar;j++)
                    archReporte.put('R');
                archReporte<<"| "<<arrFrecuenciaEncuestaReal[posicion]<<endl<<endl;
            }else archReporte<<endl<<endl;
            a=a-10;
        }else archReporte<<endl<<endl;
    }
}

int calcularMaximo(int *arreglo,int numDatos){
    int max=0;
    for(int i=0;i<numDatos;i++)
        if(arreglo[i]>max)max=arreglo[i];
    return max;
}

int buscarPosicion(int *arreglo,int elemento, int numDatos){
    for(int i=0;i<numDatos;i++)
        if(arreglo[i]==elemento)return i;
    
    return NO_ENCONTRADO;
}

void imprimeLinea(char caracter, int cantidad, ofstream &archRep){
    for(int i=0;i<cantidad;i++)archRep<<caracter;
    archRep<<endl;
}
