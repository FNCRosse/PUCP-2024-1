/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   funciones.h
 * Author: aml
 *
 * Created on 10 de mayo de 2023, 01:48 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H


void leerProductos(int *arrCodigoProducto,int *arrStockOriginalProducto,
        double *arrPrecioProd,int &numProductos);
//void leerClientes(ifstream &arrDniCliente,int &numClientes);
void leerPedidos(int *arrFechaPedido,int *arrHoraPedido,int *arrNumPedido,
        int *arrDniPedido,int &numPedidos);
void ordenarPedidos(int *arrFechaPedido,int *arrHoraPedido,int *arrNumPedido,
        int *arrDniPedido,int numPedidos);
void intercambiarInt(int *arreglo,int i,int j);
void leeProcesarDetalles(int *arrDetallePedido,int *arrDetalleProd,
        int *arrDetalleCant,int &numPedidosDetallados);
void emiteReporte(int *arrCodigoProducto,int *arrStockOriginalProducto,
        double *arrPrecioProd,int numProductos,int *arrFechaPedido,
        int* arrHoraPedido,int *arrNumPedido,int *arrDniPedido,
        int numPedidos,int *arrDetallePedido,int *arrDetalleProd,
        int *arrDetalleCant,int numPedidosDetallados);
void imprimeResumenTotal(double montoAbsolutoDevolver,ofstream &archReporte);
void imprimeDatosProductos(int stock,int codigoProducto,double precio,
        int primeraVez,int cantPedida,int cantProductos,
        double montoDevolver,double montoTotalDevolver,
        double &montoAbsolutoDevolver,int cantClientesNoAtendidos,
        int cantProductosNoEntregados,int *arrDetallePedido,
        int *arrDetalleProd,int *arrDetalleCant,int numPedidosDetallados,
        int *arrNumPedido,int *arrDniPedido,int numPedidos,ofstream &archReporte);
void imprimeResumenProductos(int cantClientesNoAtendidos,
        int cantProductosNoEntregados,double montoTotalDevolver,
        ofstream &archReporte);
void imprimeProductos(int codigo,double precio,ofstream &archReporte);
void imprimeTitulo(ofstream &archReporte);
void buscaImprimeProducto(int codigo,ofstream &archReporte);
void imprimeNombreProducto(ifstream &archProductos,ofstream &archReporte);
int calculaCantidad(int producto,int *arrDetalleProd,int *arrDetalleCant,
        int numPedidosDetallados);
void imprimeLinea(char caracter, int cantidad, ofstream &archRep);

#endif /* FUNCIONES_H */

