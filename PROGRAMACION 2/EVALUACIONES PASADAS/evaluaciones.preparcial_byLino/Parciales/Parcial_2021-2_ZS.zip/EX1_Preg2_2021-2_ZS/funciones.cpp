/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.cc to edit this template
 */

#include <iostream>
#include <iomanip>
#include <fstream>

using namespace std;

#define MAX_CAR 50
#define NO_ENCONTRADO -1
#define MAX_LINE 150
#include "funciones.h"

void leerProductos(int *arrCodigoProducto,int *arrStockOriginalProducto,
        double *arrPrecioProd,int &numProductos){
    
    ifstream archProductos("StockDeProductosAlmacenados.txt",ios::in);
    if(not archProductos.is_open()){
        cout<<"ERROR al abrir el archivo de StockDeProductosAlmacenados"<<endl;
        exit(1);
    }
    
    int codigo_producto,stock_original;
    double precio;
    numProductos=0;
    
    while(true){
        archProductos>>codigo_producto;
        if(archProductos.eof())break;
        while(archProductos.get()!=')');
        archProductos.get();
        archProductos>>stock_original;
        archProductos>>precio;
        
        arrCodigoProducto[numProductos]=codigo_producto;
        arrStockOriginalProducto[numProductos]=stock_original;
        arrPrecioProd[numProductos]=precio;
        numProductos++;
    }
}

//void leerClientes(ifstream &arrDniCliente,int &numClientes){
//    
//    ifstream archClientes("ClientesRegistrados.txt",ios::in);
//    if(not archClientes.is_open()){
//        cout<<"ERROR al abrir el archivo de ClientesRegistrados"<<endl;
//        exit(1);
//    }
//    
//    int dni_cliente;
//    numClientes=0;
//    
//    while(true){
//        archClientes>>dni_cliente;
//        if(archClientes.eof())break;
//        arrDniCliente[numClientes]=dni_cliente;
//        numClientes++;
//        while(archClientes.get()!='\n');
//    }
//}

void leerPedidos(int *arrFechaPedido,int *arrHoraPedido,int *arrNumPedido,
        int *arrDniPedido,int &numPedidos){
    
    ifstream archPedidos("Pedidos.txt",ios::in);
    if(not archPedidos.is_open()){
        cout<<"ERROR al abrir el archivo de Pedidos"<<endl;
        exit(1);
    }
    
    int num_pedido,dniCliente_pedido,dia,mes,anio,hora,min,segundo,fecha,tiempo;
    numPedidos=0;
    char c;
    while(true){
        archPedidos>>dia;
        if(archPedidos.eof())break;
        archPedidos>>c>>mes>>c>>anio;
        archPedidos>>hora>>c>>min>>c>>segundo;
        archPedidos>>num_pedido;
        archPedidos>>dniCliente_pedido;
        fecha = anio*10000 + mes * 100 + dia;
        tiempo = hora*3600 + min * 60 + segundo;
        arrFechaPedido[numPedidos]=fecha;
        arrHoraPedido[numPedidos]=tiempo;
        arrNumPedido[numPedidos]=num_pedido;
        arrDniPedido[numPedidos]=dniCliente_pedido;
        numPedidos++;
        
    }
}

void ordenarPedidos(int *arrFechaPedido,int *arrHoraPedido,int *arrNumPedido,
        int *arrDniPedido,int numPedidos){
    for(int i=0;i<numPedidos-1;i++)
        for(int k=i+1;k<numPedidos;k++){
            if(arrFechaPedido[i]>arrFechaPedido[k] or 
                    (arrFechaPedido[i]==arrFechaPedido[k]
                    and arrHoraPedido[i]>arrHoraPedido[k]) or
                    (arrFechaPedido[i]==arrFechaPedido[k] and 
                    arrHoraPedido[i]==arrHoraPedido[k] and 
                    arrNumPedido[i]>arrNumPedido[k])){
                intercambiarInt(arrFechaPedido,i,k);
                intercambiarInt(arrHoraPedido,i,k);
                intercambiarInt(arrNumPedido,i,k);
                intercambiarInt(arrDniPedido,i,k);
            }
        }
    
}

void intercambiarInt(int *arreglo,int i,int j){
    int aux;
    aux=arreglo[i];
    arreglo[i]=arreglo[j];
    arreglo[j]=aux;
}

void leeProcesarDetalles(int *arrDetallePedido,int *arrDetalleProd,
        int *arrDetalleCant,int &numPedidosDetallados){
    
    ifstream archPedidosDetalle("DetalleDeLosPedidos.txt",ios::in);
    if(not archPedidosDetalle.is_open()){
        cout<<"ERROR al abrir el archivo de DetalleDeLosPedidos"<<endl;
        exit(1);
    }
    
    int pedido_leido,prod_leido,cant_solicitada;
    numPedidosDetallados=0;
    
    while(true){
        archPedidosDetalle>>pedido_leido;
        if(archPedidosDetalle.eof())break;
        archPedidosDetalle>>prod_leido;
        archPedidosDetalle>>cant_solicitada;
        
        arrDetallePedido[numPedidosDetallados]=pedido_leido;
        arrDetalleProd[numPedidosDetallados]=prod_leido;
        arrDetalleCant[numPedidosDetallados]=cant_solicitada;
        numPedidosDetallados++;
    }
}

void emiteReporte(int *arrCodigoProducto,int *arrStockOriginalProducto,
        double *arrPrecioProd,int numProductos,int *arrFechaPedido,
        int* arrHoraPedido,int *arrNumPedido,int *arrDniPedido,
        int numPedidos,int *arrDetallePedido,int *arrDetalleProd,
        int *arrDetalleCant,int numPedidosDetallados){
    
    ofstream archReporte("ReportedePedidosNoSatisfechos.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR al abrir el archivo de ReportedePedidosNoSatisfechos"<<endl;
        exit(1);
    }
    int cantSolicitada,cantPedida=0,primeraVez=1,cantProductos,
            cantClientesNoAtendidos,cantProductosNoEntregados;
    double montoDevolver,montoTotalDevolver,montoAbsolutoDevolver=0;
    archReporte<<setprecision(2);
    archReporte<<fixed;
    imprimeTitulo(archReporte);
    for(int i=0;i<numProductos;i++){
        cantSolicitada=calculaCantidad(arrCodigoProducto[i],arrDetalleProd,
                arrDetalleCant,numPedidosDetallados);
        if(cantSolicitada>arrStockOriginalProducto[i]){
            imprimeProductos(arrCodigoProducto[i],arrPrecioProd[i],archReporte);
            imprimeDatosProductos(arrStockOriginalProducto[i],
                    arrCodigoProducto[i],arrPrecioProd[i],primeraVez,cantPedida,
                    cantProductos,montoDevolver,montoTotalDevolver,
                    montoAbsolutoDevolver,cantClientesNoAtendidos,
                    cantProductosNoEntregados,arrDetallePedido,arrDetalleProd,
                    arrDetalleCant,numPedidosDetallados,arrNumPedido,arrDniPedido,
                    numPedidos,archReporte);
        }
    }
    imprimeResumenTotal(montoAbsolutoDevolver,archReporte);
}

void imprimeResumenTotal(double montoAbsolutoDevolver,ofstream &archReporte){
    imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<"Monto total que habra que devolver a los clientes: "
            <<setw(12)<<montoAbsolutoDevolver<<endl;
    imprimeLinea('=',MAX_LINE,archReporte);
}

void imprimeDatosProductos(int stock,int codigoProducto,double precio,
        int primeraVez,int cantPedida,int cantProductos,
        double montoDevolver,double montoTotalDevolver,
        double &montoAbsolutoDevolver,int cantClientesNoAtendidos,
        int cantProductosNoEntregados,int *arrDetallePedido,
        int *arrDetalleProd,int *arrDetalleCant,int numPedidosDetallados,
        int *arrNumPedido,int *arrDniPedido,int numPedidos,ofstream &archReporte){
    primeraVez=1,cantPedida=cantProductos=montoTotalDevolver=
            cantClientesNoAtendidos=cantProductosNoEntregados=0;
    for(int j=0;j<numPedidos;j++){
        for(int k=0;k<numPedidosDetallados;k++){
            if(codigoProducto==arrDetalleProd[k] and
                    arrNumPedido[j]==arrDetallePedido[k]){
                cantPedida+=arrDetalleCant[k];                    
                if(cantPedida>stock){
                    cantProductos++;
                    cantClientesNoAtendidos++;
                    archReporte<<setw(6)<<cantProductos<<')'<<setw(9)
                            <<arrDniPedido[j]<<setw(10)<<' '
                            <<setw(8)<<arrDetalleCant[k];
                    if(primeraVez==1){
                        archReporte<<setw(10)<<' '<<setw(18)
                                <<cantPedida-stock;
                        montoDevolver=(cantPedida-stock)*precio;
                        archReporte<<setw(20)<<' '<<setw(9)
                                <<montoDevolver<<endl;
                        primeraVez=0;
                        cantProductosNoEntregados+=(cantPedida-stock);
                    }else {
                        archReporte<<setw(10)<<' '<<setw(18)
                            <<arrDetalleCant[k];
                        montoDevolver=arrDetalleCant[k]*precio;
                        archReporte<<setw(20)<<' '<<setw(9)
                                <<montoDevolver<<endl;
                        cantProductosNoEntregados+=arrDetalleCant[k];
                    }
                    montoTotalDevolver+=montoDevolver;
                }
            }
        }
    }
    montoAbsolutoDevolver+=montoTotalDevolver;
    imprimeResumenProductos(cantClientesNoAtendidos,cantProductosNoEntregados,
            montoTotalDevolver,archReporte);
}

void imprimeResumenProductos(int cantClientesNoAtendidos,
        int cantProductosNoEntregados,double montoTotalDevolver,
        ofstream &archReporte){
        imprimeLinea('-',MAX_LINE,archReporte);
    archReporte<<"Cantidad de clientes no atendidos:"<<setw(12)
            <<cantClientesNoAtendidos<<endl;
    archReporte<<"Cantidad de productos no entregados:"<<setw(10)
            <<cantProductosNoEntregados<<endl;
    archReporte<<"Monto total a devolver:"<<setw(23)<<montoTotalDevolver<<endl;
}

void imprimeProductos(int codigo,double precio,ofstream &archReporte){
        imprimeLinea('-',MAX_LINE,archReporte);
    archReporte<<"Producto: ";
    buscaImprimeProducto(codigo,archReporte);
    archReporte<<"Codigo: "<<setw(8)<<codigo<<setw(10)
            <<' '<<"Precio: "<<setw(5)<<precio<<endl;
    archReporte<<"ClIENTES A LOS QUE NO SE LE PODRA ATENDER:"<<endl;
    archReporte<<setw(10)<<' '<<"DNI"<<setw(10)<<' '<<"CANTIDAD SOLICITADA"
            <<setw(10)<<' '<<"CANTIDAD NO ATENDIDA"<<setw(10)<<' '
            <<"MONTO A DEVOLVER"<<endl;
}

void imprimeTitulo(ofstream &archReporte){
    
    imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<setw(50)<<' '<<"TIENDA VIRTUAL LA MAGNIFICA"<<endl;
    archReporte<<setw(45)<<' '<<"ALERTA DE INSUFICIENCIA DE PRODUCTOS"<<endl;
}

void buscaImprimeProducto(int codigo,ofstream &archReporte){
    
    ifstream archProductos("StockDeProductosAlmacenados.txt",ios::in);
    if(not archProductos.is_open()){
        cout<<"ERROR al abrir el archivo de StockDeProductosAlmacenados"<<endl;
        exit(1);
    }
    
    int producto;
    
    while(true){
        archProductos>>producto;
        if(archProductos.eof())break;
        if(producto==codigo){
            imprimeNombreProducto(archProductos,archReporte);
            return;
        }else while(archProductos.get()!='\n');
    }
    
}

void imprimeNombreProducto(ifstream &archProductos,ofstream &archReporte){
    
    char producto;
    int numCar=0;
    archProductos>>ws;
    archProductos.get();
    while(true){
        producto=archProductos.get();
        if(producto==')')break;
        archReporte.put(producto);
        numCar++;
    }
    for(int i=0;i<MAX_CAR-numCar;i++)archReporte.put(' ');
}

int calculaCantidad(int producto,int *arrDetalleProd,int *arrDetalleCant,
        int numPedidosDetallados){
    
    int cantidadSolicitada_producto=0;
    for(int i=0;i<numPedidosDetallados;i++){
        if(arrDetalleProd[i]==producto){
            cantidadSolicitada_producto+=arrDetalleCant[i];
        }
    }
    return cantidadSolicitada_producto;
}


int buscarPosicion(int *arreglo,int elemento,int numDatos){
    for(int i=0;i<numDatos;i++)
        if(arreglo[i]==elemento)return i;
    
    return NO_ENCONTRADO;
}

void imprimeLinea(char caracter, int cantidad, ofstream &archRep){
    for(int i=0;i<cantidad;i++)archRep.put(caracter);
    archRep.put('\n');
}

//void leerDetallesPedidos(int *arrCodigoProducto,int *arrStockOriginalProducto,
//            double *arrPrecioProd,int numProductos,int *arrDniCliente,int *arrCantAtendida,
//            int *arrCantNoAtendidad,double *arrMontoDevolver,int numClientes,
//            int *arrDniPedido,int *arrNumPedido,int numPedidos){
//     
//    ifstream archDetalles("DetalleDeLosPedidos.txt",ios::in);
//    if(not archDetalles.is_open()){
//        cout<<"ERROR al abrir el archivo de DetalleDeLosPedidos"<<endl;
//        exit(1);
//    }
//    
//    int numeroPedido_evaluar,codProd_evaluar,cantPedida_producto,
//            posPedido,posProducto;
//    
//    while(true){
//        archDetalles>>numeroPedido_evaluar;
//        if(archDetalles.eof())break;
//        archDetalles>>codProd_evaluar;
//        archDetalles>>cantPedida_producto;
//        posPedido=(arrNumPedido,numeroPedido_evaluar,numPedidos);
//        if(posPedido!=NO_ENCONTRADO){
//            posProducto=buscarPosicion(arrCodigoProducto,codProd_evaluar,numProductos);
//            if(posProducto!=NO_ENCONTRADO){
//                
//            }
//        }
//    }
//}
