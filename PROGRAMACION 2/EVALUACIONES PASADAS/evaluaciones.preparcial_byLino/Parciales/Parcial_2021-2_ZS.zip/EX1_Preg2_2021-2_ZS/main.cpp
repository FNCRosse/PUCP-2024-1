/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: aml
 *
 * Created on 10 de mayo de 2023, 01:33 PM
 */

#include <iostream>
#include <iomanip>
#include <fstream>

using namespace std;

#define MAX_ARTICULOS 10
#define MAX_PEDIDOS 50
#define MAX_PRODUCTOS 100
#define MAX_CLIENTES 100
#include "funciones.h"
/*
 * 
 */
int main(int argc, char** argv) {
    
    int arrCodigoProducto[MAX_PRODUCTOS],
            arrStockOriginalProducto[MAX_PRODUCTOS],numProductos;
    double arrPrecioProd[MAX_PRODUCTOS];
    
//    int arrDniCliente[MAX_CLIENTES],arrCantAtendida[MAX_CLIENTES],
//            arrCantNoAtendidad[MAX_CLIENTES],numClientes;
//    double arrMontoDevolver[MAX_CLIENTES];
    
    int arrFechaPedido[MAX_PEDIDOS],arrHoraPedido[MAX_PEDIDOS],
            arrNumPedido[MAX_PEDIDOS],arrDniPedido[MAX_PEDIDOS],numPedidos;
    
    int arrDetallePedido[500],arrDetalleProd[500],arrDetalleCant[500],
            numPedidosDetallados;
    leerProductos(arrCodigoProducto,arrStockOriginalProducto,arrPrecioProd,
            numProductos);
//    leerClientes(arrDniCliente,numClientes);
    leerPedidos(arrFechaPedido,arrHoraPedido,arrNumPedido,arrDniPedido,numPedidos);
    ordenarPedidos(arrFechaPedido,arrHoraPedido,arrNumPedido,arrDniPedido,numPedidos);
    
    for(int i=0;i<numPedidos;i++)
        cout<<arrFechaPedido[i]<<' '<<arrHoraPedido[i]<<' '<<arrNumPedido[i]
                <<' '<<arrDniPedido[i]<<endl;
    
    leeProcesarDetalles(arrDetallePedido,arrDetalleProd,arrDetalleCant,
            numPedidosDetallados);
    
    emiteReporte(arrCodigoProducto,arrStockOriginalProducto,arrPrecioProd,
            numProductos,arrFechaPedido,arrHoraPedido,arrNumPedido,arrDniPedido,
            numPedidos,arrDetallePedido,arrDetalleProd,arrDetalleCant,
            numPedidosDetallados);
//    leerDetallesPedidos(arrCodigoProducto,arrStockOriginalProducto,
//            arrPrecioProd,numProductos,arrCantAtendida,
//            arrCantNoAtendidad,arrMontoDevolver,numClientes,
//            arrFechaPedido,arrHoraPedido,arrDniPedido,arrNumPedido,numPedidos);
    return 0;
}

