/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.cc to edit this template
 */

#include <iostream>
#include <iomanip>
#include <fstream>
#include <set>

using namespace std;


#define MAX_NOMBRE 60
#define MAX_LINE 150
#include "funciones.h"


void emiteReporte(ifstream &archProdAlmacenados,ifstream &archDetallesPedidos,
        ifstream &archPedidos,ifstream &archClientes,ofstream &archReporte){
    
    
    imprimeEncabezados(archReporte);
    int cod_producto,cantidad_stock,stockPedido,canTotalAcomprar;
    double precio,montoAinvertir,montoTotalInvertir=0;
    while(true){
        leeImprimeProductos(cod_producto,cantidad_stock,precio,
                archProdAlmacenados,archReporte);
        if(archProdAlmacenados.eof())break;
        analizarStockProducto(archDetallesPedidos,cod_producto,
            stockPedido);
        if(stockPedido>cantidad_stock){
            archReporte<<"El stock no cubrira los "
            "pedidos"<<setw(10)<<' '<<setw(5)<<cantidad_stock<<setw(10)<<' '
            <<"Falta stock"<<endl;
            leeBuscaImprimePedidos(cod_producto,cantidad_stock,canTotalAcomprar,
                    archDetallesPedidos,archPedidos,archClientes,archReporte);
            imprimeResumen(canTotalAcomprar,precio,montoAinvertir,archReporte);
            montoTotalInvertir+=montoAinvertir;
        }
        else archReporte<<"El stock cubrira los pedidos"<<setw(10)<<' '<<setw(8)
            <<cantidad_stock<<setw(10)<<' '<<setw(5)<<stockPedido<<endl;
        imprimeLinea('-',MAX_LINE,archReporte);
    }
    imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<"MONTO TOTAL A INVERTIR PARA CUBRIR LOS PEDIDOS: S/."
            <<setw(10)<<montoTotalInvertir<<endl;
    imprimeLinea('=',MAX_LINE,archReporte);    
}

void imprimeResumen(int canTotalAcomprar,double precio,double &montoAinvertir,
        ofstream &archReporte){
    archReporte<<"Cantidad total a comprar: "<<setw(4)<<canTotalAcomprar<<endl;
    archReporte<<"Precio: "<<setw(22)<<precio<<endl;
    montoAinvertir=precio*canTotalAcomprar;
    archReporte<<"Monto a invertir: "<<setw(12)<<montoAinvertir<<endl;
}

void leeBuscaImprimePedidos(int cod_producto,int cantidad_stock,int &canTotalAcomprar,
        ifstream &archDetallesPedidos,ifstream &archPedidos,
        ifstream &archClientes,ofstream &archReporte){
    
    archDetallesPedidos.clear();
    archDetallesPedidos.seekg(0,ios::beg);
    imprimeEncabezadosPedidos(archReporte);
    int num_pedido,codProd_evaluar,cant_pedida,stockPedido=0,primeraVez=1;
    canTotalAcomprar=0;
    while(true){
        archDetallesPedidos>>num_pedido;
        if(archDetallesPedidos.eof())break;
        archDetallesPedidos>>codProd_evaluar;
        archDetallesPedidos>>cant_pedida;
        if(codProd_evaluar==cod_producto){
            stockPedido+=cant_pedida;
            if(stockPedido>cantidad_stock){
                buscaPedidosDeProducto(num_pedido,archPedidos,archClientes,
                        archReporte);
                if(primeraVez){
                    canTotalAcomprar+=stockPedido-cantidad_stock;
                    archReporte<<setw(10)<<' '<<setw(3)
                            <<stockPedido-cantidad_stock<<endl;
                    primeraVez=0;
                }else archReporte<<setw(10)<<' '<<setw(3)<<cant_pedida<<endl;
                canTotalAcomprar+=cant_pedida;
            }
        }
    }
}

void buscaPedidosDeProducto(int num_pedido,ifstream &archPedidos,
        ifstream &archClientes,ofstream &archReporte){
    archPedidos.clear();
    archPedidos.seekg(0,ios::beg);
    
    int dia,mes,anio,hora,min,seg,numPedido_evaluar,dni;
    char c;
    while(true){
        archPedidos>>dia;
        if(archPedidos.eof())break;
        archPedidos>>c>>mes>>c>>anio;
        archPedidos>>hora>>c>>min>>c>>seg;
        archPedidos>>numPedido_evaluar;
        archPedidos>>dni;
        if(numPedido_evaluar==num_pedido){          
            archReporte<<num_pedido<<setw(10)<<' '<<dni<<'-';
            buscaImprimeCliente(dni,archClientes,archReporte);
            archReporte<<setfill('0')<<setw(2)<<dia<<'/'<<setw(2)<<mes<<'/'
                    <<anio<<setfill(' ');
        }
    }
}

void buscaImprimeCliente(int dni,ifstream &archClientes,ofstream &archReporte){
    archClientes.clear();
    archClientes.seekg(0,ios::beg);
    
    int dni_evaluar;
    
    while(true){
        archClientes>>dni_evaluar;
        if(archClientes.eof())break;
        if(dni_evaluar==dni){
            imprimeCliente(archClientes,archReporte);
        }else while(archClientes.get()!='\n');
    }
}

void imprimeCliente(ifstream &archClientes,ofstream &archReporte){
    char cliente;
    int numCar=0,canEspacios=0;
    archClientes>>ws;
    while(true){
        cliente=archClientes.get();
        if(cliente=='\n')break;
        if(cliente!=' '){
            archReporte.put(cliente);
            numCar++;
        }else if(cliente==' ' and canEspacios==0){
            archReporte.put(cliente);
            numCar++;
            archClientes>>ws;
        }else if(cliente==' ' and canEspacios==1){
            canEspacios=0;
        }
    }
    for(int i=0;i<MAX_NOMBRE-numCar;i++)archReporte.put(' ');
}

void imprimeEncabezadosPedidos(ofstream &archReporte){
    imprimeLinea('-',MAX_LINE,archReporte);
    archReporte<<"Pedidos que requieren comprar el producto"<<endl;
    imprimeLinea('-',MAX_LINE,archReporte);
    archReporte<<"Pedido"<<setw(30)<<' '<<"Cliente"<<setw(45)<<' '
            <<"Fecha"<<setw(5)<<' '<<"Cantidad por comprar"<<endl;
    imprimeLinea('-',MAX_LINE,archReporte);
}

void analizarStockProducto(ifstream &archDetallesPedidos,int cod_producto,
        int &stockPedido){
    
    archDetallesPedidos.clear();
    archDetallesPedidos.seekg(0,ios::beg);
    int numero_pedido,codProd_evaluar,cantidad_solicitada;
    stockPedido=0;
    while(true){
        archDetallesPedidos>>numero_pedido;
        if(archDetallesPedidos.eof())break;
        archDetallesPedidos>>codProd_evaluar;
        archDetallesPedidos>>cantidad_solicitada;
        if(codProd_evaluar==cod_producto)stockPedido+=cantidad_solicitada;
    }
}

void  leeImprimeProductos(int &cod_producto,int &cantidad_stock,
        double &precio,ifstream &archProdAlmacenados,
        ofstream &archReporte){
    
    archProdAlmacenados>>cod_producto;
    if(archProdAlmacenados.eof())return;
    archReporte<<cod_producto<<'-';
    imprimeProducto(archProdAlmacenados,archReporte);
    archProdAlmacenados>>cantidad_stock;
    archProdAlmacenados>>precio;
    
}

void imprimeProducto(ifstream &archProdAlmacenados,ofstream &archReporte){
    
    char producto;
    int numCar=0;
    
    archProdAlmacenados>>ws;
    archProdAlmacenados.get();
    while(true){
        producto=archProdAlmacenados.get();
        if(producto==')')break;
        archReporte.put(producto);
        numCar++;
    }
    
    for(int i=0;i<MAX_NOMBRE-numCar;i++)archReporte.put(' ');
}



void imprimeEncabezados(ofstream &archRep){
    imprimeLinea('=',MAX_LINE,archRep);
    archRep<<setw(50)<<' '<<"TIENDA VIRTUAL LA MAGNIFICA"<<endl;
    archRep<<setw(49)<<' '<<"CONTROL DE STOCKS DE PRODUCTOS"<<endl;
    imprimeLinea('=',MAX_LINE,archRep);
    archRep<<"PRODUCTO"<<setw(60)<<' '<<"OBSERVACIONES"<<setw(27)<<' '
            <<"STOCK"<<setw(3)<<' '<<"COMPROMETIDO EN PEDIDOS"<<endl;
    imprimeLinea('=',MAX_LINE,archRep);
}

void imprimeLinea(char caracter, int cantidad, ofstream &archRep){
    for(int i=0;i<cantidad;i++)archRep.put(caracter);
    archRep.put('\n');
}