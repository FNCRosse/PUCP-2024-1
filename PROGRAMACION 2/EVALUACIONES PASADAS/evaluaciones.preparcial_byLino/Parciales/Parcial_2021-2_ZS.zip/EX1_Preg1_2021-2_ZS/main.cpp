/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: aml
 *
 * Created on 10 de mayo de 2023, 01:33 PM
 */

#include <iostream>
#include <iomanip>
#include <fstream>

using namespace std;

#include "funciones.h"

/*
 * 
 */
int main(int argc, char** argv) {
    
    ifstream archProdAlmacenados("StockDeProductosAlmacenados.txt",ios::in);
    if(not archProdAlmacenados.is_open()){
        cout<<"ERROR al abrir el archivo de productos"<<endl;
        exit(1);
    }
    ifstream archDetallesPedidos("DetalleDeLosPedidos.txt",ios::in);
    if(not archDetallesPedidos.is_open()){
        cout<<"ERROR al abrir el archivo de DetalleDeLosPedidos"<<endl;
        exit(1);
    }
    ifstream archPedidos("Pedidos.txt",ios::in);
    if(not archPedidos.is_open()){
        cout<<"ERROR al abrir el archivo de Pedidos"<<endl;
        exit(1);
    }
    ifstream archClientes("ClientesRegistrados.txt",ios::in);
    if(not archClientes.is_open()){
        cout<<"ERROR al abrir el archivo de ClientesRegistrados"<<endl;
        exit(1);
    }
    ofstream archReporte("ReportedeControldeStocks.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR al abrir el archivo de ReportedeControldeStocks"<<endl;
        exit(1);
    }
    
    emiteReporte(archProdAlmacenados,archDetallesPedidos,archPedidos,
            archClientes,archReporte);
    
    return 0;
}

