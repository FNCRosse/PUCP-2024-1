/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   funciones.h
 * Author: aml
 *
 * Created on 10 de mayo de 2023, 01:37 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void emiteReporte(ifstream &archProdAlmacenados,ifstream &archDetallesPedidos,
        ifstream &archPedidos,ifstream &archClientes,ofstream &archReporte);
void imprimeResumen(int canTotalAcomprar,double precio,double &montoAinvertir,
        ofstream &archReporte);
void leeBuscaImprimePedidos(int cod_producto,int cantidad_stock,int &canTotalAcomprar,
        ifstream &archDetallesPedidos,ifstream &archPedidos,
        ifstream &archClientes,ofstream &archReporte);
void buscaPedidosDeProducto(int num_pedido,ifstream &archPedidos,
        ifstream &archClientes,ofstream &archReporte);
void buscaImprimeCliente(int dni,ifstream &archClientes,ofstream &archReporte);
void imprimeCliente(ifstream &archClientes,ofstream &archReporte);
void imprimeEncabezadosPedidos(ofstream &archReporte);

void analizarStockProducto(ifstream &archDetallesPedidos,int cod_producto,
        int &stockPedido);
void  leeImprimeProductos(int &cod_producto,int &cantidad_stock,
        double &precio,ifstream &archProdAlmacenados,
        ofstream &archReporte);
void imprimeProducto(ifstream &archProdAlmacenados,ofstream &archReporte);
void imprimeEncabezados(ofstream &archRep);
void imprimeLinea(char caracter, int cantidad, ofstream &archRep);

#endif /* FUNCIONES_H */

