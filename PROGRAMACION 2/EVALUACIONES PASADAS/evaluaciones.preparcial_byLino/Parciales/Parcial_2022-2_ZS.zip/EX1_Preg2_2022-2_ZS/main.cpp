

/* 
 * File:   main.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 8 de mayo de 2023, 11:35 AM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#define MAX_USUARIOS 20
#define MAX_TIKTOKS 1000    
#include "funciones.h"
/*
 * 
 */
int main(int argc, char** argv) {
    
    int arrFechaTikTok[MAX_TIKTOKS],arrCantLikesReprod[MAX_TIKTOKS],
            arrCantReprod[MAX_TIKTOKS],numTikToks;
    
    int arrCodUsuario[MAX_USUARIOS],numUsuarios;
    char arrTipoUsuario[MAX_USUARIOS];
    
    int arrCantComentarios[MAX_TIKTOKS]{},arrCantLikesComentario[MAX_TIKTOKS]{},
            arrCantSeguidoresPublic[MAX_TIKTOKS]{};
    double arrRatioComentarios[MAX_TIKTOKS];
    
    leerTikToks(arrFechaTikTok,arrCantLikesReprod,arrCantReprod,numTikToks);
    leerUsuarios(arrCodUsuario,arrTipoUsuario,numUsuarios);
    
    leerProcesarComentariosTikTok(arrFechaTikTok,arrCantLikesReprod,
            arrCantReprod,numTikToks,arrCodUsuario,arrTipoUsuario,numUsuarios,
            arrCantComentarios,arrCantLikesComentario,arrCantSeguidoresPublic,
            arrRatioComentarios);
    int diaIni,mesIni,anioIni,diaFin,mesFin,anioFin;
    char c;
    
    cout<<"Ingrese un rango de fechas con el siguiente formato: (DD/MM/AA)"<<endl;
    cout<<"Ingrese fecha inicial: ";
    cin>>diaIni>>c>>mesIni>>c>>anioIni;
    cout<<"Ingrese fecha final: ";
    cin>>diaFin>>c>>mesFin>>c>>anioFin;
    ordenarArreglos(arrFechaTikTok,arrCantComentarios,arrCantLikesComentario,
            arrCantReprod,arrRatioComentarios,arrCantSeguidoresPublic,
            numTikToks);
    emiteReporte(diaIni,mesIni,anioIni,diaFin,mesFin,anioFin,arrFechaTikTok,
            arrCantLikesReprod,arrCantReprod,numTikToks,arrCodUsuario,
            arrTipoUsuario,numUsuarios,arrCantComentarios,
            arrCantLikesComentario,arrCantSeguidoresPublic,arrRatioComentarios);
    
    return 0;
}

