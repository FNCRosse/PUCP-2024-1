

/* 
 * File:   funciones.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 8 de mayo de 2023, 11:35 AM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void leerTikToks(int *arrFechaTikTok,int *arrCantLikesReprod,
        int *arrCantReprod,int &numTikToks);
void leerUsuarios(int *arrCodUsuario,char *arrTipoUsuario,
        int &numUsuarios);
void leerProcesarComentariosTikTok(int *arrFechaTikTok,int *arrCantLikesReprod,
        int *arrCantReprod,int numTikToks,int *arrCodUsuario,
        char *arrTipoUsuario,int numUsuarios,int *arrCantComentarios,
        int *arrCantLikesComentario,int *arrCantSeguidoresPublic,
        double *arrRatioComentarios);
void leerComentarios(ifstream &archComentarios,int *arrFechaTikTok,int *arrCantLikesReprod,
        int *arrCantReprod,int numTikToks,int *arrCodUsuario,
        char *arrTipoUsuario,int numUsuarios,int *arrCantComentarios,
        int *arrCantLikesComentario,int *arrCantSeguidoresPublic,
        double *arrRatioComentarios,int posTikTok);
void ordenarArreglos(int *arrFechaTikTok,int *arrCantComentarios,
        int *arrCantLikesComentario,int *arrCantReprod,
        double *arrRatioComentarios,int *arrCantSeguidoresPublic,int numTikToks);
void intercambiarInt(int *arreglo,int i,int j);
void intercambiarDouble(double *arreglo,int i,int j);
void emiteReporte(int diaIni,int mesIni,int anioIni,int diaFin,int mesFin,
        int anioFin,int *arrFechaTikTok,int *arrCantLikesReprod,
        int *arrCantReprod,int numTikToks,int *arrCodUsuario,
        char *arrTipoUsuario,int numUsuarios,int *arrCantComentarios,
        int *arrCantLikesComentario,int *arrCantSeguidoresPublic,
        double *arrRatioComentarios);
void imprimeEncabezado(ofstream &archReporte,int diaIni,int mesIni,int anioIni,
        int diaFin,int mesFin,int anioFin);
void imprimeLinea(char caracter, int cantidad, ofstream &archRep);
int buscarPosicion(int *arreglo, int elemento, int numDat);
int juntarFecha(int dia, int mes, int anio);
void separarFecha(int fecha, int &dia,int &mes, int &anio);


#endif /* FUNCIONES_H */

