

/* 
 * File:   funciones.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 8 de mayo de 2023, 11:35 AM
 */


#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#define MAX_LINE 150
#define NO_ENCONTRADO -1
#include "funciones.h"


void leerTikToks(int *arrFechaTikTok,int *arrCantLikesReprod,
        int *arrCantReprod,int &numTikToks){
    
    ifstream archTikToks("TikToks.txt",ios::in);
    if(not archTikToks.is_open()){
        cout<<"ERROR al abrir el archivo de tiktoks"<<endl;
        exit(1);
    }
    
    int fecha,dia,mes,anio,cantLikes,cantReprod;
    char c;
    numTikToks=0;
    while(true){
        archTikToks>>dia;
        if(archTikToks.eof())break;
        archTikToks>>c>>mes>>c>>anio;
        archTikToks>>cantLikes;
        archTikToks>>cantReprod;
        fecha = juntarFecha(dia,mes,anio);
        arrFechaTikTok[numTikToks]=fecha;
        arrCantLikesReprod[numTikToks]=cantLikes;
        arrCantReprod[numTikToks]=cantReprod;
        
        numTikToks++;
    }
    
}

void leerUsuarios(int *arrCodUsuario,char *arrTipoUsuario,
        int &numUsuarios){
    
    ifstream archUsuarios("Usuarios.txt",ios::in);
    if(not archUsuarios.is_open()){
        cout<<"ERROR al abrir el archivo de Usuarios"<<endl;
        exit(1);
    }
    
    int pais,identificador,num_seguidores,codigo_usuario;
    char identificador_publico,c;
    numUsuarios=0;
    
    while(true){
        archUsuarios>>pais;
        if(archUsuarios.eof())break;
        archUsuarios>>c>>identificador;
        archUsuarios>>ws;
        while(archUsuarios.get()!=' ');
        archUsuarios>>num_seguidores;
        archUsuarios>>identificador_publico;
        
        codigo_usuario= pais *1000 + identificador;
        
        arrCodUsuario[numUsuarios]=codigo_usuario;
        arrTipoUsuario[numUsuarios]=identificador_publico;
        numUsuarios++;
    }
    
}

void leerProcesarComentariosTikTok(int *arrFechaTikTok,int *arrCantLikesReprod,
        int *arrCantReprod,int numTikToks,int *arrCodUsuario,
        char *arrTipoUsuario,int numUsuarios,int *arrCantComentarios,
        int *arrCantLikesComentario,int *arrCantSeguidoresPublic,
        double *arrRatioComentarios){
    
    ifstream archComentarios("Comentarios.txt",ios::in);
    if(not archComentarios.is_open()){
        cout<<"ERROR al abrir el archivo de Comentarios"<<endl;
        exit(1);
    }
    
    int fechaAux,dia,mes,anio,posTikTok;
    char c;
    
    while(true){
        archComentarios>>dia;
        if(archComentarios.eof())break;
        archComentarios>>c>>mes>>c>>anio;
        fechaAux=juntarFecha(dia,mes,anio);
        posTikTok=buscarPosicion(arrFechaTikTok,fechaAux,numTikToks);
        if(posTikTok!=NO_ENCONTRADO){
            leerComentarios(archComentarios,arrFechaTikTok,arrCantLikesReprod,
            arrCantReprod,numTikToks,arrCodUsuario,arrTipoUsuario,numUsuarios,
            arrCantComentarios,arrCantLikesComentario,arrCantSeguidoresPublic,
            arrRatioComentarios,posTikTok);
        }else while(archComentarios.get()!='\n');
    }
}

void leerComentarios(ifstream &archComentarios,int *arrFechaTikTok,int *arrCantLikesReprod,
        int *arrCantReprod,int numTikToks,int *arrCodUsuario,
        char *arrTipoUsuario,int numUsuarios,int *arrCantComentarios,
        int *arrCantLikesComentario,int *arrCantSeguidoresPublic,
        double *arrRatioComentarios,int posTikTok){
    
    int pais,identificador,cantLikes_comentario,cod_usuario,posUsuario;
    char c;
    
    while(true){
        archComentarios>>pais;
        archComentarios>>c>>identificador;
        archComentarios>>ws;
        while(archComentarios.get()!=' ');
        archComentarios>>cantLikes_comentario;
        cod_usuario=pais*1000+identificador;
        posUsuario=buscarPosicion(arrCodUsuario,cod_usuario,numUsuarios);
        
        if(posUsuario!=NO_ENCONTRADO){
            arrCantComentarios[posTikTok]++;
            arrCantLikesComentario[posTikTok]+=cantLikes_comentario;
            arrRatioComentarios[posTikTok]=(double)arrCantReprod[posTikTok]*100
                    /(arrCantLikesComentario[posTikTok]);
            if(arrTipoUsuario[posUsuario]=='V')arrCantSeguidoresPublic[posTikTok]++;
        }
        
        if(archComentarios.get()=='\n')break;
    }
}

void ordenarArreglos(int *arrFechaTikTok,int *arrCantComentarios,
        int *arrCantLikesComentario,int *arrCantReprod,
        double *arrRatioComentarios,int *arrCantSeguidoresPublic,int numTikToks){
    
    for(int i=0;i<numTikToks-1;i++)
        for(int k=i+1;k<numTikToks;k++){
            if(arrCantReprod[i]<arrCantReprod[k] or
                    (arrCantReprod[i]==arrCantReprod[k] and 
                    arrFechaTikTok[i]>arrFechaTikTok[k]) ){
                intercambiarInt(arrFechaTikTok,i,k);
                intercambiarInt(arrCantComentarios,i,k);
                intercambiarInt(arrCantLikesComentario,i,k);
                intercambiarInt(arrCantReprod,i,k);
                intercambiarInt(arrCantSeguidoresPublic,i,k);
                intercambiarDouble(arrRatioComentarios,i,k);
            }
        }
}

void intercambiarInt(int *arreglo,int i,int j){
    int aux;
    aux=arreglo[i];
    arreglo[i]=arreglo[j];
    arreglo[j]=aux;
}

void intercambiarDouble(double *arreglo,int i,int j){
    double aux;
    aux =arreglo[i];
    arreglo[i]=arreglo[j];
    arreglo[j]=aux;
}

void emiteReporte(int diaIni,int mesIni,int anioIni,int diaFin,int mesFin,
        int anioFin,int *arrFechaTikTok,int *arrCantLikesReprod,
        int *arrCantReprod,int numTikToks,int *arrCodUsuario,
        char *arrTipoUsuario,int numUsuarios,int *arrCantComentarios,
        int *arrCantLikesComentario,int *arrCantSeguidoresPublic,
        double *arrRatioComentarios){
    
    ofstream archReporte("ReporteTikToksNuevoDiseño.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR al abrir el archivo de reporte"<<endl;
        exit(1);
    }
    archReporte<<setprecision(2);
    archReporte<<fixed;
    imprimeEncabezado(archReporte,diaIni,mesIni,anioIni,diaFin,mesFin,anioFin);
    int dia,mes,anio,cantVirales=0,cantNoVirales=0;
    int fechaIni= juntarFecha(diaIni,mesIni,anioIni);
    int fechaFin = juntarFecha(diaFin,mesFin,anioFin);
    for(int i=0;i<numTikToks;i++){
        if(arrFechaTikTok[i]>=fechaIni and arrFechaTikTok[i]<=fechaFin){
            separarFecha(arrFechaTikTok[i],dia,mes,anio); 
            archReporte<<setfill('0')<<setw(2)<<dia<<'/'<<setw(2)<<mes<<'/'<<anio
                    <<setfill(' ')<<setw(13)<<' '<<setw(3)<<arrCantComentarios[i]
                    <<setw(17)<<' '<<setw(8)<<arrCantLikesComentario[i]<<setw(16)
                    <<' '<<setw(8)<<arrCantReprod[i]<<setw(12)<<' '
                    <<setw(8)<<arrRatioComentarios[i];
            if(arrCantComentarios[i] > (double)arrCantReprod[i]/arrCantLikesReprod[i]){
                archReporte<<setw(15)<<' '<<"Sí";
                cantVirales++;
            }else {
                archReporte<<setw(15)<<' '<<"No";
                cantNoVirales++;
            }
            archReporte<<setw(20)<<' '<<setw(5)<<arrCantSeguidoresPublic[i]<<endl;
        }        
    }
    imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<"CANTIDAD VIRALES"<<setw(8)<<cantVirales<<endl;
    archReporte<<"CANTIDAD NO VIRALES"<<setw(5)<<cantNoVirales<<endl;
    imprimeLinea('=',MAX_LINE,archReporte);
    
}

void imprimeEncabezado(ofstream &archReporte,int diaIni,int mesIni,int anioIni,
        int diaFin,int mesFin,int anioFin){
    archReporte<<setw(50)<<' '<<"@TikTok_tp"<<endl;
    archReporte<<setw(40)<<' '<<"REPORTE PARA LA CAMPAÑA : Parcial 2022-1"<<endl;
    archReporte<<setw(35)<<' '<<"Fecha Inicial: "<<setfill('0')<<setw(2)
            <<diaIni<<'/'<<setw(2)<<mesIni<<'/'<<anioIni<<setfill(' ')<<' '
            <<"Fecha Final: "<<setfill('0')<<setw(2)<<diaFin<<'/'<<setw(2)
            <<mesFin<<'/'<<anioFin<<setfill(' ')<<endl;
    imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<"Fecha del"<<setw(10)<<' '<<"Cantidad de"
            <<setw(10)<<' '<<"Cantidad de likes"<<setw(10)
            <<' '<<"Cantidad de"<<setw(10)<<' '
            <<"Ratio de"<<setw(10)<<' '<<"Es viral?"<<setw(10)
            <<' '<<"Cantidad de seguidores"<<endl;
    archReporte<<" TikTok"<<setw(12)<<' '<<"Comentarios"<<setw(11)<<' '
            <<"de comentarios"<<setw(11)<<' '<<"Reproducciones"<<setw(7)
            <<' '<<"Comentarios"<<setw(33)<<' '<<"Publicos"<<endl;
    imprimeLinea('-',MAX_LINE,archReporte);
}

void imprimeLinea(char caracter, int cantidad, ofstream &archRep){
    for(int i=0;i<cantidad;i++)archRep.put(caracter);
    archRep.put('\n');
}

int buscarPosicion(int *arreglo, int elemento, int numDat){
    for(int i=0;i<numDat;i++)
        if(arreglo[i]==elemento)return i;
    
    return NO_ENCONTRADO;
}

int juntarFecha(int dia, int mes, int anio){
    
    int fechaJuntada = anio*10000 + mes*100 + dia;
    return fechaJuntada;
}

void separarFecha(int fecha, int &dia,int &mes, int &anio){
    
    anio = fecha/10000;
    mes = (fecha/10000)%100;
    dia = (fecha%10000)%100;
}