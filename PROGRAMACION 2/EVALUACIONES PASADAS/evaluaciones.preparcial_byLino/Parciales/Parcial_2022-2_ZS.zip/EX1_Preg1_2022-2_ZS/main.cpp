

/* 
 * File:   main.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 9 de mayo de 2023, 02:22 PM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#include "funciones.h"

/*
 * 
 */
int main(int argc, char** argv) {
    
    
    ifstream archTikTok("TikToks.txt",ios::in);
    if(not archTikTok.is_open()){
        cout<<"ERROR al abrir el archivo de tiktoks"<<endl;
        exit(1);
    }
    ifstream archComentarios("Comentarios.txt",ios::in);
    if(not archComentarios.is_open()){
        cout<<"ERROR al abrir el archivo de Comentarios"<<endl;
        exit(1);
    }
    ifstream archUsuarios("Usuarios.txt",ios::in);
    if(not archUsuarios.is_open()){
        cout<<"ERROR al abrir el archivo de Usuarios"<<endl;
        exit(1);
    }
    ifstream archPaises("Paises.txt",ios::in);
    if(not archPaises.is_open()){
        cout<<"ERROR al abrir el archivo de Paises"<<endl;
        exit(1);
    }
    
    ofstream archReporte("ReporteTikToks.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR al abrir el archivo de reporte"<<endl;
        exit(1);
    }
    int diaIni,mesIni,anioIni,diaFin,mesFin,anioFin;
    char c;
    cout<<"Ingrese un rango de fechas con el siguiente formato: (DD/MM/AA)"<<endl;
    cout<<"Ingrese fecha inicial: ";
    cin>>diaIni>>c>>mesIni>>c>>anioIni;
    cout<<"Ingrese fecha final: ";
    cin>>diaFin>>c>>mesFin>>c>>anioFin;
    emiteReporte(diaIni,mesIni,anioIni,diaFin,mesFin,anioFin,
            archTikTok,archComentarios,archUsuarios,archPaises,archReporte);
    
    return 0;
}

