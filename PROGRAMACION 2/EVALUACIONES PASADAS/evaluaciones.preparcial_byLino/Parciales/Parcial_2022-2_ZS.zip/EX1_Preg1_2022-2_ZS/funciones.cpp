

/* 
 * File:   funciones.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 9 de mayo de 2023, 03:36 PM
 */


#include <iostream>
#include <fstream>
#include <iomanip>
#include <streambuf>
#include <set>

using namespace std;

#define MAX_CAR_USU 20
#define MAX_CARAC 130
#define MAX_LINE 220
#include "funciones.h"

void emiteReporte(int diaIni,int mesIni,int anioIni,int diaFin,int mesFin,
        int anioFin,ifstream &archTikTok,ifstream &archComentarios,
        ifstream &archUsuarios,ifstream &archPaises, ofstream &archReporte){
    
    imprimeEncabezado(diaIni,mesIni,anioIni,diaFin,mesFin,anioFin,archReporte);
    int cantTiktok=0,cantLikes_tiktok,fechaTiktok,cantReprod_tiktok,
            cantComentarios,cantSeguidores_publicos,cantSeguidores_No_publicos,
            fechaMax=0,paisMax=0,identifMax=0,cantLikes_Max=0;
    double mayorRatio=0;
    while(true){
        leeImprimeTikToks(fechaTiktok,cantTiktok,cantLikes_tiktok,
                cantReprod_tiktok,archTikTok,archReporte);
        if(archTikTok.eof())break;
        imprimeEncabezadoComentarios(archReporte);
        leeImprimeComentarios(fechaTiktok,cantComentarios,
                cantSeguidores_publicos,cantSeguidores_No_publicos,
                paisMax,identifMax,cantLikes_Max,archComentarios,archUsuarios,
                archPaises,archReporte);
        analizaMejorTiktok(fechaMax,fechaTiktok,mayorRatio,
                cantLikes_tiktok,cantReprod_tiktok);
        imprimeResumenTiktok(cantLikes_tiktok,cantReprod_tiktok,cantComentarios,
                cantSeguidores_publicos,cantSeguidores_No_publicos,archReporte);
        imprimeLinea('=',MAX_LINE,archReporte);
    }
    imprimeResumentTotal(fechaMax,paisMax,identifMax,archUsuarios,archReporte);
}

void imprimeResumentTotal(int fechaMax,int paisMax,int identifMax,
        ifstream &archUsuarios,ofstream &archReporte){
    
    int anio= fechaMax/10000;
    int mes = (fechaMax/10000)%100;
    int dia = (fechaMax%10000)%100;
    
    archReporte<<endl<<"RESUMEN MEJOR TIKTOK"<<endl;
    archReporte<<"FECHA: "<<setw(10)<<' '<<setfill('0')<<setw(2)<<dia<<'/'<<setw(2)<<mes
            <<'/'<<anio<<setfill(' ')<<endl;
    archReporte<<"Seguidor que obtuvo mayor numero de likes: "<<setw(10)<<' ';
    buscaUsuario(paisMax,identifMax,archUsuarios,archReporte);
    
}

void buscaUsuario(int paisMax,int identifMax,ifstream &archUsuarios,
        ofstream &archReporte){
    archUsuarios.clear();
    archUsuarios.seekg(0,ios::beg);
    
    int codPais,codIdentificador;
    char c;
    while(true){
        archUsuarios>>codPais;
        if(archUsuarios.eof())break;
        archUsuarios>>c>>codIdentificador;
        if(codPais == paisMax and codIdentificador==identifMax)
            imprimeUsuario(archUsuarios,archReporte);
        else while(archUsuarios.get()!='\n');
    }
}

void imprimeResumenTiktok(int cantLikes_tiktok,int cantReprod_tiktok,
        int cantComentarios,int cantSeguidores_publicos,
        int cantSeguidores_No_publicos,ofstream &archReporte){
    
    
    archReporte<<"RESUMEN TIKTOK"<<setw(20)<<' '<<"LIKES: "<<setw(8)
            <<cantLikes_tiktok<<setw(10)<<' '<<"REPRODUCCIONES: "
            <<setw(8)<<cantReprod_tiktok<<endl;
    archReporte<<"Cantidad Comentarios :"<<setw(8)<<cantComentarios<<endl;
    archReporte<<"Seguidores Publicos: "<<setw(9)<<cantSeguidores_publicos<<endl;
    archReporte<<"Seguidores no publicos: "<<setw(6)
            <<cantSeguidores_No_publicos<<setw(20)<<' ';
    double ratio=(double)cantReprod_tiktok/cantLikes_tiktok;
    if(cantComentarios>ratio)archReporte<<"TIKTTOK VIRAL"<<endl;
    else archReporte<<"TIKTOK NO VIRAL"<<endl;
}

void analizaMejorTiktok(int &fechaMax,int &fechaTiktok,double &mayorRatio,
        int cantLikes_tiktok,int cantReprod_tiktok){
    
    double ratioViralidad = (double) (cantReprod_tiktok*100)/cantLikes_tiktok;
    if(ratioViralidad>mayorRatio){
        mayorRatio=ratioViralidad;
        fechaMax=fechaTiktok;
    }
}

void leeImprimeComentarios(int fechaTiktok,int &cantComentarios,
        int &cantSeguidores_publicos,int &cantSeguidores_No_publicos,
        int &paisMax,int &identifMax,int &cantLikes_Max,
        ifstream &archComentarios,ifstream &archUsuarios,ifstream &archPaises,
        ofstream &archReporte){
    
    archComentarios.clear();
    archComentarios.seekg(0,ios::beg);
    int dia_evaluar,mes_evaluar,anio_evaluar,cantLikes_comentario,fechaAux,
            codPais,identificador,codigo_usuario;
    char c;
    cantComentarios=0;
    while(true){
        archComentarios>>dia_evaluar;
        if(archComentarios.eof())break;
        archComentarios>>c>>mes_evaluar>>c>>anio_evaluar;
        fechaAux=juntarFecha(dia_evaluar,mes_evaluar,anio_evaluar);
        if(fechaAux==fechaTiktok){
            while(true){
                archComentarios>>codPais;
                archComentarios>>c>>identificador;
                codigo_usuario=codPais*1000+identificador;
                imprimeComentario(archComentarios,archReporte);
                archComentarios>>cantLikes_comentario;
                leeImprimeDatosUsuario(codPais,identificador,cantLikes_comentario,
                        cantSeguidores_publicos,cantSeguidores_No_publicos,
                        archUsuarios,archPaises,archReporte);
                analizaMayorComentario(paisMax,identifMax,cantLikes_Max,
                        codPais,identificador,cantLikes_comentario);
                cantComentarios++;
                if(archComentarios.get()=='\n')break;
            }
        }else while(archComentarios.get()!='\n');        
    }
    imprimeLinea('-',MAX_LINE,archReporte);
}

void leeImprimeDatosUsuario(int codPais,int identificador,int cantLikes_comentario,
        int &cantSeguidores_publicos,int &cantSeguidores_No_publicos,
        ifstream &archUsuarios,ifstream &archPaises,ofstream &archReporte){
    
    archUsuarios.clear();
    archUsuarios.seekg(0,ios::beg);
    
    int codpais_evaluar,identificador_evaluar,cantSeguidores;
    char tipo_cuenta,c;
    cantSeguidores_publicos=0;
    cantSeguidores_No_publicos=0;
    while(true){
        archUsuarios>>codpais_evaluar;
        if(archUsuarios.eof())break;
        archUsuarios>>c>>identificador_evaluar;
        if(codpais_evaluar==codPais and identificador_evaluar==identificador){
            imprimeUsuario(archUsuarios,archReporte);
            archUsuarios>>cantSeguidores;
            archUsuarios>>tipo_cuenta;
            archReporte<<setw(12)<<cantLikes_comentario<<setw(20)<<' ';
            if(tipo_cuenta=='V'){
                cantSeguidores_publicos++;
                buscaImprimePais(codPais,archPaises,archReporte);
            }
            else if(tipo_cuenta=='F'){
                cantSeguidores_No_publicos++;
                archReporte<<"INFORMACION NO PUBLICA"<<endl;
            }
        }else while(archUsuarios.get()!='\n');
    }
}

void analizaMayorComentario(int &paisMax,int &identifMax,
        int &cantLikes_Max,int codPais,int identificador,
        int cantLikes_comentario){
    
    if(cantLikes_comentario>cantLikes_Max){
        cantLikes_Max=cantLikes_comentario;
        paisMax=codPais;
        identifMax=identificador;
    }
}

void buscaImprimePais(int codPais,ifstream &archPaises,ofstream &archReporte){
    archPaises.clear();
    archPaises.seekg(0,ios::beg);
    
    int codPais_evaluar;
    while(true){
        archPaises>>codPais_evaluar;
        if(archPaises.eof())break;
        if(codPais_evaluar==codPais){
            imprimePais(archPaises,archReporte);
        }else while(archPaises.get()!='\n');
    }
    
}

void imprimePais(ifstream &archPaises,ofstream &archReporte){
    
    char pais;
    archPaises>>ws;
    while(true){
        pais=archPaises.get();
        if(pais=='\n')break;
        archReporte.put(pais);
    }
    archReporte.put('\n');
}

void imprimeUsuario(ifstream &archUsuarios,ofstream &archReporte){
    char usuario;
    int numCar=0;
    
    archUsuarios>>ws;
    while(true){
        usuario=archUsuarios.get();
        if(usuario==' ')break;
        archReporte.put(usuario);
        numCar++;
    }
    
    for(int i=0;i<MAX_CAR_USU-numCar;i++)archReporte.put(' ');
}

void imprimeComentario(ifstream &archComentarios,ofstream &archReporte){
    char comentario;
    int numCar=0;
    
    archComentarios>>ws;
    while(true){
        comentario=archComentarios.get();
        if(comentario==' ')break;
        archReporte.put(comentario);
        numCar++;
    }
    for(int i=0;i<MAX_CARAC-numCar;i++)archReporte.put(' ');
}

void imprimeEncabezadoComentarios(ofstream &archReporte){
    archReporte<<"COMENTARIO"<<setw(115)<<' '<<"AUTOR DEL COMENTARIO"
            <<setw(8)<<' '<<"CANTIDAD DE LIKES"<<setw(12)<<' '
            <<"PAIS DEL AUTOR"<<endl;
    imprimeLinea('-',MAX_LINE,archReporte);
}

void leeImprimeTikToks(int &fechaTiktok,int &cantTiktok,
        int &cantLikes_tiktok,int &cantReprod_tiktok,ifstream &archTikTok,
        ofstream &archReporte){
    int ddTiktok,mmTiktok,aaTiktok;
    char c;
    archTikTok>>ddTiktok;
    if(archTikTok.eof())return;
    archTikTok>>c>>mmTiktok>>c>>aaTiktok;
    fechaTiktok=juntarFecha(ddTiktok,mmTiktok,aaTiktok);
    archTikTok>>cantLikes_tiktok;
    archTikTok>>cantReprod_tiktok;
    cantTiktok++;
    imprimeTikToks(ddTiktok,mmTiktok,aaTiktok,cantTiktok,cantLikes_tiktok,
                cantReprod_tiktok,archReporte);
    
}

void imprimeTikToks(int ddTiktok,int mmTiktok,int aaTiktok,int cantTiktok,
        int cantLikes_tiktok,int cantReprod_tiktok,ofstream &archReporte){
    
    
    archReporte<<"TikTok "<<setw(3)<<cantTiktok<<") "<<setfill('0')<<setw(2)
            <<ddTiktok<<'/'<<setw(2)<<mmTiktok<<'/'<<aaTiktok<<setfill(' ')
            <<endl<<endl;
    
}

void imprimeEncabezado(int diaIni,int mesIni,int anioIni,int diaFin,int mesFin,
        int anioFin,ofstream &archReporte) {
    archReporte<<setw(45)<<' '<<"@TikTok_tp"<<endl;
    archReporte<<setw(30)<<' '<<"REPORTE PARA LA CAMPAÑA: Parcial 2022-1"<<endl;
    archReporte<<setw(26)<<' '<<"Fecha Inicial: "<<setfill('0')<<setw(2)
            <<diaIni<<'/'<<setw(2)<<mesIni<<'/'<<anioIni<<setfill(' ')
            <<" Fecha Fin: "<<setfill('0')<<setw(2)<<diaFin<<'/'
            <<setw(2)<<mesFin<<'/'<<anioFin<<setfill(' ')<<endl;
    imprimeLinea('=',MAX_LINE,archReporte);
}

int juntarFecha(int dia,int mes, int anio){
    
    int fechaJuntada= anio*10000 + mes*100+dia;
    return fechaJuntada;
}

void imprimeLinea(char caracter, int cantidad, ofstream &archReporte){
    
    for(int i=0;i<cantidad;i++)archReporte.put(caracter);
    archReporte.put('\n');
}

