

/* 
 * File:   funciones.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 9 de mayo de 2023, 03:36 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void emiteReporte(int diaIni,int mesIni,int anioIni,int diaFin,int mesFin,
        int anioFin,ifstream &archTikTok,ifstream &archComentarios,
        ifstream &archUsuarios,ifstream &archPaises, ofstream &archReporte);
void imprimeResumentTotal(int fechaMax,int paisMax,int identifMax,
        ifstream &archUsuarios,ofstream &archReporte);
void buscaUsuario(int paisMax,int identifMax,ifstream &archUsuarios,
        ofstream &archReporte);
void imprimeResumenTiktok(int cantLikes_tiktok,int cantReprod_tiktok,
        int cantComentarios,int cantSeguidores_publicos,
        int cantSeguidores_No_publicos,ofstream &archReporte);
void analizaMejorTiktok(int &fechaMax,int &fechaTiktok,double &mayorRatio,
        int cantLikes_tiktok,int cantReprod_tiktok);
void leeImprimeComentarios(int fechaTiktok,int &cantComentarios,
        int &cantSeguidores_publicos,int &cantSeguidores_No_publicos,
        int &paisMax,int &identifMax,int &cantLikes_Max,
        ifstream &archComentarios,ifstream &archUsuarios,ifstream &archPaises,
        ofstream &archReporte);
void leeImprimeDatosUsuario(int codPais,int identificador,int cantLikes_comentario,
        int &cantSeguidores_publicos,int &cantSeguidores_No_publicos,
        ifstream &archUsuarios,ifstream &archPaises,ofstream &archReporte);
void analizaMayorComentario(int &paisMax,int &identifMax,
        int &cantLikes_Max,int codPais,int identificador,
        int cantLikes_comentario);
void buscaImprimePais(int codPais,ifstream &archPaises,ofstream &archReporte);
void imprimePais(ifstream &archPaises,ofstream &archReporte);
void imprimeUsuario(ifstream &archUsuarios,ofstream &archReporte);

void imprimeComentario(ifstream &archComentarios,ofstream &archReporte);
void imprimeEncabezadoComentarios(ofstream &archReporte);
void leeImprimeTikToks(int &fechaTiktok,int &cantTiktok,
        int &cantLikes_tiktok,int &cantReprod_tiktok,ifstream &archTikTok,
        ofstream &archReporte);
void imprimeTikToks(int ddTiktok,int mmTiktok,int aaTiktok,int cantTiktok,
        int cantLikes_tiktok,int cantReprod_tiktok,ofstream &archReporte);
void imprimeEncabezado(int diaIni,int mesIni,int anioIni,int diaFin,int mesFin,
        int anioFin,ofstream &archReporte);
int juntarFecha(int dia,int mes, int anio);
void imprimeLinea(char caracter, int cantidad, ofstream &archReporte);

#endif /* FUNCIONES_H */

