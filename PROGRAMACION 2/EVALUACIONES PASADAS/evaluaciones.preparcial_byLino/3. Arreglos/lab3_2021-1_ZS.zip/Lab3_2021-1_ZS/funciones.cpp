

/* 
 * 
 * Chupetin
 *
 * Created on 28 de abril de 2023, 01:21 AM
 */


#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#include "funciones.h"
#define NO_ENCONTRADO -1
#define MAX_LINEA 150

void leerTiendas(int *arrCodTienda,int *arrCodPostal,int &numTiendas){
   
    ifstream archTiendas("tiendas.txt",ios::in);
    if(not archTiendas.is_open()){
        cout<<"No se pudo abrir el archivo de tiendas "<<endl;
        exit(1);
    }
    
    int codTienda,codPostal;
    numTiendas=0;
    
    while(true){
        archTiendas>>codTienda;
        if(archTiendas.eof())break;
        archTiendas>>ws;
        while(archTiendas.get()!=' ');
        archTiendas>>codPostal;
        arrCodTienda[numTiendas]=codTienda;
        arrCodPostal[numTiendas]=codPostal;
        numTiendas++;
    }
}

void leerProductos(int *arrCodProd,double *arrPrecUni,int &numProd){
    
    ifstream archProductos("productos.txt",ios::in);
    if(not archProductos.is_open()){
        cout<<"No se pudo abrir el archivo de productos "<<endl;
        exit(1);
    }
    
    int codProducto;
    double precio;
    numProd=0;
    
    while(true){
        archProductos>>codProducto;
        if(archProductos.eof())break;
        archProductos>>ws;
        while(archProductos.get()!=' ');
        archProductos>>precio;
        arrCodProd[numProd]=codProducto;
        arrPrecUni[numProd]=precio;
        numProd++;
    }
}


void leerCompras(int *arrCodTienda,int *arrCodPostal,int numTiendas,
        int *arrCodProd,double *arrPrecUni,double *arrMontoTienda,
        int *arrCantTotalProd,int numProd,int *arrCantProdTienda){
    
    ifstream archCompras("compras.txt",ios::in);
    if(not archCompras.is_open()){
        cout<<"ERROR al abrir el archivo de compras"<<endl;
        exit(1);
    }
    
    int serie_doc,num_doc,dni,codTienda_evaluar,posTienda;
    char c,tipo_tienda;
    while(true){
        archCompras>>serie_doc;
        if(archCompras.eof())break;
        archCompras>>c>>num_doc>>dni;
        archCompras>>tipo_tienda;
        if(tipo_tienda=='T'){
            archCompras>>c>>codTienda_evaluar;
            posTienda=buscarIntEnArr(arrCodTienda,codTienda_evaluar,numTiendas);
            if(posTienda!=NO_ENCONTRADO){
                leerComprasTienda(posTienda,arrCantProdTienda,arrCodProd,
                        arrPrecUni,arrMontoTienda,arrCantTotalProd,
                        numProd,archCompras);
            }
        }else while(archCompras.get()!='\n');
    }
}

void leerComprasTienda(int posTienda,int *arrCantProdTienda,int *arrCodProd,
        double *arrPrecUni,double *arrMontoTienda,int *arrCantTotalProd,
        int numProd,ifstream &archCompras){
    
    int dd,mm,aa,prod_evaluar,cantidad,posProd;
    char c;
    archCompras>>dd>>c>>mm>>c>>aa;
    while(true){
        archCompras>>prod_evaluar>>c>>cantidad;
        posProd=buscarIntEnArr(arrCodProd,prod_evaluar,numProd);
        if(posProd!=NO_ENCONTRADO){
            arrMontoTienda[posTienda]+=arrPrecUni[posProd]*cantidad;
            arrCantProdTienda[posTienda]+=cantidad;
            arrCantTotalProd[posProd]+=cantidad;
        }
        if(archCompras.get()=='\n')break;
    }
}

void emiteReporte(int *arrCodTienda,int *arrCodPostal,int numTiendas,
        int *arrCodProd,double *arrPrecUni,double *arrMontoTienda,
        int *arrCantTotalProd,int numProd,int *arrCantProdTienda){
    
    ofstream archReporte("reporte.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR al abrir el archivo reporte"<<endl;
        exit(1);
    }
    archReporte<<setprecision(2);
    archReporte<<fixed;
    archReporte<<setw(50)<<' '<<"ENTREGA DE PRODUCTOS"<<endl;
    double montoAbsoluto=0;
    for(int i=0;i<numTiendas;i++){
        if(arrCantProdTienda[i]>0){
            imprimeTiendas(arrCodTienda[i],arrCodPostal[i],archReporte);
            imprimeDetallesProductos(arrCodTienda[i],arrCodProd,arrPrecUni,
                    numProd,archReporte);
            imprimeLinea('-',MAX_LINEA,archReporte);
            imprimeResumen(arrCantProdTienda[i],arrMontoTienda[i],archReporte);
            montoAbsoluto+=arrMontoTienda[i];
        }
    }
    imprimeResumenTotal(arrCodProd,arrPrecUni,arrCantTotalProd,numProd,
            montoAbsoluto,archReporte);
}

void imprimeResumenTotal(int *arrCodProd,double *arrPrecUni,int *arrCantTotalProd,
        int numProd,double montoAbsoluto,ofstream &archReporte){
    imprimeLinea('=',MAX_LINEA,archReporte);
    archReporte<<"RESUMEN TOTAL"<<endl;
    int prodMax,cantMax=0;
    int prodMin, cantMin=100000;
    double montoMax,montoMin;
    for(int i=0;i<numProd;i++){
        if(arrCantTotalProd[i]>cantMax){
            prodMax=arrCodProd[i];
            cantMax=arrCantTotalProd[i];
            montoMax=arrPrecUni[i]*arrCantTotalProd[i];
        }
    }
    
    for(int i=0;i<numProd;i++){
        if(arrCantTotalProd[i]<cantMin){
            prodMin=arrCodProd[i];
            cantMin=arrCantTotalProd[i];
            montoMin=arrPrecUni[i]*arrCantTotalProd[i];
        }
    }
    
    archReporte<<"Producto con mas entregas: "<<prodMax<<setw(10)<<' '
            <<"Cantidad: "<<cantMax<<setw(10)<<' '<<"Total Venta: S/."
            <<setw(10)<<montoMax<<endl;
    archReporte<<"Producto con mas entregas: "<<prodMin<<setw(12)<<' '
            <<"Cantidad: "<<cantMin<<setw(11)<<' '<<"Total Venta: S/."
            <<setw(10)<<montoMin<<endl;
    archReporte<<"Total ventas entregadas en tiendas: S/. "
            <<montoAbsoluto<<endl;
    imprimeLinea('=',MAX_LINEA,archReporte);
}

void imprimeResumen(int cantProdTienda,double montoTienda,
        ofstream &archReporte){
    
    archReporte<<"RESUMEN POR TIENDA"<<endl;
    archReporte<<"CANTIDAD DE PRODUCTOS A ENTREGAR: "<<cantProdTienda<<endl;
    archReporte<<"MONTO DE PRODUCTOS A ENTREGAR: S/."<<montoTienda<<endl;
    
}

void imprimeDetallesProductos(int tienda,int *arrCodProd,double *arrPrecUni,
        int numProd,ofstream &archReporte){
    
    ifstream archCompras("compras.txt",ios::in);
    if(not archCompras.is_open()){
        cout<<"ERROR al abrir el archivo de compras"<<endl;
        exit(1);
    }
    
    int serie_doc,num_doc,dni,cod_tienda;;
    char c,tipoTienda;
    
    while(true){
        archCompras>>serie_doc;
        if(archCompras.eof())break;
        archCompras>>c>>num_doc>>dni;
        archCompras>>tipoTienda;
        if(tipoTienda=='T'){
            archCompras>>c>>cod_tienda;
            if(cod_tienda==tienda){
                imprimeComprasTienda(dni,arrCodProd,
                    arrPrecUni,numProd,archCompras,
                    archReporte);
            }else while(archCompras.get()!='\n');
        }else while(archCompras.get()!='\n');
    }
}

void imprimeComprasTienda(int dni,int *arrCodProd,double *arrPrecUni,int numProd,
        ifstream &archCompras, ofstream &archReporte){
    
    int dd,mm,aa,codigo_producto,cantidad,posProd;
    char c;
    archCompras>>dd>>c>>mm>>c>>aa;
    while(true){
        archCompras>>codigo_producto>>c>>cantidad;
        posProd=buscarIntEnArr(arrCodProd,codigo_producto,numProd);
        if(posProd!=NO_ENCONTRADO){
            archReporte<<setw(4)<<' '<<setfill('0')<<setw(2)<<dd<<'/'<<setw(2)
                    <<mm<<'/'<<aa<<setfill(' ');
            archReporte<<setw(10)<<' '<<setw(6)<<arrCodProd[posProd]
                    <<setw(10)<<' '<<setw(3)<<cantidad<<setw(10)<<' '
                    <<setw(6)<<arrPrecUni[posProd]<<setw(10)<<' '
                    <<setw(8)<<arrPrecUni[posProd]*cantidad<<setw(10)<<' '
                    <<setfill('0')<<setw(8)<<dni<<setfill(' ')<<endl;
        }
        if(archCompras.get()=='\n')break;
    }
}

void imprimeTiendas(int codigoTienda,int codigoPostal,ofstream &archReporte){
    imprimeLinea('=',MAX_LINEA,archReporte);
    archReporte<<setw(5)<<' '<<"Destino: Tienda "<<setfill('0')<<setw(2)
            <<codigoTienda<<setfill(' ')<<setw(10)<<' '<<"Codigo Postal: "
            <<setfill('0')<<setw(5)<<codigoPostal<<setfill(' ')<<endl;
    imprimeLinea('-',MAX_LINEA,archReporte);
    archReporte<<setw(6)<<' '<<"FECHA"<<setw(10)<<' '<<"PRODUCTO"<<setw(10)
            <<' '<<"CANTIDAD"<<setw(10)<<' '<<"PRECIO UNITARIO"<<setw(10)
            <<' '<<"SUBTOTAL"<<setw(10)<<' '<<"CLIENTE"<<endl;
    imprimeLinea('-',MAX_LINEA,archReporte);
}

int buscarIntEnArr(int *arregelo, int elemento, int cantDatos){
    
    for(int i=0;i<cantDatos;i++){
        if(arregelo[i]==elemento)
            return i;
    }
    return NO_ENCONTRADO;
}

void imprimeLinea(char caracter, int cantidad, ofstream &archRep){
    for(int i=0;i<cantidad;i++)archRep.put(caracter);
    archRep.put('\n');
}