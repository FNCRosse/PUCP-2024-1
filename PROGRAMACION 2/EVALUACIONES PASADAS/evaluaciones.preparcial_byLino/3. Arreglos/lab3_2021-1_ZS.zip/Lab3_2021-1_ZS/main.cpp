

/* 
 * Chupetin
 *
 * Created on 28 de abril de 2023, 01:21 AM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#include "funciones.h"
#define MAX_PRODUC 50
#define MAX_TIENDA 20

/*
 * 
 */
int main(int argc, char** argv) {
    
    int arrCodTienda[MAX_TIENDA], arrCodPostal[MAX_TIENDA], numTiendas;
    
    int arrCodProd[MAX_PRODUC],arrCantProdTienda[MAX_TIENDA] {},
            arrCantTotalProd[MAX_PRODUC] {},numProd;
    double arrPrecUni[MAX_PRODUC],arrMontoTienda[MAX_TIENDA] {};
    
    leerTiendas(arrCodTienda,arrCodPostal,numTiendas);
    leerProductos(arrCodProd,arrPrecUni,numProd);
    
    leerCompras(arrCodTienda,arrCodPostal,numTiendas,arrCodProd,arrPrecUni,
            arrMontoTienda,arrCantTotalProd,numProd,arrCantProdTienda);
    emiteReporte(arrCodTienda,arrCodPostal,numTiendas,arrCodProd,arrPrecUni,
            arrMontoTienda,arrCantTotalProd,numProd,arrCantProdTienda);
    
    return 0;
}

