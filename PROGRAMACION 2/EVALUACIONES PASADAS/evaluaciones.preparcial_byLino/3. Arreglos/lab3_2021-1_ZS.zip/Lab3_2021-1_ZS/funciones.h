

/* 
 * Chupetin
 *
 * Created on 28 de abril de 2023, 01:21 AM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void leerTiendas(int *arrCodTienda,int *arrCodPostal,int &numTiendas);
void leerProductos(int *arrCodProd,double *arrPrecUni,int &numProd);
void leerCompras(int *arrCodTienda,int *arrCodPostal,int numTiendas,
        int *arrCodProd,double *arrPrecUni,double *arrMontoTienda,
        int *arrCantTotalProd,int numProd,int *arrCantProdTienda);
void leerComprasTienda(int posTienda,int *arrCantProdTienda,int *arrCodProd,
        double *arrPrecUni,double *arrMontoTienda,int *arrCantTotalProd,
        int numProd,ifstream &archCompras);
void emiteReporte(int *arrCodTienda,int *arrCodPostal,int numTiendas,
        int *arrCodProd,double *arrPrecUni,double *arrMontoTienda,
        int *arrCantTotalProd,int numProd,int *arrCantProdTienda);
void imprimeResumenTotal(int *arrCodProd,double *arrPrecUni,int *arrCantTotalProd,
        int numProd,double montoAbsoluto,ofstream &archReporte);
void imprimeResumen(int cantProdTienda,double montoTienda,
        ofstream &archReporte);
void imprimeDetallesProductos(int tienda,int *arrCodProd,double *arrPrecUni,
        int numProd,ofstream &archReporte);
void imprimeComprasTienda(int dni,int *arrCodProd,double *arrPrecUni,int numProd,
        ifstream &archCompras, ofstream &archReporte);
void imprimeTiendas(int codigoTienda,int codigoPostal,ofstream &archReporte);
int buscarIntEnArr(int *arregelo, int elemento, int cantDatos);
void imprimeLinea(char caracter, int cantidad, ofstream &archRep);

#endif /* FUNCIONES_H */

