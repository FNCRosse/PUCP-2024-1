

/* 
 * Chupetin
 *
 * Created on 1 de mayo de 2023, 07:26 AM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void leerMedicos(int *arrCodMed,double *arrTarifaMed,int &numMedicos);
void leerPacientes(int* arrDniPaci, int* arrDistritoPaci, int& numPacientes);
void leerDistritos(int *arrDistritos,int &numDistritos);
void leeProcesaImprimeAtencionesMedicas(int *arrCodMed,double *arrTarifaMed,
        int numMedicos,int *arrDniPaci,int *arrDistritoPaci,int *arrPrimeraFecha,
        int *arrUltimaFecha,int *arrCantCitasPaciente,double *arrMontoTotalPaciente,
        int *arrDuracionPacientes,int numPacientes,int *arrDistritos,
        int *arrCantCitasDistrito,double *arrMontoTotalDistrito,int numDistritos);
void ordenarArreglos(int *arrDistritos,int *arrCantCitasDistrito,double *arrMontoTotalDistrito,
        int numDistritos);
void intercambiarElementoInt(int *arreglo, int i,int j);
void intercambiarElementoDouble(double* arreglo, int i, int j);
void imprimeReporte(int *arrCodMed,double *arrTarifaMed,
        int numMedicos,int *arrDniPaci,int *arrDistritoPaci,int *arrPrimeraFecha,
        int *arrUltimaFecha,int *arrCantCitasPaciente,double *arrMontoTotalPaciente,
        int *arrDuracionPacientes,int numPacientes,int *arrDistritos,
        int *arrCantCitasDistrito,double *arrMontoTotalDistrito,int numDistritos);
void imprimeMayoresYmenores(int *arrDistritos,int *arrCantCitasDistrito,
        double *arrMontoTotalDistrito,int numDistritos,ofstream &archReporte);
void separarDuracion(int duracion,int &hora,int &minuto,int &segundo);
void separarFecha(int fecha, int &dia, int &mes, int &anio);
void imprimeEncabezado(ofstream &archReporte);
void buscaImprimeDistrito(int distrito, ofstream &archReporte);
void imprimeTitulos(ofstream &archReporte);
double calculaMonto(int duracion,double tarifa);
void ordenarFechas(int *arrPrimeraFecha,int *arrUltimaFecha,int fecha,
        int posPaciente);
int calculaDuracion(int horaIni,int minIni,int segIni,int horaFin,int minFin,
        int segFin);
void leerHora(int &hora,int &minuto,int &segundo,ifstream &arch);
int buscarPosicion(int *arreglo,int elemento, int numDatos);
void inicializarFechas(int *arrPrimeraFecha,int *arrUltimaFecha,int numPacientes);
void imprimeDistrito(ifstream& archDistrito, ofstream& archRep);
void imprimeLinea(char caracter, int cantidad, ofstream& archRep);
#endif /* FUNCIONES_H */

