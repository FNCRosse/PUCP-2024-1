

/* 
 *Chupetin
 *
 * Created on 1 de mayo de 2023, 07:21 AM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#define MAX_DISTRITOS 50
#define MAX_MEDICOS 20
#define MAX_PACIENTES 50
#define MAX_CITAS 1000
#include "funciones.h"
/*
 * 
 */
int main(int argc, char** argv) {
    
    int arrCodMed[MAX_MEDICOS],numMedicos;
    double arrTarifaMed[MAX_MEDICOS];
    
    int arrDniPaci[MAX_PACIENTES],arrDistritoPaci[MAX_PACIENTES],
            arrPrimeraFecha[MAX_PACIENTES],arrUltimaFecha[MAX_PACIENTES],
            arrCantCitasPaciente[MAX_PACIENTES]{},
            arrDuracionPacientes[MAX_PACIENTES]{},numPacientes;
    double arrMontoTotalPaciente[MAX_PACIENTES]{};
    
    int arrDistritos[MAX_DISTRITOS],arrCantCitasDistrito[MAX_DISTRITOS]{},
            numDistritos;
    double arrMontoTotalDistrito[MAX_DISTRITOS]{};
    
    /*llenar arreglos explicitos*/
    leerMedicos(arrCodMed,arrTarifaMed,numMedicos);
    leerPacientes(arrDniPaci,arrDistritoPaci,numPacientes);
    inicializarFechas(arrPrimeraFecha,arrUltimaFecha,numPacientes);
    leerDistritos(arrDistritos,numDistritos);
    //llenar arreglos implicitos
    leeProcesaImprimeAtencionesMedicas(arrCodMed,arrTarifaMed,numMedicos,
            arrDniPaci,arrDistritoPaci,arrPrimeraFecha,arrUltimaFecha,
            arrCantCitasPaciente,arrMontoTotalPaciente,arrDuracionPacientes,
            numPacientes,arrDistritos,arrCantCitasDistrito,arrMontoTotalDistrito,
            numDistritos);
    ordenarArreglos(arrDistritos,arrCantCitasDistrito,arrMontoTotalDistrito,numDistritos);
    imprimeReporte(arrCodMed,arrTarifaMed,numMedicos,
            arrDniPaci,arrDistritoPaci,arrPrimeraFecha,arrUltimaFecha,
            arrCantCitasPaciente,arrMontoTotalPaciente,arrDuracionPacientes,
            numPacientes,arrDistritos,arrCantCitasDistrito,
            arrMontoTotalDistrito,numDistritos);
    return 0;
}

