

/* 
 *Chupetin
 *
 * Created on 1 de mayo de 2023, 07:26 AM
 */


#include <iostream>
#include <fstream>
#include <iomanip>
#include <ios>
using namespace std;

#define NO_ENCONTRADO -1
#define MAX_LINEA 150
#include "funciones.h"

void leerMedicos(int *arrCodMed,double *arrTarifaMed,int &numMedicos){
    
    ifstream archMedicos("Medicos.txt",ios::in);
    if(not archMedicos.is_open()){
        cout<<"ERROR al abrir el archivo de medicos"<<endl;
        exit(1);
    }
    
    int cod_medico;
    double tarifa;
    numMedicos=0;
    while(true){
        archMedicos>>cod_medico;
        if(archMedicos.eof())break;
        archMedicos>>ws;
        while(archMedicos.get()!=' ');
        archMedicos>>tarifa;
        while(archMedicos.get()!='\n');
        
        arrCodMed[numMedicos]=cod_medico;
        arrTarifaMed[numMedicos]=tarifa;
        numMedicos++;
    }
}

void leerPacientes(int *arrDniPaci,int *arrDistritoPaci,int &numPacientes){
    
    ifstream archPacientes("Pacientes.txt",ios::in);
    if(not archPacientes.is_open()){
        cout<<"ERROR al abrir el archivo de pacientes"<<endl;
        exit(1);
    }
    
    int cod_paciente,cod_postal;
    numPacientes=0;
    while(true){
        archPacientes>>cod_paciente;
        if(archPacientes.eof())break;
        archPacientes>>ws;
        while(archPacientes.get()!=']');
        archPacientes>>ws;
        archPacientes>>cod_postal;
        
        arrDniPaci[numPacientes]=cod_paciente;
        arrDistritoPaci[numPacientes]=cod_postal;
        numPacientes++;
    }
}

void leerDistritos(int *arrDistritos,int &numDistritos){
    
    ifstream archDistritos("distritos.txt",ios::in);
    if(not archDistritos.is_open()){
        cout<<"ERROR al abrir el archivo de distritos"<<endl;
        exit(1);
    }
    
    int cod_distrito;
    numDistritos=0;
    while(true){
        archDistritos>>cod_distrito;
        if(archDistritos.eof())break;
        while(archDistritos.get()!='\n');
        arrDistritos[numDistritos]=cod_distrito;
        numDistritos++;
    }
}

void leeProcesaImprimeAtencionesMedicas(int *arrCodMed,double *arrTarifaMed,
        int numMedicos,int *arrDniPaci,int *arrDistritoPaci,int *arrPrimeraFecha,
        int *arrUltimaFecha,int *arrCantCitasPaciente,double *arrMontoTotalPaciente,
        int *arrDuracionPacientes,int numPacientes,int *arrDistritos,
        int *arrCantCitasDistrito,double *arrMontoTotalDistrito,int numDistritos){
    
    ifstream archAteciones("AtencionesMedicas.txt",ios::in);
    if(not archAteciones.is_open()){
        cout<<"ERROR al abrir el archivo de atenciones"<<endl;
        exit(1);
    }
    
    int cod_medico,dd,mm,aa,fecha,cod_paciente,horaIni,minIni,segIni,
            horaFin,minFin,segFin,duracion,posPaciente,posMedico,posDistrito;
    double monto;
    char c;
    
    
    while(true){
        archAteciones>>cod_medico;
        if(archAteciones.eof())break;
        archAteciones>>dd>>c>>mm>>c>>aa;
        fecha=aa*10000+mm*100+dd;
        while(true){
            archAteciones>>cod_paciente;
            leerHora(horaIni,minIni,segIni,archAteciones);
            leerHora(horaFin,minFin,segFin,archAteciones);
            duracion=calculaDuracion(horaIni,minIni,segIni,horaFin,minFin,segFin);
            posPaciente=buscarPosicion(arrDniPaci,cod_paciente,numPacientes);
            if(posPaciente!=NO_ENCONTRADO){
                arrDuracionPacientes[posPaciente]+=duracion;
                ordenarFechas(arrPrimeraFecha,arrUltimaFecha,fecha,
                        posPaciente);
                arrCantCitasPaciente[posPaciente]++;
                posMedico=buscarPosicion(arrCodMed,cod_medico,numMedicos);
                if(posMedico!=NO_ENCONTRADO){
                    monto=calculaMonto(duracion,arrTarifaMed[posMedico]);
                    arrMontoTotalPaciente[posPaciente]+=monto;
                    posDistrito=buscarPosicion(arrDistritos,
                            arrDistritoPaci[posPaciente],numDistritos);
                    if(posDistrito!=NO_ENCONTRADO){
                        arrCantCitasDistrito[posDistrito]++;
                        arrMontoTotalDistrito[posDistrito]+=monto;
                    }
                }
            }
            if(archAteciones.get()=='\n')break;
        }
    }
}

void ordenarArreglos(int *arrDistritos,int *arrCantCitasDistrito,double *arrMontoTotalDistrito,
        int numDistritos){
    for (int i = 0; i < numDistritos - 1; i++)
    for (int j = i + 1; j < numDistritos; j++)
        if (arrCantCitasDistrito[j] < arrCantCitasDistrito[i] ||
            (arrCantCitasDistrito[i] == arrCantCitasDistrito[j]) &&
            arrMontoTotalDistrito[j] > arrMontoTotalDistrito[i]){
            intercambiarElementoInt(arrDistritos, i, j);
            intercambiarElementoInt(arrCantCitasDistrito, i, j);
            intercambiarElementoDouble(arrMontoTotalDistrito, i, j);
        }
}

void intercambiarElementoInt(int *arreglo, int i,int j){
    int aux;
    aux = arreglo[i];
    arreglo[i] = arreglo[j];
    arreglo[j] = aux;
}

void intercambiarElementoDouble(double *arreglo, int i,int j){
    double aux;
    aux = arreglo[i];
    arreglo[i] = arreglo[j];
    arreglo[j] = aux;
}

void imprimeReporte(int *arrCodMed,double *arrTarifaMed,
        int numMedicos,int *arrDniPaci,int *arrDistritoPaci,int *arrPrimeraFecha,
        int *arrUltimaFecha,int *arrCantCitasPaciente,double *arrMontoTotalPaciente,
        int *arrDuracionPacientes,int numPacientes,int *arrDistritos,
        int *arrCantCitasDistrito,double *arrMontoTotalDistrito,int numDistritos){
    
    ofstream archReporte("ReporteDeAtencionesPorDistrito.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR al abrir el archivo de reporte"<<endl;
        exit(1);
    }
    
    int diaIni,mesIni,anioIni,diaFin,mesFin,anioFin,hora,minuto,segundo;
    imprimeTitulos(archReporte);
    archReporte<<setprecision(2);
    archReporte<<fixed;
    for(int i=0;i<numDistritos;i++){
        if(arrCantCitasDistrito[i]>0){
            buscaImprimeDistrito(arrDistritos[i],archReporte);
            imprimeEncabezado(archReporte);
            for(int k=0;k<numPacientes;k++){
                if(arrDistritos[i]==arrDistritoPaci[k]){
                    archReporte<<setw(2)<<' '<<arrDniPaci[k];
                    separarFecha(arrPrimeraFecha[k],diaIni,mesIni,anioIni);
                    separarFecha(arrUltimaFecha[k],diaFin,mesFin,anioFin);
                    archReporte<<setw(10)<<' '<<setfill('0')<<setw(2)
                            <<diaIni<<'/'<<setw(2)<<mesIni<<'/'<<anioIni
                            <<setfill(' ')<<setw(10)<<' '<<setfill('0')<<setw(2)
                            <<diaFin<<'/'<<setw(2)<<mesFin<<'/'<<anioFin
                            <<setfill(' ');
                    separarDuracion(arrDuracionPacientes[k],hora,minuto,segundo);
                    archReporte<<setw(8)<<' '<<setfill('0')<<setw(2)<<hora
                            <<':'<<setw(2)<<minuto<<':'<<setw(2)<<segundo
                            <<setfill(' ')<<setw(20)<<' '<<setw(2)
                            <<arrCantCitasPaciente[k]<<setw(18)<<' '
                            <<setw(9)<<arrMontoTotalPaciente[k]<<endl;
                }
            }
            imprimeLinea('-',MAX_LINEA,archReporte);
            archReporte<<"CANTIDAD TOTAL DE CITAS: "<<arrCantCitasDistrito[i]<<endl;
            archReporte<<"PAGO TOTAL:    S/. "<<arrMontoTotalDistrito[i]<<endl;
        }
    }
    imprimeMayoresYmenores(arrDistritos,arrCantCitasDistrito,
            arrMontoTotalDistrito,numDistritos,archReporte);
}

void imprimeMayoresYmenores(int *arrDistritos,int *arrCantCitasDistrito,
        double *arrMontoTotalDistrito,int numDistritos,ofstream &archReporte){
    double montoMax=0,montoMin=9999;
    int distritoMax,distritoMin;
    
    imprimeLinea('=',MAX_LINEA,archReporte);
    for(int i=0;i<numDistritos;i++){
        if(arrCantCitasDistrito[i]>0){
            if(arrMontoTotalDistrito[i]>montoMax){
                montoMax=arrMontoTotalDistrito[i];
                distritoMax=arrDistritos[i];
            }
            if(arrMontoTotalDistrito[i]<montoMin){
                montoMin=arrMontoTotalDistrito[i];
                distritoMin=arrDistritos[i];
            }
        }
    }
    
    archReporte<<"DISTRITO CON MAYOR PAGO REALIZADO: "<<distritoMax<<" - S/. "
            <<setw(9)<<montoMax<<endl;
    archReporte<<"DISTRITO CON MAYOR PAGO REALIZADO: "<<distritoMin<<" - S/. "
            <<setw(9)<<montoMin<<endl;
}

void separarDuracion(int duracion,int &hora,int &minuto,int &segundo){
    
    hora=(duracion/3600);
    minuto=(duracion%3600)/60;
    segundo=(duracion%3600)%60;
}

void separarFecha(int fecha, int &dia, int &mes, int &anio){
    
    anio = fecha/10000;
    mes = (fecha%10000)/100;
    dia = (fecha%10000)%100;
}

void imprimeEncabezado(ofstream &archReporte){
    archReporte<<setw(2)<<' '<<"PACIENTE"<<setw(12)<<' '<<"INICIO"
            <<setw(15)<<' '<<"FIN"<<setw(10)<<' '<<"DURACION CITAS"
            <<setw(10)<<' '<<"CANTIDAD CITAS"<<setw(10)<<' '<<"MONTO PAGADO"
            <<endl;
    imprimeLinea('-',MAX_LINEA,archReporte);
}

void buscaImprimeDistrito(int distrito, ofstream &archReporte){
    
    ifstream archDistritos("distritos.txt",ios::in);
    if(not archDistritos.is_open()){
        cout<<"ERROR al abrir el archivo de distritos"<<endl;
        exit(1);
    }
    
    int distrito_evaluar;
    imprimeLinea('=',MAX_LINEA,archReporte);
    while(true){
        archDistritos>>distrito_evaluar;
        if(archDistritos.eof())break;
        if(distrito_evaluar==distrito){
            archReporte<<setw(10)<<' '<<"Distrito: "<<distrito<<" - ";
            imprimeDistrito(archDistritos,archReporte);
        }else while(archDistritos.get()!='\n');
    }
    imprimeLinea('-',MAX_LINEA,archReporte);
    
}

void imprimeTitulos(ofstream &archReporte){
    archReporte<<setw(50)<<' '<<"EMPRESA PRESTADORA DE SALUD"<<endl;
    archReporte<<setw(46)<<' '<<"ATENCION DE PACIENTES POR DISTRITO"<<endl;
}

double calculaMonto(int duracion,double tarifa){
    int minutos=(duracion/60);
    int segundos=(duracion%60)%60;
    double monto_A_calcular;
    
    if(segundos==0) monto_A_calcular=tarifa*minutos;
    else if(segundos>0)monto_A_calcular=tarifa*(minutos+1);
    
    return monto_A_calcular;
}

void ordenarFechas(int *arrPrimeraFecha,int *arrUltimaFecha,int fecha,
        int posPaciente){
    
    if(fecha < arrPrimeraFecha[posPaciente])arrPrimeraFecha[posPaciente]=fecha;
    else if(fecha > arrUltimaFecha[posPaciente])arrUltimaFecha[posPaciente]=fecha;
}

int calculaDuracion(int horaIni,int minIni,int segIni,int horaFin,int minFin,
        int segFin){
    int duracion = (horaFin*3600+minFin*60+segFin)-
    (horaIni*3600+minIni*60+segIni);
    
    return duracion;
}

void leerHora(int &hora,int &minuto,int &segundo,ifstream &arch){
    
    char c;
    while(true){
        arch>>hora;
        c=arch.get();
        if(c==':'){
            arch>>minuto;
            c=arch.get();
            if(c==':'){
                arch>>segundo;
                break;
            }else{
                segundo=0;
                if(c=='\n'){
                    arch.unget();
                    break;
                }else break;
            }
        }else{
            minuto=0;
            segundo=0;
            if(c=='\n'){
                arch.unget();
                break;
            }else break;
        }
    }
}

int buscarPosicion(int *arreglo,int elemento, int numDatos){
    for(int i=0;i<numDatos;i++){
        if(arreglo[i]==elemento)
            return i;
    }
    
    return NO_ENCONTRADO;
}

void inicializarFechas(int *arrPrimeraFecha,int *arrUltimaFecha,int numPacientes){
    
    for(int i=0;i<numPacientes;i++){
        arrPrimeraFecha[i]=999999999;
        arrUltimaFecha[i]=-1;
    }
}

void imprimeDistrito(ifstream &archDistrito,ofstream &archRep){
    char distrito;
    
    archDistrito>>ws;
    while(true){
        distrito=archDistrito.get();
        if(distrito=='\n')break;
        distrito-=(distrito>='a' and distrito<='z')?('a'-'A'):0;
        archRep.put(distrito);
    }
    archRep.put('\n');
}

void imprimeLinea(char caracter, int cantidad, ofstream &archRep){
    
    for(int i=0;i<cantidad;i++)archRep.put(caracter);
    archRep.put('\n');
}