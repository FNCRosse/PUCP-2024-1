

/* 
 * chupetin
 *
 * Created on 1 de mayo de 2023, 08:49 PM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#define MAX_VERTICES 100
#include "funciones.h"

/*
 * 
 */
int main(int argc, char** argv) {
    
    double arrCord_X[MAX_VERTICES],arrCord_Y[MAX_VERTICES];
    int numVertices;
    
    double arrCord_X_medio[MAX_VERTICES],arrCord_Y_medio[MAX_VERTICES]{};
    int numPuntos;
    
    leerCordenadas(arrCord_X,arrCord_Y,numVertices);
    leerCordenadasInternas(arrCord_X_medio,numPuntos);
    emiteReporte(arrCord_X,arrCord_Y,numVertices,arrCord_X_medio,arrCord_Y_medio,
            numPuntos);
    
    return 0;
}

