

/* 
 * chupetin
 *
 * Created on 1 de mayo de 2023, 08:49 PM
 */


#include <iostream>
#include <fstream>
#include <iomanip>
#include <math.h>
#include <complex>
#include <ios>
using namespace std;


#include "funciones.h"

void leerCordenadas(double *arrCord_X,double *arrCord_Y,int &numVertices){
    
    ifstream archPoligonal("Poligonal.txt",ios::in);
    if(not archPoligonal.is_open()){
        cout<<"ERROR al abrir el archivo poligonal"<<endl;
        exit(1);
    }
    
    double cordX,cordY;
    numVertices=0;
    
    while(true){
        archPoligonal>>cordX;
        if(archPoligonal.eof())break;
        archPoligonal>>cordY;
        arrCord_X[numVertices]=cordX;
        arrCord_Y[numVertices]=cordY;
        numVertices++;
    }
}

void leerCordenadasInternas(double *arrCord_X_medio,
        int &numPuntos){
    
    ifstream archPuntosIncompletos("A_Completar.txt",ios::in);
    if(not archPuntosIncompletos.is_open()){
        cout<<"ERROR al abrir el archivo A_Completar"<<endl;
        exit(1);
    }
    
    double puntoMedio;
    numPuntos=0;
    
    while(true){
        archPuntosIncompletos>>puntoMedio;
        if(archPuntosIncompletos.eof())break;
        arrCord_X_medio[numPuntos]=puntoMedio;
        numPuntos++;
    }
}

void emiteReporte(double *arrCord_X,double *arrCord_Y,int numVertices,
        double *arrCord_X_medio,double *arrCord_Y_medio,int numPuntos){
    
    ofstream archReporte("reporte.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR al abrir el archivo de reporte"<<endl;
        exit(1);
    }
    
    double longitud=0,area=0;
    archReporte<<setprecision(2);
    archReporte<<fixed;
    determinaLongitud(longitud,arrCord_X,arrCord_Y,numVertices);
    determinaArea(area,arrCord_X,arrCord_Y,numVertices);
    archReporte<<"a) "<<longitud<<endl;
    archReporte<<"b) "<<area<<endl;
    archReporte<<"c) "<<setw(5)<<' '<<"Picos"<<endl;
    imprimePicos(arrCord_X,arrCord_Y,numVertices,archReporte);
    archReporte<<setw(8)<<' '<<"Valles"<<endl;
    imprimeValles(arrCord_X,arrCord_Y,numVertices,archReporte);
    archReporte<<"d) "<<"pico más bajo"<<endl;
    imprimePicoMasBajo(arrCord_X,arrCord_Y,numVertices,archReporte);
    archReporte<<setw(3)<<' '<<"valle mas alto"<<endl;
    imprimeValleMasAlto(arrCord_X,arrCord_Y,numVertices,archReporte);
    completarCoordenadas(arrCord_X,arrCord_Y,numVertices,
            arrCord_X_medio,arrCord_Y_medio,numPuntos);
    archReporte<<"f) ";
    imprimeCoordenadasIncompletas(arrCord_X,arrCord_Y,numVertices,
            arrCord_X_medio,arrCord_Y_medio,numPuntos,archReporte);
            
            
    
}

void imprimeCoordenadasIncompletas(double *arrCord_X,double *arrCord_Y,
        int numVertices,double *arrCord_X_medio,double *arrCord_Y_medio,
        int numPuntos,ofstream &archReporte){
    archReporte<<endl;
    archReporte<<setw(10)<<' '<<"COORDENADAS COMPLETAS"<<endl;
    archReporte<<setw(10)<<' '<<'X'<<setw(18)<<' '<<'Y'<<endl;
    
    for(int i=0;i<numPuntos;i++){
        archReporte<<setw(5)<<' '<<setw(8)<<arrCord_X_medio[i]<<setw(10)<<' '
                <<setw(8)<<arrCord_Y_medio[i]<<endl;
    }
}

void completarCoordenadas(double *arrCord_X,double *arrCord_Y,int numVertices,
        double *arrCord_X_medio,double *arrCord_Y_medio,int numPuntos){

    
    double pendiente;
    
    for(int i=0;i<numPuntos;i++){
        for(int j=0;j<numVertices-1;j++){
            if(arrCord_X_medio[i]>arrCord_X[j] and 
                    arrCord_X_medio[i]<arrCord_X[j+1]){
                pendiente = (arrCord_Y[j]-arrCord_Y[j+1])/
                        (arrCord_X[j]-arrCord_X[j+1]);
                arrCord_Y_medio[i] = 
                        (pendiente*(arrCord_X_medio[i]-arrCord_X[j])) + arrCord_Y[j];
            }
        }
    }
    
}

void imprimeValleMasAlto(double *arrCord_X,double *arrCord_Y,int numVertices,
        ofstream &archReporte){
    
    double valleMinY=999999,valleMinX;
    for(int i=0;i<numVertices-1;i++){
        if(arrCord_Y[i+1]<arrCord_Y[i] and arrCord_Y[i+1]<arrCord_Y[i+2]){
            if(arrCord_Y[i+1]<valleMinY){
                valleMinY=arrCord_Y[i+1];
                valleMinX=arrCord_X[i+1];
            }
        }
    }
    archReporte<<setw(3)<<' '<<'('<<valleMinX<<','<<valleMinY<<')'<<endl;
}

void imprimePicoMasBajo(double *arrCord_X,double *arrCord_Y,int numVertices,
        ofstream &archReporte){
    
    double picoMinY=999999,picoMinX;
    for(int i=0;i<numVertices-1;i++){
        if(arrCord_Y[i+1]>arrCord_Y[i] and arrCord_Y[i+1]>arrCord_Y[i+2]){
            if(arrCord_Y[i+1]<picoMinY){
                picoMinY=arrCord_Y[i+1];
                picoMinX=arrCord_X[i+1];
            }
        }
    }
    archReporte<<setw(3)<<' '<<'('<<picoMinX<<','<<picoMinY<<')'<<endl;
}

void imprimeValles(double *arrCord_X,double *arrCord_Y,
        int numVertices,ofstream &archReporte){
    for(int i=0;i<numVertices-1;i++){
        if(arrCord_Y[i+1] < arrCord_Y[i] and arrCord_Y[i+1] < arrCord_Y[i+2]){
            archReporte<<" "<<'('<<setw(6)<<arrCord_Y[i+1]<<','
                    <<setw(8)<<arrCord_X[i+1]<<')'<<endl;
        }
    }
}

void imprimePicos(double *arrCord_X,double *arrCord_Y,
        int numVertices,ofstream &archReporte){
    
    
    for(int i=0;i<numVertices-1;i++){
        
        if(arrCord_Y[i+1]>arrCord_Y[i] and arrCord_Y[i+1]>arrCord_Y[i+2]){
            archReporte<<" "<<'('<<setw(6)<<arrCord_Y[i+1]<<','
                    <<setw(8)<<arrCord_X[i+1]<<')'<<endl;
        }
    }
    
}

void determinaArea(double &area,double *arrCord_X,double *arrCord_Y,
        int numVertices){
    
    double bases,altura;
    for(int i=0;i<numVertices-1;i++){
        bases = arrCord_Y[i+1]+arrCord_Y[i];
        altura = arrCord_X[i+1]-arrCord_X[i];
        
        area += (bases/2)*altura;
    }
}

void determinaLongitud(double &longitud,double *arrCord_X,double *arrCord_Y,
        int numVertices){
    double primerTermino,segundoTermino,suma;
    for(int i=0;i<numVertices-1;i++){
        
        primerTermino=(arrCord_X[i+1]-arrCord_X[i])*(arrCord_X[i+1]-arrCord_X[i]);
        segundoTermino=(arrCord_Y[i+1]-arrCord_Y[i])*(arrCord_Y[i+1]-arrCord_Y[i]);
        suma =primerTermino+segundoTermino;
        longitud+=sqrt(suma);
    }
    
}
