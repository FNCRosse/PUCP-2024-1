

/* 
 * chupetin
 *
 * Created on 1 de mayo de 2023, 08:49 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void leerCordenadas(double *arrCord_X,double *arrCord_Y,int &numVertices);
void leerCordenadasInternas(double* arrCord_X_medio, int& numPuntos);
void emiteReporte(double *arrCord_X,double *arrCord_Y,int numVertices,
        double *arrCord_X_medio,double *arrCord_Y_medio,int numPuntos);
void imprimeCoordenadasIncompletas(double *arrCord_X,double *arrCord_Y,
        int numVertices,double *arrCord_X_medio,double *arrCord_Y_medio,
        int numPuntos,ofstream &archReporte);
void completarCoordenadas(double *arrCord_X,double *arrCord_Y,int numVertices,
        double *arrCord_X_medio,double *arrCord_Y_medio,int numPuntos);
void imprimeValleMasAlto(double *arrCord_X,double *arrCord_Y,int numVertices,
        ofstream &archReporte);
void imprimePicoMasBajo(double *arrCord_X,double *arrCord_Y,int numVertices,
        ofstream &archReporte);
void imprimePicosValles(double *arrCord_X,double *arrCord_Y,
        int numVertices,ofstream &archReporte);
void imprimeValles(double *arrCord_X,double *arrCord_Y,
        int numVertices,ofstream &archReporte);
void imprimePicos(double *arrCord_X,double *arrCord_Y,
        int numVertices,ofstream &archReporte);

void determinaArea(double &area,double *arrCord_X,double *arrCord_Y,
        int numVertices);
void determinaLongitud(double &longitud,double *arrCord_X,double *arrCord_Y,
        int numVertices);

#endif /* FUNCIONES_H */

