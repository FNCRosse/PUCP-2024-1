

/* 
 * File:   funciones.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 3 de mayo de 2023, 11:24 AM
 */


#include <iostream>
#include <fstream>
#include <iomanip>
#include <ios>
using namespace std;

#define NO_ENCONTRADO -1
#define MAX_LINE 120
#include "funciones.h"


void llenarMedicos(int *arrCodMedi,char *arrCategDesc,double *arrTarifa,
        int &numMedicos){
    
    ifstream archMedicos("medicos.txt",ios::in);
    if(not archMedicos.is_open()){
        cout<<"ERROR al abrir el archivo de medicos"<<endl;
        exit(1);
    }
    
    int cod_medico;
    char categoria;
    double tarifa;
    numMedicos=0;
    
    while(true){
        archMedicos>>cod_medico;
        if(archMedicos.eof())break;
        archMedicos>>categoria>>tarifa;
        
        arrCodMedi[numMedicos]=cod_medico;
        arrCategDesc[numMedicos]=categoria;
        arrTarifa[numMedicos]=tarifa;
        
        numMedicos++;
    }
}

void llenarPacientes(int *arrDni,int *arrTelef,char *arrSeguro,
        int &numPacientes){
    
    ifstream archPacientes("pacientes.txt",ios::in);
    if(not archPacientes.is_open()){
        cout<<"ERROR al abrir el archivo de pacientes"<<endl;
        exit(1);
    }
    
    int dni,telefono;
    char seguro;
    numPacientes=0;
    
    while(true){
        archPacientes>>dni;
        if(archPacientes.eof())break;
        archPacientes>>telefono;
        archPacientes>>seguro;
        
        arrDni[numPacientes]=dni;
        arrTelef[numPacientes]=telefono;
        arrSeguro[numPacientes]=seguro;
        
        numPacientes++;
    }
}

void procesarOtrosArreglos(int *arrPacienteCita,int *arrMedicoCita,
        int *arrFechaCita,int *arrLlegada,int *arrSalida,double *arrTiempo,
        double *arrPago,double *arrDescuento,int &numCitas,int *arrDni,
        int *arrTelef,char *arrSeguro,int numPacientes,int *arrCodMedi,
        char *arrCategDesc,double *arrTarifa,int numMedicos){
    
    ifstream archCitas("citas.txt",ios::in);
    if(not archCitas.is_open()){
        cout<<"ERROR al abrir el archivo de citas"<<endl;
        exit(1);
    }
    
    int dni_paciente,cod_medico,dia,mes,anio,horaIng,minIng,segIng,
            horaSal,minSal,segSal,fecha,horaLlegada,horaSalida,posMedico,
            posPaciente;
    double tiempoEnHoras,total,descuento;
    char c;
    numCitas=0;
    while(true){
        archCitas>>dni_paciente;
        if(archCitas.eof())break;
        archCitas>>cod_medico>>dia>>c>>mes>>c>>anio;
        archCitas>>horaIng>>c>>minIng>>c>>segIng;
        archCitas>>horaSal>>c>>minSal>>c>>segSal;
        fecha=juntarDatos(dia,mes,anio);
        horaLlegada=juntarDatos(horaIng,minIng,segIng);
        horaSalida=juntarDatos(horaSal,minSal,segSal);
        arrFechaCita[numCitas]=fecha;
        arrPacienteCita[numCitas]=dni_paciente;
        arrMedicoCita[numCitas]=cod_medico;
        arrLlegada[numCitas]=horaLlegada;
        arrSalida[numCitas]=horaSalida;
        tiempoEnHoras=calculaHoras(horaSal,minSal,segSal,horaIng,minIng,segIng);
        arrTiempo[numCitas] = tiempoEnHoras;
        numCitas++;
        
    }
    
}

int buscarPosicion(int *arreglo,int elemento, int numDat){
    for(int i=0;i<numDat;i++){
        if(arreglo[i]==elemento)return i;
    }
    return NO_ENCONTRADO;
}

double calculaHoras(int horaSal,int minSal,int segSal,int horaIng,int minIng,
        int segIng){
    
    int duracionSeg = (horaSal*3600+minSal*60+segSal) - 
    (horaIng*3600+minIng*60+segIng);
    
    double tiempoHora = (double) (duracionSeg)/3600;
    return tiempoHora;
}

int juntarDatos(int primero_numero,int segundo_numero,int tercer_numero){
    
    int numeroJuntado=primero_numero*10000 + segundo_numero*100+tercer_numero;
    
    return numeroJuntado;
    
}

void emiteReporte(int *arrPacienteCita,int *arrMedicoCita,
        int *arrFechaCita,int *arrLlegada,int *arrSalida,double *arrTiempo,
        double *arrPago,double *arrDescuento,int numCitas,int *arrDni,
        int *arrTelef,char *arrSeguro,int numPacientes,int *arrCodMedi,
        char *arrCategDesc,double *arrTarifa,int numMedicos){
    
    ofstream archReporte("reporte.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR al abrir el archivo de reporte"<<endl;
        exit(1);
    }
    archReporte<<setprecision(2);
    archReporte<<fixed;
    int cantPacientesA=0,cantPacientesB=0,cantPacientesC=0;
    double gastoTotalCita,desTotalCita,recaudadoTotal=0;
    imprimeTitulo(archReporte);
    for(int i=0;i<numPacientes;i++){
        imprimeLinea('=',MAX_LINE,archReporte);
        archReporte<<setw(5)<<' '<<"DNI:"<<setw(7)<<' '<<arrDni[i]
                <<setw(30)<<' '<<"Seguro: ";
        if(arrSeguro[i]=='V')archReporte<<"EL PACIENTE ESTA ASEGURADO"<<endl;
        else if(arrSeguro[i]=='F')archReporte<<"EL PACIENTE NO ESTA ASEGURADO"<<endl;
        archReporte<<setw(5)<<' '<<"Telefono: "<<arrTelef[i]<<endl;
        archReporte<<endl<<setw(5)<<' '<<"CITAS REALIZADAS:"<<endl;
        imprimeLinea('-',MAX_LINE,archReporte);
        archReporte<<setw(5)<<' '<<"FECHA"<<setw(6)<<' '<<"ID MEDICO"
                <<setw(5)<<' '<<"DESCUENTO"<<setw(8)<<' '<<"TARIFA"
                <<setw(6)<<' '<<"LLEGADA"<<setw(7)<<' '<<"SALIDA"
                <<setw(8)<<' '<<"TIEMPO(hrs.)"<<setw(5)<<' '<<"PAGO"
                <<setw(3)<<' '<<"  DESCUENTO APLICADO"<<endl;
        imprimeLinea('-',MAX_LINE,archReporte);
        imprimeCitas(arrPacienteCita,arrMedicoCita,arrFechaCita,arrLlegada,
            arrSalida,arrTiempo,arrPago,arrDescuento,numCitas,arrDni[i],arrTelef,
            arrSeguro[i],numPacientes,arrCodMedi,arrCategDesc,arrTarifa,numMedicos,
                gastoTotalCita,desTotalCita,cantPacientesA,cantPacientesB,
                cantPacientesC,archReporte);
        imprimeLinea('-',MAX_LINE,archReporte); 
        archReporte<<setw(5)<<' '<<"Total de gastos por cita:"<<setw(11)
                <<gastoTotalCita<<endl;
        archReporte<<setw(5)<<' '<<"Total de descuento por cita:"<<setw(8)
                <<desTotalCita<<endl;
        recaudadoTotal+=gastoTotalCita;
    }
    imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<"TOTAL RECAUDADO POR LA CLINICA:"<<setw(12)<<recaudadoTotal
            <<endl;
    archReporte<<"Cantidad de Pacientes que recibieron descuentos de tipo A: "
            <<setw(4)<<cantPacientesA<<endl;
    archReporte<<"Cantidad de Pacientes que recibieron descuentos de tipo B: "
            <<setw(4)<<cantPacientesB<<endl;;
    archReporte<<"Cantidad de Pacientes que recibieron descuentos de tipo C: "
            <<setw(4)<<cantPacientesC<<endl;
    imprimeLinea('=',MAX_LINE,archReporte);
}
       


void imprimeCitas(int *arrPacienteCita,int *arrMedicoCita,
        int *arrFechaCita,int *arrLlegada,int *arrSalida,double *arrTiempo,
        double *arrPago,double *arrDescuento,int numCitas,int dni,
        int *arrTelef,char seguro,int numPacientes,int *arrCodMedi,
        char *arrCategDesc,double *arrTarifa,int numMedicos,
        double &gastoTotalCita,double &desTotalCita,int &cantPacientesA,
        int &cantPacientesB,int &cantPacientesC,ofstream &archReporte){
    
    gastoTotalCita=desTotalCita=0;
    int dia,mes,anio,horaIng,minIng,segIng,horaSal,minSal,segSal,posMedico;
    double descuento,total;
    for(int j=0;j<numCitas;j++){
        if(dni==arrPacienteCita[j]){
            posMedico=buscarPosicion(arrCodMedi,arrMedicoCita[j],numMedicos);   
            if(posMedico!=NO_ENCONTRADO ){
                separarDatos(arrFechaCita[j],dia,mes,anio);
                separarDatos(arrLlegada[j],horaIng,minIng,segIng);
                separarDatos(arrSalida[j],horaSal,minSal,segSal);
                archReporte<<setw(5)<<' '<<setfill('0')<<setw(2)<<dia<<'/'
                        <<setw(2)<<mes<<'/'<<anio<<setfill(' ')
                        <<setw(6)<<' '<<arrMedicoCita[j]<<setw(7)<<' ';
                if(arrCategDesc[posMedico]=='A'){
                    archReporte<<"10%";
                    descuento=0.1;
                    if(seguro=='V')cantPacientesA++;
                }else if(arrCategDesc[posMedico]=='B'){
                    archReporte<<" 5%";
                    descuento=0.05;
                    if(seguro=='V')cantPacientesB++;
                }
                else if(arrCategDesc[posMedico]=='C'){
                    archReporte<<" 2%";
                    descuento=0.02;
                    if(seguro=='V')cantPacientesC++;
                }
                else {
                    archReporte<<" 0%";
                    descuento=0;
                }
                total=arrTarifa[posMedico]*arrTiempo[j];
                arrPago[j]=total-(total*descuento);
                arrDescuento[j]=(total*descuento);
                archReporte<<setw(10)<<' '<<setw(8)<<arrTarifa[posMedico]
                        <<setw(5)<<' '<<setfill('0')<<setw(2)<<horaIng
                        <<':'<<setw(2)<<minIng<<':'<<setw(2)<<segIng<<setfill(' ');
                archReporte<<setw(5)<<' '<<setfill('0')<<setw(2)<<horaSal
                        <<':'<<setw(2)<<minSal<<':'<<setw(2)<<segSal<<setfill(' ');
                archReporte<<setw(6)<<' '<<setw(8)<<arrTiempo[j]<<setw(7)
                        <<' '<<setw(8)<<arrPago[j]<<setw(6)<<' '
                        <<setw(8);
                if(seguro=='V')archReporte<<arrDescuento[j]<<endl;
                else {
                    arrDescuento[j]=0;
                    archReporte<<arrDescuento[j]<<endl;
                }
                gastoTotalCita+=arrPago[j];
                desTotalCita+=arrDescuento[j];
            }
        }
    }            
}

void separarDatos(int numero, int &primer_dato, int &segundo_dato,
        int &tercer_dato){
    
    primer_dato=numero/10000;
    segundo_dato=(numero%10000)/100;
    tercer_dato=(numero%10000)%100;
}

void imprimeTitulo(ofstream &archRep){
    archRep<<setw(50)<<' '<<"CLINICA PSICOLOGICA TP."<<endl;
    archRep<<setw(46)<<' '<<"RELACION DE CITAS POR PACIENTE"<<endl;
    
}

void imprimeLinea(char caracter, int cantidad, ofstream &arcRep){
    for(int i=0;i<cantidad;i++)arcRep.put(caracter);
    arcRep.put('\n');
}
