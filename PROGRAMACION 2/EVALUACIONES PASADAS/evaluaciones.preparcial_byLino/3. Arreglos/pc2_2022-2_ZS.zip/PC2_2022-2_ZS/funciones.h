

/* 
 * File:   funciones.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 3 de mayo de 2023, 11:24 AM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void llenarMedicos(int *arrCodMedi,char *arrCategDesc,double *arrTarifa,
        int &numMedicos);
void llenarPacientes(int* arrDni, int* arrTelef, char* arrSeguro, int& numPacientes);
void procesarOtrosArreglos(int *arrPacienteCita,int *arrMedicoCita,
        int *arrFechaCita,int *arrLlegada,int *arrSalida,double *arrTiempo,
        double *arrPago,double *arrDescuento,int &numCitas,int *arrDni,
        int *arrTelef,char *arrSeguro,int numPacientes,int *arrCodMedi,
        char *arrCategDesc,double *arrTarifa,int numMedicos);
int buscarPosicion(int *arreglo,int elemento, int numDat);
double calculaHoras(int horaSal,int minSal,int segSal,int horaIng,int minIng,
        int segIng);
int juntarDatos(int primero_numero,int segundo_numero,int tercer_numero);
void emiteReporte(int *arrPacienteCita,int *arrMedicoCita,
        int *arrFechaCita,int *arrLlegada,int *arrSalida,double *arrTiempo,
        double *arrPago,double *arrDescuento,int numCitas,int *arrDni,
        int *arrTelef,char *arrSeguro,int numPacientes,int *arrCodMedi,
        char *arrCategDesc,double *arrTarifa,int numMedicos);
void imprimeCitas(int *arrPacienteCita,int *arrMedicoCita,
        int *arrFechaCita,int *arrLlegada,int *arrSalida,double *arrTiempo,
        double *arrPago,double *arrDescuento,int numCitas,int dni,
        int *arrTelef,char seguro,int numPacientes,int *arrCodMedi,
        char *arrCategDesc,double *arrTarifa,int numMedicos,
        double &gastoTotalCita,double &desTotalCita,int &cantPacientesA,
        int &cantPacientesB,int &cantPacientesC,ofstream &archReporte);
void separarDatos(int numero, int &primer_dato, int &segundo_dato,
        int &tercer_dato);
void imprimeTitulo(ofstream &archRep);
void imprimeLinea(char caracter, int cantidad, ofstream &arcRep);

#endif /* FUNCIONES_H */

