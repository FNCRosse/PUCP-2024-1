

/* 
 * File:   main.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 3 de mayo de 2023, 10:31 AM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#define MAX_CITAS 500
#define MAX_PACI 200 
#define MAX_MED 50
#include "funciones.h"

/*
 * 
 */
int main(int argc, char** argv) {
    
    
    int arrCodMedi[MAX_MED],numMedicos;
    double arrTarifa[MAX_MED];
    char arrCategDesc[MAX_MED];
    
    int arrDni[MAX_PACI],arrTelef[MAX_PACI],numPacientes;
    char arrSeguro[MAX_PACI];
    double arrGastosPaci[MAX_PACI]{};
    
    int arrMedicoCita[MAX_CITAS],arrPacienteCita[MAX_CITAS],
            arrFechaCita[MAX_CITAS],arrLlegada[MAX_CITAS],arrSalida[MAX_CITAS],
            numCitas;
    double  arrTiempo[MAX_CITAS],arrPago[MAX_CITAS],
            arrDescuento[MAX_CITAS];
    
    llenarMedicos(arrCodMedi,arrCategDesc,arrTarifa,numMedicos);
    
    llenarPacientes(arrDni,arrTelef,arrSeguro,numPacientes);
    
    procesarOtrosArreglos(arrPacienteCita,arrMedicoCita,arrFechaCita,arrLlegada,
            arrSalida,arrTiempo,arrPago,arrDescuento,numCitas,arrDni,arrTelef,
            arrSeguro,numPacientes,arrCodMedi,arrCategDesc,arrTarifa,numMedicos);
    
    emiteReporte(arrPacienteCita,arrMedicoCita,arrFechaCita,arrLlegada,
            arrSalida,arrTiempo,arrPago,arrDescuento,numCitas,arrDni,arrTelef,
            arrSeguro,numPacientes,arrCodMedi,arrCategDesc,arrTarifa,numMedicos);
    
    return 0;
}

