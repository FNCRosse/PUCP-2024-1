

/* 
 * Chupetin
 *
 * Created on 29 de abril de 2023, 12:15 PM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;


#define MAX_PROD 50
#include "funciones.h"
/*
 * 
 */
int main(int argc, char** argv) {
    
    
    int arrCodProd[MAX_PROD],arrCantProd[MAX_PROD] {},numProd;
    double arrPrecUni[MAX_PROD];
    
    leerProductos(arrCodProd,arrPrecUni,numProd);
    
    emiteReporteYpocesaArreglos(arrCodProd,arrPrecUni,arrCantProd,numProd);
    
    return 0;
}

