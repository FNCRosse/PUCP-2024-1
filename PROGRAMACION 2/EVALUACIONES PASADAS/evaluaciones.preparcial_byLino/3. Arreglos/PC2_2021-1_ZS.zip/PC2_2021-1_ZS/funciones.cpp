

/* 
 *Chupetin
 *
 * Created on 29 de abril de 2023, 12:23 PM
 */



#include <iostream>
#include <fstream>
#include <iomanip>
#include <ios>
using namespace std;

#define MAX_LINEA 120
#define NO_ENCONTRADO -1
#include "funciones.h"



void leerProductos(int *arrCodProd,double *arrPrecUni,int &numProd){
    
    ifstream archProd("productos.txt",ios::in);
    if(not archProd.is_open()){
        cout<<"ERROR al abrir el archivo de productos"<<endl;
        exit(1);
    }
    
    int cod_producto;
    double precio;
    numProd=0;
    
    while(true){
        archProd>>cod_producto;
        if(archProd.eof())break;
        archProd>>ws;
        while(archProd.get()!=' ');
        archProd>>precio;
        
        arrCodProd[numProd]=cod_producto;
        arrPrecUni[numProd]=precio;
        numProd++;
    }
}

void emiteReporteYpocesaArreglos(int *arrCodProd,double *arrPrecUni,
        int *arrCantProd,int numProd){
    
    ifstream archTiendas("tiendas.txt",ios::in);
    if(not archTiendas.is_open()){
        cout<<"ERROR al abrir el archivo de tiendas"<<endl;
        exit(1);
    }
    ofstream archReporte("reporte.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR al abrir el archivo reporte"<<endl;
        exit(1);
    }
    int cod_tienda,cod_postal;
    double totalVenta=0;
    archReporte<<setw(50)<<' '<<"ENTREGA DE PRODUCTOS"<<endl;
    archReporte<<setprecision(2);
    archReporte<<fixed;
    while(true){
        archTiendas>>cod_tienda;
        if(archTiendas.eof())break;
        imprimeLinea('=',MAX_LINEA,archReporte);
        archReporte<<setw(5)<<' '<<"Destino: Tienda "<<setfill('0')<<setw(2)
                <<cod_tienda<<" - "<<setfill(' ');
        imprimeNombreTienda(archTiendas,archReporte);
        archTiendas>>cod_postal;
        archReporte<<"- Codigo Postal: "<<setfill('0')<<setw(5)<<cod_postal
                <<setfill(' ')<<endl;
        imprimeEncabezado(archReporte);
        leeProcesaProductosPorTienda(cod_tienda,arrCodProd,arrPrecUni,numProd,
                totalVenta,arrCantProd,archReporte);
    }
    resumenTotal(arrCodProd,arrPrecUni,arrCantProd,numProd,totalVenta,archReporte);
}

void leeProcesaProductosPorTienda(int cod_tienda,int *arrCodProd,double *arrPrecUni,
        int numProd,double &totalVenta,int *arrCantProd,ofstream &archReporte){
    
    ifstream archCompras("compras.txt",ios::in);
    if(not archCompras.is_open()){
        cout<<"ERROR al abrir el archivo de compras"<<endl;
        exit(1);
    }
    
    int serie_doc,num_doc,dni,cantidadPorTienda=0;
    double montoPorTienda=0;
    while(true){
        archCompras>>serie_doc;
        if(archCompras.eof())break;
        archCompras>>num_doc>>dni;
        leeTipoTiendas(cod_tienda,dni,arrCodProd,arrPrecUni,arrCantProd,numProd,
                cantidadPorTienda,montoPorTienda,totalVenta,archCompras,archReporte);
    }
    imprimeLinea('-',MAX_LINEA,archReporte);
    archReporte<<"RESUMEN POR TIENDA"<<endl;
    archReporte<<"CANTIDAD DE PRODUCTOS A ENTREGAR: "
            <<setw(8)<<cantidadPorTienda<<endl;
    archReporte<<"MONTO DE PRODUCTOS A ENTREGAR: S/. "
            <<setw(10)<<montoPorTienda<<endl;
}

void leeTipoTiendas(int cod_tienda,int dni,int *arrCodProd,double *arrPrecUni,
        int *arrCantProd,int numProd,int &cantidadPorTienda,double &montoPorTienda,
        double &totalVenta,ifstream &archCompras,ofstream &archReporte){
    char tipo_tienda,c;
    int num_tienda;
    while(true){
        archCompras>>tipo_tienda;
        if(tipo_tienda=='T'){
            archCompras>>c>>num_tienda;
            if(num_tienda==cod_tienda){
                leeProductos(dni,arrCodProd,arrPrecUni,arrCantProd,numProd,
                        cantidadPorTienda,montoPorTienda,totalVenta,
                        archCompras,archReporte);
                archCompras.unget();
            }else{
                while(true){
                    tipo_tienda=archCompras.get();
                    if(tipo_tienda=='\n'){
                        break;
                    }else if(tipo_tienda=='T'){
                        archCompras.unget();
                        break;
                    }
                }
            }
        }else if(tipo_tienda=='D'){
            while(true){
                tipo_tienda=archCompras.get();
                if(tipo_tienda=='\n'){
                    break;
                }else if(tipo_tienda=='T'){
                    archCompras.unget();
                    break;
                }
            } 
        }
        if(tipo_tienda=='\n')break;
    }
}

void leeProductos(int dni,int *arrCodProd,double *arrPrecUni,int *arrCantProd,
        int numProd,int &cantidadPorTienda,double &montoPorTienda,
        double &totalVenta,ifstream &archCompras,ofstream &archReporte){
    int dd,mm,aa,cod_producto,cantidad,posProd;
    char c;
    archCompras>>dd>>c>>mm>>c>>aa;
    while(true){
        archCompras>>c;
        if(c=='T' or c=='D' or c=='\n')break;
        else archCompras.unget();
        archCompras>>cod_producto>>c>>cantidad;
        posProd=buscarPosicion(arrCodProd,cod_producto,numProd);
        if(posProd!=NO_ENCONTRADO){
            imprimeDetallesProductos(dd,mm,aa,dni,cantidad,
                    arrCodProd[posProd],arrPrecUni[posProd],numProd,archReporte);
            cantidadPorTienda+=cantidad;
            montoPorTienda+=cantidad*arrPrecUni[posProd];
            arrCantProd[posProd]+=cantidad;
            totalVenta+=montoPorTienda;
        }
        if(archCompras.get()=='\n')break;
        else archCompras.unget();
    }
}

void imprimeDetallesProductos(int dd,int mm,int aa,int dni,int cantidad,
        int cod_producto,double precio_unitario,int numProd,ofstream &archReporte){
    
    archReporte<<setw(4)<<' '<<setfill('0')<<setw(2)<<dd<<'/'<<setw(2)
            <<mm<<'/'<<setw(4)<<aa<<setfill(' ');
    archReporte<<setw(9)<<' '<<setfill('0')<<setw(5)<<cod_producto<<setfill(' ')
            <<setw(14)<<' '<<setw(2)<<cantidad<<setw(15)<<' '<<setw(8)
            <<precio_unitario<<setw(14)<<' '<<setw(8)<<precio_unitario*cantidad
            <<setw(10)<<' '<<setfill('0')<<setw(8)<<dni<<setfill(' ')<<endl;
}

void resumenTotal(int *arrCodProd,double *arrPrecUni,int *arrCantProd,
        int numProd,double totalVenta,ofstream &archReporte){
    imprimeLinea('=',MAX_LINEA,archReporte);
    int prodMax,prodMin,cantMax=0,cantMin=arrCantProd[0];
    double ventaMax,ventaMin;
    archReporte<<"RESUMEN TOTAL"<<endl;
    analizarProductos(arrCodProd,arrPrecUni,arrCantProd,numProd,prodMax,prodMin,
            cantMax,cantMin,ventaMax,ventaMin);
    archReporte<<"Producto con más entregas:"<<setw(10)<<prodMax
            <<setw(10)<<' '<<"Cantidad: "<<setw(2)<<cantMax<<setw(10)<<' '
            <<"Total Venta: S/. "<<setw(8)<<ventaMax<<endl;
    archReporte<<"Producto con más entregas:"<<setw(10)<<prodMin
            <<setw(10)<<' '<<"Cantidad: "<<setw(2)<<cantMin<<setw(10)<<' '
            <<"Total Venta: S/. "<<setw(8)<<ventaMin<<endl;
    archReporte<<"Total Ventas entregadas en tiendas: S/. "<<totalVenta<<endl;
    imprimeLinea('=',MAX_LINEA,archReporte);
}

void analizarProductos(int *arrCodProd,double *arrPrecUni,int *arrCantProd,int numProd,
        int &prodMax,int &prodMin,int &cantMax,int &cantMin,
        double &ventaMax,double &ventaMin){
    
    for(int i=0;i<numProd;i++){
        if(arrCantProd[i]>cantMax){
            cantMax=arrCantProd[i];
            prodMax=arrCodProd[i];
            ventaMax=arrCantProd[i]*arrPrecUni[i];
        }else if(arrCantProd[i]<cantMin){
            cantMin=arrCantProd[i];
            prodMin=arrCodProd[i];
            ventaMin=arrCantProd[i]*arrPrecUni[i];
        }
    }
}

int buscarPosicion(int *arrCodProd,int cod_producto,int numProd){
    
    for(int i=0;i<numProd;i++){
        if(cod_producto==arrCodProd[i])
            return i;
    }
    return NO_ENCONTRADO;
}

void imprimeEncabezado(ofstream &archReporte){
    imprimeLinea('-',MAX_LINEA,archReporte);
    archReporte<<setw(6)<<' '<<"FECHA"<<setw(10)<<' '<<"PRODUCTO"
            <<setw(10)<<' '<<"CANTIDAD"<<setw(10)<<' '<<"PRECIO UNITARIO"
            <<setw(10)<<' '<<"SUBTOTAL"<<setw(10)<<' '<<"CLIENTE"<<endl;
    imprimeLinea('-',MAX_LINEA,archReporte);
}

void imprimeNombreTienda(ifstream &archTiendas,ofstream &archReporte){
    char tienda;
    archTiendas>>ws;
    while(true){
        tienda = archTiendas.get();
        if(tienda==' ')break;
        if(tienda=='_')tienda=' ';
        archReporte.put(tienda);
    }
}

void imprimeLinea(char caracter, int cantidad, ofstream &archRep){
    for(int i=0;i<cantidad;i++)archRep.put(caracter);
    archRep.put('\n');
}

