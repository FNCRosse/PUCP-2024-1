

/* 
 Chupetin
 *
 * Created on 29 de abril de 2023, 12:23 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H


void leerProductos(int *arrCodProd,double *arrPrecUni,int &numProd);
void emiteReporteYpocesaArreglos(int *arrCodProd,double *arrPrecUni,
        int *arrCantProd,int numProd);
void leeProcesaProductosPorTienda(int cod_tienda,int *arrCodProd,
        double *arrPrecUni,int numProd,double &totalVenta,int *arrCantProd,
        ofstream &archReporte);
void leeTipoTiendas(int cod_tienda,int dni,int *arrCodProd,double *arrPrecUni,
        int *arrCantProd,int numProd,int &cantidadPorTienda,double &montoPorTienda,
        double &totalVenta,ifstream &archCompras,ofstream &archReporte);
void leeProductos(int dni,int *arrCodProd,double *arrPrecUni,int *arrCantProd,
        int numProd,int &cantidadPorTienda,double &montoPorTienda,
        double &totalVenta,ifstream &archCompras,ofstream &archReporte);
void imprimeDetallesProductos(int dd,int mm,int aa,int dni,
        int cantidad,int cod_producto,double precio_unitario,int numProd,
        ofstream &archReporte);
void resumenTotal(int *arrCodProd,double *arrPrecUni,int *arrCantProd,
        int numProd,double totalVenta,ofstream &archReporte);
void analizarProductos(int *arrCodProd,double *arrPrecUni,int *arrCantProd,
        int numProd,int &prodMax,int &prodMin,int &cantMax,int &cantMin,
        double &ventaMax,double &ventaMin);
int buscarPosicion(int* arrCodProd, int cod_producto, int numProd);
void imprimeEncabezado(ofstream &archReporte);
void imprimeNombreTienda(ifstream &archTiendas,ofstream &archReporte);
void imprimeLinea(char caracter, int cantidad, ofstream &archRep);


#endif /* FUNCIONES_H */

