

/* 
 * File:   funciones.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 4 de mayo de 2023, 01:42 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void leerMedicos(int *arrCodigo,double *arrTarifa,int &numMed);
void leeProcesaCitas(int *arrCodMed,double *arrTarifa,int numMed,
        double *arrFactorRes,int *arrPacRes,double *arrMontoPaciRes,
        double *arrMontoSeguroRes,double *arrFactorAten,int *arrPacAten,
        double *arrMontoPaciAten,double *arrMontoSeguroAten);
void llenaPaciReservados(int *arrCodMed,double *arrTarifa,int numMed,
        double *arrFactorRes,int *arrPacRes,double *arrMontoPaciRes,
        double *arrMontoSeguroRes,ifstream &archCitas);
void llenaPaciAtendidos(int *arrCodMed,double *arrTarifa,int numMed,
        double *arrFactorAten,int *arrPacAten,double *arrMontoPaciAten,
        double *arrMontoSeguroAten,ifstream &archCitas);
void emiteReporte(int *arrCodMed,double *arrTarifa,int numMed,
        double *arrFactorRes,int *arrPacRes,double *arrMontoPaciRes,
        double *arrMontoSeguroRes,double *arrFactorAten,int *arrPacAten,
        double *arrMontoPaciAten,double *arrMontoSeguroAten);
void leeImprimeNombre(int codigoMed,ifstream &archMed,ofstream &archReporte);
void imprimeNombre(ifstream &archMed,ofstream &archReporte);
void leeImprimeEspecialidad(int codigoMed,ifstream &archMed,ofstream &archReporte);
void imprimeEspecialidad(ifstream &archMed,ofstream &archReporte);
void imprimeLinea(char caracter, int cantidad, ofstream& archRep);
int buscarPosicion(int *arreglo,int elemento, int numDatos);

#endif /* FUNCIONES_H */

