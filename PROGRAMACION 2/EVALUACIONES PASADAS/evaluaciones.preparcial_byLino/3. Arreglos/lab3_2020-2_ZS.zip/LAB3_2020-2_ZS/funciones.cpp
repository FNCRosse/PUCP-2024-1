

/* 
 * File:   funciones.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 4 de mayo de 2023, 01:41 PM
 */


#include <iostream>
#include <fstream>
#include <iomanip>
#include <ios>
using namespace std;

#define MAX_LINE 120
#define NO_ENCONTRADO -1
#include "funciones.h"

void leerMedicos(int *arrCodigo,double *arrTarifa,int &numMed){
    
    
    ifstream archMed("Medicos.txt",ios::in);
    if(not archMed.is_open()){
        cout<<"ERROR al abrir el archivo de medicos"<<endl;
        exit(1);
    }
    
    int codigo_med;
    double tarifa;
    numMed=0;
    while(true){
        archMed>>codigo_med;
        if(archMed.eof())break;
        archMed>>ws;
        while(archMed.get()!=' ');
        archMed>>ws;
        while(archMed.get()!=' ');
        archMed>>tarifa;
        
        arrCodigo[numMed]=codigo_med;
        arrTarifa[numMed]=tarifa;
        
        numMed++;
    }
    /*Verifica si tu arreglo esta lleno*/
//    for(int i=0;i<numMed;i++)
//        cout<<arrCodigo[i]<<' '<<arrTarifa[i]<<endl;
}

void leeProcesaCitas(int *arrCodMed,double *arrTarifa,int numMed,
        double *arrFactorRes,int *arrPacRes,double *arrMontoPaciRes,
        double *arrMontoSeguroRes,double *arrFactorAten,int *arrPacAten,
        double *arrMontoPaciAten,double *arrMontoSeguroAten){
    
    ifstream archCitas("AtencionDePacientes.txt",ios::in);
    if(not archCitas.is_open()){
        cout<<"ERROR al abrir el archivo de AtencionDePacientes"<<endl;
        exit(1);
    }
    
    int dia,mes,anio;
    char c,estado;
    
    while(true){
        archCitas>>dia;
        if(archCitas.eof())break;
        archCitas>>c>>mes>>c>>anio;
        
        while(true){
            archCitas>>estado;
            if(estado=='R'){/*paciente reservado / por atender*/
                archCitas>>ws;
                while(archCitas.get()!=' ');
                llenaPaciReservados(arrCodMed,arrTarifa,numMed,arrFactorRes,
                        arrPacRes,arrMontoPaciRes,arrMontoSeguroRes,archCitas);
            }else if(estado=='A'){/*paciente atndido*/
                archCitas>>ws;
                while(archCitas.get()!=' ');
                
                llenaPaciAtendidos(arrCodMed,arrTarifa,numMed,arrFactorAten,
                        arrPacAten,arrMontoPaciAten,arrMontoSeguroAten,archCitas);
            }
            if(archCitas.get()=='\n')break;
        }
        
    }
}

void llenaPaciReservados(int *arrCodMed,double *arrTarifa,int numMed,
        double *arrFactorRes,int *arrPacRes,double *arrMontoPaciRes,
        double *arrMontoSeguroRes,ifstream &archCitas){
    
    double factor;
    int codMed_evaluar,posMedico;
    
    archCitas>>factor;
    archCitas>>codMed_evaluar;
    posMedico=buscarPosicion(arrCodMed,codMed_evaluar,numMed);
    if(posMedico!=NO_ENCONTRADO){
        arrFactorRes[posMedico]+=factor;
        arrPacRes[posMedico]++;
        if(factor<1){/*Tiene seguro*/
            arrMontoPaciRes[posMedico]+=arrTarifa[posMedico]*factor;
            arrMontoSeguroRes[posMedico]+=arrTarifa[posMedico]*(1-factor);
        }else if(factor==1){/*No tiene seguro*/
            arrMontoPaciRes[posMedico]+=arrTarifa[posMedico]*factor;
        }
        
    }
    
}

void llenaPaciAtendidos(int *arrCodMed,double *arrTarifa,int numMed,
        double *arrFactorAten,int *arrPacAten,double *arrMontoPaciAten,
        double *arrMontoSeguroAten,ifstream &archCitas){
    double factor;
    int codMed_evaluar,posMedico;
    
    archCitas>>factor;
    archCitas>>codMed_evaluar;
    posMedico=buscarPosicion(arrCodMed,codMed_evaluar,numMed);
    if(posMedico!=NO_ENCONTRADO){
        arrFactorAten[posMedico]+=factor;
        arrPacAten[posMedico]++;
        if(factor<1){/*Tiene seguro*/
            arrMontoPaciAten[posMedico]+=arrTarifa[posMedico]*factor;
            arrMontoSeguroAten[posMedico]+=arrTarifa[posMedico]*(1-factor);
        }else if(factor==1){/*No tiene seguro*/
            arrMontoPaciAten[posMedico]+=arrTarifa[posMedico]*factor;
        }
    }
}

void emiteReporte(int *arrCodMed,double *arrTarifa,int numMed,
        double *arrFactorRes,int *arrPacRes,double *arrMontoPaciRes,
        double *arrMontoSeguroRes,double *arrFactorAten,int *arrPacAten,
        double *arrMontoPaciAten,double *arrMontoSeguroAten){
    
    ofstream archReporte("reporte.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR al abrir el archivo de reporte"<<endl;
        exit(1);
    }
    
    ifstream archMed("Medicos.txt",ios::in);
    if(not archMed.is_open()){
        cout<<"ERROR al abrir el archivo de medicos"<<endl;
        exit(1);
    }
    archReporte.precision(2);
    archReporte<<fixed;
    for(int i=0;i<numMed;i++){
        archReporte<<"Medico: ";
        leeImprimeNombre(arrCodMed[i],archMed,archReporte);
        archReporte<<endl<<"Codigo: "<<arrCodMed[i]<<endl;
        archReporte<<"Especialidad: ";
        leeImprimeEspecialidad(arrCodMed[i],archMed,archReporte);
        archReporte<<endl<<"Honorarios por cita: "<<arrTarifa[i]<<endl;
        imprimeLinea('-',MAX_LINE,archReporte);
        archReporte<<"Pacientes atendidos: "<<arrPacAten[i]<<endl;
        imprimeLinea('-',MAX_LINE,archReporte);
        archReporte<<"Monto total recibido por pacientes: "<<arrMontoPaciAten[i]<<endl;
        archReporte<<"Monto a solicitar al seguro: "<<arrMontoSeguroAten[i]<<endl;
        imprimeLinea('-',MAX_LINE,archReporte);
        archReporte<<"Pacientes por atender: "<<arrPacRes[i]<<endl;
        archReporte<<"Monto total recibido por pacientes: "<<arrMontoPaciRes[i]<<endl;
        archReporte<<"Monto a solicitar al seguro: "<<arrMontoSeguroRes[i]<<endl;
        imprimeLinea('-',MAX_LINE,archReporte);
        archReporte<<"Total ingresos: "<<setw(8)<<arrMontoPaciAten[i]+
                arrMontoPaciRes[i]<<endl;
        imprimeLinea('=',MAX_LINE,archReporte);
    }
}

void leeImprimeNombre(int codigoMed,ifstream &archMed,ofstream &archReporte){
    
    archMed.clear();
    archMed.seekg(0,ios::beg);
    
    int codigo_evaluar;
    while(true){
        archMed>>codigo_evaluar;
        if(archMed.eof())break;
        if(codigo_evaluar==codigoMed){
            imprimeNombre(archMed,archReporte);
            return;
        }else
            while(archMed.get()!='\n');
    }
}

void imprimeNombre(ifstream &archMed,ofstream &archReporte){
    char nombre;
    
    archMed>>ws;
    while(true){
        nombre=archMed.get();
        if(nombre==' ')break;
        if(nombre=='/')nombre=' ';
        if(nombre=='-')nombre=' ';
        nombre-=(nombre>='a' and nombre<='z')?('a'-'A'):0;
        archReporte.put(nombre);
    }
    
}

void leeImprimeEspecialidad(int codigoMed,ifstream &archMed,ofstream &archReporte){
    archMed.clear();
    archMed.seekg(0,ios::beg);
    
    int codigo_evaluar;
    while(true){
        archMed>>codigo_evaluar;
        if(archMed.eof())break;
        if(codigo_evaluar==codigoMed){
            archMed>>ws;
            while(archMed.get()!=' ');
            imprimeEspecialidad(archMed,archReporte);
            return;
        }else
            while(archMed.get()!='\n');
    }
}

void imprimeEspecialidad(ifstream &archMed,ofstream &archReporte){
    
    char especialidad;
    
    archMed>>ws;
    while(true){
        especialidad=archMed.get();
        if(especialidad==' ')break;
        archReporte.put(especialidad);
    }
}

void imprimeLinea(char caracter, int cantidad, ofstream &archRep){
    for(int i=0;i<cantidad;i++)archRep.put(caracter);
    archRep.put('\n');
}

int buscarPosicion(int *arreglo,int elemento, int numDatos){
    for(int i=0;i<numDatos;i++)
        if(arreglo[i]==elemento)return i;
    
    return NO_ENCONTRADO;
}

