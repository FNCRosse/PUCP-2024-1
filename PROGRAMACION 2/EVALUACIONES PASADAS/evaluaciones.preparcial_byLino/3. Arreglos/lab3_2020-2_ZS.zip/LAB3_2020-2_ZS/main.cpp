

/* 
 * File:   main.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 4 de mayo de 2023, 01:41 PM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#define MAX_CITAS 100
#define MAX_MED 40
#include "funciones.h"

/*
 * 
 */
int main(int argc, char** argv) {
    
    int arrCodMed[MAX_MED],numMed;
    double arrTarifa[MAX_MED];
    
    int arrPacRes[MAX_MED]{},arrPacAten[MAX_MED]{};
    double arrFactorRes[MAX_MED]{},arrFactorAten[MAX_MED] {},
            arrMontoPaciAten[MAX_MED] {},arrMontoPaciRes[MAX_MED]{},
            arrMontoSeguroAten[MAX_MED]{},arrMontoSeguroRes[MAX_MED]{};
    

    
    leerMedicos(arrCodMed,arrTarifa,numMed);
    
    leeProcesaCitas(arrCodMed,arrTarifa,numMed,arrFactorRes,arrPacRes,
            arrMontoPaciRes,arrMontoSeguroRes,arrFactorAten,arrPacAten,
            arrMontoPaciAten,arrMontoSeguroAten);
    
    emiteReporte(arrCodMed,arrTarifa,numMed,arrFactorRes,arrPacRes,
            arrMontoPaciRes,arrMontoSeguroRes,arrFactorAten,arrPacAten,
            arrMontoPaciAten,arrMontoSeguroAten);
    
    return 0;
}

