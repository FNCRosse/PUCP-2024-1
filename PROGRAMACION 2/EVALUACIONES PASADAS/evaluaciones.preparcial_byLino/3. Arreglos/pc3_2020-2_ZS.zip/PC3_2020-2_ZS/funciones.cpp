

/* 
 * File:   funciones.cpp
 * Author: Derik  20191163
 *
 * Created on 5 de mayo de 2023, 08:55 AM
 */


#include <iostream>
#include <fstream>
#include <iomanip>
#include <ios>
#include <algorithm>
using namespace std;

#define MAX_LINE 120
#define MAX_CARACTERES 60
#define NO_ENCONTRADO -1
#include "funciones.h"

void leerProductos(int *arrCodProd,int *arrStockProd,int &numProd){
    
    ifstream archProd("Productos.txt",ios::in);
    if(not archProd.is_open()){
        cout<<"ERROR al abrir el archivo de productos"<<endl;
        exit(1);
    }
    
    int codigo_prod,stock;
    numProd=0;
    while(true){
        archProd>>codigo_prod;
        if(archProd.eof())break;
        archProd>>stock;
        while(archProd.get()!='\n');
        
        arrCodProd[numProd]=codigo_prod;
        arrStockProd[numProd]=stock;
        
        numProd++;
    }
}

void leeProcesaMovimientos(int *arrCodProd,int *arrStockProd,int &numProd,
        int *arrCodProdDeficit,int *arrStockFaltante,int &numProdFaltantes){
    
    ifstream archMovimientos("Movimientos.txt",ios::in);
    if(not archMovimientos.is_open()){
        cout<<"ERROR al abrir el archivo de movimientos"<<endl;
        exit(1);
    }
    
    int num_operacion,cod_operacion,codProd_leido,cantidad_solicitada,posProd;
    char operacion;
    numProdFaltantes=0;
    while(true){
        archMovimientos>>num_operacion;
        if(archMovimientos.eof())break;
        archMovimientos>>cod_operacion;
        archMovimientos>>operacion;
        while(true){
            archMovimientos>>codProd_leido;
            archMovimientos>>cantidad_solicitada;
            posProd=buscarPosicion(arrCodProd,codProd_leido,numProd);
            if(posProd!=NO_ENCONTRADO){ /*Si se encuentra en el arreglo original*/
                modificarArregloOriginal(operacion,arrCodProd,arrStockProd,numProd,
                        arrCodProdDeficit,arrStockFaltante,numProdFaltantes,
                        posProd,cantidad_solicitada,codProd_leido);         
            }else if(posProd==NO_ENCONTRADO){/*Si no está en el arr original,
                                             verificamos en el arreglo de deficit*/
                modificarArregloDeficit(operacion,arrCodProd,arrStockProd,numProd,
                        arrCodProdDeficit,arrStockFaltante,numProdFaltantes,
                        posProd,cantidad_solicitada,codProd_leido);
            }
            if(archMovimientos.get()=='\n')break;
        }
    }
}

void modificarArregloDeficit(char operacion,int *arrCodProd,int *arrStockProd,
        int &numProd,int *arrCodProdDeficit,int *arrStockFaltante,
        int &numProdFaltantes,int posProd,int cantidad_solicitada,
        int codProd_leido){
    int posProdFaltante;
    posProdFaltante=buscarPosicion(arrCodProdDeficit,codProd_leido,
            numProdFaltantes);
    if(posProdFaltante!=NO_ENCONTRADO){
        if(operacion=='R'){
            if(cantidad_solicitada>arrStockFaltante[posProdFaltante]){
                eliminarElementoDeArreglo(arrCodProdDeficit,codProd_leido,
                        numProdFaltantes);
                arrCodProd[numProd]=codProd_leido;
                arrStockProd[numProd]+=cantidad_solicitada-
                        arrStockFaltante[posProdFaltante];
                eliminarElementoDeArreglo(arrStockFaltante,
                        arrStockFaltante[posProdFaltante],numProdFaltantes);
                numProd++;
            }else if(cantidad_solicitada<arrStockFaltante[posProdFaltante]){
                arrStockFaltante[posProdFaltante]-=cantidad_solicitada;
            }
        }else if(operacion=='P')arrStockFaltante[posProdFaltante]+=
                cantidad_solicitada;
    }
}

void modificarArregloOriginal(char operacion,int *arrCodProd,int *arrStockProd,
        int &numProd,int *arrCodProdDeficit,int *arrStockFaltante,
        int &numProdFaltantes,int posProd,int cantidad_solicitada,
        int codProd_leido){
    if(operacion=='R')arrStockProd[posProd]+=cantidad_solicitada;
    else if(operacion=='P'){
        if(cantidad_solicitada>arrStockProd[posProd]){
            eliminarElementoDeArreglo(arrCodProd,codProd_leido,numProd);
            arrCodProdDeficit[numProdFaltantes]=codProd_leido;
            arrStockFaltante[numProdFaltantes]+=cantidad_solicitada-
                    arrStockProd[posProd];
            eliminarElementoDeArreglo(arrStockProd,arrStockProd[posProd],numProd);
            numProdFaltantes++;
        }else if(cantidad_solicitada<arrStockProd[posProd]){
            arrStockProd[posProd]-=cantidad_solicitada;
        }
    }
}

void emiteReporte(int *arrCodProd,int *arrStockProd,int numProd,
        int *arrCodProdDeficit,int *arrStockFaltante,int numProdFaltantes){
    
    ofstream archReporte("reporte.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR al abrir el archivo de reporte"<<endl;
        exit(1);
    }
    imprimeEncabezado(1,archReporte);
    int totalProd=0,totalProdFalta=0;
    for(int i=0;i<numProd;i++){
        archReporte<<arrCodProd[i]<<setw(8)<<' ';
        buscaNombreProducto(arrCodProd[i],archReporte);
        archReporte<<setw(5)<<arrStockProd[i]<<endl;
        totalProd+=arrStockProd[i];
    }
    imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<"Total de productos: "<<totalProd<<endl;
    imprimeLinea('=',MAX_LINE,archReporte); 
    imprimeEncabezado(2,archReporte);
    for(int i=0;i<numProdFaltantes;i++){
        archReporte<<arrCodProdDeficit[i]<<setw(8)<<' ';
        buscaNombreProducto(arrCodProdDeficit[i],archReporte);
        archReporte<<setw(5)<<arrStockFaltante[i]<<endl;
        totalProdFalta+=arrStockFaltante[i];
    }
    imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<"Total de productos: "<<totalProdFalta<<endl;
    imprimeLinea('=',MAX_LINE,archReporte); 
}

void imprimeEncabezado(int tipo,ofstream &archReporte){
    
    if(tipo==1){
        archReporte<<setw(20)<<' '<<"REPORTE DE STOCK Y DEFICIT DE PRODUCTOS"<<endl;
        imprimeLinea('=',MAX_LINE,archReporte);
        archReporte<<setw(30)<<' '<<"PRODUCTOS EN STOCK"<<endl;
        imprimeLinea('-',MAX_LINE,archReporte);
        archReporte<<"CODIGO"<<setw(8)<<' '<<"DESCRIPCION"<<setw(49)<<' '
                <<"STOCK"<<endl;
        imprimeLinea('-',MAX_LINE,archReporte);
    }else if(tipo==2){
        imprimeLinea('=',MAX_LINE,archReporte);
        archReporte<<setw(30)<<' '<<"PRODUCTOS CON DEFICIT"<<endl;
        imprimeLinea('-',MAX_LINE,archReporte);
        archReporte<<"CODIGO"<<setw(8)<<' '<<"DESCRIPCION"<<setw(49)<<' '
                <<"STOCK"<<endl;
        imprimeLinea('-',MAX_LINE,archReporte);
    }
}

void buscaNombreProducto(int codigo,ofstream &archReporte){
    
    ifstream archProd("Productos.txt",ios::in);
    if(not archProd.is_open()){
        cout<<"ERROR al abrir el archivo de productos"<<endl;
        exit(1);
    }
    
    int codProd_evaluar,stock;
    
    while(true){
        archProd>>codProd_evaluar;
        if(archProd.eof())break;
        archProd>>stock;
        if(codProd_evaluar==codigo){
            imprimeNombreProducto(archProd,archReporte);
        }else while(archProd.get()!='\n');
    }
}

void imprimeNombreProducto(ifstream &archProd,ofstream &archReporte){
    
    char producto,primeraLetra=1;
    int numCar=0;
    archProd>>ws;
    while(true){
        producto=archProd.get();
        if(producto=='\n')break;
        if(producto!=' ' and primeraLetra)primeraLetra=0;
        else if(producto=='/' )primeraLetra=1;
        else if(producto<='9' and producto>='0')primeraLetra=1;
        else if(producto!=' ' and !primeraLetra)producto+='a'-'A';
        else if(producto==' ')primeraLetra=1;
        archReporte.put(producto);
        numCar++;
        
    }
    for(int i=0;i<MAX_CARACTERES-numCar;i++)archReporte.put(' ');
}


void eliminarElementoDeArreglo(int *arreglo,int elemento,int &numProd){
    for(int i=0;i<numProd;i++){
        if(arreglo[i]==elemento){
            for(int k=i;k<numProd-1;k++){
                arreglo[k]=arreglo[k+1];
            }
        }
    }
    numProd--;
}

int buscarPosicion(int *arreglo,int elemento,int numDat){
    for(int i=0;i<numDat;i++)
        if(arreglo[i]==elemento)return i;
    
    return NO_ENCONTRADO;
}

void imprimeLinea(char caracter, int cantidad, ofstream &archRep){
    for(int i=0;i<cantidad;i++)archRep.put(caracter);
    archRep.put('\n');
}
