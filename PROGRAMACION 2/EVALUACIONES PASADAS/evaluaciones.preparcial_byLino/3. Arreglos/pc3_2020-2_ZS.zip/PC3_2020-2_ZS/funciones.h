

/* 
 * File:   funciones.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 5 de mayo de 2023, 08:55 AM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void leerProductos(int *arrCodProd,int *arrStockProd,int &numProd);
void leeProcesaMovimientos(int *arrCodProd,int *arrStockProd,int &numProd,
        int *arrCodProdDeficit,int *arrStockFaltante,int &numProdFaltantes);
void modificarArregloDeficit(char operacion,int *arrCodProd,int *arrStockProd,
        int &numProd,int *arrCodProdDeficit,int *arrStockFaltante,
        int &numProdFaltantes,int posProd,int cantidad_solicitada,
        int codProd_leido);
void modificarArregloOriginal(char operacion, int* arrCodProd, 
        int* arrStockProd, int& numProd, int* arrCodProdDeficit, 
        int* arrStockFaltante, int& numProdFaltantes, int posProd, 
        int cantidad_solicitada, int codProd_leido);
void emiteReporte(int *arrCodProd,int *arrStockProd,int numProd,
        int *arrCodProdDeficit,int *arrStockFaltante,int numProdFaltantes);
void imprimeEncabezado(int tipo,ofstream &archReporte);
void buscaNombreProducto(int codigo,ofstream &archReporte);
void imprimeNombreProducto(ifstream &archProd,ofstream &archReporte);
void imprimeLinea(char caracter, int cantidad, ofstream &archRep);
void eliminarElementoDeArreglo(int *arreglo,int elemento,int &numProd);
int buscarPosicion(int* arreglo, int elemento, int numDat);

#endif /* FUNCIONES_H */

