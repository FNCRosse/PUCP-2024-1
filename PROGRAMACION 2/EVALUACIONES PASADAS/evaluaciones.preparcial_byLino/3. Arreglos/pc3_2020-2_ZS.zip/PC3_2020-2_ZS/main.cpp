

/* 
 * File:   main.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 5 de mayo de 2023, 08:54 AM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#define MAX_PROD 200
#include "funciones.h"
/*
 * 
 */
int main(int argc, char** argv) {
    
    int arrCodProd[MAX_PROD],arrStockProd[MAX_PROD]{},numProd;
    
    int arrCodProdDeficit[MAX_PROD],arrStockFaltante[MAX_PROD]{},numProdFaltantes;
    
    leerProductos(arrCodProd,arrStockProd,numProd);
    
    
    leeProcesaMovimientos(arrCodProd,arrStockProd,numProd,arrCodProdDeficit,
            arrStockFaltante,numProdFaltantes);
    
    emiteReporte(arrCodProd,arrStockProd,numProd,arrCodProdDeficit,
            arrStockFaltante,numProdFaltantes);
    return 0;
}

