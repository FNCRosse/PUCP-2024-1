/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * chupetin
 *
 * Created on 2 de mayo de 2023, 02:56 PM
 */

#include <iostream>
#include <iomanip>
#include <fstream>

using namespace std;

#define MAX_CURSOS 100
#include "funciones.h"

/*
 * 
 */
int main(int argc, char** argv) {
    
    
    int arrAnios[MAX_CURSOS]{}, arrCiclos[MAX_CURSOS]{}, arrCodCurso[MAX_CURSOS]{},
            arrCantHorarios[MAX_CURSOS]{},arrCantAlumnosMatric[MAX_CURSOS]{},
            numCursos;
    double arrPorcenAsis[MAX_CURSOS],arrPesos[MAX_CURSOS]{}, arrPromedioTotal[MAX_CURSOS]{},
            arrEncuestaReal[MAX_CURSOS]{},arrEncuestaAjustada[MAX_CURSOS];
    
    
    int anio_solicitado, ciclo_solicitado;
    
    cin>>anio_solicitado>>ciclo_solicitado;
    llenarAsistencias(anio_solicitado,ciclo_solicitado,arrAnios,arrCiclos,
            arrCodCurso,arrCantHorarios,arrCantAlumnosMatric,arrPesos,
            arrPorcenAsis,numCursos);
    llenarEncuestas(anio_solicitado,ciclo_solicitado,arrAnios,arrCiclos,arrCodCurso,
            arrCantHorarios,arrCantAlumnosMatric,arrPesos,arrPorcenAsis,
            arrEncuestaReal,arrEncuestaAjustada,arrPromedioTotal,numCursos);
    llenaArregloEncuestaAjustada(arrPorcenAsis,arrEncuestaAjustada,numCursos);
    ordenarArreglos(arrCodCurso,arrCantAlumnosMatric,arrCantHorarios,
            arrPorcenAsis,arrEncuestaReal,arrEncuestaAjustada,numCursos);
    emiteReporte(anio_solicitado,ciclo_solicitado,arrAnios,arrCiclos,arrCodCurso,
            arrCantHorarios,arrCantAlumnosMatric,arrPesos,arrPorcenAsis,
            arrEncuestaReal,arrEncuestaAjustada,arrPromedioTotal,numCursos);
    
    return 0;
}

