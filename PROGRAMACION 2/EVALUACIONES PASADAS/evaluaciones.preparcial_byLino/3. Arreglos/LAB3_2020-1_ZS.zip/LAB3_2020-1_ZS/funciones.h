/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * chupetin
 *
 * Created on 2 de mayo de 2023, 02:56 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void llenarAsistencias(int anio_solicitado,int ciclo_solicitado,
        int *arrAnios,int *arrCiclos,int *arrCodCurso,
        int *arrCantHorarios,int *arrCantAlumnosMatric,
        double *arrPesos,double *arrPorcenAsis,int &numCursos);
void llenarEncuestas(int anio_solicitado,int ciclo_solicitado,int *arrAnios,
        int *arrCiclos,int *arrCodCurso, int *arrCantHorarios,
        int *arrCantAlumnosMatric,double *arrPesos,
        double *arrPorcenAsis,double *arrEncuestaReal,
        double *arrEncuestaAjustada,double *arrPromedioTotal,int numCursos);
void llenaArregloEncuestaAjustada(double *arrPorcenAsis,
        double *arrEncuestaAjustada,int numCursos);
void ordenarArreglos(int *arrCodCurso,int *arrCantAlumnosMatric,
        int *arrCantHorarios,double *arrPorcenAsis,double *arrEncuestaReal,
        double *arrEncuestaAjustada,int numCursos);
void intercambiarInt(int *arreglo,int i,int j);
void intercambiarDouble(double *arreglo,int i,int j);
void emiteReporte(int anio_solicitado,int ciclo_solicitado,int *arrAnios,
        int *arrCiclos,int *arrCodCurso, int *arrCantHorarios,
        int *arrCantAlumnosMatric,double *arrPesos,
        double *arrPorcenAsis,double *arrEncuestaReal,
        double *arrEncuestaAjustada,double *arrPromedioTotal,int numCursos);
int buscarPosicion(int *arreglo, int elemento, int numDat);
void imprimeLinea(char caracter, int cantidad, ofstream &archRep);


#endif /* FUNCIONES_H */

