/*
 * chupetin
 */

#include <iostream>
#include <iomanip>
#include <fstream>

using namespace std;

#define MAX_LINE 120
#define NO_ENCONTRADO -1
#include "funciones.h"

void llenarAsistencias(int anio_solicitado,int ciclo_solicitado,
        int *arrAnios,int *arrCiclos,int *arrCodCurso,
        int *arrCantHorarios,int *arrCantAlumnosMatric,
        double *arrPesos,double *arrPorcenAsis,int &numCursos){  
    ifstream archAsistencias("Asistencia_clases.txt",ios::in);
    if(not archAsistencias.is_open()){
        cout<<"ERROR al abrir el archivo de asistencias"<<endl;
        exit(1);
    }
    int anio,ciclo,codCurso,codHorario,cant_alumnos,posCurso;
    double porcentaje_asistencia;
    numCursos=0;
    while(true){
        archAsistencias>>anio;
        if(archAsistencias.eof())break;
        archAsistencias>>ciclo>>codCurso>>codHorario>>cant_alumnos
                >>porcentaje_asistencia;
        if(anio==anio_solicitado and ciclo==ciclo_solicitado){
            posCurso=buscarPosicion(arrCodCurso,codCurso,numCursos);
            if(posCurso==NO_ENCONTRADO){ //Si el curso es nuevo
                arrAnios[numCursos]=anio;
                arrCiclos[numCursos]=ciclo;
                arrCodCurso[numCursos]=codCurso;
                arrCantHorarios[numCursos]++;
                arrCantAlumnosMatric[numCursos]+=cant_alumnos;/*denominadior*/
                arrPesos[numCursos]=porcentaje_asistencia*cant_alumnos;/*numerador*/
                arrPorcenAsis[numCursos]=
                        arrPesos[numCursos]/(double)arrCantAlumnosMatric[numCursos];
                numCursos++;
            }else if(posCurso!= NO_ENCONTRADO){ //Si el curso ya se ha registrado
                arrCantHorarios[posCurso]++;
                arrCantAlumnosMatric[posCurso]+=cant_alumnos;
                arrPesos[posCurso]+=porcentaje_asistencia*cant_alumnos;
                arrPorcenAsis[posCurso]=
                        arrPesos[posCurso]/(double)arrCantAlumnosMatric[posCurso];
            }
        }
    }   
}

void llenarEncuestas(int anio_solicitado,int ciclo_solicitado,int *arrAnios,
        int *arrCiclos,int *arrCodCurso, int *arrCantHorarios,
        int *arrCantAlumnosMatric,double *arrPesos,
        double *arrPorcenAsis,double *arrEncuestaReal,
        double *arrEncuestaAjustada,double *arrPromedioTotal,int numCursos){
    
    ifstream archEncuestas("Encuestas_Alumnos.txt",ios::in);
    if(not archEncuestas.is_open()){
        cout<<"ERROR al abrir el archivo de Encuestas_Alumnos"<<endl;
        exit(1);
    }
    
    int anio_evaluar,ciclo_evaluar,codCurso_evaluar,cod_horario,dia,mes,anio,
            posCurso,cantValores;
    char c;
    double valores,sumaValores,promedio,promedioTotal=0;
    
    while(true){
        archEncuestas>>anio_evaluar;
        if(archEncuestas.eof())break;
        archEncuestas>>ciclo_evaluar;
        if(anio_evaluar==anio_solicitado and ciclo_evaluar==ciclo_solicitado){
            archEncuestas>>codCurso_evaluar;
            archEncuestas>>cod_horario>>dia>>c>>mes>>c>>anio;
            posCurso=buscarPosicion(arrCodCurso,codCurso_evaluar,numCursos);
            if(posCurso!=NO_ENCONTRADO){
                sumaValores=0;
                cantValores=0;
                while(true){
                    archEncuestas>>valores;
                    sumaValores+=valores;
                    cantValores++;
                    if(archEncuestas.get()=='\n')break;
                }
                promedio=sumaValores/cantValores;
                arrEncuestaReal[posCurso]=promedio/arrCantHorarios[posCurso]; 
            }
        }else while(archEncuestas.get()!='\n');
    }
}

void ordenarArreglos(int *arrCodCurso,int *arrCantAlumnosMatric,
        int *arrCantHorarios,double *arrPorcenAsis,double *arrEncuestaReal,
        double *arrEncuestaAjustada,int numCursos){
    
    for(int i=0;i<numCursos-1;i++){
        for(int j=i+1;j<numCursos;j++){
            if(arrEncuestaAjustada[i]<arrEncuestaAjustada[j] or 
                    arrEncuestaAjustada[i]==arrEncuestaAjustada[j] and 
                    arrPorcenAsis[i]<arrPorcenAsis[j] or
                    arrEncuestaAjustada[i] == arrEncuestaAjustada[j] and
                    arrPorcenAsis[i] == arrPorcenAsis[j] and 
                    arrCantHorarios[i]>arrCantHorarios[j]){
                intercambiarInt(arrCodCurso,i,j);
                intercambiarInt(arrCantAlumnosMatric,i,j);
                intercambiarInt(arrCantHorarios,i,j);
                intercambiarDouble(arrPorcenAsis,i,j);
                intercambiarDouble(arrEncuestaReal,i,j);
                intercambiarDouble(arrEncuestaAjustada,i,j);
            }
        }
    }
}

void intercambiarInt(int *arreglo,int i,int j){
    int aux;
    
    aux=arreglo[i];
    arreglo[i]=arreglo[j];
    arreglo[j]=aux;
}

void intercambiarDouble(double *arreglo,int i,int j){
    double aux;
    aux=arreglo[i];
    arreglo[i]=arreglo[j];
    arreglo[j]=aux;
}

void emiteReporte(int anio_solicitado,int ciclo_solicitado,int *arrAnios,
        int *arrCiclos,int *arrCodCurso, int *arrCantHorarios,
        int *arrCantAlumnosMatric,double *arrPesos,
        double *arrPorcenAsis,double *arrEncuestaReal,
        double *arrEncuestaAjustada,double *arrPromedioTotal,int numCursos){
    
    ofstream archReporte("reporte.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR al abrir el archivo de reporte"<<endl;
        exit(1);
    }
    
    archReporte<<setprecision(2);
    archReporte<<fixed;
    archReporte<<"RESUMEN DE LA ASISTENCIA Y ENCUESTA DE ALUMNOS POR CURSO"<<endl;
    archReporte<<"ANIO:"<<setw(3)<<' '<<anio_solicitado<<setw(8)<<' '
            <<"CICLO: "<<ciclo_solicitado<<endl;
    imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<"CURSO"<<setw(2)<<' '<<"ALUMNOS"<<setw(2)<<' '<<"HORARIOS"
            <<setw(2)<<' '<<"ASISTENCIA (%)"<<setw(2)<<' '
            <<"ENCUESTA REAL (%)"<<setw(2)<<' '<<"ENCUESTA AJUSTADA (%)"<<endl;
    imprimeLinea('=',MAX_LINE,archReporte);
            
    for(int i=0;i<numCursos;i++){
        archReporte<<setw(5)<<arrCodCurso[i]<<setw(4)<<' '
                <<setw(4)<<arrCantAlumnosMatric[i]
                <<' '<<setw(8)<<arrCantHorarios[i]<<' '<<setw(12)
                <<arrPorcenAsis[i]<<'%'<<setw(12)<<' '<<arrEncuestaReal[i]<<'%'
                <<setw(15)<<' '<<arrEncuestaAjustada[i]<<'%'<<endl;
            
    }
}

void llenaArregloEncuestaAjustada(double *arrPorcenAsis,
        double *arrEncuestaAjustada,int numCursos){
    
    for(int i=0;i<numCursos;i++){
        if(arrPorcenAsis[i]<50)arrEncuestaAjustada[i]=arrPorcenAsis[i]*0;
        else if(arrPorcenAsis[i]>=50 and arrPorcenAsis[i]<60)
            arrEncuestaAjustada[i]=arrPorcenAsis[i]*1.13;
        else if(arrPorcenAsis[i]>=60 and arrPorcenAsis[i]<70)
            arrEncuestaAjustada[i]=arrPorcenAsis[i]*1.11;
        else if(arrPorcenAsis[i]>=70 and arrPorcenAsis[i]<80)
            arrEncuestaAjustada[i]=arrPorcenAsis[i]*1.08;
        else if(arrPorcenAsis[i]>=80 and arrPorcenAsis[i]<90)
            arrEncuestaAjustada[i]=arrPorcenAsis[i]*1.05;
        else if(arrPorcenAsis[i]>=90)
            arrEncuestaAjustada[i]=arrPorcenAsis[i]*1.0;
    }
}

int buscarPosicion(int *arreglo, int elemento, int numDat){
    
    
    for(int i=0;i<numDat;i++){
        if(arreglo[i]==elemento)
            return i;
    }
    
    return NO_ENCONTRADO;
}

void imprimeLinea(char caracter, int cantidad, ofstream &archRep){
    for(int i=0;i<cantidad;i++)archRep.put(caracter);
    archRep.put('\n');
}