

/* 
 * chupetin
 *
 * Created on 1 de mayo de 2023, 06:47 PM
 */


#include <iostream>
#include <fstream>
#include <iomanip>
#include <ios>
using namespace std;

#define MAX_LINEA 120
#define NO_ENCONTRADO -1
#include "funciones.h"


void leerClientes(int *arrDni,int *arrTelefono,int &numClientes){
    
    ifstream archClientes("Clientes.txt",ios::in);
    if(not archClientes.is_open()){
        cout<<"ERROR al abrir el archivo de clientes"<<endl;
        exit(1);
    }
    
    int dni, telefono;
    numClientes=0;
    while(true){
        archClientes>>dni;
        if(archClientes.eof())break;
        archClientes>>ws;
        while(archClientes.get()!=']');
        archClientes>>telefono;
        
        arrDni[numClientes]=dni;
        arrTelefono[numClientes]=telefono;
        
        numClientes++;
    }
}

void leerProcesarPedidos(int *arrDni,int *arrTelefono,double *arrTotalGastadoCli,
        int numClientes,int *arrCodProd,double *arrPrecioProd,double *arrCantidadProd,
        double *arrTotalProd,int &numProd){
    
    ifstream archPedidos("Pedidos.txt",ios::in);
    if(not archPedidos.is_open()){
        cout<<"ERROR al abrir el archivo de Pedidos"<<endl;
        exit(1);
    }
    
    int codigo_producto,pos_producto,posCliente;
    double precio_unitario,cantidad_solicitada,dni,dd,mm,aa;
    char c;
    numProd=0;
    while(true){
        archPedidos>>codigo_producto;
        if(archPedidos.eof())break;
        archPedidos>>ws;
        archPedidos.get();
        while(archPedidos.get()!='*');
        archPedidos>>precio_unitario>>cantidad_solicitada;
        archPedidos>>dni>>dd>>c>>mm>>c>>aa;
        pos_producto=buscarPosicion(arrCodProd,codigo_producto,numProd);
        if(pos_producto!=NO_ENCONTRADO){/*Si es repetido*/
            arrCantidadProd[pos_producto]+=cantidad_solicitada;
            arrTotalProd[pos_producto]+=cantidad_solicitada*precio_unitario;
            if(posCliente!=NO_ENCONTRADO){
                arrTotalGastadoCli[posCliente]+=arrTotalProd[posCliente];
            }
        }else if(pos_producto==NO_ENCONTRADO){/*En caso no encuentre el producto*/
            arrCodProd[numProd]=codigo_producto;
            arrPrecioProd[numProd]=precio_unitario;
            arrCantidadProd[numProd]=cantidad_solicitada;
            arrTotalProd[numProd]=arrPrecioProd[numProd]*arrCantidadProd[numProd];
            posCliente=buscarPosicion(arrDni,dni,numClientes);
            if(posCliente!=NO_ENCONTRADO){
                arrTotalGastadoCli[posCliente]=arrTotalProd[posCliente];
            }
            numProd++;
        }
        
    }
}

void ordenarProductos(int *arrCodProd,double *arrPrecioProd,
        double *arrCantidadProd,double *arrTotalProd,int numProd){
    
    for(int i=0;i<numProd-1;i++){
        for(int j=i+1; j<numProd;j++)
            if(arrCodProd[i]>arrCodProd[j]){
                intercambiarInt(arrCodProd,i,j);
                intercambiarDouble(arrPrecioProd,i,j);
                intercambiarDouble(arrCantidadProd,i,j);
                intercambiarDouble(arrTotalProd,i,j);
            }
    }
}

void ordenarClientes(int *arrDni,int *arrTelefono,double *arrTotalGastadoCli,
        int numClientes){
    for(int i=0;i<numClientes-1;i++){
        for(int j=i+1; j < numClientes; j++)
            if(arrTotalGastadoCli[i]<arrTotalGastadoCli[j]){
                intercambiarInt(arrDni,i,j);
                intercambiarInt(arrTelefono,i,j);
                intercambiarDouble(arrTotalGastadoCli,i,j);
            }
    }
}

void intercambiarInt(int *arreglo,int i,int j){
    int aux;
    aux = arreglo[i];
    arreglo[i] = arreglo[j];
    arreglo[j] = aux;
}

void intercambiarDouble(double *arreglo,int i,int j){
    double aux;
    aux = arreglo[i];
    arreglo[i] = arreglo[j];
    arreglo[j] = aux;
}

void emiteReporte(int *arrDni,int *arrTelefono,double *arrTotalGastadoCli,
        int numClientes,int *arrCodProd,double *arrPrecioProd,double *arrCantidadProd,
        double *arrTotalProd,int &numProd){
    
    ofstream archReporte("ReporteDeVentas.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR al abrir el archivo de reporte"<<endl;
        exit(1);
    }
    
    double montoTotal=0;
    imprimeTitulos(archReporte);
    archReporte<<setprecision(2);
    archReporte<<fixed;
    for(int i=0;i<numProd;i++){
        archReporte<<setfill(' ')<<setw(2)<<i+1<<')'<<setw(10)<<' '<<arrCodProd[i]
                <<setw(12)<<' '<<setw(6)<<arrPrecioProd[i]<<setw(10)<<' '
                <<setw(6)<<arrCantidadProd[i]<<setw(10)<<' '
                <<setw(8)<<arrTotalProd[i]<<endl;
        montoTotal+=arrTotalProd[i];
    }
    imprimeLinea('-',MAX_LINEA,archReporte);
    archReporte<<setw(60)<<' '<<"TOTAL RECAUDADO: "<<montoTotal<<endl;
    imprimeLinea('=',MAX_LINEA,archReporte);
    
    imprimeOtrosTitulos(archReporte);
    for(int i=0;i<numClientes;i++){
        archReporte<<setfill(' ')<<setw(2)<<i+1<<')'<<setw(10)<<' '
                <<arrDni[i]<<setw(10)<<' '<<setfill(' ')<<setw(9)
                <<arrTelefono[i]<<setw(10)
                <<' '<<setw(10)<<arrTotalGastadoCli[i]<<endl;
    }
    imprimeLinea('=',MAX_LINEA,archReporte);
    analizaImprimeMayoresMenores(arrDni,arrTotalGastadoCli,numClientes,
            archReporte);
    
}

void analizaImprimeMayoresMenores(int *arrDni,double *arrTotalGastadoCli,
        int numClientes,ofstream &archReporte){
    
    double cantMax=0,cantMin=arrTotalGastadoCli[0];
    int clienteMax,clienteMin;
    
    for(int i=0;i<numClientes;i++){
        if(arrTotalGastadoCli[i]>cantMax){
            cantMax=arrTotalGastadoCli[i];
            clienteMax=arrDni[i];
        }
        if(arrTotalGastadoCli[i]<cantMin){
            cantMin=arrTotalGastadoCli[i];
            clienteMin=arrDni[i];
        }
    }
    archReporte<<"Cliente con mayor gasto: "<<clienteMax<<" - S/."<<cantMax<<endl;
    archReporte<<"Cliente con menor gasto: "<<clienteMin<<" - S/."<<cantMin<<endl;
}

void imprimeOtrosTitulos(ofstream &archReporte){
    archReporte<<"GASTOS POR CLIENTE"<<endl;
    archReporte<<"NO."<<setw(10)<<' '<<"DNI"<<setw(16)<<' '<<"TELEFONO"
            <<setw(10)<<' '<<"TOTAL GASTADO"<<endl;
}

void imprimeTitulos(ofstream &archRep){
    archRep<<setw(50)<<' '<<"EMPRESA COMERCIALIZADORA ABC S.A."<<endl;
    archRep<<setw(56)<<' '<<"REPORTE DE VENTAS"<<endl;
    imprimeLinea('=',MAX_LINEA,archRep);
    archRep<<"INGRESOS POR PRODUCTO"<<endl;
    archRep<<"No."<<setw(10)<<' '<<"CODIGO"<<setw(13)<<' '<<"PRECIO"
            <<setw(4)<<' '<<"CANTIDAD VENDIDA"<<setw(5)<<' '
            <<"MONTO RECAUDADO"<<endl;
    
}



int buscarPosicion(int *arreglo,int elemento, int numDatos){
    for(int i=0;i<numDatos;i++){
        if(arreglo[i]==elemento)
            return i;
    }
    
    return NO_ENCONTRADO;
}

void imprimeLinea(char caracter, int cantidad, ofstream &archRep){
    for(int i=0;i<cantidad;i++)archRep.put(caracter);
    archRep.put('\n');
}