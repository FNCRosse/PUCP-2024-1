

/* 
 * chupetin
 *
 * Created on 1 de mayo de 2023, 06:47 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void leerClientes(int *arrDni,int *arrTelefono,int &numClientes);
void leerProcesarPedidos(int *arrDni,int *arrTelefono,double *arrTotalGastadoCli,
        int numClientes,int *arrCodProd,double *arrPrecioProd,double *arrCantidadProd,
        double *arrTotalProd,int &numProd);
void ordenarProductos(int *arrCodProd,double *arrPrecioProd,
        double *arrCantidadProd,double *arrTotalProd,int numProd);
void ordenarClientes(int *arrDni,int *arrTelefono,double *arrTotalGastadoCli,
        int numClientes);
void intercambiarInt(int *arreglo,int i,int j);
void intercambiarDouble(double *arreglo,int i,int j);
void emiteReporte(int *arrDni,int *arrTelefono,double *arrTotalGastadoCli,
        int numClientes,int *arrCodProd,double *arrPrecioProd,double *arrCantidadProd,
        double *arrTotalProd,int &numProd);
void analizaImprimeMayoresMenores(int *arrDni,double *arrTotalGastadoCli,
        int numClientes,ofstream &archReporte);
void imprimeOtrosTitulos(ofstream &archReporte);
void imprimeTitulos(ofstream &archRep);
int buscarPosicion(int *arreglo,int elemento, int numDatos);
void imprimeLinea(char caracter, int cantidad, ofstream &archRep);

#endif /* FUNCIONES_H */

