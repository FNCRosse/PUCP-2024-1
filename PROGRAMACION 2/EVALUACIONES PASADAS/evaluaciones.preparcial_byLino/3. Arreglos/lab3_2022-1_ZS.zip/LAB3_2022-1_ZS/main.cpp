

/* 
 * chupetin
 *
 * Created on 1 de mayo de 2023, 06:37 PM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#define MAX_CLIENTES 30
#define MAX_PRODUCTOS 200
#include "funciones.h"
/*
 * 
 */
int main(int argc, char** argv) {
    
    int arrDni[MAX_CLIENTES],arrTelefono[MAX_CLIENTES],numClientes;
    double arrTotalGastadoCli[MAX_CLIENTES] {};
    
    int arrCodProd[MAX_PRODUCTOS],numProd;
    double arrPrecioProd[MAX_PRODUCTOS],arrCantidadProd[MAX_PRODUCTOS] {},
            arrTotalProd[MAX_PRODUCTOS] {};
    
    
    /*llenar arreglos explicitos*/
    leerClientes(arrDni,arrTelefono,numClientes);
    /*Llenar arreglos implícitos*/
    leerProcesarPedidos(arrDni,arrTelefono,arrTotalGastadoCli,numClientes,arrCodProd,
            arrPrecioProd,arrCantidadProd,arrTotalProd,numProd);
    /*Ordenar arreglos*/
    ordenarProductos(arrCodProd,arrPrecioProd,arrCantidadProd,arrTotalProd,
            numProd);
    ordenarClientes(arrDni,arrTelefono,arrTotalGastadoCli,numClientes);
    
    emiteReporte(arrDni,arrTelefono,arrTotalGastadoCli,numClientes,arrCodProd,
            arrPrecioProd,arrCantidadProd,arrTotalProd,numProd);
    
    
    
    return 0;
}

