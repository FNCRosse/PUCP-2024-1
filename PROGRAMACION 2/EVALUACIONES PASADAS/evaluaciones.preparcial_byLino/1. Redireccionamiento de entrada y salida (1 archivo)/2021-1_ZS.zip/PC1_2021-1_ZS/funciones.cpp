

/* 
 * File:   funciones.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 6 de abril de 2023, 06:41 PM
 */


#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#define MAX_LINE 130
#define MAX_ESPAC 50
#define MAX_ESPAC_CURSO 15

#include "funciones.h"


void emitirReporte(){
    int anioIngreso,cantAlumnos=0;
    imprimeTitutlo();
    while(true){
        imprimeDatosAlumno(anioIngreso,cantAlumnos);
        if(cin.eof())break;
        imprimeCursos(anioIngreso);
    }
    cout<<"TOTAL DE ALUMNOS REGISTRADOS:"<<setw(5)<<cantAlumnos;
}

void imprimeCursos(int anioIngreso){
    double creditos,cantCredAprob=0,cantCredDesaprob=0,totalCred=0;
    int nota,dd,mm,aa,contCursos=1,cantCursosMatric=0,cantCursosAprobados=0,
            cantCursosDesaprobados=0,cantCursosErrores=0,sumaNotas=0,cantNotas=0,
            sumaNotasAprob=0,cantNotasAprob=0;
    char c;
    imprimeEncabezado();
    while(true){
        cin>>creditos;
        if(creditos==0)break;
        cin>>nota;
        cin>>dd>>c>>mm>>c>>aa;
        imprimeRelaciones(dd,mm,aa,nota,creditos,contCursos,anioIngreso,
                cantCursosAprobados,cantCursosDesaprobados,cantCredAprob,
                cantCredDesaprob,cantCursosMatric,totalCred,cantCursosErrores,
                sumaNotas,cantNotas,sumaNotasAprob,cantNotasAprob);
        contCursos++;
    }
    imprimeResumen(cantCursosAprobados,cantCursosDesaprobados,cantCredAprob,
            cantCredDesaprob,cantCursosMatric,totalCred,cantCursosErrores,
           sumaNotas,cantNotas,sumaNotasAprob,cantNotasAprob);
}

void imprimeResumen(int cantCursosAprobados,int cantCursosDesaprobados,
        double cantCredAprob,double cantCredDesaprob,int cantCursosMatric,
        double totalCred,int cantCursosErrores,int sumaNotas,int cantNotas,
        int sumaNotasAprob,int cantNotasAprob){
    cout<<"RESUMEN:"<<endl;
    cout<<"Cursos matriculados:"<<setw(4)<<cantCursosMatric;
    cout<<setw(30)<<' '<<"Total de creditos:"<<setw(8)<<' '<<totalCred<<endl;
    cout<<"Creditos aprobados:"<<setw(6)<<cantCredAprob;
    cout<<setw(30)<<' '<<"Creditos desaprobados:"<<setw(6)<<cantCredDesaprob<<endl;
    cout<<"Creditos aprobados/matriculados:"<<setw(2)<<' '
            <<(cantCredAprob/totalCred)*100<<'%'<<endl;
    imprimeLinea('-',MAX_LINE);
    cout<<"Promedio general:"<<setw(10)<<' '<<(double)sumaNotas/cantNotas<<endl;
    cout<<"Promedio general de aprobados:"<<setw(3)<<' '
            <<(double)sumaNotasAprob/cantNotasAprob<<endl;
    imprimeLinea('-',MAX_LINE);
    cout<<"Cursos con error no considerados:"<<setw(4)<<cantCursosErrores<<endl;
    imprimeLinea('=',MAX_LINE);
}

void imprimeRelaciones(int dd,int mm,int aa,int nota,double creditos,
        int contCursos,int anioIngreso,int &cantCursosAprobados,
        int &cantCursosDesaprobados,double &cantCredAprob,
        double &cantCredDesaprob,int &cantCursosMatric,double &totalCred,
        int &cantCursosErrores,int &sumaNotas,int &cantNotas,
        int &sumaNotasAprob, int &cantNotasAprob){
    
    cout<<setprecision(2);
    cout<<fixed;
    cout<<setfill('0')<<setw(3)<<contCursos<<setfill(' ')<<setw(3)<<' ';
    cout.fill(' ');
    if(anioIngreso>=aa){ /*Cursos validos*/
        
        if(nota>10){
            imprimeNombreCurso();
            cout<<creditos;
            cout<<setw(10)<<' '<<setw(2)<<nota;
            cout<<setw(10)<<' '<<setw(4)<<aa<<'/'<<setfill('0')<<setw(2)<<mm<<'/'
                    <<setfill('0')<<setw(2)<<dd<<endl;
            cout.fill(' ');
            cantCursosAprobados++;
            cantCredAprob+=creditos;
            sumaNotasAprob+=nota;
            cantNotasAprob++;
        }else if(nota<=10){
            cout<<setw(56)<<' ';
            imprimeNombreCurso();
            cout<<creditos;
            cout<<setw(10)<<' '<<setw(2)<<nota;
            cout<<setw(10)<<' '<<setw(4)<<aa<<'/'<<setfill('0')<<setw(2)<<mm<<'/'
                    <<setfill('0')<<setw(2)<<dd<<endl;
            cout.fill(' ');
            cantCursosDesaprobados++;
            cantCredDesaprob+=creditos;
        }
        sumaNotas+=nota;
        cantCursosMatric++;
        totalCred+=creditos;
        cantNotas++;
    }else{/*Cursos no validos*/
        if(nota>10){
            imprimeNombreCurso();
            cout<<creditos;
            cout<<setw(10)<<' '<<setw(2)<<nota;
            cout<<setw(10)<<' '<<setw(4)<<aa<<'/'<<setfill('0')<<setw(2)<<mm<<'/'
                    <<setfill('0')<<setw(2)<<dd;
            cout.fill(' ');
            cout<<setw(70)<<' '<<"ERROR FECHA"<<endl;
        }else{
            cout<<setw(56)<<' ';
            imprimeNombreCurso();
            cout<<creditos;
            cout<<setw(10)<<' '<<setw(2)<<nota;
            cout<<setw(10)<<' '<<setw(4)<<aa<<'/'<<setfill('0')<<setw(2)<<mm<<'/'
                    <<setfill('0')<<setw(2)<<dd;
            cout.fill(' ');
            cout<<setw(14)<<' '<<"ERROR FECHA"<<endl;
        }
        
        cantCursosErrores++;
    }
}

void imprimeNombreCurso(){
    char curso;
    int cantCarac=0;
    cin>>ws;
    while(true){
        curso=cin.get();
        if(curso=='\n')break;
        cout.put(curso);
        cantCarac++;
    }
    for(int i=0;i<MAX_ESPAC_CURSO-cantCarac;i++)
        cout.put(' ');
}

void imprimeEncabezado(){
    cout<<setw(15)<<' '<<"CURSOS APROBADOS";
    cout<<setw(35)<<' '<<"CURSOS DESAPROBADOS";
    cout<<setw(42)<<' '<<"OBSERVACION"<<endl;
    cout<<"No."<<setw(3)<<' '<<"CODIGO"<<setw(7)<<' '<<"CREDITOS"<<setw(7)<<' '
            <<"NOTA"<<setw(12)<<' '<<"FECHA";
    cout<<setw(7)<<' '<<"CODIGO"<<setw(7)<<' '<<"CREDITOS"<<setw(7)<<' '
            <<"NOTA"<<setw(12)<<' '<<"FECHA"<<endl;
}

void imprimeDatosAlumno(int &anioIngreso,int &cantAlumnos){
    char c;
    int codigoAlumno;
    cin>>codigoAlumno;
    if(cin.eof())return;
    cin>>c>>anioIngreso;
    imprimeLinea('=',MAX_LINE);
    cout<<setw(10)<<' '<<"Alumnno: ";
    leeImprimeNombre();
    cout<<"Codigo: "<<anioIngreso<<" - "<<setfill('0')<<setw(6)
            <<codigoAlumno<<endl;
    cout.fill(' ');
    imprimeLinea('-',MAX_LINE);
    cantAlumnos++;
}

void leeImprimeNombre(){
    char nombre;
    int numCarac=0;
    cin>>ws;
    while(true){
        nombre=cin.get();
        if(nombre=='\n')break;
        if(nombre=='/')nombre=' ';
        if(nombre=='-')nombre=' ';
        cout.put(nombre);
        numCarac++;
    }
    for(int i=0;i<MAX_ESPAC-numCarac;i++)
        cout.put(' ');
    
}

void imprimeTitutlo(){
    cout<<setw(50)<<' '<<"INFORMACION ACADEMICA DE LOS ESTUDIANTES"<<endl; 
}

void imprimeLinea(char caracter, int cantidad){
    for(int i=0;i<cantidad;i++)
        cout.put(caracter);
    cout.put('\n');
}


