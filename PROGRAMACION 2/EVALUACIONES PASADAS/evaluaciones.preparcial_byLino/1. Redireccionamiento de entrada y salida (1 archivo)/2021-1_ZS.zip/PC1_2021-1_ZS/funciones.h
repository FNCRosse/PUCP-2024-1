

/* 
 * File:   funciones.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 6 de abril de 2023, 06:41 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void emitirReporte();
void imprimeCursos(int anioIngreso);
void imprimeResumen(int cantCursosAprobados,int cantCursosDesaprobados,
        double cantCredAprob,double cantCredDesaprob,int cantCursosMatric,
        double totalCred,int cantCursosErrores,int sumaNotas,int cantNotas,
        int sumaNotasAprob,int cantNotasAprob);
void imprimeEncabezado();
void imprimeRelaciones(int dd,int mm,int aa,int nota,double creditos,
        int contCursos,int anioIngreso,int &cantCursosAprobados,
        int &cantCursosDesaprobados,double &cantCredAprob,
        double &cantCredDesaprob,int &cantCursosMatric,double &totalCred,
        int &cantCursosErrores,int &sumaNotas,int &cantNotas,
        int &sumaNotasAprob, int &cantNotasAprob);
void imprimeNombreCurso();
void imprimeDatosAlumno(int &anioIngreso,int &cantAlumnos);
void leeImprimeNombre();
void imprimeTitutlo();
void imprimeLinea(char caracter, int cantidad);

#endif /* FUNCIONES_H */

