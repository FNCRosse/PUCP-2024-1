

/* 
 * File:   main.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 6 de abril de 2023, 06:39 PM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#include "funciones.h"
/*
 * 
 */
int main(int argc, char** argv) {
    
    emitirReporte();
    
    return 0;
}

