

/* 
 * File:   funciones.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 7 de abril de 2023, 10:02 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H


void emiteReporte();
void leeImprimeCitas(double tarifa);
void imprimeResumen(double montoTotal_seguro,double promedio_consultas,
                int promHoraEfec,int promMinEfec,int promSegEfec,
        int diaMayor,int mesMayor,int anioMayor,int horaMay,int minMay,
        int segMay,int diaMayConsultas,int mesMayConsultas,
            int anioMayConsultas,int mayorConsultas);
void analizarMayor(int dd,int mm,int aa,int &diaMayor,int &mesMayor,
        int &anioMayor,int horaEfecPorDia,int minEfecPorDia,int segEfecPorDia,
        int &horaMay,int &minMay,int &segMay,int &tiempoMayor);
void imprimeDatosCitas(int dd,int mm,int aa,int cantConsultas,int horaEfec,
        int minEfec,int segEfec,double montoRecaudado_paciente);
void devuelveTiempoEfectivo(int horas,int minutos,int segundos,
        int &horaEfecPorDia,int &minEfecPorDia,int &segEfecPorDia);
void tiempoEfectivo(int horaIni,int minIni,int segIni,int horaFin,int minFin,
        int segFin,int &horaEfec,int &minEfec,int &segEfec);
void imprimeEncabezado();
void leeImprimeMedicos(int &dni_medico, double &tarifa);
void imprimeDatosMedic(int dni_medico,double tarifa);
void imprimeLinea(char caracter, int cantidad);

#endif /* FUNCIONES_H */

