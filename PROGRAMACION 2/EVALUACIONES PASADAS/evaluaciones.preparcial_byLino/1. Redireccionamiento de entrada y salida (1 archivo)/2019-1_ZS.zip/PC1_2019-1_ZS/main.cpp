

/* 
 * File:   main.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 7 de abril de 2023, 10:02 PM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#include "funciones.h"
/*
 * 
 */
int main(int argc, char** argv) {
    
    emiteReporte();
    
    return 0;
}

