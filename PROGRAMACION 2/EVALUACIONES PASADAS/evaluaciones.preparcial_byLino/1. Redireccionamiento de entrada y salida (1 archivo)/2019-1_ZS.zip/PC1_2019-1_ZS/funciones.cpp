

/* 
 * File:   funciones.cpp
 * Author: chupetin
 *
 * Created on 7 de abril de 2023, 10:02 PM
 */


#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#include "funciones.h"
#define MAX_LINE 150

void emiteReporte(){
    
    
    int dni_medico;
    double tarifa;
    cout<<"Reporte de consultas:"<<endl;
    while(true){
        leeImprimeMedicos(dni_medico,tarifa);
        if(cin.eof())break;
        imprimeLinea('=',MAX_LINE);
        leeImprimeCitas(tarifa);
        imprimeLinea('=',MAX_LINE);        
    }
    
}

void leeImprimeCitas(double tarifa){
    int dd,mm,aa,horaIni,minIni,segIni,horaFin,minFin,segFin,horaEfec,
            minEfec,segEfec,cantConsultas,cantDatos=0,horaEfecPorDia,
            minEfecPorDia,segEfecPorDia,horas,minutos,segundos,minutApagar;
    double porc_paci,porc_seguro,montoRecaudado_paciente=0,montoPagar_seguro=0,
            promedio_consultas,promedio_tiempoEfectivo,montoTotal_seguro=0;
    char c;
    int consultasTotales=0,sumaHora=0,sumaMin=0,sumaSeg=0,promHoraEfec,
            promMinEfec,promSegEfec,horaMax=0,minMax=0,segMax=0,
            diaMayor,mesMayor,anioMayor,horaMay,minMay,segMay,tiempoMayor=0,
            mayorConsultas=0,diaMayConsultas,mesMayConsultas,anioMayConsultas;
    
    imprimeEncabezado();
    while(true){
        cin>>dd;
        if(dd==0)break;
        cin>>c>>mm>>c>>aa;
        cantConsultas=horas=minutos=segundos=minutApagar=0;
        montoRecaudado_paciente=0,montoPagar_seguro=0;
        while(true){
            cin>>horaIni>>c>>minIni>>c>>segIni;
            cin>>horaFin>>c>>minFin>>c>>segFin;
            cin>>porc_paci;
            cantConsultas++;
            tiempoEfectivo(horaIni,minIni,segIni,horaFin,minFin,segFin,
                    horaEfec,minEfec,segEfec);
            horas+=horaEfec;
            minutos+=minEfec;
            segundos+=segEfec;
            minutApagar=horaEfec*60+minEfec;
            if(segEfec>0)minutApagar+=1;
            montoRecaudado_paciente+=(double)(tarifa*minutApagar)*(porc_paci)/100;
            montoPagar_seguro+=(double)(tarifa*minutApagar)*((100-porc_paci)/100);
            if(cin.get()=='\n'){
                
                devuelveTiempoEfectivo(horas,minutos,segundos,horaEfecPorDia,
                        minEfecPorDia,segEfecPorDia);
                imprimeDatosCitas(dd,mm,aa,cantConsultas,horaEfecPorDia,minEfecPorDia,
                        segEfecPorDia,montoRecaudado_paciente);
                break;
            }
        }
        analizarMayor(dd,mm,aa,diaMayor,mesMayor,anioMayor,horaEfecPorDia,
                minEfecPorDia,segEfecPorDia,horaMay,minMay,segMay,tiempoMayor);
        sumaHora+=horaEfecPorDia;
        sumaMin+=minEfecPorDia;
        sumaSeg+=segEfecPorDia;
        montoTotal_seguro+=montoPagar_seguro;
        consultasTotales+=cantConsultas;
        if(cantConsultas>mayorConsultas){
            mayorConsultas=cantConsultas;
            diaMayConsultas=dd;
            mesMayConsultas=mm;
            anioMayConsultas=aa;
        }
        cantDatos++;
    }
    promHoraEfec=sumaHora/cantDatos;
    promMinEfec=sumaMin/cantDatos;
    promSegEfec=sumaSeg/cantDatos;
    promedio_consultas=(double)consultasTotales/cantDatos;
    imprimeResumen(montoTotal_seguro,promedio_consultas,
                promHoraEfec,promMinEfec,promSegEfec,diaMayor,mesMayor,
            anioMayor,horaMay,minMay,segMay,diaMayConsultas,mesMayConsultas,
            anioMayConsultas,mayorConsultas);
}

void imprimeResumen(double montoTotal_seguro,double promedio_consultas,
                int promHoraEfec,int promMinEfec,int promSegEfec,
        int diaMayor,int mesMayor,int anioMayor,int horaMay,int minMay,
        int segMay,int diaMayConsultas,int mesMayConsultas,
            int anioMayConsultas,int mayorConsultas){
    imprimeLinea('=',MAX_LINE);
    cout<<"Monto que debe pagarle el seguro: S/."<<setw(15)<<montoTotal_seguro<<endl;
    cout<<"Promedio de consultas diario:"<<setw(15)<<promedio_consultas<<endl;
    cout<<"Promedio de tiempo efectivo:"<<setw(10)<<' '<<setw(3)<<promHoraEfec
            <<'h'<<setw(3)<<promMinEfec<<'m'<<setw(3)<<promSegEfec<<'s'<<endl;
    imprimeLinea('=',MAX_LINE);
    cout<<"Maximos Obtenidos:"<<endl;
    cout<<setw(5)<<' '<<"Consultas:"<<endl;
    cout<<setw(5)<<' '<<"Fecha: "<<setfill('0')<<setw(2)<<diaMayConsultas<<'/'
            <<setfill('0')<<setw(2)<<mesMayConsultas<<'/'<<setw(4)<<anioMayConsultas;
    cout<<setfill(' ')<<setw(5)<<' '<<"Total:"<<setw(3)<<mayorConsultas<<endl;
    cout<<setw(5)<<' '<<"Tiempo:"<<endl;
    cout<<setw(5)<<' '<<"Fecha: "<<setfill('0')<<setw(2)<<diaMayor<<'/'
            <<setfill('0')<<setw(2)<<mesMayor<<'/'<<setw(4)<<anioMayor;
    cout<<setfill(' ')<<setw(5)<<' '<<"Total: "<<setw(3)<<horaMay<<'h'
            <<setw(3)<<minMay<<'m'<<setw(3)<<segMay<<'s'<<endl;
    cout.fill(' ');    
}

void analizarMayor(int dd,int mm,int aa,int &diaMayor,int &mesMayor,
        int &anioMayor,int horaEfecPorDia,int minEfecPorDia,int segEfecPorDia,
        int &horaMay,int &minMay,int &segMay,int &tiempoMayor){
    
    int tiempoSegundos=horaEfecPorDia*3600+minEfecPorDia*60+segEfecPorDia;
    
    if(tiempoSegundos>tiempoMayor){
        tiempoMayor=tiempoSegundos;
        anioMayor=aa;
        mesMayor=mm;
        diaMayor=dd;
        horaMay=horaEfecPorDia;
        minMay=minEfecPorDia;
        segMay=segEfecPorDia;
    }
}

void imprimeDatosCitas(int dd,int mm,int aa,int cantConsultas,int horaEfecPorDia,
        int minEfecPorDia,int segEfecPorDia,double montoRecaudado_paciente){
    cout<<setprecision(2);
    cout<<fixed;
    cout<<setfill('0')<<setw(2)<<dd<<'/'<<setfill('0')<<setw(2)<<mm<<'/'
            <<setw(4)<<aa;
    cout.fill(' ');
    cout<<setw(10)<<' '<<setw(3)<<cantConsultas;
    cout<<setw(19)<<' '<<setw(3)<<horaEfecPorDia<<'h'<<setw(3)<<minEfecPorDia<<'m'
            <<setw(3)<<segEfecPorDia<<'s';
    cout<<setw(10)<<' '<<setw(10)<<montoRecaudado_paciente<<endl;
}

void devuelveTiempoEfectivo(int horas,int minutos,int segundos,
        int &horaEfecPorDia,int &minEfecPorDia,int &segEfecPorDia){
    int tiempoSegundos =  horas *3600+minutos*60+segundos;
    
    horaEfecPorDia= tiempoSegundos/3600;
    minEfecPorDia = (tiempoSegundos%3600)/60;
    segEfecPorDia = (tiempoSegundos%3600)%60;
}

void tiempoEfectivo(int horaIni,int minIni,int segIni,int horaFin,int minFin,
        int segFin,int &horaEfec,int &minEfec,int &segEfec){
    int duracionIniSegundos=horaIni*3600+minIni*60+segIni;
    int duracionFinSegundos=horaFin*3600+minFin*60+segFin;
    
    int duracionTotalSeg=duracionFinSegundos-duracionIniSegundos;
    
    horaEfec= duracionTotalSeg/3600;
    minEfec = (duracionTotalSeg%3600)/60;
    segEfec = (duracionTotalSeg%3600)%60;
}

void imprimeEncabezado(){
    cout<<"Fecha"<<setw(10)<<' '<<"Numero de consultas"<<setw(5)<<' '
            <<"Tiempo efectivo"<<setw(5)<<' '<<"Monto recaudado"<<endl;
}

void leeImprimeMedicos(int &dni_medico, double &tarifa){
    cin>>dni_medico;
    if(cin.eof())return;
    cin>>tarifa;
    imprimeDatosMedic(dni_medico,tarifa);
}

void imprimeDatosMedic(int dni_medico,double tarifa){
    cout<<"DNI del medico"<<setw(10)<<dni_medico<<endl;
    cout<<"Costo por consulta por minuto:"<<setw(10)<<tarifa<<endl;
}

void imprimeLinea(char caracter, int cantidad){
    for(int i=0;i<cantidad;i++)
        cout.put(caracter);
    cout.put('\n');
}
