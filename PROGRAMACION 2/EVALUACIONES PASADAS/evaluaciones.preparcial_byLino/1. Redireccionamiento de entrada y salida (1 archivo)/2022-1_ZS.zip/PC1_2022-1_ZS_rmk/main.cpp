

/* 
 * File:   main.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 14 de abril de 2023, 04:39 PM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;


#include "funciones.h"
/*
 * 
 */
int main(int argc, char** argv) {
    
    ifstream archVentas("Ventas.txt",ios::in);
    if(not archVentas.is_open()){
        cout<<"ERROR al abrir el archivo de ventas"<<endl;
        exit(1);
    }
    
    ofstream archReporte("reporte.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR al abrir el archivo de reporte"<<endl;
        exit(1);
    }
    
    emiteReporte(archVentas,archReporte);
    
    return 0;
}

