

/* 
 * File:   funciones.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 14 de abril de 2023, 04:40 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void emiteReporte(ifstream &archVentas,ofstream &archReporte);
void leerEimprimeDatosCliente(double descA,double descB,double descC,
        double imp_pais,double desc_producto,int prod_especial,int pais_especial,
        int mm_emision,ifstream &archVentas,ofstream &archReporte);
void leeImprimeProductos(double descA,double descB,double descC,double imp_pais,
        double desc_producto,int prod_especial,int pais_especial,
        char categoria_cliente,int mmNac,int mm_emision,int id_pais,
        double &subtotal,ifstream &archVentas,ofstream &archReporte);
void imprimeImpuesto(int id_pais,int pais_especial,double imp_pais,
        ofstream &archReporte);
void analisisDescuento(char categoria_cliente,double descA,double descB,
        double descC,int tipoProducto,double desc_producto,int prod_especial,
        int mmNac,int mm_emision,double &total);
int analizaPorc(int valor,int valor_evaluar);
void analizaCategoria(char categoria_cliente,int &tieneA,int &tieneB,
        int &tieneC,int &tieneD);
void imprimeDescuentos(char categoria_cliente,double descA,double descB,
        double descC,int tipoProducto,double desc_producto,int prod_especial,
        int mmNac,int mm_emision,ofstream &archRep);
void imprimeProductos(int tipoProducto,int codigo_producto,double prec_uni,
        double cantidad,double total,ofstream &archReporte);
void imprimeEncabezadoProductos(ofstream &archReporte);
void imprimeDatosCliente(int dni,int id_ciudad,int id_pais,int telefono,
        char categoria_cliente,int ddNac,int mmNac,int aaNac,ofstream &archRep);
void imprimeLinea(char caracter,int cantidad,ofstream &archReporte);
void imprimeEncabezado(int dd_emision,int mm_emision,int aa_emision,
        int prod_especial,int pais_especial,ofstream &archReporte);
void leerDatosPrincipales(int &dd_emision,int &mm_emision,int &aa_emision,
        int &prod_especial,int &pais_especial,double &descA,double &descB,
        double &descC,double &desc_producto,double &desc_pais,ifstream &archVentas);

#endif /* FUNCIONES_H */

