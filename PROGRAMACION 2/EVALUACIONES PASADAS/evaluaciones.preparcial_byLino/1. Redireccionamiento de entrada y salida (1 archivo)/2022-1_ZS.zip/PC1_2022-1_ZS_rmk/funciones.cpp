

/* 
 * File:   funciones.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 14 de abril de 2023, 04:39 PM
 */


#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#include "funciones.h"
#define MAX_LINE 150

void emiteReporte(ifstream &archVentas,ofstream &archReporte){
    
    int dd_emision,mm_emision,aa_emision,prod_especial,pais_especial;
    double descA,descB,descC,desc_producto,imp_pais;
    
    leerDatosPrincipales(dd_emision,mm_emision,aa_emision,prod_especial,
            pais_especial,descA,descB,descC,desc_producto,imp_pais,archVentas);
    imprimeEncabezado(dd_emision,mm_emision,aa_emision,prod_especial,
            pais_especial,archReporte);
    
    while(true){
        leerEimprimeDatosCliente(descA,descB,descC,imp_pais,desc_producto,
                prod_especial,pais_especial,mm_emision,archVentas,archReporte);
        if(archVentas.eof())break;
        
    }
}

void leerEimprimeDatosCliente(double descA,double descB,double descC,
        double imp_pais,double desc_producto,int prod_especial,int pais_especial,
        int mm_emision,ifstream &archVentas,ofstream &archReporte){
    int dni,id_ciudad,id_pais,telefono,ddNac,mmNac,aaNac;
    double subtotal=0;
    char categoria_cliente,c;
    
    archVentas>>dni;
    if(archVentas.eof())return;
    archVentas>>id_ciudad>>c>>id_pais>>c>>telefono;
    archVentas>>categoria_cliente;
    archVentas>>ddNac>>c>>mmNac>>c>>aaNac;
    
    imprimeDatosCliente(dni,id_ciudad,id_pais,telefono,categoria_cliente,
            ddNac,mmNac,aaNac,archReporte);
    
    leeImprimeProductos(descA,descB,descC,imp_pais,desc_producto,prod_especial,
            pais_especial,categoria_cliente,mmNac,mm_emision,id_pais,
            subtotal,archVentas,archReporte);
    archReporte<<"Total a pagar: "<<subtotal<<endl;
}

void leeImprimeProductos(double descA,double descB,double descC,double imp_pais,
        double desc_producto,int prod_especial,int pais_especial,
        char categoria_cliente,int mmNac,int mm_emision,int id_pais,
        double &subtotal,ifstream &archVentas,ofstream &archReporte){
    int tipoProducto,codigo_producto,tieneImpuesto;
    double prec_uni,cantidad,total;
    char c;
    imprimeEncabezadoProductos(archReporte);
    while(true){
        archVentas>>tipoProducto;
        if(tipoProducto==0)break;
        archVentas>>c>>codigo_producto;
        archVentas>>prec_uni;
        archVentas>>cantidad;
        total=cantidad*prec_uni;
        imprimeProductos(tipoProducto,codigo_producto,prec_uni,cantidad,total,
                archReporte);
        imprimeDescuentos(categoria_cliente,descA,descB,descC,tipoProducto,
                desc_producto,prod_especial,mmNac,mm_emision,archReporte);
        
        analisisDescuento(categoria_cliente,descA,descB,descC,tipoProducto,
                desc_producto,prod_especial,mmNac,mm_emision,total);  
        imprimeImpuesto(id_pais,pais_especial,imp_pais,archReporte);
        tieneImpuesto=analizaPorc(id_pais,pais_especial);
        if(tieneImpuesto)total=total + ((total*imp_pais)/100);

        archReporte<<setw(10)<<' '<<setw(8)<<total<<endl;
        subtotal+=total;        
    }
    imprimeLinea('-',MAX_LINE,archReporte);
}

void imprimeImpuesto(int id_pais,int pais_especial,double imp_pais,
        ofstream &archReporte){
    if(id_pais==pais_especial)archReporte<<setw(10)<<' '<<setfill('0')
            <<setw(5)<<imp_pais<<setfill(' ');
    else archReporte<<setw(10)<<' '<<"--.--";
}

void analisisDescuento(char categoria_cliente,double descA,double descB,
        double descC,int tipoProducto,double desc_producto,int prod_especial,
        int mmNac,int mm_emision,double &total){
    int tieneA=0,tieneB=0,tieneC=0,tieneD=0,tieneProd=0,tieneMes=0;
    analizaCategoria(categoria_cliente,tieneA,tieneB,tieneC,tieneD);
    tieneProd=analizaPorc(tipoProducto,prod_especial);
    tieneMes=analizaPorc(mmNac,mm_emision);

    if(tieneProd)total=total-((total*desc_producto)/100);
    if(tieneA)total=total-((total*descA)/100);
    if(tieneB)total=total-((total*descB)/100);
    if(tieneC)total=total-((total*descC)/100);
    if(tieneD)total=total-0;
    if(tieneMes)total=total-((total*5)/100);
}

int analizaPorc(int valor,int valor_evaluar){
    
    int verifacion=0;
    if(valor==valor_evaluar)verifacion=1;
    else verifacion=0;
    
    return verifacion;
}

void analizaCategoria(char categoria_cliente,int &tieneA,int &tieneB,
        int &tieneC,int &tieneD){
   
    if(categoria_cliente=='A')
        tieneA=1;
    else if(categoria_cliente=='B')
        tieneB=1;
    else if(categoria_cliente=='C')
        tieneC=1;
    else if(categoria_cliente=='D')
        tieneD=1;

}


void imprimeDescuentos(char categoria_cliente,double descA,double descB,
        double descC,int tipoProducto,double desc_producto,int prod_especial,
        int mmNac,int mm_emision,ofstream &archRep){
    
    if(categoria_cliente=='A')archRep<<setw(10)<<' '<<setfill('0')<<setw(5)
            <<descA<<'|'<<setfill(' ');
    else if(categoria_cliente=='B')archRep<<setw(10)<<' '<<setfill('0')
            <<setw(5)<<descB<<'|'<<setfill(' ');
    else if(categoria_cliente=='C')archRep<<setw(10)<<' '<<setfill('0')
            <<setw(5)<<descC<<'|'<<setfill(' ');
    else if(categoria_cliente=='D')archRep<<setw(10)<<' '<<"--.--"<<'|';
    
    if(tipoProducto==prod_especial)archRep<<setfill('0')<<setw(5)
            <<desc_producto<<'|'<<setfill(' ');
    else archRep<<"--.--"<<'|';
    
    if(mmNac==mm_emision)archRep<<"05.00";
    else archRep<<"--.--";
}

void imprimeProductos(int tipoProducto,int codigo_producto,double prec_uni,
        double cantidad,double total,ofstream &archReporte){
    archReporte<<setprecision(2);
    archReporte<<fixed;
    archReporte<<setw(3)<<' '<<tipoProducto<<setw(5)<<' '<<setw(5)<<codigo_producto
            <<setw(8)<<' '<<setw(5)<<prec_uni<<setw(8)<<' '<<setw(6)<<cantidad
            <<setw(5)<<' '<<setw(10)<<total;
}

void imprimeEncabezadoProductos(ofstream &archReporte){
    imprimeLinea('-',MAX_LINE,archReporte);
    archReporte<<setw(5)<<' '<<"PRODUCTOS ADQUIRIDOS"<<endl;
    archReporte<<setw(3)<<' '<<"TIPO"<<setw(6)<<' '<<"CODIGO"<<setw(6)
            <<' '<<"P.U"<<setw(8)<<' '<<"Cantidad"<<setw(10)<<' '<<"Total"
            <<setw(10)<<' '<<"% de Descuentos"<<setw(10)<<' '<<"Impuesto"
            <<setw(10)<<' '<<"A Pagar"<<endl;
    imprimeLinea('-',MAX_LINE,archReporte);
}

void imprimeDatosCliente(int dni,int id_ciudad,int id_pais,int telefono,
        char categoria_cliente,int ddNac,int mmNac,int aaNac,ofstream &archRep){
    imprimeLinea('=',MAX_LINE,archRep);
    archRep<<setw(5)<<' '<<"Cliente "<<dni;
    archRep<<setw(30)<<' '<<"Pais: ";
    if(id_pais==63)archRep<<"Brasil "<<'('<<id_pais<<')'<<endl;
    if(id_pais==51)archRep<<"Peru "<<'('<<id_pais<<')'<<endl;
    if(id_pais==77)archRep<<"Colombia "<<'('<<id_pais<<')'<<endl;
    if(id_pais==98)archRep<<"Uruguay "<<'('<<id_pais<<')'<<endl;
    archRep<<setw(51)<<' '<<"Ciudad: "<<id_ciudad<<endl;
    archRep<<setw(51)<<' '<<"Telefono: "<<telefono<<endl;
    archRep<<setw(5)<<' '<<"Fecha de nacimiento: "<<setfill('0')<<setw(2)
            <<ddNac<<'/'<<setw(2)<<mmNac<<'/'<<setw(4)<<aaNac<<setfill(' ');
    archRep<<setw(15)<<' '<<"Categoria: "<<categoria_cliente<<endl;
}

void imprimeLinea(char caracter,int cantidad,ofstream &archReporte){
    for(int i=0;i<cantidad;i++)archReporte.put(caracter);
    archReporte.put('\n');
}

void imprimeEncabezado(int dd_emision,int mm_emision,int aa_emision,
        int prod_especial,int pais_especial,ofstream &archReporte){
    
    archReporte<<setw(50)<<' '<<"EMPRESA COMERCIALIZADORA ABC S.A."<<endl;
    archReporte<<setw(45)<<' '<<"Fecha de emision: "<<setfill('0')<<setw(2)
            <<dd_emision<<'/'<<setw(2)<<mm_emision<<'/'<<setw(4)<<aa_emision
            <<setfill(' ')<<endl;
    archReporte<<setw(5)<<' '<<"Productos con descuento: "<<prod_especial<<endl;
    archReporte<<setw(5)<<' '<<"Pais con impuesto a las ventas: ";
    if(pais_especial==63)archReporte<<"Brasil "<<'('<<pais_especial<<')'<<endl;
    if(pais_especial==51)archReporte<<"Peru "<<'('<<pais_especial<<')'<<endl;
    if(pais_especial==77)archReporte<<"Colombia "<<'('<<pais_especial<<')'<<endl;
    if(pais_especial==98)archReporte<<"Uruguay "<<'('<<pais_especial<<')'<<endl;
}


void leerDatosPrincipales(int &dd_emision,int &mm_emision,int &aa_emision,
        int &prod_especial,int &pais_especial,double &descA,double &descB,
        double &descC,double &desc_producto,double &imp_pais,ifstream &archVentas){
    
    char c;
    archVentas>>dd_emision;
    archVentas>>c>>mm_emision>>c>>aa_emision;
    archVentas>>descA>>c;
    archVentas>>descB>>c;
    archVentas>>descC>>c;
    archVentas>>prod_especial>>desc_producto>>c;
    archVentas>>pais_especial>>imp_pais>>c;
    
}