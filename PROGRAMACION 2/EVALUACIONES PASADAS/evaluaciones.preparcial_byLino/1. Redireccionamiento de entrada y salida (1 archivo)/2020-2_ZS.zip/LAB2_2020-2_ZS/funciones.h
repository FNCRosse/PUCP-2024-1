

/* 
 * File:   funciones.h
 * Author: Chupetin
 *
 * Created on 14 de abril de 2023, 11:02 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void emiteReporte(ifstream &archAlumnos,ofstream &archReporte);
void leeImprimeAlumno(int &contAlumnos,ifstream &archAlumnos,ofstream &archReporte);
void leeImprimeCursos(int cod_facultad,int anio_ingreso,
        ifstream &archAlumnos,ofstream &archReporte);
void leeImprimeCursos(ifstream &archAlumnos,ofstream &archReporte);
void imprimeResumenFacultad(int cursosMatric_facu,double credAprob_facu,
        double credDesaprob_facu,double totalCred_facu,int cantNotas_facu,
        int sumNotas_facu,int notasAprob_facu,ofstream &archReporte);
void imprimeResumnNofacultad(int cursosMatric_nofacu,double credAprob_nofacu,
        double credDesaprob_nofacu,double totalCred_nofacu,
        int cantNotas_nofacu,int sumNotas_nofacu,int notasAprob_nofacu,
        ofstream &archReporte);
void imprimeErrores(int cantCursos_errores,int cursos_errorCred,
        int cursos_errorFecha,ofstream &archReporte);
void imprimeCursos(int &cursos_errorCred,int &cursos_errorFecha,int cont_cursos,
        int cod_curso,int nota,int cod_facultad,
        int cod_cursoFac,int dd_eva,int mm_eva,int aa_eva,
        int anio_ingreso,double creditos,int &cursosMatric_facu,
        double &credAprob_facu,double &credDesaprob_facu,double &totalCred_facu,
        int &cursosMatric_nofacu,double &credAprob_nofacu,
        double &credDesaprob_nofacu,double &totalCred_nofacu,
        int &cantNotas_facu,int &sumNotas_facu,int &cantNotas_nofacu,
        int &sumNotas_nofacu,int &notasAprob_facu,int &notasAprob_nofacu,
        int &esErrorCred,int &esErrorFecha,int &cantCursos_errores,
        ofstream &archReporte);
void imprimeCursosOtraFacu(int nota,int cod_curso,double creditos,int aa_eva,
        int mm_eva,int dd_eva, double &credAprob_nofacu,double &credDesaprob_nofacu,
        int &notasAprob_nofacu,double &totalCred_nofacu,int &cursosMatric_nofacu,
        int &cantNotas_nofacu,int &sumNotas_nofacu,ofstream &archReporte);
void imprimeCursosFacu(int nota,int cod_curso,double creditos,int aa_eva,
        int mm_eva,int dd_eva,double &credDesaprob_facu,double &credAprob_facu,
        int &notasAprob_facu,double &totalCred_facu,int &cursosMatric_facu,
        int &cantNotas_facu,int &sumNotas_facu, ofstream &archReporte);
void imprimeCursosConError(int nota,int cod_curso,double creditos,int aa_eva,
        int mm_eva,int dd_eva,ofstream &archReporte);
void analizaErrores(double creditos,int aa_eva,int anio_ingreso,int &esErrorCred,
        int &esErrorFecha);
void imprimeEncabezado(ofstream &archReporte);
void imprimeLinea(char caracter,int cantidad, ofstream &archRep);

#endif /* FUNCIONES_H */

