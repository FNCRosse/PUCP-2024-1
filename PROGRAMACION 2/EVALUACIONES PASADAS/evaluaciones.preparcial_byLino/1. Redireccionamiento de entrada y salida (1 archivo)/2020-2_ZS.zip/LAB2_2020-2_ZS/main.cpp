

/* 
 * File:   main.cpp
 * Author: Chupetin
 *
 * Created on 14 de abril de 2023, 11:01 PM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#include "funciones.h"
/*
 * 
 */
int main(int argc, char** argv) {
    
    ifstream archAlumnos("Alumnos-Cursos.txt",ios::in);
    if(not archAlumnos.is_open()){
        cout<<"ERROR al abrir el archivo de alumnos"<<endl;
        exit(1);
    }
    
    ofstream archReporte("reporte.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR al abrir el archivo de reporte"<<endl;
        exit(1);
    }
    
    emiteReporte(archAlumnos,archReporte);
    return 0;
}

