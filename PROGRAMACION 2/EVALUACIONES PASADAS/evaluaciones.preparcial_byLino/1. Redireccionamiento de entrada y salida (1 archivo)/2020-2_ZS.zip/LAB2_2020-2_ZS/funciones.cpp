

/* 
 * File:   funciones.cpp
 * Author: Chupetin
 *
 * Created on 14 de abril de 2023, 11:02 PM
 */


#include <iostream>
#include <fstream>
#include <iomanip>
#include <set>
using namespace std;

#include "funciones.h"
#define MAX_LINE 150


void emiteReporte(ifstream &archAlumnos,ofstream &archReporte){
    
    archReporte<<setw(50)<<' '<<"INFORMACION ACADEMICA DE LOS ESTUDIANTES"<<endl;
    int contAlumnos=0;
    while(true){
        leeImprimeAlumno(contAlumnos,archAlumnos,archReporte);
        if(archAlumnos.eof())break;
    }
    imprimeLinea('=',MAX_LINE,archReporte);
    imprimeLinea('*',MAX_LINE,archReporte);
    archReporte<<setw(4)<<' '<<"TOTAL DE ALUMNOS REGISTRADOS:"
            <<setw(3)<<contAlumnos<<endl;
    imprimeLinea('*',MAX_LINE,archReporte);
}

void leeImprimeAlumno(int &contAlumnos,ifstream &archAlumnos,ofstream &archReporte){
    int cod_alumno,anio_ingreso,cod_facultad;
    char c;
    archAlumnos>>cod_alumno;
    if(archAlumnos.eof())return;
    archAlumnos>>c>>anio_ingreso>>c>>cod_facultad;
    contAlumnos++;
    imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<setfill('0')<<setw(2)<<contAlumnos<<')'<<setfill(' ');
    archReporte<<setw(5)<<' '<<"Alumno: "<<cod_alumno;
    archReporte<<setw(10)<<' '<<"A. de Ingreso: "<<anio_ingreso;
    archReporte<<setw(10)<<' '<<"Facultad: "<<setfill('0')<<setw(7)
            <<cod_facultad<<setfill(' ')<<endl;
    imprimeLinea('-',MAX_LINE,archReporte);
    leeImprimeCursos(cod_facultad,anio_ingreso,archAlumnos,archReporte);
    

    
}

void leeImprimeCursos(int cod_facultad,int anio_ingreso,
        ifstream &archAlumnos,ofstream &archReporte){
    
    int cod_curso, cod_cursoFac,nota,dd_eva,mm_eva,aa_eva,cont_cursos=0,
            cursos_errorCred=0,cursos_errorFecha=0,cursosMatric_facu=0,
            cursosMatric_nofacu=0,cantNotas_facu=0,sumNotas_facu=0,
            cantNotas_nofacu=0,sumNotas_nofacu=0,notasAprob_facu=0,
            notasAprob_nofacu=0,esErrorCred,esErrorFecha,cantCursos_errores=0;
    char c;
    double creditos,credAprob_facu=0,credDesaprob_facu=0,totalCred_facu=0,
            credAprob_nofacu=0,credDesaprob_nofacu=0,totalCred_nofacu=0;
    
    imprimeEncabezado(archReporte);
    while(true){
        archAlumnos>>cod_curso;
        archAlumnos>>c>>cod_cursoFac;
        archAlumnos>>creditos>>nota;
        archAlumnos>>dd_eva>>c>>mm_eva>>c>>aa_eva;
        cont_cursos++;
        imprimeCursos(cursos_errorCred,cursos_errorFecha,cont_cursos,cod_curso,
                nota,cod_facultad,cod_cursoFac,dd_eva,mm_eva,aa_eva,
                anio_ingreso,creditos,cursosMatric_facu,credAprob_facu,
                credDesaprob_facu,totalCred_facu,cursosMatric_nofacu,
                credAprob_nofacu,credDesaprob_nofacu,totalCred_nofacu,
                cantNotas_facu,sumNotas_facu,cantNotas_nofacu,sumNotas_nofacu,
                notasAprob_facu,notasAprob_nofacu,esErrorCred,esErrorFecha,
                cantCursos_errores,archReporte);  
        if(archAlumnos.get()=='\n')break;
    }
    
    imprimeResumenFacultad(cursosMatric_facu,credAprob_facu,credDesaprob_facu,
            totalCred_facu,cantNotas_facu,sumNotas_facu,notasAprob_facu,
            archReporte);
    imprimeResumnNofacultad(cursosMatric_nofacu,credAprob_nofacu,
            credDesaprob_nofacu,totalCred_nofacu,cantNotas_nofacu,
            sumNotas_nofacu,notasAprob_nofacu,archReporte);
    imprimeErrores(cantCursos_errores,cursos_errorCred,cursos_errorFecha,
            archReporte);
}

void imprimeResumenFacultad(int cursosMatric_facu,double credAprob_facu,
        double credDesaprob_facu,double totalCred_facu,int cantNotas_facu,
        int sumNotas_facu,int notasAprob_facu,ofstream &archReporte){
    archReporte<<setprecision(2);
    archReporte<<fixed;
    imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<setw(10)<<' '<<"RESUMEN:"<<endl;
    archReporte<<setw(10)<<' '<<"EN SU FACULTAD:"<<endl;
    archReporte<<setw(10)<<' '<<"Cursos matriculados:"<<setw(5)<<cursosMatric_facu;
    archReporte<<setw(15)<<' '<<"Total de creditos:"<<setw(13)<<totalCred_facu<<endl;
    archReporte<<setw(10)<<' '<<"Creditos aprobados:"<<setw(9)<<credAprob_facu;
    archReporte<<setw(12)<<' '<<"Creditos desaprobados:"<<setw(9)<<credDesaprob_facu<<endl;
    archReporte<<setw(10)<<' '<<"Creditos aprobados/matriculados:"
            <<setw(7)<<(credAprob_facu/totalCred_facu)*100<<'%'<<endl;
    imprimeLinea('-',MAX_LINE,archReporte);
    archReporte<<setw(10)<<' '<<"Promedio general:"<<setw(19)
            <<double (sumNotas_facu)/cantNotas_facu<<endl;
    archReporte<<setw(10)<<' '<<"Promedio general de aprobados:"<<setw(6)
            <<double (notasAprob_facu)/cantNotas_facu<<endl;
    imprimeLinea('-',MAX_LINE,archReporte);
}

void imprimeResumnNofacultad(int cursosMatric_nofacu,double credAprob_nofacu,
        double credDesaprob_nofacu,double totalCred_nofacu,
        int cantNotas_nofacu,int sumNotas_nofacu,int notasAprob_nofacu,
        ofstream &archReporte){
    archReporte<<setw(10)<<' '<<"RESUMEN:"<<endl;
    archReporte<<setw(10)<<' '<<"EN OTRA FACULTAD:"<<endl;
    archReporte<<setw(10)<<' '<<"Cursos matriculados:"<<setw(5)<<cursosMatric_nofacu;
    archReporte<<setw(15)<<' '<<"Total de creditos:"<<setw(13)<<totalCred_nofacu<<endl;
    archReporte<<setw(10)<<' '<<"Creditos aprobados:"<<setw(9)<<credAprob_nofacu;
    archReporte<<setw(12)<<' '<<"Creditos desaprobados:"<<setw(9)<<credDesaprob_nofacu<<endl;
    archReporte<<setw(10)<<' '<<"Creditos aprobados/matriculados:"
            <<setw(7)<<(credAprob_nofacu/totalCred_nofacu)*100<<'%'<<endl;
    imprimeLinea('-',MAX_LINE,archReporte);
    archReporte<<setw(10)<<' '<<"Promedio general:"<<setw(19)
            <<double (sumNotas_nofacu)/cantNotas_nofacu<<endl;
    archReporte<<setw(10)<<' '<<"Promedio general de aprobados:"<<setw(6)
            <<double (notasAprob_nofacu)/cantNotas_nofacu<<endl;
    imprimeLinea('-',MAX_LINE,archReporte);
}

void imprimeErrores(int cantCursos_errores,int cursos_errorCred,
        int cursos_errorFecha,ofstream &archReporte){
    archReporte<<setw(10)<<' '<<"Cursos con error que no fueron considerados:"
            <<setw(3)<<cantCursos_errores<<endl;
    archReporte<<setw(10)<<' '<<"Cursos con error en la fecha:"<<setw(18)
            <<cursos_errorFecha<<endl;
    archReporte<<setw(10)<<' '<<"Cursos con error en los creditos:"<<setw(14)
            <<cursos_errorCred<<endl;
}

void imprimeCursos(int &cursos_errorCred,int &cursos_errorFecha,int cont_cursos,
        int cod_curso,int nota,int cod_facultad,
        int cod_cursoFac,int dd_eva,int mm_eva,int aa_eva,
        int anio_ingreso,double creditos,int &cursosMatric_facu,
        double &credAprob_facu,double &credDesaprob_facu,double &totalCred_facu,
        int &cursosMatric_nofacu,double &credAprob_nofacu,
        double &credDesaprob_nofacu,double &totalCred_nofacu,
        int &cantNotas_facu,int &sumNotas_facu,int &cantNotas_nofacu,
        int &sumNotas_nofacu,int &notasAprob_facu,int &notasAprob_nofacu,
        int &esErrorCred,int &esErrorFecha,int &cantCursos_errores,
        ofstream &archReporte){
    esErrorCred=0,esErrorFecha=0;
    archReporte<<setprecision(2);
    archReporte<<fixed;
    archReporte<<setfill('0')<<setw(3)<<cont_cursos<<setfill(' ');
    analizaErrores(creditos,aa_eva,anio_ingreso,esErrorCred,esErrorFecha);
    if(esErrorCred or esErrorFecha){
        cursos_errorCred+=esErrorCred;
        cursos_errorFecha+=esErrorFecha;
        cantCursos_errores++;
        imprimeCursosConError(nota,cod_curso,creditos,aa_eva,mm_eva,dd_eva,
                archReporte);
    }else{
        if(cod_facultad == cod_cursoFac){
            imprimeCursosFacu(nota,cod_curso,creditos,aa_eva,mm_eva,dd_eva,
                    credDesaprob_facu,credAprob_facu,notasAprob_facu,
                    totalCred_facu,cursosMatric_facu,cantNotas_facu,
                    sumNotas_facu,archReporte);
        }else{
            imprimeCursosOtraFacu(nota,cod_curso,creditos,aa_eva,mm_eva,dd_eva,
                    credAprob_nofacu,credDesaprob_nofacu,notasAprob_nofacu,
                    totalCred_nofacu,cursosMatric_nofacu,cantNotas_nofacu,
                    sumNotas_nofacu,archReporte);
        } 
    }
}

void imprimeCursosOtraFacu(int nota,int cod_curso,double creditos,int aa_eva,
        int mm_eva,int dd_eva, double &credAprob_nofacu,double &credDesaprob_nofacu,
        int &notasAprob_nofacu,double &totalCred_nofacu,int &cursosMatric_nofacu,
        int &cantNotas_nofacu,int &sumNotas_nofacu,ofstream &archReporte){
    if(nota>=11){
        archReporte<<setw(7)<<' '<<setfill('0')<<setw(4)<<cod_curso<<setfill(' ');
        archReporte<<setw(6)<<' '<<setw(5)<<creditos;
        archReporte<<setw(14)<<' '<<setfill('0')<<setw(2)<<nota<<setfill(' ');
        archReporte<<setw(8)<<' '<<setw(4)<<aa_eva<<'/'<<setfill('0')<<setw(2)
                <<mm_eva<<'/'<<setfill('0')<<setw(2)<<dd_eva<<setfill(' ');
        archReporte<<setw(68)<<' '<<"OTRA FACULTAD"<<endl;
        credAprob_nofacu+=creditos;
        notasAprob_nofacu+=nota;
    }else{
        archReporte<<setw(70)<<' '<<setfill('0')<<setw(4)<<cod_curso<<setfill(' ');
        archReporte<<setw(6)<<' '<<setw(5)<<creditos;
        archReporte<<setw(14)<<' '<<setfill('0')<<setw(2)<<nota<<setfill(' ');
        archReporte<<setw(8)<<' '<<setw(4)<<aa_eva<<'/'<<setfill('0')<<setw(2)
                <<mm_eva<<'/'<<setfill('0')<<setw(2)<<dd_eva<<setfill(' ');
        archReporte<<setw(5)<<' '<<"OTRA FACULTAD"<<endl;
        credDesaprob_nofacu+=creditos;
    }
    totalCred_nofacu+=creditos;
    cursosMatric_nofacu++;
    cantNotas_nofacu++;
    sumNotas_nofacu+=nota;
}

void imprimeCursosFacu(int nota,int cod_curso,double creditos,int aa_eva,
        int mm_eva,int dd_eva,double &credDesaprob_facu,double &credAprob_facu,
        int &notasAprob_facu,double &totalCred_facu,int &cursosMatric_facu,
        int &cantNotas_facu,int &sumNotas_facu, ofstream &archReporte){
    if(nota>=11){
        archReporte<<setw(7)<<' '<<setfill('0')<<setw(4)<<cod_curso<<setfill(' ');
        archReporte<<setw(6)<<' '<<setw(5)<<creditos;
        archReporte<<setw(14)<<' '<<setfill('0')<<setw(2)<<nota<<setfill(' ');
        archReporte<<setw(8)<<' '<<setw(4)<<aa_eva<<'/'<<setfill('0')<<setw(2)
                <<mm_eva<<'/'<<setfill('0')<<setw(2)<<dd_eva<<setfill(' ')<<endl;
        credAprob_facu+=creditos;
        notasAprob_facu+=nota;
    }else{
        archReporte<<setw(70)<<' '<<setfill('0')<<setw(4)<<cod_curso<<setfill(' ');
        archReporte<<setw(6)<<' '<<setw(5)<<creditos;
        archReporte<<setw(14)<<' '<<setfill('0')<<setw(2)<<nota<<setfill(' ');
        archReporte<<setw(8)<<' '<<setw(4)<<aa_eva<<'/'<<setfill('0')<<setw(2)
                <<mm_eva<<'/'<<setfill('0')<<setw(2)<<dd_eva<<setfill(' ')<<endl;
        credDesaprob_facu+=creditos;
    }
    totalCred_facu+=creditos;
    cursosMatric_facu++;
    cantNotas_facu++;
    sumNotas_facu+=nota;
}

void imprimeCursosConError(int nota,int cod_curso,double creditos,int aa_eva,
        int mm_eva,int dd_eva,ofstream &archReporte){
    if(nota>=11){
        archReporte<<setw(7)<<' '<<setfill('0')<<setw(4)<<cod_curso<<setfill(' ');
        archReporte<<setw(6)<<' '<<setw(5)<<creditos;
        archReporte<<setw(14)<<' '<<setfill('0')<<setw(2)<<nota<<setfill(' ');
        archReporte<<setw(8)<<' '<<setw(4)<<aa_eva<<'/'<<setfill('0')<<setw(2)
                <<mm_eva<<'/'<<setfill('0')<<setw(2)<<dd_eva<<setfill(' ');
        archReporte<<setw(67)<<' '<<"ERROR EN DATOS"<<endl;
    }else{
        archReporte<<setw(70)<<' '<<setfill('0')<<setw(4)<<cod_curso<<setfill(' ');
        archReporte<<setw(6)<<' '<<setw(5)<<creditos;
        archReporte<<setw(14)<<' '<<setfill('0')<<setw(2)<<nota<<setfill(' ');
        archReporte<<setw(8)<<' '<<setw(4)<<aa_eva<<'/'<<setfill('0')<<setw(2)
                <<mm_eva<<'/'<<setfill('0')<<setw(2)<<dd_eva<<setfill(' ');
        archReporte<<setw(4)<<' '<<"ERROR EN DATOS"<<endl;
    }
}

void analizaErrores(double creditos,int aa_eva,int anio_ingreso,int &esErrorCred,
        int &esErrorFecha){
    if(creditos<0)esErrorCred=1;
    if(aa_eva<anio_ingreso)esErrorFecha=1;
}

void imprimeEncabezado(ofstream &archReporte){
    archReporte<<setw(20)<<' '<<"CURSOS APROBADOS"<<setw(40)<<' '
            <<"CURSOS DESAPROBADOS"<<setw(33)<<' '<<"OBSERVACION"<<endl;
    archReporte<<"No."<<setw(5)<<' '<<"CODIGO"<<setw(5)<<' '<<"CREDITOS"
            <<setw(10)<<' '<<"NOTA"<<setw(10)<<' '<<"FECHA";
    archReporte<<setw(15)<<' '<<"CODIGO"<<setw(5)<<' '<<"CREDITOS"
            <<setw(10)<<' '<<"NOTA"<<setw(10)<<' '<<"FECHA"<<endl;
    imprimeLinea('-',MAX_LINE,archReporte);
}

void imprimeLinea(char caracter,int cantidad, ofstream &archRep){
    for(int i=0;i<cantidad;i++)archRep.put(caracter);
    archRep.put('\n');
}