/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Nodo.cpp
 * Author: user
 * 
 * Created on 19 de junio de 2024, 20:05
 */
#include <iostream>
#include <iomanip>
#include <cstring>
#include <fstream>
using namespace std;
#include "Nodo.h"

Nodo::Nodo() {
    ped = nullptr;
    sig = nullptr;
}

Nodo::~Nodo() {
}

