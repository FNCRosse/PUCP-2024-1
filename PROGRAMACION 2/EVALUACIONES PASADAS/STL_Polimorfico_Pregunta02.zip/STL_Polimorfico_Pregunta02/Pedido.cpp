/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Pedido.cpp
 * Author: user
 * 
 * Created on 19 de junio de 2024, 20:04
 */
#include <iostream>
#include <iomanip>
#include <cstring>
#include <fstream>
using namespace std;
#include "Pedido.h"

Pedido::Pedido() {
    cantidad = 0;
    codigo = 0;
    dni = 0;
    fecha = 0;
    orden = 0;
    total = 0.0;
}

Pedido::~Pedido() {
}

void Pedido::SetOrden(int orden) {
    this->orden = orden;
}

int Pedido::GetOrden() const {
    return orden;
}

void Pedido::SetTotal(double total) {
    this->total = total;
}

double Pedido::GetTotal() const {
    return total;
}

void Pedido::SetFecha(int fecha) {
    this->fecha = fecha;
}

int Pedido::GetFecha() const {
    return fecha;
}

void Pedido::SetDni(int dni) {
    this->dni = dni;
}

int Pedido::GetDni() const {
    return dni;
}

void Pedido::SetCantidad(int cantidad) {
    this->cantidad = cantidad;
}

int Pedido::GetCantidad() const {
    return cantidad;
}

void Pedido::SetCodigo(int codigo) {
    this->codigo = codigo;
}

int Pedido::GetCodigo() const {
    return codigo;
}

void Pedido::lee(ifstream &arch){
    //118050,8,8,79475585,16/12/2021
    char c;
    int dd,mm,aa;
    arch>>codigo;
    if(arch.eof())return;
    arch>>c>>cantidad>>c>>total>>c>>dni>>c>>dd>>c>>mm>>c>>aa;
    fecha = aa*10000 + mm*100 + dd;
}