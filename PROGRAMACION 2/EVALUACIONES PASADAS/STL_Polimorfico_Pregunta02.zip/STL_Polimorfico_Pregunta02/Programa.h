/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Programa.h
 * Author: user
 *
 * Created on 19 de junio de 2024, 20:06
 */

#ifndef PROGRAMA_H
#define PROGRAMA_H
#include <fstream>
#include <vector>

#include "Lista.h"
#include "NProductos.h"
#include "Pedido.h"
using namespace std;

class Programa {
private:
    Lista lpedidos;
    vector<NProductos>vproductos;
    
    void insertaEnLista(class Producto*&p);
    void insertarPedLista(class Pedido*&ped);
    void ImprimeProductos(ofstream &archPed);
public:
    Programa();
    virtual ~Programa();
    void carga(const char*nombArch1,const char*nombArch2);
    void CargaProductos(ifstream &arch);
    void CargaLista(ifstream &arch);
    void muestra(const char*nombArch1,const char*nombArch2);
};

void abrirArchLeer(ifstream &arch,const char*nombArch);
void abrirArchEcribir(ofstream &arch,const char*nombArch);

#endif /* PROGRAMA_H */

