/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   NProductos.cpp
 * Author: user
 * 
 * Created on 19 de junio de 2024, 20:05
 */
#include <iostream>
#include <iomanip>
#include <cstring>
#include <fstream>
using namespace std;
#include "NProductos.h"

NProductos::NProductos() {
    prod = nullptr;
}

NProductos::NProductos(const NProductos& orig) {
    prod = orig.prod;
}

NProductos::~NProductos() {
}

void NProductos::imprime(ofstream &arch){
    prod->imprime(arch);
}