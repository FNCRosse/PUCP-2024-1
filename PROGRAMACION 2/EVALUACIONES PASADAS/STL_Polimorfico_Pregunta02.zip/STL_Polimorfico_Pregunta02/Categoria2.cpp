/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Categoria2.cpp
 * Author: user
 * 
 * Created on 19 de junio de 2024, 20:05
 */
#include <iostream>
#include <iomanip>
#include <cstring>
#include <fstream>
using namespace std;
#include "Categoria2.h"

Categoria2::Categoria2() {
    descuento = 0;
    prioridad = 0;
}

Categoria2::~Categoria2() {
}

void Categoria2::SetDescuento(int descuento) {
    this->descuento = descuento;
}

int Categoria2::GetDescuento() const {
    return descuento;
}

void Categoria2::SetPrioridad(int prioridad) {
    this->prioridad = prioridad;
}

int Categoria2::GetPrioridad() const {
    return prioridad;
}

void Categoria2::lee(ifstream &arch){
    //,0,10,
    char c;
    arch>>c>>prioridad>>c>>descuento>>c;
    Producto::lee(arch);
}

void Categoria2::imprime(ofstream &arch){
    Producto::imprime(arch);
    arch<<prioridad<<setw(40)<<descuento<<endl;
}