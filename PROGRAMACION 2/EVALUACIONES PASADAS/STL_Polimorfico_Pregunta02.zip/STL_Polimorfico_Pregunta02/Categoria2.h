/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Categoria2.h
 * Author: user
 *
 * Created on 19 de junio de 2024, 20:04
 */

#ifndef CATEGORIA2_H
#define CATEGORIA2_H
#include <fstream>

#include "Producto.h"
using namespace std;

class Categoria2 : public Producto{
private:
    int prioridad;
    int descuento;
public:
    Categoria2();
    virtual ~Categoria2();
    void SetDescuento(int descuento);
    int GetDescuento() const;
    void SetPrioridad(int prioridad);
    int GetPrioridad() const;
    void lee(ifstream &arch);
    void imprime(ofstream &arch);
};

#endif /* CATEGORIA2_H */

