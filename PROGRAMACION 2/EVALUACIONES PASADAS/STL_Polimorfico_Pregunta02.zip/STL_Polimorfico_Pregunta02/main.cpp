/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: user
 *
 * Created on 19 de junio de 2024, 20:03
 */

#include <iostream>
#include <iomanip>
using namespace std;
#include "Programa.h"

int main(int argc, char** argv) {
    class Programa prog;
    
    prog.carga("productos4.csv","pedidos4.csv");
    prog.muestra("ReporteProductos.txt","ReportePedidos.txt");
    
    return 0;
}

