/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Producto.cpp
 * Author: user
 * 
 * Created on 19 de junio de 2024, 20:04
 */
#include <iostream>
#include <iomanip>
#include <cstring>
#include <fstream>
using namespace std;
#include "Producto.h"

Producto::Producto() {
    codprod = 0;
    nombre = nullptr;
    stock = 0;
}

Producto::~Producto() {
    if(nombre!=nullptr)delete nombre;
}

void Producto::SetStock(int stock) {
    this->stock = stock;
}

int Producto::GetStock() const {
    return stock;
}

void Producto::SetNombre(char* cad) {
    if(nombre!=nullptr)delete nombre;
    nombre = new char[strlen(cad)+1];
    strcpy(nombre,cad);
}

void Producto::GetNombre(char* cad) const {
    if(nombre==nullptr)cad[0]=0;
    else strcpy(cad,nombre);
}

void Producto::SetCodprod(int codprod) {
    this->codprod = codprod;
}

int Producto::GetCodprod() const {
    return codprod;
}

void Producto::lee(ifstream &arch){
    //...412041,TORTILLAS DE MAIZ 1KG,15
    char c,nomb[50];
    arch>>codprod>>c;
    arch.getline(nomb,50,',');
    SetNombre(nomb);
    arch>>stock;
}

void Producto::imprime(ofstream &arch){
    int len=strlen(nombre);
    arch<<codprod<<setw(5)<<" "<<nombre<<setw(50-len)<<" "<<setw(4)<<stock<<
            setw(20);
}