/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Categoria3.cpp
 * Author: user
 * 
 * Created on 19 de junio de 2024, 20:05
 */
#include <iostream>
#include <iomanip>
#include <cstring>
#include <fstream>
using namespace std;
#include "Categoria3.h"

Categoria3::Categoria3() {
    descuento = 0.0;
    prioridad = 0;
}

Categoria3::~Categoria3() {
}

void Categoria3::SetDescuento(double descuento) {
    this->descuento = descuento;
}

double Categoria3::GetDescuento() const {
    return descuento;
}

void Categoria3::SetPrioridad(int prioridad) {
    this->prioridad = prioridad;
}

int Categoria3::GetPrioridad() const {
    return prioridad;
}

void Categoria3::lee(ifstream &arch){
    //,0,10,
    char c;
    arch>>c>>prioridad>>c>>descuento>>c;
    Producto::lee(arch);
}

void Categoria3::imprime(ofstream &arch){
    Producto::imprime(arch);
    arch<<prioridad<<setw(40)<<descuento<<endl;
}