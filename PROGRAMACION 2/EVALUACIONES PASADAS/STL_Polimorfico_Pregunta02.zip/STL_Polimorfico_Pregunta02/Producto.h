/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Producto.h
 * Author: user
 *
 * Created on 19 de junio de 2024, 20:04
 */

#ifndef PRODUCTO_H
#define PRODUCTO_H
#include <fstream>
using namespace std;

class Producto {
private:
    int codprod;
    char*nombre;
    int stock;
public:
    Producto();
    virtual ~Producto();
    void SetStock(int stock);
    int GetStock() const;
    void SetNombre(char* cad);
    void GetNombre(char* cad) const;
    void SetCodprod(int codprod);
    int GetCodprod() const;
    virtual void lee(ifstream &arch);
    virtual void imprime(ofstream &arch);
};

#endif /* PRODUCTO_H */

