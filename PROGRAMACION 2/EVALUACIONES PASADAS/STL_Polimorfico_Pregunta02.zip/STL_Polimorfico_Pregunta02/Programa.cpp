/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Programa.cpp
 * Author: user
 * 
 * Created on 19 de junio de 2024, 20:06
 */
#include <iostream>
#include <iomanip>
#include <cstring>
#include <fstream>
#include <vector>
using namespace std;
#include "Programa.h"
#include "Producto.h"
#include "Categoria1.h"
#include "Categoria2.h"
#include "Categoria3.h"
#include "Pedido.h"

Programa::Programa() {
}

Programa::~Programa() {
}

void Programa::carga(const char*nombArch1,const char*nombArch2){
    ifstream archProd,archPed;
    abrirArchLeer(archProd,nombArch1);
    abrirArchLeer(archPed,nombArch2);
    CargaProductos(archProd);
    CargaLista(archPed);
}

void Programa::CargaProductos(ifstream &arch){
    class Producto*p;
    int cat;
    //1,0,10,412041,TORTILLAS DE MAIZ 1KG,15
    while(true){
        arch>>cat;
        if(arch.eof())break;
        if(cat==1)
            p = new Categoria1;
        else if(cat==2)
            p = new Categoria2;
        else
            p = new Categoria3;
        p->lee(arch);
        insertaEnLista(p);
    }
}

void Programa::insertaEnLista(class Producto*&p){
    class NProductos nuevo;
    nuevo.prod = p;
    vproductos.push_back(nuevo);
}

void Programa::CargaLista(ifstream &arch){
    class Pedido*pedido;
    char c;
    //118050,8,8,79475585,16/12/2021
    while(true){
        pedido->lee(arch);
        if(arch.eof())break;
        insertarPedLista(pedido);
    }
}

void Programa::insertarPedLista(class Pedido*&pedido){
    lpedidos.insertaPed(pedido);
}

void Programa::muestra(const char*nombArch1,const char*nombArch2){
    ofstream archProd,archPed;
    abrirArchEcribir(archPed,nombArch1);
    abrirArchEcribir(archProd,nombArch2);
    ImprimeProductos(archPed);
}

void Programa::ImprimeProductos(ofstream &arch){
    arch<<setprecision(2);
    arch<<fixed;
    arch<<setw(50)<<"Programa de productos"<<endl;
    for(vector<NProductos>::iterator it=vproductos.begin();
            it<vproductos.end();it++){
        (*it).imprime(arch);
    }
}

void abrirArchLeer(ifstream &arch,const char*nombArch){
    arch.open(nombArch,ios::in);
    if(not arch.is_open()){
        cout<<"ERROR: NO se pudo abrir el archivo "<<nombArch<<endl;
        exit(1);
    }
}

void abrirArchEcribir(ofstream &arch,const char*nombArch){
    arch.open(nombArch,ios::out);
    if(not arch.is_open()){
        cout<<"ERROR: NO se pudo abrir el archivo "<<nombArch<<endl;
        exit(1);
    }
}