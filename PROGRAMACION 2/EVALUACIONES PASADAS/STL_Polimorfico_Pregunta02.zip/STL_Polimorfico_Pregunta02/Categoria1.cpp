/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Categoria1.cpp
 * Author: user
 * 
 * Created on 19 de junio de 2024, 20:04
 */
#include <iostream>
#include <iomanip>
#include <cstring>
#include <fstream>
using namespace std;
#include "Categoria1.h"

Categoria1::Categoria1() {
    minimo = 0;
    prioridad = 0;
}

Categoria1::~Categoria1() {
}

void Categoria1::SetMinimo(int minimo) {
    this->minimo = minimo;
}

int Categoria1::GetMinimo() const {
    return minimo;
}

void Categoria1::SetPrioridad(int prioridad) {
    this->prioridad = prioridad;
}

int Categoria1::GetPrioridad() const {
    return prioridad;
}

void Categoria1::lee(ifstream &arch){
    //,0,10,
    char c;
    arch>>c>>prioridad>>c>>minimo>>c;
    Producto::lee(arch);
}

void Categoria1::imprime(ofstream &arch){
    Producto::imprime(arch);
    arch<<prioridad<<setw(20)<<minimo<<endl;
}