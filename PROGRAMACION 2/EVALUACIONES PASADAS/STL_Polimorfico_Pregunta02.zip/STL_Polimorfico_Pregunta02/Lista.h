/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Lista.h
 * Author: user
 *
 * Created on 19 de junio de 2024, 20:05
 */

#ifndef LISTA_H
#define LISTA_H
#include <fstream>

#include "Nodo.h"
using namespace std;

class Lista {
private:
    Nodo*lini;
    Nodo*lfin;
public:
    Lista();
    virtual ~Lista();
    void insertaPed(class Pedido*&pedido);
};

#endif /* LISTA_H */

