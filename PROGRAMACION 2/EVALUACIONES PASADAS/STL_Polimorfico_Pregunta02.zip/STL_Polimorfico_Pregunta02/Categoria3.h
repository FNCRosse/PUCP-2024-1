/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Categoria3.h
 * Author: user
 *
 * Created on 19 de junio de 2024, 20:05
 */

#ifndef CATEGORIA3_H
#define CATEGORIA3_H
#include <fstream>

#include "Producto.h"
using namespace std;

class Categoria3 : public Producto{
private:
    int prioridad;
    double descuento;
public:
    Categoria3();
    virtual ~Categoria3();
    void SetDescuento(double descuento);
    double GetDescuento() const;
    void SetPrioridad(int prioridad);
    int GetPrioridad() const;
    void lee(ifstream &arch);
    void imprime(ofstream &arch);
};

#endif /* CATEGORIA3_H */

