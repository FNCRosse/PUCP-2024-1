/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.h to edit this template
 */

/* 
 * File:   Nodo.h
 * Author: user
 *
 * Created on 19 de junio de 2024, 20:05
 */

#ifndef NODO_H
#define NODO_H
#include <fstream>

#include "Pedido.h"
using namespace std;

class Nodo {
private:
    Pedido*ped;
    Nodo*sig;
public:
    Nodo();
    virtual ~Nodo();
    friend class Lista;
};

#endif /* NODO_H */

