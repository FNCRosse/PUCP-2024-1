/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Lista.cpp
 * Author: user
 * 
 * Created on 19 de junio de 2024, 20:05
 */
#include <iostream>
#include <iomanip>
#include <cstring>
#include <fstream>
using namespace std;
#include "Lista.h"

Lista::Lista() {
    lfin = nullptr;
    lini = nullptr;
}

Lista::~Lista() {
}

void Lista::insertaPed(class Pedido*&pedido){
    class Nodo*nuevo;
    nuevo = new Nodo;
    nuevo->ped = pedido;
    if(lini==nullptr){//Lista vacia
        lini = nuevo;
        lfin = nuevo;
        return;
    }
    lfin->sig = nuevo;
    lfin = nuevo;
}