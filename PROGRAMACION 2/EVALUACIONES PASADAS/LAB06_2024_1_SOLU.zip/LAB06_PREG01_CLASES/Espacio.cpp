/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Espacio.cpp
 * Author: Patricia
 * 
 * Created on May 24, 2024, 9:27 PM
 */

#include "Espacio.h"

Espacio::Espacio() {
    contenido=0;
    posX=0;
    posY=0;
}


Espacio::~Espacio() {
    
}

void Espacio::SetPosY(int posY) {
    this->posY = posY;
}

int Espacio::GetPosY() const {
    return posY;
}

void Espacio::SetPosX(int posX) {
    this->posX = posX;
}

int Espacio::GetPosX() const {
    return posX;
}

void Espacio::SetContenido(char contenido) {
    this->contenido = contenido;
}

char Espacio::GetContenido() const {
    return contenido;
}


void operator <<(ofstream &arch,const class Espacio &esp){
    if(esp.GetContenido()==0){
        arch<<"[   ]";
    }
    else arch<<"[ * ]";
}

