/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Estante.h
 * Author: Patricia
 *
 * Created on May 24, 2024, 9:29 PM
 */

#ifndef ESTANTE_H
#define ESTANTE_H
#include "Libro.h"
#include "Espacio.h"
class Estante {
private:
    char *codigo;
    int anchura;
    int altura;
    Libro libros[100];
    Espacio *espacios;
    int cantidad_libros;
    
public:
    Estante();
    virtual ~Estante();
    void SetCantidad_libros(int cantidad_libros);
    int GetCantidad_libros() const;
    void SetAltura(int altura);
    int GetAltura() const;
    void SetAnchura(int anchura);
    int GetAnchura() const;
    void SetCodigo(const char* cod);
    void GetCodigo(char *cod) const;
    void crearEspacios();
    bool operator +=(class Libro &lib);
    int GetSobrantes();
    void imprimeEspacios(ofstream &arch)const;
    void imprimeLibros(ofstream &arch)const;
};

void operator >>(ifstream &arch,class Estante &est);
void operator <<(ofstream &arch,const class Estante &est);
#endif /* ESTANTE_H */

