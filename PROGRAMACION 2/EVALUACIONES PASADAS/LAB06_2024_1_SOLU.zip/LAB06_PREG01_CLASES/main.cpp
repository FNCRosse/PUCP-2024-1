/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Patricia CANTARO
 * 20210907
 * Created on May 24, 2024, 8:59 PM
 */

#include "Biblioteca.h"
#include <fstream>
#include <iostream>
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    ifstream archLib("libros.csv",ios::in);
    if(not archLib.is_open()){
        cout<<"ERROR AL ABRIR "<<"libros.csv"<<endl;
    }
    
    ifstream archEst("estantes.csv",ios::in);
    if(not archLib.is_open()){
        cout<<"ERROR AL ABRIR "<<"estantes.csv"<<endl;
    }
    class Libro lib;
    archLib>>lib;
    class Estante est;
    archEst>>est;
    est+=lib;
    ofstream archRep("RepPrueba.txt",ios::out);
    if(not archRep.is_open()){
        cout<<"ERROR AL ABRIR "<<"RepPrueba.txt"<<endl;
    }
    archRep<<est;
    archRep<<lib;
    class Espacio esp;
    archRep<<esp;
    return 0;
}

