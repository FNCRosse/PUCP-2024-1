/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Biblioteca.h
 * Author: Patricia
 *
 * Created on May 24, 2024, 10:23 PM
 */

#ifndef BIBLIOTECA_H
#define BIBLIOTECA_H
#include "Estante.h"
#include "Libro.h"
class Biblioteca {

private:
    class Estante estantes[100];
    int cantidad_estantes;
    class Libro libros[100];
    int cantidad_libros;
            
public:
    Biblioteca();
    virtual ~Biblioteca();
    void SetCantidad_libros(int cantidad_libros);
    int GetCantidad_libros() const;
    void SetCantidad_estantes(int cantidad_estantes);
    int GetCantidad_estantes() const;
};

#endif /* BIBLIOTECA_H */

