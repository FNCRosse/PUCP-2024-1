/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Libro.h
 * Author: Patricia
 *
 * Created on May 24, 2024, 9:00 PM
 */

#ifndef LIBRO_H
#define LIBRO_H
#include <fstream>
using namespace std;
class Libro {

private:
    char *codigo;
    char *nombre;
    int ancho;
    int alto;
    bool colocado;
    
public:
    Libro();
    virtual ~Libro();
    void SetColocado(bool colocado);
    bool IsColocado() const;
    void SetAlto(int alto);
    int GetAlto() const;
    void SetAncho(int ancho);
    int GetAncho() const;
    void SetNombre(const char* nom);
    void GetNombre(char *nom) const;
    void SetCodigo(const char* cod);
    void GetCodigo(char *cod) const;
};

void operator >>(ifstream &arch,class Libro &lib);
void operator <<(ofstream &arch,const class Libro &lib);
#endif /* LIBRO_H */

