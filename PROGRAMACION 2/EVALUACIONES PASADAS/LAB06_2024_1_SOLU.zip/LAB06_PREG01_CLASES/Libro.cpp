/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Libro.cpp
 * Author: Patricia
 * 
 * Created on May 24, 2024, 9:00 PM
 */

#include "Libro.h"
#include <cstring>
#include <fstream>
#include <iomanip>
using namespace std;

Libro::Libro() {
    codigo=nullptr;
    nombre=nullptr;
    ancho=0;
    alto=0;
    colocado=false;
}

Libro::~Libro() {
    if(nombre!=nullptr) delete nombre;
    if(codigo!=nullptr) delete codigo;
}

void Libro::SetColocado(bool colocado) {
    this->colocado = colocado;
}

bool Libro::IsColocado() const {
    return colocado;
}

void Libro::SetAlto(int alto) {
    this->alto = alto;
}

int Libro::GetAlto() const {
    return alto;
}

void Libro::SetAncho(int ancho) {
    this->ancho = ancho;
}

int Libro::GetAncho() const {
    return ancho;
}

void Libro::SetNombre(const char* nom) {
    if(nombre!=nullptr) delete nombre;
    nombre=new char[strlen(nom)+1];
    strcpy(nombre,nom);
}

void Libro::GetNombre(char* nom) const {
    if(nombre==nullptr) nom[0]=0;
    else strcpy(nom,nombre);
}

void Libro::SetCodigo(const char* cod) {
    if(codigo!=nullptr) delete codigo;
    codigo=new char[strlen(cod)+1];
    strcpy(codigo,cod);
}

void Libro::GetCodigo(char* cod) const {
    if(codigo==nullptr) cod[0]=0;
    else strcpy(cod,codigo);
}

void operator >>(ifstream &arch,class Libro &lib){
    char cod[20],nom[60],c;
    int an,alt;
    arch.getline(cod,20,',');
    if(arch.eof())return;
    arch>>ws;
    arch.getline(nom,60,',');
    arch>>an>>c>>alt>>ws;
    lib.SetAlto(alt);
    lib.SetAncho(an);
    lib.SetCodigo(cod);
    lib.SetNombre(nom);
}

void operator <<(ofstream &arch,const class Libro &lib){
    char cod[20],nom[60];
    lib.GetCodigo(cod);
    lib.GetNombre(nom);
    if(lib.IsColocado()){
        arch<<left<<setw(10)<<cod<<setw(25)<<nom<<right<<setw(4)<<lib.GetAncho()
            <<setw(9)<<lib.GetAlto()<<endl;
    }
    else{
        arch<<left<<setw(10)<<cod<<setw(25)<<"NO SE PUDO COLOCAR"<<right<<setw(4)<<lib.GetAncho()
            <<setw(9)<<lib.GetAlto()<<endl;
    }
}

