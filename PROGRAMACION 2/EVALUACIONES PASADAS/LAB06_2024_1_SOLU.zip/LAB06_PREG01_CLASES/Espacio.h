/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Espacio.h
 * Author: Patricia
 *
 * Created on May 24, 2024, 9:27 PM
 */

#ifndef ESPACIO_H
#define ESPACIO_H
#include <fstream>
using namespace std;

class Espacio {

private:
    char contenido;
    int posX;
    int posY;
public:
    Espacio();
    virtual ~Espacio();
    void SetPosY(int posY);
    int GetPosY() const;
    void SetPosX(int posX);
    int GetPosX() const;
    void SetContenido(char contenido);
    char GetContenido() const;
};
void operator <<(ofstream &arch,const class Espacio &esp);

#endif /* ESPACIO_H */

