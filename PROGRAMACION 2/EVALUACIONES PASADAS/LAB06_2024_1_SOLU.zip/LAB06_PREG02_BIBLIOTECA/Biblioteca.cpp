/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Biblioteca.cpp
 * Author: Patricia
 * 
 * Created on May 24, 2024, 10:23 PM
 */

#include "Biblioteca.h"
#include <fstream>
#include <iomanip>
#include <iostream>
#define N 50
using namespace std;
Biblioteca::Biblioteca() {
    cantidad_estantes=0;
    cantidad_libros=0;
}


Biblioteca::~Biblioteca() {
    
}

void Biblioteca::SetCantidad_libros(int cantidad_libros) {
    this->cantidad_libros = cantidad_libros;
}

int Biblioteca::GetCantidad_libros() const {
    return cantidad_libros;
}

void Biblioteca::SetCantidad_estantes(int cantidad_estantes) {
    this->cantidad_estantes = cantidad_estantes;
}

int Biblioteca::GetCantidad_estantes() const {
    return cantidad_estantes;
}

void Biblioteca::cargar_libros() {
    ifstream arch("libros.csv",ios::in);
    if(not arch.is_open()){
        cout<<"ERROR AL ABRIR "<<"libros.csv"<<endl;
        exit(1);
    }
    for(int i=0;true;i++){
        arch>>libros[i];
        cantidad_libros++;
        if(arch.eof())break;
    }
}

void Biblioteca::cargar_estantes() {
    ifstream arch("estantes.csv",ios::in);
    if(not arch.is_open()){
        cout<<"ERROR AL ABRIR "<<"estantes.csv"<<endl;
        exit(1);
    }
    for(int i=0;true;i++){
        arch>>estantes[i];
        cantidad_estantes++;
        if(arch.eof())break;
    }
}

void Biblioteca::posicionar_libros() {
    for(int i=0;i<cantidad_libros; i++){
        for(int j=0; j<cantidad_estantes; j++){
            if(estantes[j]+=libros[i]) break;
        }
    }
}

int Biblioteca::imprimeLinea(ofstream& arch, int n, char c) {
    for(int i=0; i<n; i++) arch.put(c);
    arch<<endl;
}

void Biblioteca::mostrar_datos() {
    ofstream arch("ReporteFinal.txt",ios::out);
    if(not arch.is_open()){
        cout<<"ERROR AL ABRIR "<<"ReporteFinal.txt"<<endl;
        exit(1);
    }
    imprimeLinea(arch,N,'=');
    arch<<setw(5)<<" "<<"Informacion del posicionamiento de Libros"<<endl;
    arch<<setw(10)<<" "<<"en los estantes de la Biblioteca"<<endl;
    imprimeLinea(arch,N,'=');
    for(int i=0;i<cantidad_estantes; i++){
        arch<<estantes[i];
        imprimeLinea(arch,N,'-');
    }
    arch<<endl;
    imprimeLinea(arch,N,'=');
    arch<<"Informacion de todos los Libros: "<<endl;
    arch<<"Cantidad de Libros Total: "<<cantidad_libros<<endl;
    for(int i=0; i<cantidad_libros; i++){
        arch<<libros[i];
    }
    imprimeLinea(arch,N,'=');
}





