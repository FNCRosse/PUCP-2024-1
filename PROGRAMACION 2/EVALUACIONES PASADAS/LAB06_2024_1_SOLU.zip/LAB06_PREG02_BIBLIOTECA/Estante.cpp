/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Estante.cpp
 * Author: Patricia
 * 
 * Created on May 24, 2024, 9:29 PM
 */

#include "Estante.h"
#include <cstring>
#include <iomanip>
#define N 50
using namespace std;
Estante::Estante() {
    codigo=nullptr;
    anchura=0;
    altura=0;
    espacios=nullptr;
    cantidad_libros=0;
}

Estante::~Estante() {
    if(codigo!=nullptr)delete codigo;
    if(espacios!=nullptr) delete espacios;
}

void Estante::SetCantidad_libros(int cantidad_libros) {
    this->cantidad_libros = cantidad_libros;
}

int Estante::GetCantidad_libros() const {
    return cantidad_libros;
}

void Estante::SetAltura(int altura) {
    this->altura = altura;
}

int Estante::GetAltura() const {
    return altura;
}

void Estante::SetAnchura(int anchura) {
    this->anchura = anchura;
}

int Estante::GetAnchura() const {
    return anchura;
}

void Estante::SetCodigo(const char* cod) {
    if(codigo!=nullptr) delete codigo;
    codigo=new char[strlen(cod)+1];
    strcpy(codigo,cod);
}

void Estante::GetCodigo(char* cod) const {
    if(codigo==nullptr) cod[0]=0;
    else strcpy(cod,codigo);
}

void Estante::crearEspacios() {
    if(altura!=0 and anchura!=0){
        espacios=new Espacio[altura*anchura];
        for(int i=0; i<altura*anchura; i++){
            espacios[i].SetPosX(i/anchura); //seteamos las posiciones, pero todavia no determinamos si estan ocupadas o no
            espacios[i].SetPosY(i%anchura);
        }
    }

}

int Estante::GetSobrantes() {
    //se analiza la ultima fila donde esttan las bases de los llibros
    int sumaAnchLib=0;
    for(int i=0; i<cantidad_libros; i++){
        sumaAnchLib+=libros[i].GetAncho();
    }
    return anchura-sumaAnchLib;
}

bool Estante::operator+=(Libro& lib) {
    int sobrante=GetSobrantes();
    int altLib=lib.GetAlto();
    int anchLib=lib.GetAncho();
    if(sobrante>0 and anchLib<=sobrante and altLib<=altura){ //encaja
        //llenamos el estante con el libro seg
        for(int i=0, k=altura*anchura-sobrante; i<altLib;i++,k-=anchura){ //retrocedemos en cuanto al alto del libro
            for(int j=0; j<anchLib; j++){ //llenamos el numero de recuadros segun el ancho
                espacios[k+j].SetContenido('O');
            }
        }
        char nom[60],cod[20];
        lib.GetCodigo(cod);
        lib.GetNombre(nom);
        libros[cantidad_libros].SetNombre(nom);
        libros[cantidad_libros].SetAlto(lib.GetAlto());
        libros[cantidad_libros].SetAncho(lib.GetAncho());
        libros[cantidad_libros].SetCodigo(cod);
        libros[cantidad_libros].SetColocado(true);
        cantidad_libros++;
        lib.SetColocado(true);
        return true;
    }
    else return false;
}

void Estante::imprimeEspacios(ofstream& arch) const {
    for(int i=0; i<anchura*altura; i++){
        arch<<espacios[i];
        if(espacios[i].GetPosY()==anchura-1)arch<<endl;
    }
}

void Estante::imprimeLibros(ofstream& arch) const {
    arch<<left<<setw(10)<<"CODIGO"<<setw(25)<<"NOMBRE"<<setw(10)<<"ANCHO"<<"ALTO"<<endl;
    for(int i=0; i<N; i++)arch.put('.');
    arch<<endl;
    for(int i=0; i<cantidad_libros; i++){
        arch<<libros[i];
    }
}



void operator >>(ifstream &arch,class Estante &est){
    char cod[20],c;
    int an, alt;
    arch.getline(cod,20,',');
    if(arch.eof())return;
    arch>>an>>c>>alt>>ws;
    est.SetAltura(alt);
    est.SetAnchura(an);
    est.SetCodigo(cod);
    est.crearEspacios();
}

void operator <<(ofstream &arch,const class Estante &est){
    char cod[20];
    est.GetCodigo(cod);
    arch<<left<<setw(15)<<"Codigo Estante: "<<setw(10)<<
            cod<<"Cantidad de Libros: "<<setw(5)<<est.GetCantidad_libros()<<endl;
    arch<<left<<setw(20)<<"Anchura del Estante: "
            <<setw(5)<<est.GetAnchura()<<"Altura del Estante: "<<est.GetAltura()<<endl;
    for(int i=0; i<N; i++)arch.put('-');
    arch<<endl;
    est.imprimeEspacios(arch);
    arch<<endl;
    est.imprimeLibros(arch);
}

