
#ifndef TAXI_H
#define TAXI_H

class Taxi {//abstracta
protected:
    double distancia;
    double tiempo;
    double precio;
public:
    Taxi(double _dist, double _tiempo);
    virtual const char* getNombre();
    double getDistancia();
    double getTiempo();
    double getPrecio();
    virtual void calcularPrecio()=0;
    virtual ~Taxi();
};

#endif /* TAXI_H */

