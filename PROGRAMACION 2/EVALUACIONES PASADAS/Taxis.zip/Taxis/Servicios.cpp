#include <iostream>
#include <fstream>
#include "Servicios.h"
using namespace std;

Servicios::Servicios(int capacidad){
    this->capacidad=capacidad;
    this->taxis = new Taxi*[capacidad]{};
    this->numTaxis = 0;
}
void Servicios::agregarTaxi(Taxi* taxi)
{
    if(numTaxis < capacidad){
        taxis[numTaxis] = taxi;
        numTaxis++;
    }
}
void Servicios::leerArchivo(const char* nomArch){
    ifstream file(nomArch);
    if(!file.is_open()){
        cout<<"El archivo no existe\n";
        return;
    }
    char tipo;
    double distancia, tiempo;
    while(true){
        file>>tipo; file.get();
        if(file.eof()) break;
        file>>distancia;file.get();
        file>>tiempo;file.get();
        Taxi* ptr = nullptr;
        switch(tipo){
            case 'U': 
                ptr = new Uber(distancia, tiempo);
                break;
            case 'T':
                ptr = new TaxiBeat(distancia, tiempo);
                break;
            case 'C':
                ptr = new Cabify(distancia, tiempo);
                break;
            default:
                cout<<"Tipo no reconocido\n";
        }
        agregarTaxi(ptr);
    }
    file.close();
}

void Servicios::mostrarDatos(const char* nomArch){
    ofstream file(nomArch);
    if(!file.is_open()) cout<<"No se pudo abrir\n";
    for(int i=0;i<numTaxis;i++){
        file<<"Servicio "<<i+1<<endl;
        file<<"\t- Nombre de servicio:"<<taxis[i]->getNombre()<<endl;
        file<<"\t- Distancia:"<<taxis[i]->getDistancia()<<endl;
        file<<"\t- Tiempo:"<<taxis[i]->getTiempo()<<endl;
        taxis[i]->calcularPrecio();
        file<<"\t- Precio:"<<taxis[i]->getPrecio()<<endl;
    }
    file.close();
} 

Servicios::~Servicios() {
    if(taxis != nullptr){
        delete[] taxis;
    }
}

