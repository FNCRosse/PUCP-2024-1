#include <iostream>
#include <fstream>
#include "Servicios.h"
using namespace std;

int main() {
    Servicios servicios(50);
    servicios.leerArchivo("datos.csv");
    servicios.mostrarDatos("salida.txt");
    return 0;
}

