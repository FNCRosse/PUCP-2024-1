#ifndef TAXIBEAT_H
#define TAXIBEAT_H
#include "Taxi.h"

class TaxiBeat: public Taxi {
private:
    double tarifaFija;
    double tarifaKM;
    double tarifaTiempo;
public:
    TaxiBeat(double _dist, double _tiempo);
    const char* getNombre();
    void calcularPrecio();
    virtual ~TaxiBeat();
};

#endif /* TAXIBEAT_H */

