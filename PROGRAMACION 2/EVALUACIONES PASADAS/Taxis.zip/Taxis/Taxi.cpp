#include "Taxi.h"

 Taxi::Taxi(double _dist, double _tiempo){
     distancia = _dist;
     tiempo = _tiempo;
     precio = 0;
}
const char* Taxi::getNombre(){
    return "Taxi";
}

double Taxi::getDistancia(){
    return distancia;
}

double Taxi::getTiempo(){
    return tiempo;
}

double Taxi::getPrecio(){
    return precio;
}
    
Taxi::~Taxi() {
}

