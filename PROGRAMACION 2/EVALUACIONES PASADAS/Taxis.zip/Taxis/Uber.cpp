#include "Uber.h"
#include "Taxi.h"

Uber::Uber(double _dist, double _tiempo): Taxi(_dist, _tiempo){
    this->tarifaKM = 1.2;
    this->tarifaAdicional = 0.1;
}

const char* Uber::getNombre(){
    return "Uber";
}

void Uber::calcularPrecio(){
    this->precio = tarifaKM*distancia + tarifaAdicional*tiempo;
}

Uber::~Uber() {
}

