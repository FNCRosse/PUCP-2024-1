#include "TaxiBeat.h"

TaxiBeat::TaxiBeat(double _dist, double _tiempo): Taxi(_dist, _tiempo)
{
    this->tarifaFija = 2.4;
    this->tarifaKM = 1.05;
    this->tarifaTiempo = 0.34;
}

const char* TaxiBeat::getNombre(){
    return "TaxiBeat";
}
void TaxiBeat::calcularPrecio(){
    precio = tarifaFija;
    precio += tarifaKM*distancia;
    precio += tarifaTiempo*tiempo;
}
TaxiBeat::~TaxiBeat() {
}

