#ifndef SERVICIOS_H
#define SERVICIOS_H
#include "Uber.h"
#include "Cabify.h"
#include "TaxiBeat.h"

class Servicios {
private:
    Taxi** taxis;
    int capacidad;
    int numTaxis;
public:
    Servicios(int capacidad = 3);
    void agregarTaxi(Taxi* taxi);
    void leerArchivo(const char* nomArch);
    void mostrarDatos(const char* nomArch);    
    ~Servicios();
};

#endif /* SERVICIOS_H */

