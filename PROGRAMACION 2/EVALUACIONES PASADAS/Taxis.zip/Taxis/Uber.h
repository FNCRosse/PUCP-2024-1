#ifndef UBER_H
#define UBER_H
#include "Taxi.h"

class Uber: public Taxi {
private:
    double tarifaKM;
    double tarifaAdicional;
public:
    Uber(double _dist, double _tiempo);
    const char* getNombre();
    void calcularPrecio();    
    virtual ~Uber();
};

#endif /* UBER_H */

