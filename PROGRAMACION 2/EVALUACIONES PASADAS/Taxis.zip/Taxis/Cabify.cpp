#include "Cabify.h"

Cabify::Cabify(double _dist, double _tiempo) : Taxi(_dist, _tiempo) {
    this->tarifa20 = 1.65;
    this->tarifaResto = 1.10;  
}

const char* Cabify::getNombre(){
    return "Cabify";
}

void Cabify::calcularPrecio(){
    if(distancia <= 20)
        precio = tarifa20*distancia;
    else {
        precio = tarifa20*20 + tarifaResto*(distancia - 20);
    }
}

Cabify::~Cabify() {
}

