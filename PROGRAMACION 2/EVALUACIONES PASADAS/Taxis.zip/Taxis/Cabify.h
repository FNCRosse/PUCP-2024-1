#ifndef CABIFY_H
#define CABIFY_H
#include "Taxi.h"

class Cabify: public Taxi {
private:
    double tarifa20;
    double tarifaResto;
public:
    Cabify(double _dist, double _tiempo);
    const char* getNombre();
    void calcularPrecio();  
    virtual ~Cabify();
};

#endif /* CABIFY_H */

