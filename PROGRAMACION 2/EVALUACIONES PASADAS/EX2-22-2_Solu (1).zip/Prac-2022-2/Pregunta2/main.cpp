/* 
 * Proyecto:   main.cpp
 * Author: Jeremy Lopez Galindo
 *
 * Created on 3 de diciembre de 2023, 01:52 AM
 */

#include <iostream>
#include <iomanip>

#include "almacen.h"

using namespace std;

int main(int argc, char** argv) {
    almacen alma;
    alma.carga(20220701,"E. Gomez");
    alma.actualiza(20221129,"J. Lopez");
    alma.imprime();
    return 0;
}

