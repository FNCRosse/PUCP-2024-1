/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   vencido.h
 * Author: Jeremy Lopez Galindo
 *
 * Created on 3 de diciembre de 2023, 02:00 AM
 */

#ifndef VENCIDO_H
#define VENCIDO_H

#include "medicamento.h"


class vencido:public medicamento {
public:
    vencido();
    vencido(const vencido& orig);
    virtual ~vencido();
    
    void setFechaBaja(int f);
    void setInspector(const char *cad);
    int getFechaBaja()const;
    void getInspector(char *cad)const;
    
    void lee(ifstream &in,const char *cad, int fechaV);
    void imprime(ofstream &out);
    void actualiza(medicamento *otro, int fecha, const char *cad);
private:
    int fechabaja;
    char *inspector;
};

#endif /* VENCIDO_H */

