/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Arbol.h
 * Author: Jeremy Lopez Galindo
 *
 * Created on 3 de diciembre de 2023, 02:04 AM
 */

#ifndef ARBOL_H
#define ARBOL_H

#include "Nodo.h"


class Arbol {
public:
    Arbol();
//    Arbol(const Arbol& orig);
    virtual ~Arbol();
    
    void eliminarArbol();
    bool arbolVacio();
    void insertarArbol(medicamento *med);
    void imprimirArbol(ofstream &out);
    void actualizar(int fehca, const char *cad);
private:
    Nodo *raiz;
    void eliminarArbolR(Nodo *nodo);
    void insertarR(Nodo *&actual,medicamento *med);
    void imprimirR(Nodo *actual,ofstream &out);
    void actualizarR(Nodo *nodo,int fehca, const char *cad);
};

#endif /* ARBOL_H */

