/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   medicamento.h
 * Author: Jeremy Lopez Galindo
 *
 * Created on 3 de diciembre de 2023, 01:54 AM
 */

#ifndef MEDICAMENTO_H
#define MEDICAMENTO_H

#include "Librerias.h"

class medicamento {
public:
    medicamento();
    medicamento(const medicamento& orig);
    virtual ~medicamento();
    
    void setCodigo(int c);
    void setNombre(char *cad);
    void setStock(int st);
    void setFechaven(int f);
    void setEstado(int e);
    int getCodigo()const;
    void getNombre(char *cad)const;
    int getStock()const;
    int getFecha()const;
    int getEstado()const;
    
    virtual void lee(ifstream &in, const char *cad, int fechaV);
    virtual void imprime(ofstream &out);
    virtual void actualiza(medicamento *otro, int fecha, const char *cad);
private:
    int codigo;
    char *nombre;
    int stock;
    int fechavenc;
    int estado;
};

#endif /* MEDICAMENTO_H */

