/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   almacen.h
 * Author: Jeremy Lopez Galindo
 *
 * Created on 3 de diciembre de 2023, 02:05 AM
 */

#ifndef ALMACEN_H
#define ALMACEN_H

#include "Arbol.h"


class almacen {
public:
    almacen();
//    almacen(const almacen& orig);
    virtual ~almacen();
    
    void carga(int fecha, const char *cad);
    void actualiza(int fecha, const char *cad);
    void imprime();
private:
    Arbol arbolalma;
};

#endif /* ALMACEN_H */

