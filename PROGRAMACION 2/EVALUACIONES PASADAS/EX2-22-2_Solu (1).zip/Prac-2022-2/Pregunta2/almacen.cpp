/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   almacen.cpp
 * Author: Jeremy Lopez Galindo
 * 
 * Created on 3 de diciembre de 2023, 02:05 AM
 */

#include "almacen.h"
#include "activo.h"
#include "vencido.h"

almacen::almacen() {
}

//almacen::almacen(const almacen& orig) {
//}

almacen::~almacen() {
}

void almacen::carga(int fecha, const char *cad) {
    ifstream in("lotes.csv",ios::in);
    if(!in){
        cout<<"No se pudo abrir el archivo lotes"<<endl;
        exit(1);
    }
    
    int fechaLeida;
    while(true){
        medicamento *med;
        in>>fechaLeida;
        if(in.eof())break;
        if(fechaLeida > fecha)med = new activo;
        else med = new vencido;
        med->setFechaven(fechaLeida);
        med->lee(in,cad,fecha);
        cout<<med->getFecha()<<endl;
        arbolalma.insertarArbol(med);
    }    
}

void almacen::actualiza(int fecha, const char* cad) {
    arbolalma.actualizar(fecha,cad);
}

void almacen::imprime() {
    ofstream out("ReporteAlmacen.txt",ios::out);
    if(!out){
        cout<<"No se pudo abrir el archivo reporte."<<endl;
        exit(1);
    }
    out.precision(2);
    out<<fixed;
    out<<left;
    out<<setw(10)<<"CODIGO"<<setw(50)<<"NOMBRE"<<setw(15)<<"FECHA"<<setw(10)<<"STOCK"<<setw(10)<<"ESTADO"<<
            setw(20)<<"VENDEDOR/INSPECTOR"<<setw(10)<<"PRECIO/FECHA DE BAJA"<<endl;
    for(int i=0;i<140;i++)out<<"=";
    out<<endl;
    arbolalma.imprimirArbol(out);
}
