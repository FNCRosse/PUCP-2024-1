/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Nodo.cpp
 * Author: Jeremy Lopez Galindo
 * 
 * Created on 3 de diciembre de 2023, 02:02 AM
 */

#include "Nodo.h"

Nodo::Nodo() {
    der = nullptr;
    izq = nullptr;
    med = nullptr;
}

//Nodo::Nodo(const Nodo& orig) {
//}

Nodo::~Nodo() {
    if(izq)delete izq;
    if(der)delete der;
    if(med)delete med;
}

