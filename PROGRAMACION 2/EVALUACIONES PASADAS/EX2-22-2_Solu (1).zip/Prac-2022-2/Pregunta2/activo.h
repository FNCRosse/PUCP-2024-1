/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   activo.h
 * Author: Jeremy Lopez Galindo
 *
 * Created on 3 de diciembre de 2023, 01:57 AM
 */

#ifndef ACTIVO_H
#define ACTIVO_H

#include "medicamento.h"


class activo:public medicamento {
public:
    activo();
    activo(const activo& orig);
    virtual ~activo();
    
    void setPrecio(double p);
    void setVendedor(char *cad);
    double getPrecio()const;
    void getVendedor(char *cad);
    
    void lee(ifstream &in,const char *cad, int fechaV);
    void imprime(ofstream &out);
    void actualiza(medicamento *otro, int fecha, const char *cad);
private:
    double precio;
    char *vendedor;
};

#endif /* ACTIVO_H */

