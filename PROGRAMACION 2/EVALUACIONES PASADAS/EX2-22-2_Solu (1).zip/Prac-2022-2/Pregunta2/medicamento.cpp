/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   medicamento.cpp
 * Author: Jeremy Lopez Galindo
 * 
 * Created on 3 de diciembre de 2023, 01:54 AM
 */

#include "medicamento.h"

medicamento::medicamento() {
    codigo = 0;
    estado = 0;
    fechavenc = 0;
    nombre = nullptr;
    stock = 0;
}

medicamento::medicamento(const medicamento& orig) {
}

medicamento::~medicamento() {
    if(nombre)delete nombre;
}

int medicamento::getCodigo() const {
    return codigo;
}

int medicamento::getEstado() const {
    return estado;
}

int medicamento::getFecha() const {
    return fechavenc;
}

void medicamento::getNombre(char* cad) const {
    if(nombre == nullptr)cad[0] = 0;
    else strcpy(cad,nombre);
}

int medicamento::getStock() const {
    return stock;
}

void medicamento::setCodigo(int c) {
    codigo = c;
}

void medicamento::setEstado(int e) {
    estado = e;
}

void medicamento::setFechaven(int f) {
    fechavenc = f;
}

void medicamento::setNombre(char* cad) {
    if(nombre)delete nombre;
    nombre = new char[strlen(cad)+1];
    strcpy(nombre,cad);
}

void medicamento::setStock(int st) {
    stock = st;
}

void medicamento::lee(ifstream& in,const char *cad, int fechaV) {
    int cod, st,fecha, estado;
    char c, nomb[200];
    in>>c;
    if(in.eof())return;
    in>>cod>>c;
    in.getline(nomb,200,',');
    in>>st>>c;
    setCodigo(cod);
 
    setNombre(nomb);
    setStock(st);
}

void medicamento::imprime(ofstream& out) {
    char nomb[200];
    int dd, mm, aa;
    dd = getFecha()%100;
    aa = getFecha()/1000;
    mm = getFecha()/100;
    mm = mm%100;
    getNombre(nomb);
    out<<setw(10)<<getCodigo()<<setw(50)<<nomb<<setfill('0')<<setw(2)<<dd<<"/"<<setw(2)<<mm<<"/"
            <<setfill(' ')<<setw(9)<<aa<<setw(10)<<getStock()<<setw(10)<<getEstado();
}

void medicamento::actualiza(medicamento *otro, int fecha, const char* cad) {
    char nomb[200];
    otro->getNombre(nomb);
    setCodigo(otro->getCodigo());
    setFechaven(otro->getFecha());
    setStock(otro->getStock());
    setNombre(nomb);
}
