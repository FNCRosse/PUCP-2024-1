/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Nodo.h
 * Author: Jeremy Lopez Galindo
 *
 * Created on 3 de diciembre de 2023, 02:02 AM
 */

#ifndef NODO_H
#define NODO_H

#include "medicamento.h"


class Nodo {
public:
    Nodo();
//    Nodo(const Nodo& orig);
    virtual ~Nodo();
    friend class Arbol;
private:
    medicamento *med;
    Nodo *izq;
    Nodo *der;
};

#endif /* NODO_H */

