/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   vencido.cpp
 * Author: Jeremy Lopez Galindo
 * 
 * Created on 3 de diciembre de 2023, 02:00 AM
 */

#include "vencido.h"

vencido::vencido() {
    fechabaja = 0;
    inspector = nullptr;
}

vencido::vencido(const vencido& orig) {
}

vencido::~vencido() {
    if(inspector)delete inspector;
}

int vencido::getFechaBaja() const {
    return fechabaja;
}

void vencido::getInspector(char* cad) const {
    if(inspector == nullptr)cad[0] = 0;
    else strcpy(cad,inspector);
}

void vencido::setFechaBaja(int f) {
    fechabaja = f;
}

void vencido::setInspector(const char* cad) {
    if(inspector)delete inspector;
    inspector = new char[strlen(cad)+1];
    strcpy(inspector,cad);
}

void vencido::lee(ifstream& in,const char *cad, int fechaV) {
    medicamento::lee(in,cad,fechaV);
    char nomb[200];
    double prec;
    in.getline(nomb,200,',');
    in>>prec;
    setInspector(cad);
    setFechaBaja(fechaV);
}

void vencido::imprime(ofstream& out) {
    medicamento::imprime(out);
    char ins[200];
    int dd,mm,aa;
    dd = getFechaBaja()%100;
    aa = getFechaBaja()/1000;
    mm = getFechaBaja()/100;
    mm = mm%100;
    getInspector(ins);
    out<<setw(20)<<ins<<setfill('0')<<right<<setw(2)<<dd<<"/"<<setw(2)<<mm<<"/"<<left<<setfill(' ')<<setw(10)<<aa<<endl;
}

void vencido::actualiza(medicamento *otro, int fecha, const char* cad) {
    medicamento::actualiza(otro,fecha,cad);
    setEstado(0);
    setInspector(cad);
    setFechaBaja(fecha);
}
