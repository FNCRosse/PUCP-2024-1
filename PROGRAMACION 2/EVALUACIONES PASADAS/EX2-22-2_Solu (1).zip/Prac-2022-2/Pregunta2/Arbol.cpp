/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Arbol.cpp
 * Author: Jeremy Lopez Galindo
 * 
 * Created on 3 de diciembre de 2023, 02:04 AM
 */

#include "Arbol.h"
#include "activo.h"
#include "vencido.h"

Arbol::Arbol() {
    raiz = nullptr;
}

//Arbol::Arbol(const Arbol& orig) {
//}

Arbol::~Arbol() {
    eliminarArbol();
}

void Arbol::eliminarArbol() {
    
    //eliminarArbolR(raiz);
}

void Arbol::eliminarArbolR(Nodo* nodo) {
    if(nodo == nullptr)return;
    eliminarArbolR(nodo->izq);
    eliminarArbolR(nodo->der);
    delete nodo;
}

bool Arbol::arbolVacio() {
    if(raiz == nullptr)return true;
    else return false;
}

void Arbol::insertarArbol(medicamento* med) {
    if(arbolVacio()){
        Nodo *nodo;
        nodo = new Nodo;
        nodo->izq = nullptr;
        nodo->der = nullptr;
        nodo->med = med;
        raiz = nodo;
    }
    else{
        insertarR(raiz,med);
    }
}

void Arbol::insertarR(Nodo *&actual,medicamento *med) {
    if(actual == nullptr){
        actual = new Nodo;
        actual->der = nullptr;
        actual->izq = nullptr;
        actual->med = med;
        return;
    }
    if(med->getFecha() < actual->med->getFecha())insertarR(actual->izq,med);
    else insertarR(actual->der,med);
}

void Arbol::imprimirArbol(ofstream& out) {
    imprimirR(raiz,out);
}

void Arbol::imprimirR(Nodo* actual,ofstream &out) {
    if(actual != nullptr){
        imprimirR(actual->izq,out);
        actual->med->imprime(out);
        imprimirR(actual->der,out);
    }
}

void Arbol::actualizar(int fecha, const char* cad) {
    actualizarR(raiz,fecha,cad);
}

void Arbol::actualizarR(Nodo *nodo,int fecha, const char* cad) {
    if(nodo == nullptr)return;
    actualizarR(nodo->der,fecha,cad);
    if(nodo->med->getFecha() > fecha){
        medicamento *medi;
        medi = new vencido;
        medi->actualiza(nodo->med,fecha,cad);
        delete nodo->med;
        nodo->med = medi;
    }
    actualizarR(nodo->izq,fecha,cad);
}

