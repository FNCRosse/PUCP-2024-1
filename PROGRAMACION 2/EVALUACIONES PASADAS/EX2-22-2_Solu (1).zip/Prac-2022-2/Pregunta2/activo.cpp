/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   activo.cpp
 * Author: Jeremy Lopez Galindo
 * 
 * Created on 3 de diciembre de 2023, 01:57 AM
 */

#include "activo.h"

activo::activo() {
    precio = 0;
    vendedor = nullptr;
}

activo::activo(const activo& orig) {
}

activo::~activo() {
    if(vendedor)delete vendedor;
}

double activo::getPrecio() const {
    return precio;
}

void activo::getVendedor(char* cad) {
    if(vendedor == nullptr)cad[0] = 0;
    else strcpy(cad,vendedor);
}

void activo::setPrecio(double p) {
    precio = p;
}

void activo::setVendedor(char* cad) {
    if(vendedor)delete vendedor;
    vendedor = new char[strlen(cad)+1];
    strcpy(vendedor,cad);
}

void activo::lee(ifstream& in,const char *cad, int fechaV) {
    medicamento::lee(in,cad,fechaV);
    char nomb[200];
    double prec;
    in.getline(nomb,200,',');
    in>>prec;
    setEstado(1);
    setVendedor(nomb);
    setPrecio(prec);
}

void activo::imprime(ofstream& out) {
    medicamento::imprime(out);
    char vend[200];
    getVendedor(vend);
    out<<setw(20)<<vend<<setw(10)<<getPrecio()<<endl;
}

void activo::actualiza(medicamento *otro, int fecha, const char* cad) {
    //Nada porque nunca lo llamo
}
