/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Paciente_Medicina.cpp
 * Author: Jeremy Lopez Galindo
 * 
 * Created on 3 de diciembre de 2023, 12:43 AM
 */

#include "Paciente_Medicina.h"

Paciente_Medicina::Paciente_Medicina() {
    totalDeGastos = 0;
}

//Paciente_Medicina::Paciente_Medicina(const Paciente_Medicina& orig) {
//}

Paciente_Medicina::~Paciente_Medicina() {
}

double Paciente_Medicina::getTotalGastos() const {
    return totalDeGastos;
}

void Paciente_Medicina::setTotalGastos(double t) {
    totalDeGastos = t;
}

void Paciente_Medicina::totalizar(map<int, Medicina> med) {
    double total = 0, precio;
    for(list<Medicina_Cantidad>::iterator i = medicina_cantidad.begin();i!=medicina_cantidad.end();i++){
        precio = buscarPrecioMedicina(med, i->getCodigo(),i->getCantidad());
        if(precio != -1)total+=precio;
        else cout<<"No se encontro"<<endl;
    }
    setTotalGastos(total);
}

double Paciente_Medicina::buscarPrecioMedicina(map<int, Medicina> med, int cod, int cant) {
    for(int i=0; i<med.size();i++){
        if(cod == med[i].GetCodigo()){
            return (med[i].GetPrecio())*(cant);
        }
    }
    return -1;
}


void Paciente_Medicina::insertarMedicina(Medicina_Cantidad med) {
    for(list<Medicina_Cantidad>::iterator i = medicina_cantidad.begin();i!=medicina_cantidad.end();i++){
        if(med.getCodigo() == i->getCodigo()){
            i->setCantidad(i->getCantidad()+med.getCantidad());
            return;
        }
    }
    medicina_cantidad.push_back(med);
}

void Paciente_Medicina::leerPaciente(ifstream& in) {
    int dd, mm, aa, dni, misc;
    char c, nomb[200];
    in>>dd;
    if(in.eof())return;
    in>>c>>mm>>c>>aa>>c>>dni>>c;
    in.getline(nomb,20,',');
    in>>c>>c>>misc;
    paciente.SetDni(dni);
    paciente.SetFechaUltimaConsulta(dd+100*mm+10000*aa);
    paciente.SetNombre(nomb);
}

int Paciente_Medicina::getDni() {
    return paciente.GetDni();
}

void Paciente_Medicina::imprimir(ofstream& out) {
    int dd, mm, aa;
    char nomb[200];
    paciente.GetNombre(nomb);
    dd = paciente.GetFechaUltimaConsulta()%100;
    aa = paciente.GetFechaUltimaConsulta()/10000;
    mm = paciente.GetFechaUltimaConsulta()/100;
    mm = mm%100;
    out<<setw(15)<<paciente.GetDni()<<setw(50)<<nomb<<setw(20)<<getTotalGastos()<<right<<
            setfill('0')<<setw(2)<<dd<<"/"<<setw(2)<<mm<<"/"<<left<<setfill(' ')<<setw(15)<<aa<<endl;
    for(int i=0;i<120;i++)out<<"-";
    out<<endl;
    out<<setw(10)<<" "<<"Lista de medicinas:"<<endl;
    out<<setw(10)<<" "<<setw(10)<<"Codigo"<<setw(10)<<"Cantidad"<<endl;
    for(Medicina_Cantidad m: medicina_cantidad){
        out<<setw(10)<<" ";
        m.imprimeMedicina(out);
    }
}
