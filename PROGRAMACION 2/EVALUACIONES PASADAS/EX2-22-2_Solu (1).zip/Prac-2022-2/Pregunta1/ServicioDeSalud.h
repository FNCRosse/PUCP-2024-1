/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ServicioDeSalud.h
 * Author: Jeremy Lopez Galindo
 *
 * Created on 3 de diciembre de 2023, 12:45 AM
 */

#ifndef SERVICIODESALUD_H
#define SERVICIODESALUD_H

#include "Medicina.h"
#include "Paciente_Medicina.h"


class ServicioDeSalud {
public:
    ServicioDeSalud();
//    ServicioDeSalud(const ServicioDeSalud& orig);
    virtual ~ServicioDeSalud();
    
    void leerMedicinas(const char *arch);
    void imprimirMedicinas(const char *arch);
    void leerConsultas(const char* arch);
    void totalizar();
    void imprimePacientes(const char *arch);
private:
    map<int,Medicina> medicina;
    list<Paciente_Medicina> paciente_medicina;
    
    list<Paciente_Medicina>::iterator buscarPaciente(Paciente_Medicina pac);
};

#endif /* SERVICIODESALUD_H */

