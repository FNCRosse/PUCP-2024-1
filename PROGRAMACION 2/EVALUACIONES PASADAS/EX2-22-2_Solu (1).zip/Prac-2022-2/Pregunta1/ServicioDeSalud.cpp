/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   ServicioDeSalud.cpp
 * Author: Jeremy Lopez Galindo
 * 
 * Created on 3 de diciembre de 2023, 12:45 AM
 */

#include "ServicioDeSalud.h"

ServicioDeSalud::ServicioDeSalud() {
}

//ServicioDeSalud::ServicioDeSalud(const ServicioDeSalud& orig) {
//}

ServicioDeSalud::~ServicioDeSalud() {
}

void ServicioDeSalud::leerMedicinas(const char* arch) {
    ifstream in(arch,ios::in);
    if(!in){
        cout<<"No se pudo abrir ela rchivo "<<arch<<endl;
        exit(1);
    }
    
    for(int i = 0;true;i++){
        Medicina med;
        in>>med;
        if(in.eof())break;
        medicina[i] = med;
    }
}

void ServicioDeSalud::imprimirMedicinas(const char* arch) {
    ofstream out(arch,ios::out);
    if(!out){
        cout<<"No se pudo abrir el archivo "<<arch<<endl;
        exit(1);
    }
    
    out.precision(2);
    out<<fixed;
    out<<left;
    out<<setw(35)<<" "<<"REPORTE DE MEDICINAS"<<endl;
    for(int i=0;i<120;i++)out<<"=";
    out<<endl;
    out<<setw(19)<<"CODIGO"<<setw(50)<<"DESCRIPCION"<<setw(20)<<"PRECIO"<<endl;
    for(int i=0;i<120;i++)out<<"=";
    out<<endl;
    for(int i=0;i<medicina.size();i++){
        out<<medicina[i];
    }
}

void ServicioDeSalud::leerConsultas(const char* arch) {
    ifstream in(arch,ios::in);
    if(!in){
        cout<<"No se pudo abrir ela rchivo "<<arch<<endl;
        exit(1);
    }
    list<Paciente_Medicina>::iterator pos;
    while(true){
        Paciente_Medicina pac;
        Medicina_Cantidad med;
        pac.leerPaciente(in);
        if(in.eof())break;
        pos = buscarPaciente(pac);
        if(pos == paciente_medicina.end()){
            while(in.get() != '\n'){
                in>>med;
                pac.insertarMedicina(med);
            }
            paciente_medicina.push_back(pac);
        }
        else{
            while(in.get() != '\n'){
                in>>med;
                pos->insertarMedicina(med);
            }
        }
    }
}

list<Paciente_Medicina>::iterator ServicioDeSalud::buscarPaciente(Paciente_Medicina pac) {
    for(list<Paciente_Medicina>::iterator i = paciente_medicina.begin();i!=paciente_medicina.end();i++){
        if(pac.getDni() == i->getDni())return i;
    }
    return paciente_medicina.end();
}

void ServicioDeSalud::totalizar() {
    for(list<Paciente_Medicina>::iterator i = paciente_medicina.begin();i!=paciente_medicina.end();i++){
        i->totalizar(medicina);
    }
}

void ServicioDeSalud::imprimePacientes(const char* arch) {
    ofstream out(arch,ios::out);
    if(!out){
        cout<<"No se pudo abrir el archivo "<<arch<<endl;
        exit(1);
    }
    
    out.precision(2);
    out<<fixed;
    out<<left;
    out<<setw(35)<<" "<<"REPORTE DE PACIENTES"<<endl;
    for(int i=0;i<120;i++)out<<"=";
    out<<endl;
    out<<setw(15)<<"DNI"<<setw(50)<<"NOMBRE"<<setw(20)<<"TOTAL GASTOS"<<setw(20)<<"FECHA ULT. CONSULTA"<<endl;
    for(int i=0;i<120;i++)out<<"=";
    out<<endl;
    for(Paciente_Medicina p:paciente_medicina){
        p.imprimir(out);
        for(int i=0;i<120;i++)out<<"=";
        out<<endl;
    }
}
