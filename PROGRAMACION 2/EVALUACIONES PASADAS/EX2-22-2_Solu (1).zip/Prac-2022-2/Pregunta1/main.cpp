/* 
 * Proyecto:   main.cpp
 * Author: Jeremy Lopez Galindo
 *
 * Created on 3 de diciembre de 2023, 12:38 AM
 */

#include <iostream>
#include <iomanip>

#include "ServicioDeSalud.h"

using namespace std;

int main(int argc, char** argv) {
    ServicioDeSalud servicioDeSalud;
    servicioDeSalud.leerMedicinas("Medicinas-Preg01.csv");
    servicioDeSalud.imprimirMedicinas("PruebaMedicinas.txt");
    servicioDeSalud.leerConsultas("Consultas-Preg01.csv");
    servicioDeSalud.imprimePacientes("PruebaConsultas.txt");
    servicioDeSalud.totalizar();
    servicioDeSalud.imprimePacientes("PruebaConsultasTotal.txt");
    return 0;
}

