
/* 
 * File:   Librerias.h
 * Author: Jeremy Lopez Galindo
 *
 * Created on 3 de diciembre de 2023, 12:38 AM
 */

#ifndef LIBRERIAS_H
#define LIBRERIAS_H

#include <iostream>
#include <fstream>
#include <cstring>
#include <iomanip>
#include <vector>
#include <list>
#include <map>
#include <iterator>
#include <algorithm>
using namespace std;

#endif /* LIBRERIAS_H */

