/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Medicina_Cantidad.h
 * Author: Jeremy Lopez Galindo
 *
 * Created on 3 de diciembre de 2023, 12:41 AM
 */

#ifndef MEDICINA_CANTIDAD_H
#define MEDICINA_CANTIDAD_H

#include "Librerias.h"

class Medicina_Cantidad {
public:
    Medicina_Cantidad();
    Medicina_Cantidad(const Medicina_Cantidad& orig);
    virtual ~Medicina_Cantidad();
    
    void operator=(const Medicina_Cantidad &med);
    void setCodigo(int c);
    void setCantidad(int c);
    int getCodigo()const;
    int getCantidad()const;
    
    void imprimeMedicina(ofstream &out);
private:
    int codigo;
    int cantidad;
};
void operator>>(ifstream &in, Medicina_Cantidad &med);

#endif /* MEDICINA_CANTIDAD_H */

