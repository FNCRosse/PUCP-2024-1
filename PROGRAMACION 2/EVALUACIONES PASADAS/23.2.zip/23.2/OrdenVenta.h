/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <iomanip>
#include "Pedido.h"
/* 
 * File:   OrdenVenta.h
 * Author: Axel Mestanza
 *
 * Created on 28 de mayo de 2024, 14:27
 */

#ifndef ORDENVENTA_H
#define ORDENVENTA_H

class OrdenVenta {
private:
    Pedido *ptr_orden;
public:
    OrdenVenta();
    OrdenVenta(const OrdenVenta& orig);
    virtual ~OrdenVenta();
    void InicializarPrioridadAlta();
    void InicializarPrioridadMedia();
    void InicializarPrioridadBaja();


};

#endif /* ORDENVENTA_H */

