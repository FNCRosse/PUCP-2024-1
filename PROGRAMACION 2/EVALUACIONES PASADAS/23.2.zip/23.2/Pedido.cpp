/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
/* 
 * File:   Pedido.cpp
 * Author: Axel Mestanza
 * 
 * Created on 28 de mayo de 2024, 13:30
 */

#include "Pedido.h"

Pedido::Pedido() {
    codigo=nullptr;
    dni_cliente=0;
    subtotal=0;
    fecha=0;
    estado=nullptr;
    total=0;
}

Pedido::Pedido(const Pedido& orig) {
}

Pedido::~Pedido() {
}

void Pedido::SetTotal(double total) {
    this->total = total;
}

double Pedido::GetTotal() const {
    return total;
}

void Pedido::SetEstado(char* cadena) {
    if(estado!=nullptr)delete estado;
    estado=new char [strlen(cadena)+1];
    strcpy(estado,cadena);
}

void Pedido::GetEstado(char *cadena) const {
    if(estado!=nullptr)strcpy(cadena,estado);
}

void Pedido::SetFecha(int fecha) {
    this->fecha = fecha;
}

int Pedido::GetFecha() const {
    return fecha;
}

void Pedido::SetSubtotal(double subtotal) {
    this->subtotal = subtotal;
}

double Pedido::GetSubtotal() const {
    return subtotal;
}

void Pedido::SetDni_cliente(int dni_cliente) {
    this->dni_cliente = dni_cliente;
}

int Pedido::GetDni_cliente() const {
    return dni_cliente;
}

void Pedido::SetCodigo(char* cadena) {
    if(codigo!=nullptr)delete codigo;
    codigo=new char [strlen(cadena)+1];
    strcpy(codigo,cadena);
}

void Pedido::GetCodigo(char *cadena) const {
     if(codigo!=nullptr)strcpy(cadena,codigo);
}

