/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <iomanip>
/* 
 * File:   PrioridadBaja.cpp
 * Author: Axel Mestanza
 * 
 * Created on 28 de mayo de 2024, 14:20
 */

#include "PrioridadBaja.h"

PrioridadBaja::PrioridadBaja() :Pedido::Pedido(){
    dias_espera=0;
    nueva_fecha_entrega=0;
}

PrioridadBaja::PrioridadBaja(const PrioridadBaja& orig) {
}

PrioridadBaja::~PrioridadBaja() {
}

void PrioridadBaja::SetNueva_fecha_entrega(int nueva_fecha_entrega) {
    this->nueva_fecha_entrega = nueva_fecha_entrega;
}

int PrioridadBaja::GetNueva_fecha_entrega() const {
    return nueva_fecha_entrega;
}

void PrioridadBaja::SetDias_espera(int dias_espera) {
    this->dias_espera = dias_espera;
}

int PrioridadBaja::GetDias_espera() const {
    return dias_espera;
}

