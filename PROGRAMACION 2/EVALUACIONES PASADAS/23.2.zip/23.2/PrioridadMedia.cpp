/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
/* 
 * File:   PrioridadMedia.cpp
 * Author: Axel Mestanza
 * 
 * Created on 28 de mayo de 2024, 14:13
 */

#include "PrioridadMedia.h"

PrioridadMedia::PrioridadMedia(): Pedido::Pedido() {
    descripccion=nullptr;
    nueva_fecha_entrega=0;
}

PrioridadMedia::PrioridadMedia(const PrioridadMedia& orig) {
}

PrioridadMedia::~PrioridadMedia() {
    delete descripccion;
}

void PrioridadMedia::SetNueva_fecha_entrega(int nueva_fecha_entrega) {
    this->nueva_fecha_entrega = nueva_fecha_entrega;
}

int PrioridadMedia::GetNueva_fecha_entrega() const {
    return nueva_fecha_entrega;
}

void PrioridadMedia::SetDescripccion(char* cadena) {
    if(descripccion!=nullptr)delete descripccion;
    descripccion=new char [strlen(cadena)+1];
    strcpy(descripccion,cadena);
}

void PrioridadMedia::GetDescripccion(char*cadena) const {
    if(descripccion!=nullptr)strcpy(cadena,descripccion);
}

