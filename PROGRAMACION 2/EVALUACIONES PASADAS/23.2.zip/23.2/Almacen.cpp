/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <iomanip>
/* 
 * File:   Almacen.cpp
 * Author: Axel Mestanza
 * 
 * Created on 28 de mayo de 2024, 14:29
 */
#include "OrdenVenta.h"
#include "Pedido.h"
#include "PrioridadAlta.h"
#include "PrioridadBaja.h"
#include "PrioridadMedia.h"
#include "Almacen.h"

Almacen::Almacen() {
    cantidad_ordenes=0;
}

Almacen::Almacen(const Almacen& orig) {
}

Almacen::~Almacen() {
}

void Almacen::SetCantidad_ordenes(int cantidad_ordenes) {
    this->cantidad_ordenes = cantidad_ordenes;
}

int Almacen::GetCantidad_ordenes() const {
    return cantidad_ordenes;
}

void Almacen::cargar_pedidos(){
    ifstream arch("Pedidos.csv",ios::in);
    if(!arch){
        cout<<"Error en la apertura del archivo Pedidos.csv"<<endl;
        exit(1);
    }
    char tipo,*codigoPed;
    int codigoCliente,subtotal,fecha,dia,mes,anio,ultimaVariable;
    
    while(1){
        arch>>tipo;
        if(arch.eof())break;
        switch(tipo){
            
            case 'A':
                arch.get();
                
                ordenes[cantidad_ordenes].InicializarPrioridadAlta();
                
                
                break;
            case 'B':
                
                // ordenes[cantidad_ordenes].InicializarPrioridadAlta();
      
                break;
            case 'C':
                 //ordenes[cantidad_ordenes].InicializarPrioridadAlta();     
                break;
        }
        cantidad_ordenes++;
    }
    
    
    
}
