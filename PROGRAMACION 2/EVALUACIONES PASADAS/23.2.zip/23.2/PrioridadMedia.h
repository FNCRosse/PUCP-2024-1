/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <iomanip>

#include "Pedido.h"
/* 
 * File:   PrioridadMedia.h
 * Author: Axel Mestanza
 *
 * Created on 28 de mayo de 2024, 14:13
 */

#ifndef PRIORIDADMEDIA_H
#define PRIORIDADMEDIA_H

class PrioridadMedia :public Pedido{
private:
    char *descripccion;
    int nueva_fecha_entrega;
public:
    PrioridadMedia();
    PrioridadMedia(const PrioridadMedia& orig);
    ~PrioridadMedia() override;
    void SetNueva_fecha_entrega(int nueva_fecha_entrega);
    int GetNueva_fecha_entrega() const;
    void SetDescripccion(char* descripccion);
    void GetDescripccion(char *) const;
};

#endif /* PRIORIDADMEDIA_H */

