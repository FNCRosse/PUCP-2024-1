/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Axel Mestanza
 * Proyecto: main.cpp
 * Created on 28 de mayo de 2024, 13:25
 */

#include <cstdlib>
#include <iostream>
#include <fstream>
#include <iomanip>
#include "Pedido.h"
#include "PrioridadAlta.h"
#include "PrioridadMedia.h"
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    return 0;
}

