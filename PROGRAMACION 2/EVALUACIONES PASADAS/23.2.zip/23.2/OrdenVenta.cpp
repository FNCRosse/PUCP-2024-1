/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <iomanip>
/* 
 * File:   OrdenVenta.cpp
 * Author: Axel Mestanza
 * 
 * Created on 28 de mayo de 2024, 14:27
 */

#include "OrdenVenta.h"
#include "Pedido.h"
#include "PrioridadAlta.h"
#include "PrioridadMedia.h"
#include "PrioridadBaja.h"

OrdenVenta::OrdenVenta() {
    ptr_orden=nullptr;
}

OrdenVenta::OrdenVenta(const OrdenVenta& orig) {
}
void OrdenVenta::InicializarPrioridadAlta(){
    ptr_orden=new PrioridadAlta();  
    
    
    
    
}
void OrdenVenta::InicializarPrioridadMedia(){
    ptr_orden=new PrioridadMedia();   
}
void OrdenVenta::InicializarPrioridadBaja(){
    ptr_orden=new PrioridadBaja();   
}
OrdenVenta::~OrdenVenta() {
    delete ptr_orden;
}

