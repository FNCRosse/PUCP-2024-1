/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <iomanip>
/* 
 * File:   Almacen.h
 * Author: Axel Mestanza
 *
 * Created on 28 de mayo de 2024, 14:29
 */
#include "OrdenVenta.h"
#include "Pedido.h"
using namespace std;
#ifndef ALMACEN_H
#define ALMACEN_H

class Almacen {
private:
    OrdenVenta ordenes[200];
    int cantidad_ordenes;
public:
    Almacen();
    Almacen(const Almacen& orig);
    virtual ~Almacen();
    void SetCantidad_ordenes(int cantidad_ordenes);
    int GetCantidad_ordenes() const;
    void cargar_pedidos();
};

#endif /* ALMACEN_H */

