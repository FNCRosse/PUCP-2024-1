/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <iomanip>
/* 
 * File:   PrioridadAlta.cpp
 * Author: Axel Mestanza
 * 
 * Created on 28 de mayo de 2024, 13:37
 */

#include "PrioridadAlta.h"

PrioridadAlta::PrioridadAlta(): Pedido::Pedido() {
    recargo=0;
}

PrioridadAlta::PrioridadAlta(const PrioridadAlta& orig) {
}

PrioridadAlta::~PrioridadAlta() {
    
}
 
void PrioridadAlta::SetRecargo(double recargo) {
    this->recargo = recargo;
}

double PrioridadAlta::GetRecargo() const {
    return recargo;
}

