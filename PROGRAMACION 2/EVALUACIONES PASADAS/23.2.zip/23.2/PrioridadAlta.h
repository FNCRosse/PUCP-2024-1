/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <iomanip>

#include "Pedido.h"
/* 
 * File:   PrioridadAlta.h
 * Author: Axel Mestanza
 *
 * Created on 28 de mayo de 2024, 13:37
 */

#ifndef PRIORIDADALTA_H
#define PRIORIDADALTA_H

class PrioridadAlta : public Pedido {
private:
    double recargo;
public:
    PrioridadAlta();
    PrioridadAlta(const PrioridadAlta& orig);
   virtual ~PrioridadAlta() override;
    void SetRecargo(double recargo);
    double GetRecargo() const;

    
};

#endif /* PRIORIDADALTA_H */

