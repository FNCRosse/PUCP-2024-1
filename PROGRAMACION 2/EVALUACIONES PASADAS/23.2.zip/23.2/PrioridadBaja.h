/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <iomanip>

#include "Pedido.h"
/* 
 * File:   PrioridadBaja.h
 * Author: Axel Mestanza
 *
 * Created on 28 de mayo de 2024, 14:20
 */

#ifndef PRIORIDADBAJA_H
#define PRIORIDADBAJA_H

class PrioridadBaja : public Pedido{
private:
    int dias_espera;
    int nueva_fecha_entrega;
    
public:
    PrioridadBaja();
    PrioridadBaja(const PrioridadBaja& orig);
    virtual ~PrioridadBaja() override;
    void SetNueva_fecha_entrega(int nueva_fecha_entrega);
    int GetNueva_fecha_entrega() const;
    void SetDias_espera(int dias_espera);
    int GetDias_espera() const;


};

#endif /* PRIORIDADBAJA_H */

