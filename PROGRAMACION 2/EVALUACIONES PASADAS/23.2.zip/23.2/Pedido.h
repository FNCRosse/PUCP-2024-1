/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <iomanip>
/* 
 * File:   Pedido.h
 * Author: Axel Mestanza
 *
 * Created on 28 de mayo de 2024, 13:30
 */

#ifndef PEDIDO_H
#define PEDIDO_H

class Pedido {
private:
    char *codigo;
    int dni_cliente;
    double subtotal;
    int fecha;
    char *estado;
    double total;
public:
    Pedido();
    Pedido(const Pedido& orig);
    virtual ~Pedido();
    void SetTotal(double total);
    double GetTotal() const;
    void SetEstado(char* estado);
    void GetEstado(char *) const;
    void SetFecha(int fecha);
    int GetFecha() const;
    void SetSubtotal(double subtotal);
    double GetSubtotal() const;
    void SetDni_cliente(int dni_cliente);
    int GetDni_cliente() const;
    void SetCodigo(char* codigo);
    void GetCodigo(char *) const;
};

#endif /* PEDIDO_H */

