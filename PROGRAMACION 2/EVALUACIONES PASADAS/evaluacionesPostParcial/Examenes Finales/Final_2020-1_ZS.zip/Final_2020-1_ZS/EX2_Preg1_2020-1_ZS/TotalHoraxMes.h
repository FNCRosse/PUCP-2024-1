

/* 
 * File:   TotalHoraxMes.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 28 de junio de 2023, 06:50 PM
 */

#ifndef TOTALHORAXMES_H
#define TOTALHORAXMES_H

struct TotalHoraxMes{
    int anioTrabajado;
    int mesTrabajado;
    double totalHorasTrabajadoxMes;
};

#endif /* TOTALHORAXMES_H */

