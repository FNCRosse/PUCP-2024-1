

/* 
 * File:   StructDireccion.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 30 de junio de 2023, 09:07 AM
 */

#ifndef STRUCTDIRECCION_H
#define STRUCTDIRECCION_H

struct Direccion{
    char *codigoUsuario;
    char *direccion;
    char *distrito;
};

#endif /* STRUCTDIRECCION_H */

