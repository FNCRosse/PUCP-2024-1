

/* 
 * File:   StructProductoPedido.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 30 de junio de 2023, 09:24 AM
 */

#ifndef STRUCTPRODUCTOPEDIDO_H
#define STRUCTPRODUCTOPEDIDO_H

struct ProductoPedido{
    char *nombre;
    int cantidad;
    double precioUnitario;
};

#endif /* STRUCTPRODUCTOPEDIDO_H */

