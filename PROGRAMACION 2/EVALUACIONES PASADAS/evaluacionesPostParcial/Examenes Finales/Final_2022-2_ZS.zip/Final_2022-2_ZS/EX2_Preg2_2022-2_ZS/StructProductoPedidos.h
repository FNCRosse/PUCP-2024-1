

/* 
 * File:   StructProductoPedidos.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 26 de junio de 2023, 08:24 PM
 */

#ifndef STRUCTPRODUCTOPEDIDOS_H
#define STRUCTPRODUCTOPEDIDOS_H

struct ProductoPedido{
    char nombre[60];
    int cantidad;
    double precio;
};

#endif /* STRUCTPRODUCTOPEDIDOS_H */

