

/* 
 * File:   StructCurso.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 29 de junio de 2023, 01:28 PM
 */

#ifndef STRUCTCURSO_H
#define STRUCTCURSO_H

struct Curso{
    char *codigo;
    char *nombre;
    double creditos;
};

#endif /* STRUCTCURSO_H */

