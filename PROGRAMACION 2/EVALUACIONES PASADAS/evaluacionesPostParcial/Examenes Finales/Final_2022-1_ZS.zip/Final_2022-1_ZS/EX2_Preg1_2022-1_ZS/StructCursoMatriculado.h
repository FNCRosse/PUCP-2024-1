

/* 
 * File:   StructCursoMatriculado.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 29 de junio de 2023, 01:37 PM
 */

#ifndef STRUCTCURSOMATRICULADO_H
#define STRUCTCURSOMATRICULADO_H

struct CursoMatriculado{
    char *codigo;
    char *nombre;
    double creditos;
    int nota;
};

#endif /* STRUCTCURSOMATRICULADO_H */

