

/* 
 * File:   Cursos.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 27 de junio de 2023, 03:11 PM
 */

#ifndef CURSOS_H
#define CURSOS_H

struct Curso{
    char codigo[7];
    char nombre[50];
    double creditos;
};

#endif /* CURSOS_H */

