

/* 
 * File:   CursoMatric.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 27 de junio de 2023, 04:42 PM
 */

#ifndef CURSOMATRIC_H
#define CURSOMATRIC_H

struct CursoMatric{
    char codigo[7];
    char nombre[50];
    double creditos;
    int nota;
};

#endif /* CURSOMATRIC_H */

