

/* 
 * File:   ProductoNoProcesado.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 19 de junio de 2023, 12:17 AM
 */

#ifndef PRODUCTONOPROCESADO_H
#define PRODUCTONOPROCESADO_H

struct ProductoNoProcesado{
    int codigoFarmacia;
    char *codigoProducto;
    char *nombreProducto;
    int cantidad;
    double precio;
};

#endif /* PRODUCTONOPROCESADO_H */

