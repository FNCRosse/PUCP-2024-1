

/* 
 * File:   Productos.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 18 de junio de 2023, 09:36 PM
 */

#ifndef PRODUCTOS_H
#define PRODUCTOS_H

struct Producto{
    char *codigoProducto;
    char *nombreProducto;
    int cantidadTotalVendida;
    double recaudacion;
};

#endif /* PRODUCTOS_H */

