

/* 
 * File:   NoEntregado.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 15 de junio de 2023, 12:59 PM
 */

#ifndef NOENTREGADO_H
#define NOENTREGADO_H

struct NoEntregado{
    char *codigo;
    char *descripcion;
    int cantNoEntregada;
};

#endif /* NOENTREGADO_H */

