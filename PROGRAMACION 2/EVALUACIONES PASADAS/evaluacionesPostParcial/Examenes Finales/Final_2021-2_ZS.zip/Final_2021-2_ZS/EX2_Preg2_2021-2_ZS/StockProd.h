

/* 
 * File:   StockProd.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 15 de junio de 2023, 12:44 PM
 */

#ifndef STOCKPROD_H
#define STOCKPROD_H

struct StockProd{
    char *codigo;
    char *descripcion;
    int stock;
    double precio;
};

#endif /* STOCKPROD_H */

