

/* 
 * File:   Entregado.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 15 de junio de 2023, 12:56 PM
 */

#ifndef ENTREGADO_H
#define ENTREGADO_H

struct Entregado{
    char *codigo;
    char *descripcion;
    int cantEntregada;
    double precioUnitario;
    double subtotal;
};

#endif /* ENTREGADO_H */

