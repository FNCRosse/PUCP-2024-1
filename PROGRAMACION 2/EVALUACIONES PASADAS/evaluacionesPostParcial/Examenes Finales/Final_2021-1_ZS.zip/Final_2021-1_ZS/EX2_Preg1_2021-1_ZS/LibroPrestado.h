/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   LibroPrestado.h
 * Author: aml
 *
 * Created on 20 de junio de 2023, 04:49 PM
 */

#ifndef LIBROPRESTADO_H
#define LIBROPRESTADO_H

struct LibroPrestado{
    char codigo[8];
    int fecha;
};

#endif /* LIBROPRESTADO_H */

