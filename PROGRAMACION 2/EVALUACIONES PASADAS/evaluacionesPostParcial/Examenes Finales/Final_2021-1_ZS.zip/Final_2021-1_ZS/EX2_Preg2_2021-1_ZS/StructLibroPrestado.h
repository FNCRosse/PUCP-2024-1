

/* 
 * File:   StructLibroPrestado.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 14 de junio de 2023, 12:06 PM
 */

#ifndef STRUCTLIBROPRESTADO_H
#define STRUCTLIBROPRESTADO_H

struct LibroPrestado{
    char *codigo;
    int fecha;
};

#endif /* STRUCTLIBROPRESTADO_H */

