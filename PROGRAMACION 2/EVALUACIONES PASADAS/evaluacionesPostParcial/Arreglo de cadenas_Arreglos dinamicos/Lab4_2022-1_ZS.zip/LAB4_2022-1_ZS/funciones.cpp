

/* 
 * File:   funciones.cpp
 * Author: alguien de ahi
 *
 * Created on 27 de mayo de 2023, 11:15 AM
 */


#include <iostream>
#include <fstream>
#include <iomanip>


using namespace std;

#define MAX_CURSO 55
#define MAX_CAR 46
#define MAX_LINE 150
#define NO_ENCONTRADO -1
#include "funciones.h"


void leerAlumnos(int *arrCodAlumno,double *arrCredAprob,double *arrCredDesaprob,
        double *arrCredFaltantes,int &numAlumnos){
    
    ifstream archAlumnos("Alumnos.txt",ios::in);
    if(not archAlumnos.is_open()){
        cout<<"ERROR al abrir el archivo de alumnos"<<endl;
        exit(1);
    }
    
    int codigo_alumno;
    double creditos_aprobados,creditos_desaprobados,creditos_faltantes;
    numAlumnos=0;
    
    while(true){
        archAlumnos>>codigo_alumno;
        if(archAlumnos.eof())break;
        archAlumnos>>ws;
        while(archAlumnos.get()!=' ');
        archAlumnos>>creditos_aprobados>>creditos_desaprobados
                >>creditos_faltantes;
        arrCodAlumno[numAlumnos]=codigo_alumno;
        arrCredAprob[numAlumnos]=creditos_aprobados;
        arrCredDesaprob[numAlumnos]=creditos_desaprobados;
        arrCredFaltantes[numAlumnos]=creditos_faltantes;
        numAlumnos++;
    }
    
}

void leerCursos(int *arrCodCurso,double *arrCredCurso,int &numCursos){
    
    ifstream archCurso("Cursos.txt",ios::in);
    if(not archCurso.is_open()){
        cout<<"ERROR al abrir el archivo de alumnos"<<endl;
        exit(1);
    }
    
    int codigo_curso;
    double credito_curso;
    numCursos=0;
    while(true){
        archCurso>>codigo_curso;
        if(archCurso.eof())break;
        while(archCurso.get()!='}');
        archCurso.get();
        archCurso>>credito_curso;
        
        arrCodCurso[numCursos]=codigo_curso;
        arrCredCurso[numCursos]=credito_curso;
        numCursos++;
    }
}

void leerProcesarNotas(int *arrCodAlumno,double *arrCredAprob,
        double *arrCredDesaprob,double *arrCredFaltantes,int numAlumnos,
        int *arrCodCurso,double *arrCredCurso,int *arrCursosAprobados,
        int *arrCursosDesaprobados,double *arrPromedioPonderado,
        int *arrCantAprobados,int *arrCantDesaparobados,int numCursos){ 
    ifstream archNotas("Notas.txt",ios::in);
    if(not archNotas.is_open()){
        cout<<"ERROR al abrir el archivo de notas"<<endl;
        exit(1);
    }
    double sumaPesos,creditosTotales;
    int codCurso_evaluar,codAlumno_evaluar,nota,posCurso,posAlumno;
    while(true){
        archNotas>>codCurso_evaluar;
        if(archNotas.eof())break;
        posCurso=buscarPosicion(arrCodCurso,codCurso_evaluar,numCursos);
        if(posCurso!=NO_ENCONTRADO){
            while(true){
                archNotas>>codAlumno_evaluar;
                archNotas>>nota;
                posAlumno=buscarPosicion(arrCodAlumno,codAlumno_evaluar,numAlumnos);
                if(posAlumno!=NO_ENCONTRADO){
                    procesaAnalizaArreglos(arrCredAprob,arrCredDesaprob,
                            arrCredFaltantes,arrCredCurso,arrCursosAprobados,
                            arrCursosDesaprobados,arrPromedioPonderado,nota,
                            sumaPesos,creditosTotales,posAlumno,posCurso);
                    if(nota>10)arrCantAprobados[posCurso]++;
                    else arrCantDesaparobados[posCurso]++;
                }
                if(archNotas.get()=='\n')break;
            }
        }else while(archNotas.get()!='\n');
    }
}

void procesaAnalizaArreglos(double *arrCredAprob,double *arrCredDesaprob,
        double *arrCredFaltantes,double *arrCredCurso,int *arrCursosAprobados,
        int *arrCursosDesaprobados,double *arrPromedioPonderado,int nota,
        double &sumaPesos,double &creditosTotales,int posAlumno,int posCurso){
    
    sumaPesos+=nota*arrCredCurso[posCurso];
    creditosTotales+=arrCredCurso[posCurso];
    if(nota>10){
        arrCursosAprobados[posAlumno]++;
        arrCredAprob[posAlumno]++;
        arrCredFaltantes[posAlumno]-=arrCredCurso[posCurso];
    }else if(nota<=10){
        arrCursosDesaprobados[posAlumno]++;
        arrCredDesaprob[posAlumno]++;
    }
    arrPromedioPonderado[posAlumno]=sumaPesos/creditosTotales;
}

void ordenarArreglos(int *arrCodAlumno,int *arrCursosAprobados,
        int *arrCursosDesaprobados,double *arrCredAprob,double *arrCredDesaprob,
        double *arrCredFaltantes,double *arrPromedioPonderado,int numAlumnos){
    
    for(int i=0;i<numAlumnos-1;i++)
        for(int k=i+1;k<numAlumnos;k++){
            if(arrCursosAprobados[i]<arrCursosAprobados[k] or
                    arrCursosAprobados[i]==arrCursosAprobados[k] and 
                    arrPromedioPonderado[i]> arrPromedioPonderado[k]){
                cambiarInt(arrCodAlumno,i,k);
                cambiarInt(arrCursosAprobados,i,k);
                cambiarInt(arrCursosDesaprobados,i,k);
                cambiarDouble(arrPromedioPonderado,i,k);
                cambiarDouble(arrCredAprob,i,k);
                cambiarDouble(arrCredDesaprob,i,k);
                cambiarDouble(arrCredFaltantes,i,k);
            }
        }
}

void cambiarInt(int *arreglo, int i,int j){
    int aux;
    aux=arreglo[i];
    arreglo[i]=arreglo[j];
    arreglo[j]=aux;
}

void cambiarDouble(double *arreglo, int i,int j){
    double aux;
    aux=arreglo[i];
    arreglo[i]=arreglo[j];
    arreglo[j]=aux;
}

void emiteReporte(int *arrCodAlumno,double *arrCredAprob,
        double *arrCredDesaprob,double *arrCredFaltantes,int numAlumnos,
        int *arrCodCurso,double *arrCredCurso,int *arrCursosAprobados,
        int *arrCursosDesaprobados,double *arrPromedioPonderado,
        int *arrCantAprobados,int *arrCantDesaparobados,int numCursos){
    
    ofstream archReporte("ReportedeConsolidadoResultados.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR al abrir el archivo de ReportedeConsolidadoResultados.txt"
                <<endl;
        exit(1);
    }
    int cont_alumnos=0,contAlumnosNo_matriculados=0,contAlumnos_matriculados,
            cantAlumnosFacu=0,cantAlumnosNoFacu=0;
    archReporte<<setprecision(2);
    archReporte<<fixed;
    imprimeEncabezado(archReporte);
    for(int i=0;i<numAlumnos;i++){
        cont_alumnos++;
        archReporte<<setfill(' ')<<setw(3)<<cont_alumnos<<") "
                <<arrCodAlumno[i]<<"  ";
        buscaImprimeNombre(arrCodAlumno[i],archReporte);
        archReporte<<setw(4)<<arrCursosAprobados[i]<<setw(6)<<' '
                <<setw(5)<<arrCursosDesaprobados[i]<<setw(12)<<' ';
        if(arrCursosAprobados[i]==0 and arrCursosDesaprobados[i]==0){
            contAlumnosNo_matriculados++;
            archReporte<<"  --.--"; 
        }else archReporte<<setw(7)<<arrPromedioPonderado[i];  
        archReporte<<setw(5)<<' '<<setw(8)<<arrCredAprob[i]<<setw(5)<<' '
                <<setw(8)<<arrCredDesaprob[i]<<setw(10)<<' ';
        if(arrCredFaltantes[i]<=0){
            cantAlumnosFacu++;
            archReporte<<"SI"<<endl;
        }else {
            cantAlumnosNoFacu++;
            archReporte<<"No, faltan "<<setw(8)<<arrCredFaltantes[i]
                <<" creditos"<<endl;
        }
    }
    contAlumnos_matriculados=cont_alumnos-contAlumnosNo_matriculados;
    imprimeResumen(cantAlumnosFacu,cantAlumnosNoFacu,contAlumnos_matriculados,
            archReporte);
    emiteSegundoReporte(arrCodCurso,arrCantAprobados,arrCantDesaparobados,
            numCursos,archReporte);
}

void imprimeResumen(int cantAlumnosFacu,int cantAlumnosNoFacu,
        int contAlumnos_matriculados,ofstream &archReporte){
    imprimeLinea('-',MAX_LINE,archReporte);
    archReporte<<"Cantidad de alumnos que pasaran a facultad: "
            <<cantAlumnosFacu<<endl;
    archReporte<<"Cantidad de alumnos que no pasaran a facultad: "
            <<cantAlumnosNoFacu<<endl;
    imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<"TOTAL DE ALUMNOS MATRICULADOS EN EL CICLO: "
            <<contAlumnos_matriculados<<endl;
    imprimeLinea('=',MAX_LINE,archReporte);
}

void emiteSegundoReporte(int *arrCodCurso,int *arrCantAprobados,
        int *arrCantDesaparobados,int numCursos,ofstream &archReporte){
    archReporte<<endl;
    archReporte<<setw(50)<<' '<<"RESULTADOS POR CURSO"<<endl;
    archReporte<<setw(5)<<' '<<"CODIGO"<<setw(2)<<' '<<"NOMBRE"
            <<setw(46)<<' '<<"APROBADOS"<<setw(5)<<' '<<"DESAPROBADOS"<<endl;
    int contador_cursos=1;
    for(int i=0;i<numCursos;i++){
        
        archReporte<<setfill(' ')<<setw(3)<<contador_cursos<<") ";
        archReporte<<arrCodCurso[i]<<setw(4)<<' ';
        buscaImprimeCurso(arrCodCurso[i],archReporte);
        
        archReporte<<setw(3)<<arrCantAprobados[i]<<setw(14)<<' '
                <<arrCantDesaparobados[i]<<endl;
        contador_cursos++;
    }
    
}

void buscaImprimeCurso(int codigo_curso,ofstream &archReporte){   
    ifstream archCurso("Cursos.txt",ios::in);
    if(not archCurso.is_open()){
        cout<<"ERROR al abrir el archivo de alumnos"<<endl;
        exit(1);
    }
    int codCurso_evaluar,llave=0,tam,tamTotal=0;
    char nombre[60];
    while(true){
        archCurso>>codCurso_evaluar;
        if(archCurso.eof())break;
        if(codCurso_evaluar==codigo_curso){
            archCurso>>ws;
            archCurso.get();
            while(true){
                archCurso>>nombre;
                buscarLlave(nombre,llave);
                if(llave){
                    archReporte<<nombre;
                    tam=longitud(nombre);
                    tamTotal+=tam;
                    archReporte<<setw(MAX_CURSO-tamTotal)<<' ';
                    break;
                }
                archReporte<<nombre<<' ';
                tam=longitud(nombre)+1;
                tamTotal+=tam;
            }
        }else while(archCurso.get()!='\n');
    }
}

void buscarLlave(char *nombreCurso,int &indiceLLave){
    for(int i=0;nombreCurso[i];i++){
        if(nombreCurso[i]=='}'){
            indiceLLave=i;
            nombreCurso[i]='\0';
        }
    }
}

void buscaImprimeNombre(int codigo_alumno,ofstream &archReporte){
    
    ifstream archAlumnos("Alumnos.txt",ios::in);
    if(not archAlumnos.is_open()){
        cout<<"ERROR al abrir el archivo de alumnos"<<endl;
        exit(1);
    }
    int tam;
    int codAlumno_evaluar;
    char nombre[60],nombreModificado[60];
    while(true){
        archAlumnos>>codAlumno_evaluar;
        if(archAlumnos.eof())break;
        if(codAlumno_evaluar==codigo_alumno){
            archAlumnos>>nombre;
            modificarNombre(nombre,nombreModificado);
            pasarMinusYmayus(nombreModificado);
            archReporte<<nombreModificado;
            tam=longitud(nombreModificado);
            archReporte<<setw(MAX_CAR-tam)<<' ';
            return;
        }else while(archAlumnos.get()!='\n');
    }
}

void pasarMinusYmayus(char *nombreModificado){
    
    int primeraLetra=1;
    for(int i=0;nombreModificado[i];i++){     
        if(nombreModificado[i]!='.' and nombreModificado[i]!=' '){     
            if(nombreModificado[i]>='a' and nombreModificado[i]<='z'
                    and primeraLetra){
                nombreModificado[i]-='a'-'A';
                primeraLetra=0;
            }else if(nombreModificado[i]>='A' and nombreModificado[i]<='Z'
                    and !primeraLetra){
                nombreModificado[i]+='a'-'A';
                primeraLetra=0;
            }else primeraLetra=0;
        }else if(nombreModificado[i]=='.'){
            primeraLetra=1;
            if(nombreModificado[i-1]>='a' and nombreModificado[i-1]<='z'){
                nombreModificado[i-1]-='a'-'A';
            }
        }
    }
}

void modificarNombre(char *nombre,char *nombreModificado){
    int j=0,primerGuion=0,cantGuiones=0;
    int posPenultimoGuion=buscaPosicionGuion(nombre);
    //SuRAmi_aNniE_MARy_RAFfO_ARIaS 
    //RosA_SAntISteban_mEza
    for(int i=posPenultimoGuion+1;nombre[i];i++){
        if(nombre[i]=='_'){
            nombreModificado[j]=' ';
            nombreModificado[j+1]=nombre[i+1];
            nombreModificado[j+2]='.';
            nombreModificado[j+3]=' ';
            j+=4;
            primerGuion=1;
        }else if(!primerGuion){
            nombreModificado[j] = nombre[i];
            j++;
        }
    }
    primerGuion=0;
    for(int i=0;i<posPenultimoGuion;i++){
        if(nombre[i]=='_'){
            nombreModificado[j]=' ';
            nombreModificado[j+1]=nombre[i+1];
            nombreModificado[j+2]='.';
            nombreModificado[j+3]=' ';
            j+=3;
            primerGuion=1;
            cantGuiones++;
        }else if(i==posPenultimoGuion-1){
            if(cantGuiones==0){
                nombreModificado[j]=nombre[i];
                nombreModificado[j+1]=' ';
                nombreModificado[j+2]='\0';
                j+=3;
            }else{ 
                nombreModificado[j]=' ';
                nombreModificado[j+1]='\0';
                j+=2;
            }
        }else if(!primerGuion){
            nombreModificado[j]=nombre[i];
            j++;
        }
    }
}

int buscaPosicionGuion(char *nombre){
    
    int pos_anterior,pos_actual;
    for(int i=0;nombre[i];i++){
        if(nombre[i]=='_'){
            pos_anterior=pos_actual;
            pos_actual=i;
        }
    }
    return pos_anterior;
}

int longitud(const char *cadena){
    int nCar;
    for(nCar=0;cadena[nCar];nCar++);
    
    return nCar;
}

void imprimeEncabezado(ofstream &archReporte){
    archReporte<<setw(50)<<' '<<"INSTITUCION EDUCATIVA LIMA"<<endl;
    archReporte<<setw(52)<<' '<<"CONSOLIDADO DE ALUMNOS"<<endl;
    imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<setw(5)<<' '<<"CODIGO"<<setw(4)<<' '<<"NOMBRE"
            <<setw(40)<<' '<<"CURSOS"<<setw(5)<<' '<<"CURSOS"<<setw(10)
            <<' '<<"PROMEDIO"<<setw(4)<<' '<<"CREDITOS"<<setw(4)<<' '
            <<"CREDITOS"<<setw(10)<<' '<<"PASA A FACULTAD"<<endl;
    archReporte<<setw(61)<<' '<<"APROBADOS"<<setw(2)<<' '<<"DESAPROBADOS"
            <<setw(4)<<' '<<"PONDERADO"<<setw(3)<<' '<<"APROBADOS"
            <<setw(3)<<' '<<"DESAPROBADOS"<<endl;
    imprimeLinea('-',MAX_LINE,archReporte);
}

int buscarPosicion(int *arreglo,int elemento,int numDatos){
    
    for(int i=0;i<numDatos;i++)
        if(arreglo[i]==elemento)return i;
    
    return NO_ENCONTRADO;
}

void imprimeLinea(char caracter, int cantidad, ofstream &archRep){
    for(int i=0;i<cantidad;i++)archRep<<caracter;
    archRep<<endl;
}