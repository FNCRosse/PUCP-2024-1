

/* 
 * File:   main.cpp
 * Author: alguien de ahi 
 *
 * Created on 27 de mayo de 2023, 11:11 AM
 */

#include <iostream>
#include <fstream>
#include <iomanip>


using namespace std;

#define MAX_CURSOS 50
#define MAX_ALUMNOS 100

#include "funciones.h"
/*
 * 
 */
int main(int argc, char** argv) {
    
    int arrCodCurso[MAX_CURSOS],arrCantDesaparobados[MAX_CURSOS]{},
            arrCantAprobados[MAX_CURSOS]{},numCursos;
    double arrCredCurso[MAX_CURSOS];
    
    int arrCodAlumno[MAX_ALUMNOS],arrCursosAprobados[MAX_ALUMNOS]{},
            arrCursosDesaprobados[MAX_ALUMNOS]{},numAlumnos;
    double arrCredAprob[MAX_ALUMNOS],arrCredDesaprob[MAX_ALUMNOS],
            arrCredFaltantes[MAX_ALUMNOS],arrPromedioPonderado[MAX_ALUMNOS]{};
    
   
    leerAlumnos(arrCodAlumno,arrCredAprob,arrCredDesaprob,arrCredFaltantes,
            numAlumnos);
    leerCursos(arrCodCurso,arrCredCurso,numCursos);
    leerProcesarNotas(arrCodAlumno,arrCredAprob,arrCredDesaprob,arrCredFaltantes,
            numAlumnos,arrCodCurso,arrCredCurso,arrCursosAprobados,
            arrCursosDesaprobados,arrPromedioPonderado,arrCantAprobados,
            arrCantDesaparobados,numCursos);
    ordenarArreglos(arrCodAlumno,arrCursosAprobados,arrCursosDesaprobados,
            arrCredAprob,arrCredDesaprob,arrCredFaltantes,arrPromedioPonderado,
            numAlumnos);
    emiteReporte(arrCodAlumno,arrCredAprob,arrCredDesaprob,arrCredFaltantes,
            numAlumnos,arrCodCurso,arrCredCurso,arrCursosAprobados,
            arrCursosDesaprobados,arrPromedioPonderado,arrCantAprobados,
            arrCantDesaparobados,numCursos);
    
    return 0;
}

