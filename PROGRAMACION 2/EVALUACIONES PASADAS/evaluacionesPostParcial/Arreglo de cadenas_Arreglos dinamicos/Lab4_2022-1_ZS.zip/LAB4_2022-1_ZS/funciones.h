

/* 
 * File:   funciones.h
 * Author: alguien de ahi
 *
 * Created on 27 de mayo de 2023, 11:15 AM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void leerAlumnos(int *arrCodAlumno,double *arrCredAprob,double *arrCredDesaprob,
        double *arrCredFaltantes,int &numAlumnos);
void leerCursos(int* arrCodCurso, double* arrCredCurso, int& numCursos);
void leerProcesarNotas(int* arrCodAlumno, double* arrCredAprob, 
        double* arrCredDesaprob, double* arrCredFaltantes, int numAlumnos, 
        int* arrCodCurso, double* arrCredCurso, int* arrCursosAprobados, 
        int* arrCursosDesaprobados, double* arrPromedioPonderado, 
        int* arrCantAprobados, int* arrCantDesaparobados, int numCursos);
void procesaAnalizaArreglos(double *arrCredAprob,
        double *arrCredDesaprob,double *arrCredFaltantes,
        double *arrCredCurso,int *arrCursosAprobados,
        int *arrCursosDesaprobados,double *arrPromedioPonderado,
        int nota,double &sumaPesos,double &creditosTotales,int posAlumno,
        int posCurso);
void ordenarArreglos(int *arrCodAlumno,int *arrCursosAprobados,
        int *arrCursosDesaprobados,double *arrCredAprob,double *arrCredDesaprob,
        double *arrCredFaltantes,double *arrPromedioPonderado,int numAlumnos);
void cambiarInt(int* arreglo, int i, int j);
void cambiarDouble(double* arreglo, int i, int j);
void emiteReporte(int *arrCodAlumno,double *arrCredAprob,
        double *arrCredDesaprob,double *arrCredFaltantes,int numAlumnos,
        int *arrCodCurso,double *arrCredCurso,int *arrCursosAprobados,
        int *arrCursosDesaprobados,double *arrPromedioPonderado,
        int *arrCantAprobados,int *arrCantDesaparobados,int numCursos);
void imprimeResumen(int cantAlumnosFacu,int cantAlumnosNoFacu,
        int contAlumnos_matriculados,ofstream &archReporte);
void emiteSegundoReporte(int *arrCodCurso,int *arrCantAprobados,
        int *arrCantDesaparobados,int numCursos,ofstream &archReporte);
void buscaImprimeCurso(int codigo_curso,ofstream &archReporte);
void buscarLlave(char *nombreCurso,int &indiceLLave);

void buscaImprimeNombre(int codigo_alumno,ofstream &archReporte);
void pasarMinusYmayus(char *nombreModificado);
void modificarNombre(char *nombre,char *nombreModificado);
int buscaPosicionGuion(char *nombre);
int longitud(const char* cadena);
void imprimeEncabezado(ofstream &archReporte);
int buscarPosicion(int *arreglo,int elemento,int numDatos);
void imprimeLinea(char caracter, int cantidad, ofstream &archRep);

#endif /* FUNCIONES_H */

