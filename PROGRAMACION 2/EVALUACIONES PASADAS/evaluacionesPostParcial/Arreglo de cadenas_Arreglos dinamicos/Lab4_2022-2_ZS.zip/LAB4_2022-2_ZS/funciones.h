

/* 
 * File:   funciones.h
 * Author: alguien de ahi
 *
 * Created on 27 de mayo de 2023, 05:18 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void leerPaises(int *arrCodPais,int &numPaises);
void emiteReporte(int *arrCodPais,int numPaises);
void imprimeTransformacion2(char *pais,
        ofstream &archReporte);
void imprimeTransformacion1(char *comentario,char *comentarioModificado,
        ofstream &archReporte);
void cambiarMinus(char *comentario);
void imprimePais(int codigo_pais,char *pais,ofstream &archReporte);
void imprimeComentarios(char *comentario,ofstream &archReporte);
void imprimeEncabezado(int dia,int mes,int anio, ofstream &archReporte);
int longitud(const char*cadena);
void modificaGuionesNombre(char *comentario);
void imprimeLinea(char caracter, int cantidad, ofstream &archReporte );

#endif /* FUNCIONES_H */

