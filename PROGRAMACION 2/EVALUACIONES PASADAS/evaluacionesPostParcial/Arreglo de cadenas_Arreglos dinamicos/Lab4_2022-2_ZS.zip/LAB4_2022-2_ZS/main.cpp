

/* 
 * File:   main.cpp
 * Author: alguien de ahi
 *
 * Created on 27 de mayo de 2023, 05:18 PM
 */

#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

#define MAX_PAISES 10
#define MAX_CARAC 250
#include "funciones.h"
/*
 * 
 */
int main(int argc, char** argv) {
    
    
    int arrCodPais[MAX_PAISES],numPaises;
    leerPaises(arrCodPais,numPaises);
    
    emiteReporte(arrCodPais,numPaises);
    return 0;
}

