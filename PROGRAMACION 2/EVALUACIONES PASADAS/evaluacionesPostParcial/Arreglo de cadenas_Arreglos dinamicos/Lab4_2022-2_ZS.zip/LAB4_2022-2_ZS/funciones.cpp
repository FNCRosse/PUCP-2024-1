

/* 
 * File:   funciones.cpp
 * Author: alguien de ahi
 *
 * Created on 27 de mayo de 2023, 05:18 PM
 */


#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

#define MAX_CAR 130
#define NO_ENCONTRADO -1
#define MAX_LINE 340
#include "funciones.h"

void leerPaises(int *arrCodPais,int &numPaises){
    
    ifstream archPaises("Paises.txt",ios::in);
    if(not archPaises.is_open()){
        cout<<"ERROR al abrir el archivo de paises"<<endl;
        exit(1);
    }
    int codigo_pais;
    numPaises=0;
    
    while(true){
        archPaises>>codigo_pais;
        if(archPaises.eof())break;
        archPaises>>ws;
        while(archPaises.get()!='\n');
        arrCodPais[numPaises]=codigo_pais;
        numPaises++;
    }
}

void emiteReporte(int *arrCodPais,int numPaises){ 
    ofstream archReporte("ReportePreprocesamiento.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR al abrir el archivo de ReportePreprocesamiento"<<endl;
        exit(1);
    }
    ifstream archComentarios("Comentarios.txt",ios::in);
    if(not archComentarios.is_open()){
        cout<<"ERROR al abrir el archivo de comentarios"<<endl;
        exit(1);
    }
    char comentario[250]{},comentarioModificado[250],pais[20];
    int dia,mes,anio,codPais_evaluar,codigo_usuario,cantLikes;
    char c;
    archReporte<<setw(50)<<' '<<"@TikTok_tp"<<endl;
    imprimeLinea('=',MAX_LINE,archReporte);
    while(true){
        archComentarios>>dia;
        if(archComentarios.eof())break;
        archComentarios>>c>>mes>>c>>anio;
        imprimeEncabezado(dia,mes,anio,archReporte);
        while(true){
            archComentarios>>codPais_evaluar;
            archComentarios>>c>>codigo_usuario;
            archComentarios>>comentario;
            modificaGuionesNombre(comentario);
            imprimeComentarios(comentario,archReporte);
            archComentarios>>cantLikes;
            imprimePais(codPais_evaluar,pais,archReporte);
            cambiarMinus(comentario);
            cambiarMinus(pais);
            imprimeTransformacion1(comentario,comentarioModificado,archReporte);
            imprimeTransformacion2(pais,archReporte);
            if(archComentarios.get()=='\n')break;
        }
        imprimeLinea('=',MAX_LINE,archReporte);   
    }
}

void imprimeTransformacion2(char *pais,
        ofstream &archReporte){
    int tam;
    for(int i=0;pais[i];i++)
        pais[3]='\0';
    tam=longitud(pais);
    archReporte<<setw(8)<<pais;
    archReporte<<setw(10-tam)<<' '<<setw(7)<<tam<<endl;
}

void imprimeTransformacion1(char *comentario,char *comentarioModificado,
        ofstream &archReporte){
    int j=0,tam;
    int cantEspacios=0,posEspacio;
    for(int i=0;comentario[i];i++){
        //0123456789101112
        //im screami n g 0  
        if(comentario[i]==' ' and cantEspacios==0){
            cantEspacios++;
//            posEspacio=i;
            while(cantEspacios==1){
                i++;
                //Hasta hallar un espacio o el caracter de terminacion
                if(comentario[i]==' '){
                   comentarioModificado[j]='*';
                   cantEspacios++; 
                   j++;
                }else if(comentario[i]==0){
                    comentarioModificado[j]='*';
                    comentarioModificado[j+1]='\0';
                    cantEspacios++;
                    j+=2;
                    break;
                }
            }
        }else{
            comentarioModificado[j]=comentario[i];
            j++;
        }
    }
    comentarioModificado[j]='\0';
    tam=longitud(comentarioModificado);
    archReporte<<comentarioModificado;
    archReporte<<setw(MAX_CAR-tam)<<' '<<setw(3)<<tam<<setw(8)<<' ';
//    for(int j=0;comentarioModificado[j];j++)comentarioModificado[j]=0;
}

void cambiarMinus(char *comentario){
    for(int i=0;comentario[i];i++){
        if(comentario[i]>='A' and comentario[i]<='Z')comentario[i]+='a'-'A';
    }
}

void imprimePais(int codigo_pais,char *pais,ofstream &archReporte){
    ifstream archPaises("Paises.txt",ios::in);
    if(not archPaises.is_open()){
        cout<<"ERROR al abrir el archivo de paises"<<endl;
        exit(1);
    }
    int tam;
    int codPais_evaluar;
    while(true){
        archPaises>>codPais_evaluar;
        if(archPaises.eof())break;
        if(codPais_evaluar==codigo_pais){
            archPaises>>pais;
            archReporte<<pais;
            tam=longitud(pais);
            archReporte<<setw(20-tam)<<' '<<setw(2)<<tam<<setw(8)<<' ';
        }else while(archPaises.get()!='\n');
    }
}

void imprimeComentarios(char *comentario,ofstream &archReporte){
    
    int tam=longitud(comentario);
    archReporte<<comentario;
    archReporte<<setw(MAX_CAR-tam)<<' '<<setw(3)<<tam<<setw(8)<<' ';
}

void imprimeEncabezado(int dia,int mes,int anio, ofstream &archReporte){
    archReporte<<"Fecha del TikTok: "<<setfill('0')<<setw(2)<<dia<<'/'
            <<setw(2)<<mes<<'/'<<setw(4)<<anio<<setfill(' ')<<endl<<endl;
    archReporte<<"Comentario"<<setw(119)<<' '<<"Long"<<setw(8)<<' '
            <<"Pais"<<setw(14)<<' '<<"Long"<<setw(8)<<' '<<"Transformacion 1"
            <<setw(113)<<' '<<"Long"<<setw(8)<<' '<<"Transformacion 2"
            <<setw(4)<<' '<<"Long"<<endl;
    imprimeLinea('-',MAX_LINE,archReporte);
}

int longitud(const char*cadena){
    int nCar;
    for(nCar=0;cadena[nCar];nCar++);
    
    return nCar;
}

void modificaGuionesNombre(char *comentario){
    
    for(int i=0;comentario[i];i++)
        if(comentario[i]=='_')comentario[i]=' ';
}

void imprimeLinea(char caracter, int cantidad, ofstream &archRep){
    for(int i=0;i<cantidad;i++)archRep<<caracter;
    archRep<<endl;
}