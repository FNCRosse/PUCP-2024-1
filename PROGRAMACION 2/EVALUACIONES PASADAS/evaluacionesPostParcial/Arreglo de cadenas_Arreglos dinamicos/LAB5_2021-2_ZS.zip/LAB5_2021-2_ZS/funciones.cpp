

/* 
 * File:   funciones.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 1 de junio de 2023, 03:07 PM
 */


#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>

using namespace std;

#define MAX_LINE 150
#include "funciones.h"


void leerCursos(char **arrCodigoCursos,char **arrNombreCursos,
        double *arrCreditos,int &numCursos){
    
    ifstream archCursos("Cursos.csv",ios::in);
    if(not archCursos.is_open()){
        cout<<"ERROR al abrir el archivo de cursos"<<endl;
        exit(1);
    }
    char *codigoCurso,*nombreCurso;
    double creditos;
    numCursos=0;
    while(true){
        codigoCurso=leeCadenaExacta(archCursos);
        if(archCursos.eof())break;        
        nombreCurso=leeCadenaExacta(archCursos);        
        archCursos>>creditos;
        archCursos.get();//se usa el get() para comerse el salto de linea, si no
                         // se usa, cuando lea otro codigoCurso lo almacena con '\n'
        arrCodigoCursos[numCursos]=codigoCurso;
        arrNombreCursos[numCursos]=nombreCurso;
        arrCreditos[numCursos]=creditos;
        numCursos++;
    }  
//    for(int i=0;i<numCursos;i++)
//        cout<<arrCodigoCursos[i]<<' '<<arrNombreCursos[i]<<' '
//                <<arrCreditos[i];
}

void leerEscalas(char **arrEscalas,double *arrPrecioEscala,int &numEscalas){
    
    ifstream archEscalas("Escalas.txt",ios::in);
    if(not archEscalas.is_open()){
        cout<<"ERROR al abrir el archivo de escalas"<<endl;
        exit(1);
    }
    
    char *escala,arrEscala[30];
    double precio;
    numEscalas=0;
    while(true){
        archEscalas>>arrEscala;
        if(archEscalas.eof())break;
        escala=new char[strlen(arrEscala)+1];/*Se reserva un espacio de memoria*/
        strcpy(escala,arrEscala);
        archEscalas>>precio;
        arrEscalas[numEscalas]=escala;
        arrPrecioEscala[numEscalas]=precio;
        numEscalas++;
    }
//    for(int i=0;i<numEscalas;i++)
//        cout<<arrEscalas[i]<<' '<<arrPrecioEscala[i]<<endl;
}

void leerMatricula(char **arrCodigoCursos,char **arrNombreCursos,
        double *arrCreditos,int numCursos,char **arrEscalas,
        double *arrPrecioEscala,int numEscalas,double *arrRecaudacionCurso,
        double *arrRecaudacionEscala){   
    ifstream archMatricula("Matricula.csv",ios::in);
    if(not archMatricula.is_open()){
        cout<<"ERROR al abrir el archivo de escalas"<<endl;
        exit(1);
    }  
    int cod_alumno;
//    char nombreAlumno[50],escala[3],*nombreCurso;
    char *nombreAlu,*nombreEscala;
    char curso[7], *ptr_curso; 
    int posEscala,posCurso;
    while(true){
        archMatricula>>cod_alumno;
        if(archMatricula.eof())break;
        archMatricula.get();//come la coma
        nombreAlu=leeCadenaExacta(archMatricula);
        nombreEscala=leeCadenaExacta(archMatricula);    
        posEscala= buscarPosicion(arrEscalas,nombreEscala,numEscalas);
        if(posEscala!=-1){
            /*1,2,3,4,6,7*/
            arrRecaudacionEscala[posEscala]++; 
            while(true){
                archMatricula.get(curso,7);
                ptr_curso= new char[7];
                strcpy(ptr_curso,curso);
                posCurso=buscarPosicion(arrCodigoCursos,ptr_curso,numCursos);
                if(posCurso!=-1){
                    arrRecaudacionCurso[posCurso]+=arrCreditos[posCurso]*
                            arrPrecioEscala[posEscala];
                }
                if(archMatricula.get()=='\n')break;
            }
        }
    }
    for(int i=0;i<numEscalas;i++)
        arrRecaudacionEscala[i]=arrPrecioEscala[i]*arrRecaudacionEscala[i];
}

void ordenarEscalas(char **arrEscalas,double *arrPrecioEscala,
        double *arrRecaudacionEscala,int numEscalas){
    for(int i=0;i<numEscalas-1;i++)
        for(int k=i+1;k<numEscalas;k++)
            if(arrRecaudacionEscala[i]<arrRecaudacionEscala[k]){
                cambiarChar(arrEscalas[i],arrEscalas[k]);
                cambiarDouble(arrPrecioEscala,i,k);
                cambiarDouble(arrRecaudacionEscala,i,k);
            }
}

void ordenarCursos(char **arrCodigoCursos,char **arrNombreCursos,
        double *arrCreditos,double *arrRecaudacionCurso,int numCursos){
    char cadena1[4],cadena2[4];
    for(int i=0;i<numCursos-1;i++)
        for(int k=i+1;k<numCursos;k++){
            copiarTresCaracteres(cadena1,arrCodigoCursos[i]);
            copiarTresCaracteres(cadena2,arrCodigoCursos[k]);
            if(strcmp(cadena1,cadena2)>0 or strcmp(cadena1,cadena2)==0 and 
                    arrRecaudacionCurso[i] < arrRecaudacionCurso[k]){
                cambiarChar(arrCodigoCursos[i],arrCodigoCursos[k]);
                cambiarChar(arrNombreCursos[i],arrNombreCursos[k]);
                cambiarDouble(arrCreditos,i,k);
                cambiarDouble(arrRecaudacionCurso,i,k);
                
            }
        }
            
}

void copiarTresCaracteres(char *destino,char *&fuente){
    int i=0;
    while(true){
        destino[i] = fuente[i];
        if(i==3)break;
        i++;
    }
    destino[i]=0;
}

void cambiarChar(char *&escalaI, char *&escalaJ){
    char *aux;
    aux = escalaI;
    escalaI = escalaJ;
    escalaJ = aux;
}

void  cambiarDouble(double *arreglo,int i,int j){
    double aux;
    aux = arreglo[i];
    arreglo[i]=arreglo[j];
    arreglo[j]=aux;
}

void imprimeReporte(char **arrCodigoCursos,char **arrNombreCursos,
        double *arrCreditos,int numCursos,char **arrEscalas,
        double *arrPrecioEscala,int numEscalas,double *arrRecaudacionCurso,
        double *arrRecaudacionEscala){    
    ofstream archReporte("reporte.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR al abrir el archivo de reporte"<<endl;
        exit(1);
    }
    archReporte<<setw(50)<<' '<<"INSTITUCION ABC"<<endl;
    archReporte<<setw(25)<<' '<<"RECAUDACION OBTENIDA POR EL PROCESO DE "
            "MATRICULA"<<endl;
    archReporte<<setprecision(2);
    archReporte<<fixed;
    imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<setw(50)<<' '<<"Recaudacion Por Escalas"<<endl;
    archReporte<<setw(5)<<' '<<"Escala"<<setw(20)<<' '<<"Valor de Credito"
            <<setw(10)<<' '<<"RECAUDACION"<<endl;
    for(int i=0;i<numEscalas;i++){
        archReporte<<setw(2)<<i+1<<')'<<setw(5)<<arrEscalas[i]
                <<setw(25)<<' '<<setw(8)<<arrPrecioEscala[i]<<setw(15)
                <<' '<<setw(10)<<arrRecaudacionEscala[i]<<endl;
    }
    imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<setw(50)<<' '<<"Recaudacion Por Escalas"<<endl;
    imprimeLinea('-',MAX_LINE,archReporte);
    archReporte<<setw(5)<<' '<<"Codigo"<<setw(5)<<' '<<"Nombre"
                <<setw(62)<<' '<<"Creditos"<<setw(8)<<' '<<"Recaudacion"<<endl;
    for(int i=0;i<numCursos;i++){
        archReporte<<right<<setw(2)<<i+1<<")  "<<arrCodigoCursos[i]<<left
                <<setw(5)<<' '<<setw(55)<<arrNombreCursos[i]<<right<<setw(15)
                <<' '<<setw(4)<<arrCreditos[i]<<setw(10)<<' '<<setw(10)
                <<arrRecaudacionCurso[i]<<endl;
    }
}


int buscarPosicion(char **arreglo,char *elemento,int numDatos){
    
    for(int i=0;i<numDatos;i++)
        if(strcmp(arreglo[i],elemento)==0)return i;
    return -1;
}

char *leeCadenaExacta(ifstream &arch){
    char buffer[500], *cadena;
    int longitud;
    
    arch.getline(buffer,500,',');
    if(arch.eof())return nullptr;
    longitud=strlen(buffer);
    cadena = new char[longitud+1];
    strcpy(cadena,buffer);
    
    return cadena;
}

void imprimeLinea(char caracter, int cantidad, ofstream &archReporte){
    for(int i=0;i<cantidad;i++)archReporte<<caracter;
    archReporte<<endl;
}
//char *leeCadenaExactaDelim(ifstream &arch,char delim){
//    char buffer[500], *cadena;
//    int longitud;
//    
//    arch.getline(buffer,500,delim);
//    if(arch.eof())return nullptr;
//    longitud=strlen(buffer);
//    cadena = new char[longitud+1];
//    strcpy(cadena,buffer);
//    
//    return cadena;
//}