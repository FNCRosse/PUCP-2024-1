

/* 
 * File:   main.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 1 de junio de 2023, 03:07 PM
 */

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

#include "funciones.h"

/*
 * 
 */
int main(int argc, char** argv) {
    
    int numCursos;
    char *arrCodigoCursos[50],*arrNombreCursos[50];
    double arrCreditos[50],arrRecaudacionCurso[50]{};
  
    char *arrEscalas[30];
    double arrPrecioEscala[30],arrRecaudacionEscala[30]{};
    int numEscalas; 
    leerCursos(arrCodigoCursos,arrNombreCursos,arrCreditos,numCursos);
    leerEscalas(arrEscalas,arrPrecioEscala,numEscalas);
    leerMatricula(arrCodigoCursos,arrNombreCursos,arrCreditos,numCursos,
            arrEscalas,arrPrecioEscala,numEscalas,arrRecaudacionCurso,
            arrRecaudacionEscala);
    ordenarEscalas(arrEscalas,arrPrecioEscala,arrRecaudacionEscala,numEscalas);
    ordenarCursos(arrCodigoCursos,arrNombreCursos,arrCreditos,
            arrRecaudacionCurso,numCursos);
    imprimeReporte(arrCodigoCursos,arrNombreCursos,arrCreditos,numCursos,
            arrEscalas,arrPrecioEscala,numEscalas,arrRecaudacionCurso,
            arrRecaudacionEscala);
    return 0;
}

