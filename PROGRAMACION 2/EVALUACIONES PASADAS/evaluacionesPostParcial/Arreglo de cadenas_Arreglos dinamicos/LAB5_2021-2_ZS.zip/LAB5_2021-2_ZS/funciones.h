

/* 
 * File:   funciones.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 1 de junio de 2023, 03:07 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void leerCursos(char **arrCodigoCursos,char **arrNombreCursos,
        double *arrCreditos,int &numCursos);
void leerEscalas(char **arrEscalas,double *arrPrecioEscala,int &numEscalas);
void leerMatricula(char **arrCodigoCursos,char **arrNombreCursos,
        double *arrCreditos,int numCursos,char **arrEscalas,
        double *arrPrecioEscala,int numEscalas,double *arrRecaudacionCurso,
        double *arrRecaudacionEscala);
int buscarPosicion(char **arrEscalas,char *escala,int numEscalas);
void ordenarEscalas(char **arrEscalas,double *arrPrecioEscala,
        double *arrRecaudacionEscala,int numEscalas);
void ordenarCursos(char **arrCodigoCursos,char **arrNombreCursos,
        double *arrCreditos,double *arrRecaudacionCurso,int numCursos);
void copiarTresCaracteres(char *destino,char *&fuente);
void cambiarChar(char *&escalaI, char *&escalaJ);
void  cambiarDouble(double *arreglo,int i,int j);
void imprimeReporte(char **arrCodigoCursos,char **arrNombreCursos,
        double *arrCreditos,int numCursos,char **arrEscalas,
        double *arrPrecioEscala,int numEscalas,double *arrRecaudacionCurso,
        double *arrRecaudacionEscala);
void imprimeLinea(char caracter, int cantidad, ofstream& archReporte);
char *leeCadenaExacta(ifstream& arch);
//char *leeCadenaExactaDelim(ifstream& arch, char delim);
#endif /* FUNCIONES_H */

