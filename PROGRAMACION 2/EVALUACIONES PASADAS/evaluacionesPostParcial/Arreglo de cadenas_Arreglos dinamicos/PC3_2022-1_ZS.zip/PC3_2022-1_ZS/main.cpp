

/* 
 * File:   main.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 31 de mayo de 2023, 02:28 AM
 */

#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

#include "funciones.h"

/*
 * 
 */
int main(int argc, char** argv) {
    
    char *arrCodigoCursos[50], *arrNombreCurso[60];
    int numCursos;
    double arrCredCurso[50];
    
    char *arrCodigoAlumno[50],*arrNombreAlumno[60];
    int numAlumnos;
    
    char *arrCodAlumnoAux[200],*arrCursoAux[200];
    int arrNotas[200],numNotas;
    
    int arrAprobados[50]{},arrDesaprobados[50]{};
    double arrPromedio[50];
    
    leerCursos(arrCodigoCursos,arrNombreCurso,arrCredCurso,numCursos);
    leerAlumnos(arrCodigoAlumno,arrNombreAlumno,numAlumnos);
    leerNotas(arrCodigoCursos,numCursos,arrCodigoAlumno,numAlumnos,arrCursoAux,
            arrCodAlumnoAux,arrNotas,numNotas,arrAprobados,arrDesaprobados,
            arrPromedio);
    emiteReporte(arrCodigoCursos,arrNombreCurso,arrCredCurso,numCursos,
            arrCodigoAlumno,arrNombreAlumno,numAlumnos,arrCursoAux,
            arrCodAlumnoAux,arrNotas,numNotas,arrAprobados,arrDesaprobados,
            arrPromedio);
    
    return 0;
}

