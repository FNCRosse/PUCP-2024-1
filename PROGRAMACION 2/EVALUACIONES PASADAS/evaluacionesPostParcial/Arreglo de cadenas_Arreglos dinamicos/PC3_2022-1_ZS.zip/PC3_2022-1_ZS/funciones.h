

/* 
 * File:   funciones.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 31 de mayo de 2023, 02:28 AM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void leerCursos(char **arrCodigoCursos,char **arrNombreCurso,
        double *arrCredCurso,int &numCursos);
void leerNombre(char *nombreCurso,char *nombreCompletoCursoAux,
        ifstream &archCursos);
void modificarNombre(char *cadena1,char *cadena2);
int verificaSeparador(char *nombreCurso);
void leerAlumnos(char **arrCodigoAlumno,char **arrNombreAlumno,int &numAlumnos);
void pasarMinusMayus(char *nombreModificado);
void modificarNombreAlumno(char *nombrAlumnoModificado,char *nombreAlumno);
int buscaPosicionGuion(char *nombre);
void leerNotas(char **arrCodigoCursos,int numCursos,char **arrCodigoAlumno,
        int numAlumnos,char **arrCursoAux,char **arrCodAlumnoAux,int *arrNotas,
        int &numNotas,int *arrAprobados,int *arrDesaprobados,
        double *arrPromedio);
void almacenarDatosCurso(int nota,int *arrAprobados,int *arrDesaprobados,
        int posCurso);
void emiteReporte(char **arrCodigoCursos,char **arrNombreCurso,
        double *arrCredCurso,int numCursos,char **arrCodigoAlumno,
        char **arrNombreAlumno,int numAlumnos,char **arrCursoAux,
        char **arrCodAlumnoAux,int *arrNotas,int &numNotas,int *arrAprobados,
        int *arrDesaprobados,double *arrPromedio);
void emiteReporte2(char **arrCodigoCursos,char **arrNombreCurso,
        double *arrCredCurso,int *arrAprobados,int *arrDesaprobados,
        double *arrPromedio,int numCursos,ofstream &archReporte);
void imprimeEncabezado(ofstream &archReporte);
void buscaImprimeNombre(char **arrCodigoAlumno,char **arrNombreAlumno,
        char *elemento,int numDatos,ofstream &archReporte);
void imprimeLinea(char caracter, int cantidad, ofstream& archRep);
int buscarPosicion(char** arreglo, char* elemento, int numDatos);
//char *leeCadenaExacta(ifstream& arch);

#endif /* FUNCIONES_H */

