

/* 
 * File:   funciones.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 31 de mayo de 2023, 02:28 AM
 */


#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>

using namespace std;

#define MAX_CAR 60
#define MAX_LINE 150
#include "funciones.h"

void leerCursos(char **arrCodigoCursos,char **arrNombreCurso,
        double *arrCredCurso,int &numCursos){
    
    ifstream archCursos("Cursos.txt",ios::in);
    if(not archCursos.is_open()){
        cout<<"ERROR al abrir el archivo de cursos"<<endl;
        exit(1);
    }
    char *codigoCursoCompleto,codigoCurso[60];
    char nombreCurso[60],nombreCompletoCursoAux[60],nombreFinalCurso[60],
            *nombreCompletoCurso;
    double creditos;
    numCursos=0;
    while(true){
        archCursos>>codigoCurso;
        if(archCursos.eof())break;
        codigoCursoCompleto=new char[strlen(codigoCurso)+1];
        /*sobre un puntero se copia una cadena que no se ha modificado*/
        strcpy(codigoCursoCompleto,codigoCurso);
        arrCodigoCursos[numCursos]=codigoCursoCompleto;
        leerNombre(nombreCurso,nombreCompletoCursoAux,archCursos);
        modificarNombre(nombreFinalCurso,nombreCompletoCursoAux);
        /*sobre un puntero se copia una cadena que no se ha modificado*/
        nombreCompletoCurso=new char[strlen(nombreFinalCurso)+1];
        strcpy(nombreCompletoCurso,nombreCompletoCursoAux);
        arrNombreCurso[numCursos]=nombreCompletoCurso;
        archCursos>>creditos;
        arrCredCurso[numCursos]=creditos;
        numCursos++;        
    }
}

void leerNombre(char *nombreCurso,char *nombreCompletoCursoAux,
        ifstream &archCursos){
    int cantNombres=0,flag;
    while(true){
        archCursos>>nombreCurso;
        flag=verificaSeparador(nombreCurso);
        if(cantNombres<1){
            strcpy(nombreCompletoCursoAux,nombreCurso);
            if(flag)break;
            else strcat(nombreCompletoCursoAux," ");
            cantNombres++;
        }else{
            strcat(nombreCompletoCursoAux,nombreCurso);
            if(flag)break;
            else strcat(nombreCompletoCursoAux," ");
        }
    }
}

void modificarNombre(char *cadena2,char *cadena1){

    for(int i=0;cadena1[i];i++){
        if(cadena1[i]=='{')cadena1[i]=' ';
        else if(cadena1[i]=='}')cadena1[i]=0;
    }
    strcpy(cadena2,cadena1);
}

int verificaSeparador(char *nombreCurso){
    for(int i=0;nombreCurso[i];i++)
        if(nombreCurso[i]=='}')return 1;
    return 0;
}

void leerAlumnos(char **arrCodigoAlumno,char **arrNombreAlumno,int &numAlumnos){
    
    ifstream archAlumnos("Alumnos.txt",ios::in);
    if(not archAlumnos.is_open()){
        cout<<"ERROR al abrir el archivo de alumnos"<<endl;
        exit(1);
    }
    
    char codigoAlumno[60], *ptr_codigoAlumno;
    char nombreAlumno[60],nombrAlumnoModificado[60], *ptr_nombreAlumno;
    numAlumnos=0;
    double valo1,valor2,valor3;
    while(true){
        archAlumnos>>codigoAlumno;
        if(archAlumnos.eof())break;
        archAlumnos>>nombreAlumno;
        modificarNombreAlumno(nombrAlumnoModificado,nombreAlumno);
        pasarMinusMayus(nombrAlumnoModificado);
        ptr_codigoAlumno=new char[strlen(codigoAlumno)+1];
        ptr_nombreAlumno=new char[strlen(nombrAlumnoModificado)+1];
        strcpy(ptr_codigoAlumno,codigoAlumno);
        strcpy(ptr_nombreAlumno,nombrAlumnoModificado);
        arrCodigoAlumno[numAlumnos]=ptr_codigoAlumno;
        arrNombreAlumno[numAlumnos]=ptr_nombreAlumno;
        archAlumnos>>valo1>>valor2>>valor3;
        numAlumnos++;
    }
}

void pasarMinusMayus(char *nombreModificado){
    int primeraLetra=1;
    for(int i=0;nombreModificado[i];i++){     
        if(nombreModificado[i]!='.' and nombreModificado[i]!=' '){     
            if(nombreModificado[i]>='a' and nombreModificado[i]<='z'
                    and primeraLetra) nombreModificado[i]-='a'-'A';
            else if(nombreModificado[i]>='A' and nombreModificado[i]<='Z'
                    and !primeraLetra) nombreModificado[i]+='a'-'A';
            primeraLetra=0;
        }else if(nombreModificado[i]=='.'){
            primeraLetra=1;
            if(nombreModificado[i-1]>='a' and nombreModificado[i-1]<='z')
                nombreModificado[i-1]-='a'-'A';
        }
    }
}

void modificarNombreAlumno(char *nombrAlumnoModificado,char *nombreAlumno){
    int j=0,primerGuion=0,cantGuiones=0;
    int posPenultimoGuion=buscaPosicionGuion(nombreAlumno);
    for(int i=posPenultimoGuion+1;nombreAlumno[i];i++){
        if(nombreAlumno[i]=='_'){
            nombrAlumnoModificado[j]=' ';
            nombrAlumnoModificado[j+1]=nombreAlumno[i+1];
            nombrAlumnoModificado[j+2]='.';
            nombrAlumnoModificado[j+3]=' ';
            j+=4;
            primerGuion=1;
        }else if(!primerGuion){
            nombrAlumnoModificado[j] = nombreAlumno[i];
            j++;
        }
    }
    primerGuion=0;
    for(int i=0;i<posPenultimoGuion;i++){
        if(nombreAlumno[i]=='_'){
            nombrAlumnoModificado[j]=' ';
            nombrAlumnoModificado[j+1]=nombreAlumno[i+1];
            nombrAlumnoModificado[j+2]='.';
            nombrAlumnoModificado[j+3]=' ';
            j+=3;
            primerGuion=1;
            cantGuiones++;
        }else if(i==posPenultimoGuion-1){
            if(cantGuiones==0){/*Solo un nombre*/
                nombrAlumnoModificado[j]=nombreAlumno[i];
                nombrAlumnoModificado[j+1]=' ';
                nombrAlumnoModificado[j+2]='\0';
                j+=3;
            }else{ 
                nombrAlumnoModificado[j]=' ';
                nombrAlumnoModificado[j+1]='\0';
                j+=2;
            }
        }else if(!primerGuion){
            nombrAlumnoModificado[j]=nombreAlumno[i];
            j++;
        }
    }
}

int buscaPosicionGuion(char *nombre){
    
    int pos_anterior,pos_actual;
    for(int i=0;nombre[i];i++){
        if(nombre[i]=='_'){
            pos_anterior=pos_actual;
            pos_actual=i;
        }
    }
    return pos_anterior;
}

void leerNotas(char **arrCodigoCursos,int numCursos,char **arrCodigoAlumno,
        int numAlumnos,char **arrCursoAux,char **arrCodAlumnoAux,int *arrNotas,
        int &numNotas,int *arrAprobados,int *arrDesaprobados,
        double *arrPromedio){
    ifstream archNotas("Notas.txt",ios::in);
    if(not archNotas.is_open()){
        cout<<"ERROR al abrir el archivo de notas"<<endl;
        exit(1);
    }
    char cursoLeido[20],alumnoLeido[20],*ptr_alumnoAux,*ptr_cursoAux;;
    int nota,posCurso,posAlumno,cantNotas,sumNotas;
    numNotas=0;
    while(true){
        archNotas>>cursoLeido;
        if(archNotas.eof())break;
        posCurso=buscarPosicion(arrCodigoCursos,cursoLeido,numCursos);
        if(posCurso!=-1){
            ptr_cursoAux=new char[strlen(cursoLeido)+1];
            strcpy(ptr_cursoAux,cursoLeido);
            cantNotas=sumNotas=0;
            while(true){
                archNotas>>alumnoLeido;
                archNotas>>nota;
                posAlumno=buscarPosicion(arrCodigoAlumno,alumnoLeido,numAlumnos);
                if(posAlumno!=-1){
                    ptr_alumnoAux=new char[strlen(alumnoLeido)+1];
                    strcpy(ptr_alumnoAux,alumnoLeido);
                    arrCursoAux[numNotas]=ptr_cursoAux;
                    arrCodAlumnoAux[numNotas]=ptr_alumnoAux;
                    arrNotas[numNotas]=nota;
                    numNotas++;
                    sumNotas+=nota;
                    cantNotas++;
                    almacenarDatosCurso(nota,arrAprobados,arrDesaprobados,
                            posCurso);
                }
                arrPromedio[posCurso]=(double)sumNotas/cantNotas;
                if(archNotas.get()=='\n')break;
            }
        }else while(archNotas.get()!='\n');
    }    
}

void almacenarDatosCurso(int nota,int *arrAprobados,int *arrDesaprobados,
        int posCurso){
    
    if(nota>10){
        arrAprobados[posCurso]++; 
    }else if(nota<=10){
        arrDesaprobados[posCurso]++;
    }
}

void emiteReporte(char **arrCodigoCursos,char **arrNombreCurso,
        double *arrCredCurso,int numCursos,char **arrCodigoAlumno,
        char **arrNombreAlumno,int numAlumnos,char **arrCursoAux,
        char **arrCodAlumnoAux,int *arrNotas,int &numNotas,int *arrAprobados,
        int *arrDesaprobados,double *arrPromedio){ 
    ofstream archReporte("ReporteConsolidadoDeCursos.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR al abrir el archivo de ReporteConsolidadoDeCursos"<<endl;
        exit(1);
    }
    int cont_cursos=0,contAlumnos;
    archReporte<<setw(50)<<' '<<"INSTITUCION EDUCATIVA LIMA"<<endl;
    archReporte<<setw(48)<<' '<<"CONSOLIDADO DE CURSOS"<<endl;
    archReporte<<setprecision(2);
    archReporte<<fixed;
    for(int i=0;i<numCursos;i++){
        imprimeLinea('=',MAX_LINE,archReporte);
        cont_cursos++;
        archReporte<<setw(3)<<cont_cursos<<") "<<"CODIGO"<<setw(6)<<' '
                <<"NOMBRE"<<setw(60)<<' '<<"CREDITOS"<<endl;
        archReporte<<setw(5)<<' '<<arrCodigoCursos[i]<<setw(5)<<' '
                <<arrNombreCurso[i]<<setw(MAX_CAR-strlen(arrNombreCurso[i]))
                <<' '<<setw(14)<<arrCredCurso[i]<<endl;
        imprimeEncabezado(archReporte);
        contAlumnos=0;
        for(int k=0;k<numNotas;k++){
            if(strcmp(arrCodigoCursos[i],arrCursoAux[k])==0){
                contAlumnos++;
                archReporte<<setw(7)<<contAlumnos<<") "<<arrCodAlumnoAux[k]
                        <<setw(6)<<' ';
                buscaImprimeNombre(arrCodigoAlumno,arrNombreAlumno,
                        arrCodAlumnoAux[k],numAlumnos,archReporte);
                archReporte<<setw(4)<<arrNotas[k]<<endl;
            }
        }
    }
    emiteReporte2(arrCodigoCursos,arrNombreCurso,arrCredCurso,arrAprobados,
            arrDesaprobados,arrPromedio,numCursos,archReporte);   
}

void emiteReporte2(char **arrCodigoCursos,char **arrNombreCurso,
        double *arrCredCurso,int *arrAprobados,int *arrDesaprobados,
        double *arrPromedio,int numCursos,ofstream &archReporte){
    imprimeLinea('=',MAX_LINE,archReporte);
    imprimeLinea('/',MAX_LINE,archReporte);
    archReporte<<setw(50)<<' '<<"RESUMEN DE LOS CURSOS DICTADOS ESTE SEMESTRE"
            <<endl;
    archReporte<<setw(6)<<' '<<"CODIGO"<<setw(4)<<' '<<"NOMBRE"
            <<setw(60)<<' '<<"CREDITOS"<<setw(5)<<' '<<"APROBADOS"<<setw(5)<<' '
            <<"DESAPROBADOS"<<setw(5)<<' '<<"PROMEDIO"<<endl;
    int contCursos=0;
    for(int i=0;i<numCursos;i++){
        contCursos++;
        archReporte<<setw(4)<<contCursos<<") "<<arrCodigoCursos[i]<<setw(3)
                <<' '<<arrNombreCurso[i]<<setw(60-strlen(arrNombreCurso[i]))
                <<' '<<setw(13)<<arrCredCurso[i]<<setw(10)<<' '<<setw(2)
                <<arrAprobados[i]<<setw(14)<<' '<<setw(2)<<arrDesaprobados[i]
                <<setw(10)<<' '<<setw(6)<<arrPromedio[i]<<endl;
    }
}

void imprimeEncabezado(ofstream &archReporte){
    imprimeLinea('-',MAX_LINE,archReporte);
    archReporte<<setw(5)<<' '<<"ALUMNOS MATRICULADOS"<<endl;
    archReporte<<setw(9)<<' '<<"CODIGO"<<setw(8)<<' '<<"NOMBRE"
            <<setw(25)<<' '<<"NOTA"<<endl;
}
void buscaImprimeNombre(char **arrCodigoAlumno,char **arrNombreAlumno,
        char *elemento,int numDatos,ofstream &archReporte){
    
    for(int i=0;i<numDatos;i++)
        if(strcmp(arrCodigoAlumno[i],elemento)==0)
            archReporte<<arrNombreAlumno[i]<<setw(30-strlen(arrNombreAlumno[i]))
                    <<' ';
        
}

void imprimeLinea(char caracter, int cantidad, ofstream &archRep){
    for(int i=0;i<cantidad;i++)archRep<<caracter;
    archRep<<endl;
}

int buscarPosicion(char **arreglo,char *elemento,int numDatos){
    
    for(int i=0;i<numDatos;i++)
        if(strcmp(arreglo[i],elemento)==0)return i;
    return -1;
}

//char *leeCadenaExacta(ifstream &arch){
//    char buff[500],*cadena;
//    int longitud;
//    
//    arch.getline(buff,500);
//    if(arch.eof())return nullptr;
//    
//    longitud=strlen(buff);
//    cadena=new char[longitud+1];
//    strcpy(cadena,buff);
//    
//    return cadena;
//}
