

/* 
 * File:   funciones.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 30 de mayo de 2023, 11:51 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void emiteReporte();
void imprimeNombreAutor(int codigo_autor,char *nombre,char *nombreCompleto,
        char *apellido1,char *apellido2,char *apellidoCompleto,
        char *nomrbreApellidos,char *nombreModificado,ifstream &archAutores,
        ofstream &archReporte);
void imprimeDatosLibros(ifstream &archAutores,ofstream &archReporte);
void buscaImprimeLibro(int codigo_libro,ofstream &archReporte);
void imprimeNombreLibro(char *nombre,char *nombreCompleto,
        char *nombreModificado,ifstream &archLibros,ofstream &archReporte);
int obtenerCantVendida(int cod_libro);
double obtenerMontoVendido(int cod_libro, int cantidad);
void ordenarArreglos(int *arrCodLibro,int *arrLibrosVendidos,
        double *arrRecaudado,int numLibros);
void cambiarInt(int* arreglo, int i, int j);
void cambiarDouble(double* arreglo, int i, int j);;
void modificaNombreLibro(char *nombre,char *nombreModificado);
void formatearNombre(char *cadena);
void modificarNombreAutor(char *cadena2,char *cadena1);
int verificaComa(char *cadena1);
void imprimeLinea(char caracter, int cantidad, ofstream& archReporte);

#endif /* FUNCIONES_H */

