

/* 
 * File:   funciones.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 30 de mayo de 2023, 11:50 PM
 */


#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>
using namespace std;

#define MAX_LIBRO 30
#define NO_ENCONTRADO -1
#define MAX_CAR 60
#define MAX_LINE 150
#include "funciones.h"


void emiteReporte(){
    ofstream archReporte("ReporteVentaLibrosPorAutor.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR al abrir el archivo de ReporteVentaLibrosPorAutor"<<endl;
        exit(1);
    }
    ifstream archAutores("Autores.txt",ios::in);
    if(not archAutores.is_open()){
        cout<<"ERROR al abrir el archivo de Autores"<<endl;
        exit(1);
    }   
    int codigo_autor;
    char nombre[60],apellido1[60],apellido2[60],apellidoCompleto[60],
            nombreCompleto[60],nomrbreApellidos[120],nombreModificado[120];
    archReporte<<"EDITORIAL XYZ"<<endl;
    imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<"VENTAS DE LIBROS POR AUTOR"<<endl;
    imprimeLinea('-',MAX_LINE,archReporte);
    while(true){
        archAutores>>codigo_autor;
        if(archAutores.eof())break;
        imprimeNombreAutor(codigo_autor,nombre,nombreCompleto,apellido1,
                apellido2,apellidoCompleto,nomrbreApellidos,nombreModificado,
                archAutores,archReporte);
        imprimeDatosLibros(archAutores,archReporte);
    } 
}

void imprimeNombreAutor(int codigo_autor,char *nombre,char *nombreCompleto,
        char *apellido1,char *apellido2,char *apellidoCompleto,
        char *nomrbreApellidos,char *nombreModificado,ifstream &archAutores,
        ofstream &archReporte){ 
    int cantNombres=0,coma,tam;
    while(true){
        archAutores>>nombre;
        coma=verificaComa(nombre); 
        if(cantNombres==0){
            strcpy(nombreCompleto,nombre);
            cantNombres++;
        }else{
            strcat(nombreCompleto," ");
            strcat(nombreCompleto,nombre);
        }  
        if(coma){
            archAutores>>apellido1>>apellido2;
            strcpy(apellidoCompleto,apellido1);
            strcat(apellidoCompleto,"/");
            strcat(apellidoCompleto,apellido2);
            strcpy(nomrbreApellidos,apellidoCompleto);
            strcat(nomrbreApellidos,"/");
            strcat(nomrbreApellidos,nombreCompleto);
            modificarNombreAutor(nombreModificado,nomrbreApellidos);
            tam=strlen(nombreModificado);
            archReporte<<"Autor: "<<nombreModificado<<setw(MAX_CAR-tam)
                    <<' '<<"DNI: "<<codigo_autor<<endl;
            imprimeLinea('-',MAX_LINE,archReporte);
            archReporte<<"Libros Vendidos:"<<endl;
            imprimeLinea('=',MAX_LINE,archReporte);
            archReporte<<"CODIGO"<<setw(10)<<' '<<"TITULO"<<setw(50)<<' '
                    <<"TOTAL VENDIDO"<<setw(10)<<' '<<"MONTO TOTAL"<<endl;
            break;
        }
    }
}

void imprimeDatosLibros(ifstream &archAutores,ofstream &archReporte){
    
    int codigo_libro,arrCodLibro[MAX_LIBRO],arrLibrosVendidos[MAX_LIBRO]{},
            numLibros=0;
    double arrMontoVendido[MAX_LIBRO]{},montoTotalVendido=0;
    while(true){
        archAutores>>codigo_libro;
        arrCodLibro[numLibros]=codigo_libro;
        arrLibrosVendidos[numLibros]=obtenerCantVendida(codigo_libro);
        arrMontoVendido[numLibros]=obtenerMontoVendido(codigo_libro,
                arrLibrosVendidos[numLibros]);
        montoTotalVendido+=arrMontoVendido[numLibros];
        numLibros++;
        if(archAutores.get()=='\n')break;
    }
    ordenarArreglos(arrCodLibro,arrLibrosVendidos,arrMontoVendido,numLibros);
    for (int i=0;i<numLibros;i++){
        archReporte<<arrCodLibro[i]<<setw(10)<<' ';
        buscaImprimeLibro(arrCodLibro[i],archReporte);
        archReporte<<setw(8)<<arrLibrosVendidos[i]<<setw(24)
                <<arrMontoVendido[i]<<endl;
    }
    imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<"Monto total vendido: "<<montoTotalVendido<<endl;
    imprimeLinea('=',MAX_LINE,archReporte);
}

void buscaImprimeLibro(int codigo_libro,ofstream &archReporte){  
    ifstream archLibros("Libros.txt",ios::in);
    if(not archLibros.is_open()){
        cout<<"ERROR al abrir el archivo de libros"<<endl;
        exit(1);
    }
    int codLibro_evaluar;
    char nombre[80],nombreCompleto[80],nombreModificado[80];
    archReporte<<setprecision(2);
    archReporte<<fixed;
    while(true){
        archLibros>>codLibro_evaluar;
        if(archLibros.eof())break;
        if(codLibro_evaluar==codigo_libro){
            imprimeNombreLibro(nombre,nombreCompleto,nombreModificado,
                    archLibros,archReporte);
            return;
        }else while(archLibros.get()!='\n');     
    }   
}

void imprimeNombreLibro(char *nombre,char *nombreCompleto,
        char *nombreModificado,ifstream &archLibros,ofstream &archReporte){
    int cantNombres=0,coma,tam;
    while(true){
        archLibros>>nombre;
            coma=verificaComa(nombre);
            if(cantNombres==0){
                modificaNombreLibro(nombre,nombreModificado);
                strcpy(nombreCompleto,nombreModificado);
                cantNombres++;
                if(coma)break;
            }else if(cantNombres>0){
                if(coma){
                    modificaNombreLibro(nombre,nombreModificado);
                    strcat(nombreCompleto,nombreModificado);
                    break;
                }else {
                    modificaNombreLibro(nombre,nombreModificado);
                    strcat(nombreCompleto,nombreModificado);
                }
            }
    }
    tam=strlen(nombreCompleto);
    archReporte<<nombreCompleto<<setw(MAX_CAR-tam)<<' ';
}

int obtenerCantVendida(int cod_libro){
    ifstream archVentas("Ventas.txt",ios::in);
    if(not archVentas.is_open()){
        cout<<"ERROR al abrir el archivo de Ventas"<<endl;
        exit(1);
    }
    int libro_leido, cantidad, cantTotal=0;
    while(1){
        archVentas>>libro_leido;
        if(archVentas.eof())break;
        archVentas>>cantidad;
        if(libro_leido==cod_libro)
            cantTotal+=cantidad;
    }   
    return cantTotal;
}

double obtenerMontoVendido(int cod_libro, int cantidad){
    ifstream archLibros("Libros.txt",ios::in);
    if(not archLibros.is_open()){
        cout<<"ERROR al abrir el archivo de Libros"<<endl;
        exit(1);
    }
    int libro_leido;
    double precio;
    while(1){
        archLibros>>libro_leido;
        if(archLibros.eof())break;
        while(archLibros.get()!=',');
        archLibros>>precio;
        if(libro_leido==cod_libro)
            return cantidad*precio;
    }
}

void ordenarArreglos(int *arrCodLibro,int *arrLibrosVendidos,
        double *arrRecaudado,int numLibros){
    
    for(int i=0;i<numLibros-1;i++)
        for(int k=i+1;k<numLibros;k++)
            if(arrLibrosVendidos[i]>arrLibrosVendidos[k] or 
                    arrLibrosVendidos[i]==arrLibrosVendidos[k] and
                    arrRecaudado[i]<arrRecaudado[k]){
                cambiarInt(arrCodLibro,i,k);
                cambiarInt(arrLibrosVendidos,i,k);
                cambiarDouble(arrRecaudado,i,k);
            }
}

void cambiarInt(int *arreglo,int i,int j){
    int aux;
    aux = arreglo[i];
    arreglo[i]=arreglo[j];
    arreglo[j]=aux;
}

void cambiarDouble(double *arreglo,int i,int j){
    double aux;
    aux = arreglo[i];   
    arreglo[i]=arreglo[j];
    arreglo[j]=aux;
}

void modificaNombreLibro(char *nombre,char *nombreModificado){
    int j=0;
    for(int i=0;nombre[i];i++){
        nombreModificado[j]=nombre[i];
        j++;
    }
    nombreModificado[j]=0;
    formatearNombre(nombreModificado);
    int tam = strlen(nombreModificado);
    if(tam<3){
        for(int i=tam;i<3;i++)
            nombreModificado[i]='X';
        nombreModificado[3]=0;
    }else if(tam>3){       
        nombreModificado[3]=0;
    }
}

void formatearNombre(char *cadena){
    int longitud = strlen(cadena);
    cadena[0] = toupper(cadena[0]);
    for (int i = 1; i < longitud; i++)
        cadena[i] = tolower(cadena[i]);
}

void modificarNombreAutor(char *cadena2,char *cadena1){
    int j=0;
    int flag=1; /*primera letra*/
    for(int i=0;cadena1[i];i++){
        /*Forma Lino*/
        if(cadena1[i]!='/' and cadena1[i]!=' ' ){
            /*verificamos si es distinto a ambos separadores*/
            if(flag){
                if(cadena1[i]>='a' and cadena1[i]<='z')cadena1[i]-='a'-'A';
                cadena2[j]=cadena1[i];
                j++;
                flag=0;
            }else if(!flag){
                if(cadena1[i]>='A' and cadena1[i]<='Z')cadena1[i]+='a'-'A';
                cadena2[j]=cadena1[i];
                j++;
            }
        }else if(cadena1[i] =='/' or cadena1[i]==' '){
            cadena2[j]=cadena1[i];
            j++;
            flag=1;
        }
        /*Forma Cyndx (c4br4s0)*/
//        if(cadena1[i]>='A' and cadena1[i]<='Z')cadena1[i]+='a'-'A';          
//        if(i==0 or cadena1[i-1]=='/' or cadena1[i-1]==' ')
//            if(cadena1[i]>='a' and cadena1[i]<='z')cadena1[i]-='a'-'A';    
//        cadena2[j]=cadena1[i];
//        j++;
    }
    cadena2[j]='\0';
}

int verificaComa(char *cadena1){  
    for(int i=0;cadena1[i];i++)
        if(cadena1[i]==',') {
            cadena1[i]='\0';
            return 1;
        }
    return 0;
}

void imprimeLinea(char caracter,int cantidad,ofstream &archReporte){
    for(int i=0;i<cantidad;i++)archReporte<<caracter;
    archReporte<<endl;
}
