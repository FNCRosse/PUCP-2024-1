/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * Alumno: Chupetin
 *
 * Created on 5 de junio de 2023, 07:08 PM
 */

#include <iomanip>
#include <iostream>
#include <fstream>


using namespace std;

#define MAX_REGISTRO 300
#define MAX_PRODUCTOS 70
#define MAX_ALMACEN 10
#include "funciones.h"
/*
 * 
 */
int main(int argc, char** argv) {
    
    int arrCodDistrito[MAX_ALMACEN],numAlmacenes;
    char *arrCodAlmacen[MAX_ALMACEN],*arrNombreAlmacen[MAX_ALMACEN];
    
    char *arrCodProducto[MAX_PRODUCTOS],*arrNombreProducto[MAX_PRODUCTOS];
    int numProductos;
    
    char *arrCodProdStock[MAX_REGISTRO],*arrCodAlmacenProd[MAX_REGISTRO];
    double arrStockProducto[MAX_REGISTRO];
    int numRegistros;
    
    double arrIngresos[MAX_REGISTRO]{},arrSalidas[MAX_REGISTRO]{},
            arrEnviados[MAX_REGISTRO]{},arrTransferidos[MAX_REGISTRO]{},
            arrStockFinal[MAX_REGISTRO];
    leerAlmacen(arrCodAlmacen,arrNombreAlmacen,arrCodDistrito,numAlmacenes);
    leerProductos(arrCodProducto,arrNombreProducto,numProductos);
    ordenarAlmacenes(arrCodAlmacen,arrNombreAlmacen,arrCodDistrito,numAlmacenes);
    mostrarAlmacenesOrdenados(arrCodAlmacen,arrNombreAlmacen,arrCodDistrito,
            numAlmacenes);
    leerStock(arrCodProdStock,arrCodAlmacenProd,arrStockProducto,numRegistros);
    mostrarStocksProductos(arrCodProdStock,arrCodAlmacenProd,arrStockProducto,
            numRegistros);
    leerTransacciones(arrCodAlmacen,arrNombreAlmacen,arrCodDistrito,numAlmacenes,
            arrCodProducto,arrNombreProducto,numProductos,arrCodProdStock,
            arrCodAlmacenProd,arrStockProducto,numRegistros,arrIngresos,
            arrSalidas,arrEnviados,arrTransferidos);
    actualizaStockFinal(arrStockProducto,arrIngresos,arrSalidas,arrEnviados,
            arrTransferidos,arrStockFinal,numRegistros);
    ordenarProdAlmacenes(arrCodProdStock,arrCodAlmacenProd,arrStockProducto,
            arrIngresos,arrSalidas,arrEnviados,arrTransferidos,arrStockFinal,
            numRegistros);
    emiteReporte(arrCodAlmacen,arrNombreAlmacen,arrCodDistrito,numAlmacenes,
            arrCodProducto,arrNombreProducto,numProductos,arrCodProdStock,
            arrCodAlmacenProd,arrStockProducto,numRegistros,arrIngresos,
            arrSalidas,arrEnviados,arrTransferidos,arrStockFinal);
    return 0;
}      