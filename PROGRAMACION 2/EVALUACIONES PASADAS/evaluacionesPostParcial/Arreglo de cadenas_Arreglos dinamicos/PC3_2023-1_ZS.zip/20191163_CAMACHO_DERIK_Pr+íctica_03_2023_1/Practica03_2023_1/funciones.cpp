

/* 
 * Alumno: Chupetin
 *
 * Created on 5 de junio de 2023, 07:09 PM
 */


#include <iomanip>
#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;

#define NO_ENCONTRADO -1
#include "funciones.h"

void leerAlmacen(char **arrCodAlmacen,char **arrNombreAlmacen,int *arrCodDistrito,
        int &numAlmacenes){   
    ifstream archAlmacen("Almacen.csv",ios::in);
    if(not archAlmacen.is_open()){
        cout<<"ERROR al abrir el archivo de almacen"<<endl;
        exit(1);
    }  
    int codigo_distrito;
    char *ptr_codAlmacen;
    char *ptr_nombreAlmacen,almacen[40];
    numAlmacenes=0;
    while(true){
        ptr_codAlmacen=leerCadenaExacta(archAlmacen);
        if(archAlmacen.eof())break;
//        ptr_nombreAlmacen=leerCadenaExacta(archAlmacen);
        archAlmacen.getline(almacen,40,',');
        ptr_nombreAlmacen=new char[strlen(almacen)+1];
        strcpy(ptr_nombreAlmacen,&almacen[8]);
        
        archAlmacen>>codigo_distrito;
        archAlmacen.get();
        arrCodAlmacen[numAlmacenes]=ptr_codAlmacen;
        arrNombreAlmacen[numAlmacenes]=ptr_nombreAlmacen;
        arrCodDistrito[numAlmacenes]=codigo_distrito;
        
        numAlmacenes++;
    }
    
//    for(int i=0;i<numAlmacenes;i++)
//        cout<<arrCodAlmacen[i]<<' '<<arrNombreAlmacen[i]<<' '<<arrCodDistrito[i]<<endl;
}

void leerProductos(char **arrCodProducto,char **arrNombreProducto,
        int &numProductos){
    
    ifstream archProductos("Productos.csv",ios::in);
    if(not archProductos.is_open()){
        cout<<"ERROR al abrir el archivo de almacen"<<endl;
        exit(1);
    }
    
    char *ptr_codigoProducto, *ptr_nombreProducto;
    numProductos=0;
    char producto[50];
    while(true){
        ptr_codigoProducto=leerCadenaExacta(archProductos);
        if(archProductos.eof())break;
        
        archProductos.getline(producto,50);
        ptr_nombreProducto= new char[strlen(producto)+1];
        strcpy(ptr_nombreProducto,producto);
        
        arrCodProducto[numProductos]=ptr_codigoProducto;
        arrNombreProducto[numProductos]=ptr_nombreProducto;
        numProductos++;
    }
//    for(int i=0;i<numProductos;i++)
//        cout<<arrCodProducto[i]<<' '<<arrNombreProducto[i]<<endl;
}

void ordenarAlmacenes(char **arrCodAlmacen,char **arrNombreAlmacen,
        int *arrCodDistrito,int numAlmacenes){
    
    for(int i=0;i<numAlmacenes-1;i++)
        for(int k=i+1;k<numAlmacenes;k++)
            if(arrCodDistrito[i]>arrCodDistrito[k] or 
                    arrCodDistrito[i]==arrCodDistrito[k] and
                    strcmp(arrNombreAlmacen[i],arrNombreAlmacen[k])<0){
                cambiarChar(arrCodAlmacen[i],arrCodAlmacen[k]);
                cambiarChar(arrNombreAlmacen[i],arrNombreAlmacen[k]);
                cambiarInt(arrCodDistrito,i,k);
            }
//    for(int i=0;i<numAlmacenes;i++)
//        cout<<arrCodAlmacen[i]<<' '<<arrNombreAlmacen[i]<<' '<<arrCodDistrito[i]<<endl;
}

void mostrarAlmacenesOrdenados(char **arrCodAlmacen,char **arrNombreAlmacen,
        int *arrCodDistrito,int numAlmacenes){
    
    ofstream archReporteAlmacenes("AlmacenesOrdenados.txt",ios::out);
    if(not archReporteAlmacenes.is_open()){
        cout<<"ERROR al abrir el archivo de AlmacenesOrdenados.txt"<<endl;
        exit(1);
    }
    for(int i=0;i<numAlmacenes;i++)
        archReporteAlmacenes<<arrCodAlmacen[i]<<' '<<arrNombreAlmacen[i]<<' '
                <<arrCodDistrito[i]<<endl;
}

void leerStock(char **arrCodProdStock,char **arrCodAlmacenProd,
        double *arrStockProducto,int &numRegistros){
    
    ifstream archStock("stockProductos.txt",ios::in);
    if(not archStock.is_open()){
        cout<<"ERROR al abrir el archivo de stockProductos"<<endl;
        exit(1);
    }
    char codProducto[10],codAlmacen[10];
    char *ptr_producto,*ptr_almacen;
    int stock;
    numRegistros=0;
    while(true){
        archStock>>codProducto;
        if(archStock.eof())break;
        archStock>>codAlmacen;
        archStock>>stock;
        archStock.get();
        ptr_producto=new char[strlen(codProducto)+1];
        strcpy(ptr_producto,codProducto);
        ptr_almacen=new char[strlen(codAlmacen)+1];
        strcpy(ptr_almacen,codAlmacen);
        
        arrCodProdStock[numRegistros]=ptr_producto;
        arrCodAlmacenProd[numRegistros]=ptr_almacen;
        arrStockProducto[numRegistros]=stock;
        
        numRegistros++;
    }    
//    for(int i=0;i<numRegistros;i++)
//        cout<<arrCodProdStock[i]<<' '<<arrCodAlmacenProd[i]<<' '
//    <<arrStockProducto[i]<<endl;
}

void mostrarStocksProductos(char **arrCodProdStock,char **arrCodAlmacenProd,
        double *arrStockProducto,int numRegistros){
    
    ofstream archReporteStock("Muestra_De_StocksProductos.txt",ios::out);
    if(not archReporteStock.is_open()){
        cout<<"ERROR al abrir el archivo de Stocks_De_Productos.txt"<<endl;
        exit(1);
}
    for(int i=0;i<numRegistros;i++)
        archReporteStock<<arrCodProdStock[i]<<' '<<arrCodAlmacenProd[i]<<' '
                <<arrStockProducto[i]<<endl;
}

void leerTransacciones(char **arrCodAlmacen,char **arrNombreAlmacen,
        int *arrCodDistrito,int numAlmacenes,char **arrCodProducto,
        char **arrNombreProducto,int numProductos,char **arrCodProdStock,
        char **arrCodAlmacenProd,double *arrStockProducto,int numRegistros,
        double *arrIngresos,double *arrSalidas,double *arrEnviados,
        double *arrTransferidos){  
    ifstream archTransacciones("Transacciones.txt",ios::in);
    if(not archTransacciones.is_open()){
        cout<<"ERROR al abrir el archivo de Transacciones.txt"<<endl;
        exit(1);
    }
    char codAlmacen[10],*ptr_almacen;
    char c;
    int dia,mes,anio,posAlmacen;
    while(true){
        archTransacciones>>codAlmacen;
        if(archTransacciones.eof())break;
        archTransacciones>>dia>>c>>mes>>c>>anio; 
        ptr_almacen=new char[strlen(codAlmacen)+1];
        strcpy(ptr_almacen,codAlmacen);
        posAlmacen=buscarPosicion(arrCodAlmacen,ptr_almacen,numAlmacenes);
        if(posAlmacen!=NO_ENCONTRADO){
            while(true){      
                leeDatosTransacciones(ptr_almacen,arrCodProdStock,arrCodAlmacenProd,
                        arrStockProducto,numRegistros,arrCodProducto,
                        arrNombreProducto,numProductos,arrIngresos,
                        arrSalidas,arrEnviados,arrTransferidos,archTransacciones);           
                if(archTransacciones.get()=='\n')break;
            }
        }else while(archTransacciones.get()!='\n');       
    }
}

void leeDatosTransacciones(char *ptr_almacen,char **arrCodProdStock,
        char **arrCodAlmacenProd,double *arrStockProducto,int numRegistros,
        char **arrCodProducto,char **arrNombreProducto,int numProductos,
        double *arrIngresos,double *arrSalidas,double *arrEnviados,
        double *arrTransferidos,ifstream &archTransacciones){
    
    int hora,minuto,segundo,cantidad,posProducto,posProducto_adicional;
    char codAlmacen_adicional[10],codProducto[10],*ptr_producto,*ptr_almacenAdicional;
    char c,tipo_transaccion;
    archTransacciones>>hora>>c>>minuto>>c>>segundo;
    archTransacciones>>codProducto;
    archTransacciones>>cantidad>>tipo_transaccion;
    ptr_producto=new char[strlen(codProducto)+1];
    strcpy(ptr_producto,codProducto);
    posProducto=buscarPosicionCompartida(arrCodProdStock,arrCodAlmacenProd,ptr_producto,
            ptr_almacen,numRegistros);
    if(posProducto!=NO_ENCONTRADO){
        if(tipo_transaccion=='I'){
            arrIngresos[posProducto]+=cantidad;
        }else if(tipo_transaccion=='S'){
            arrSalidas[posProducto]+=cantidad;
        }else if(tipo_transaccion=='T'){
            archTransacciones>>codAlmacen_adicional;
            ptr_almacenAdicional=new char[strlen(codAlmacen_adicional)+1];
            strcpy(ptr_almacenAdicional,codAlmacen_adicional);     
            if(strcmp(ptr_almacen,ptr_almacenAdicional)==0){
                arrEnviados[posProducto]+=cantidad;
            }else{
                posProducto_adicional=buscarPosicionCompartida(arrCodProdStock,
                        arrCodAlmacenProd,ptr_producto,ptr_almacenAdicional,numRegistros);
                if(posProducto_adicional!=NO_ENCONTRADO){
                    arrEnviados[posProducto_adicional]+=cantidad;
                    arrTransferidos[posProducto]+=cantidad;                    
                }
            }       
        }
    }else if(tipo_transaccion=='T')archTransacciones>>codAlmacen_adicional;
}

void actualizaStockFinal(double *arrStockProducto,double *arrIngresos,
        double *arrSalidas,double *arrEnviados,
            double *arrTransferidos,double *arrStockFinal,int numRegistros){
    for(int i=0;i<numRegistros;i++){
        arrStockFinal[i]=arrStockProducto[i]+arrIngresos[i]-arrSalidas[i]-
                arrTransferidos[i]+arrEnviados[i];
    }
}

void ordenarProdAlmacenes(char **arrCodProdStock,char **arrCodAlmacenProd,
        double *arrStockProducto,double *arrIngresos,double *arrSalidas,
        double *arrEnviados,double *arrTransferidos,double *arrStockFinal,
        int numRegistros){
    
    for(int i=0;i<numRegistros-1;i++)
        for(int k=i+1;k<numRegistros;k++)
            if(strcmp(arrCodAlmacenProd[i],arrCodAlmacenProd[k])<0 or
                    strcmp(arrCodAlmacenProd[i],arrCodAlmacenProd[k])==0
                    and strcmp(arrCodProdStock[i],arrCodProdStock[k])>0){
                cambiarChar(arrCodAlmacenProd[i],arrCodAlmacenProd[k]);
                cambiarChar(arrCodProdStock[i],arrCodProdStock[k]);
                cambiarDouble(arrStockProducto,i,k);
                cambiarDouble(arrIngresos,i,k);
                cambiarDouble(arrSalidas,i,k);
                cambiarDouble(arrTransferidos,i,k);
                cambiarDouble(arrEnviados,i,k);
                cambiarDouble(arrStockFinal,i,k);
            }
}


void emiteReporte(char **arrCodAlmacen,char **arrNombreAlmacen,
        int *arrCodDistrito,int numAlmacenes,char **arrCodProducto,
        char **arrNombreProducto,int numProductos,char **arrCodProdStock,
        char **arrCodAlmacenProd,double *arrStockProducto,int numRegistros,
        double *arrIngresos,double *arrSalidas,double *arrEnviados,
        double *arrTransferidos,double *arrStockFinal){
    
    ofstream archReporte("ReporteStocksxAlmacen.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR al abrir el ReporteStocksxAlmacen.txt"<<endl;
        exit(1);
    }
    archReporte<<setw(50)<<' '<<"CONSOLIDADO DE STOCKS DE PRODUCTOS POR "
            "ALMACEN"<<endl;
    int posProd;
    for(int i=0;i<numAlmacenes;i++){
        imprimeLinea('=',150,archReporte);
        archReporte<<"Almacen: "<<arrCodAlmacen[i]<<" - "<<left<<setw(35)
                <<arrNombreAlmacen[i]<<setw(10)<<' '<<right<<"Distrito: "
                <<arrCodDistrito[i]<<endl;
        imprimeEncabezado(archReporte);
        for(int k=0;k<numRegistros;k++){
            if(strcmp(arrCodAlmacen[i],arrCodAlmacenProd[k])==0){
                archReporte<<arrCodProdStock[k]<<'-';
                posProd=buscarPosicion(arrCodProducto,arrCodProdStock[k],
                        numProductos);
                archReporte<<left<<setw(60)<<arrNombreProducto[posProd]
                        <<right<<setw(5)<<arrStockProducto[k]<<setw(10)<<' '
                        <<setw(3)<<arrIngresos[k]<<setw(15)<<' '<<setw(3)
                        <<arrSalidas[k]<<setw(15)<<' '<<setw(4)<<arrTransferidos[k]
                        <<setw(20)<<' '<<setw(4)<<arrEnviados[k]<<setw(20)<<' ';
                if(arrStockFinal[k]<0)archReporte<<setw(5)<<arrStockFinal[k]
                        <<setw(10)<<' '<<"Trans. Incorrectas"<<endl;
                else archReporte<<setw(5)<<arrStockFinal[k]<<endl;
            }
        }
    }    
}

void imprimeEncabezado(ofstream &archReporte){
    imprimeLinea('-',150,archReporte);
    archReporte<<"PRODUCTO"<<setw(55)<<' '<<"STOCK INICIAL"<<setw(5)
            <<' '<<"INGRESOS"<<setw(10)<<' '<<"SALIDAS"<<setw(10)<<' '
            <<"ENVIADO A ALM."<<setw(10)<<' '<<"RECIBIDO DE ALM."
            <<setw(10)<<' '<<"STOCK FINAL"<<setw(10)<<' '<<"OBSERVACION"
            <<endl;
    imprimeLinea('-',150,archReporte);
}


int buscarPosicionCompartida(char **arreglo1,char **arreglo2,char *elemento1,
        char *elemento2,int numDatos){
    for(int i=0;i<numDatos;i++)
        if(strcmp(arreglo1[i],elemento1)==0 and 
                strcmp(arreglo2[i],elemento2)==0)return i;
    return NO_ENCONTRADO;
}

int buscarPosicion(char **arreglo, char *elemento, int numDatos){
    for(int i=0;i<numDatos;i++)
        if(strcmp(arreglo[i],elemento)==0)return i;
    return NO_ENCONTRADO;
}

void cambiarChar(char *&elementoI, char*&elementoJ){
    char *aux;
    aux = elementoI;
    elementoI = elementoJ;
    elementoJ = aux;
}

void cambiarInt(int *arreglo,int i,int j){
    int aux;
    aux = arreglo[i];
    arreglo[i]=arreglo[j];
    arreglo[j]=aux;
}

void cambiarDouble(double *arreglo,int i,int j){
    double aux;
    aux = arreglo[i];
    arreglo[i]=arreglo[j];
    arreglo[j]=aux;
}

char *leerCadenaExacta(ifstream &arch){
    char buffer[500],*cadena;
    int longitud;
    
    arch.getline(buffer,500,',');
    if(arch.eof())return nullptr;
    longitud= strlen(buffer);
    cadena = new char[longitud+1];
    
    strcpy(cadena,buffer);
    
    return cadena;
    
}

void imprimeLinea(char caracter, int cantidad, ofstream &archRep){
    for(int i=0;i<cantidad;i++)archRep<<caracter;
    archRep<<endl;
}