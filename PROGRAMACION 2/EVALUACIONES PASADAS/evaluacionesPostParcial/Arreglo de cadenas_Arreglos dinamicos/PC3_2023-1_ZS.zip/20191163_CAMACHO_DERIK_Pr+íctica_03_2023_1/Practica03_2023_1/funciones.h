/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * Alumno: Chupetin
 *
 * Created on 5 de junio de 2023, 07:09 PM
 */


#ifndef FUNCIONES_H
#define FUNCIONES_H

void leerAlmacen(char **arrCodAlmacen,char **arrNombreAlmacen,int *arrCodDistrito,
        int &numAlmacenes);
void leerProductos(char **arrCodProducto,char **arrNombreProducto,
        int &numProductos);
void ordenarAlmacenes(char **arrCodAlmacen,char **arrNombreAlmacen,
        int *arrCodDistrito,int numAlmacenes);
void mostrarAlmacenesOrdenados(char **arrCodAlmacen,char **arrNombreAlmacen,
        int *arrCodDistrito,int numAlmacenes);
void leerStock(char **arrCodProdStock,char **arrCodAlmacenProd,
        double *arrStockProducto,int &numRegistros);
void mostrarStocksProductos(char **arrCodProdStock,char **arrCodAlmacenProd,
        double *arrStockProducto,int numRegistros);
void leerTransacciones(char **arrCodAlmacen,char **arrNombreAlmacen,
        int *arrCodDistrito,int numAlmacenes,char **arrCodProducto,
        char **arrNombreProducto,int numProductos,char **arrCodProdStock,
        char **arrCodAlmacenProd,double *arrStockProducto,int numRegistros,
        double *arrIngresos,double *arrSalidas,double *arrEnviados,
        double *arrTransferidos);
void leeDatosTransacciones(char *ptr_almacen,char **arrCodProdStock,
        char **arrCodAlmacenProd,double *arrStockProducto,int numRegistros,
        char **arrCodProducto,char **arrNombreProducto,int numProductos,
        double *arrIngresos,double *arrSalidas,double *arrEnviados,
        double *arrTransferidos,ifstream &archTransacciones);
void actualizaStockFinal(double *arrStockProducto,double *arrIngresos,
        double *arrSalidas,double *arrEnviados,
            double *arrTransferidos,double *arrStockFinal,int numRegistros);
void ordenarProdAlmacenes(char **arrCodProdStock,char **arrCodAlmacenProd,
        double *arrStockProducto,double *arrIngresos,double *arrSalidas,
        double *arrEnviados,double *arrTransferidos,double *arrStockFinal,
        int numRegistros);
void emiteReporte(char **arrCodAlmacen,char **arrNombreAlmacen,
        int *arrCodDistrito,int numAlmacenes,char **arrCodProducto,
        char **arrNombreProducto,int numProductos,char **arrCodProdStock,
        char **arrCodAlmacenProd,double *arrStockProducto,int numRegistros,
        double *arrIngresos,double *arrSalidas,double *arrEnviados,
        double *arrTransferidos,double *arrStockFinal);
void imprimeEncabezado(ofstream &archReporte);
int buscProducto(char **arrCodProducto,char *elemento,int numProductos);
int buscarPosicionCompartida(char **arreglo1,char **arreglo2,char *elemento1,
        char *elemento2,int numDatos);
int buscarPosicion(char **arreglo, char *elemento, int numDatos);
void cambiarChar(char*& elementoI, char*& elementoJ);
void cambiarInt(int* arreglo, int i, int j);
void cambiarDouble(double *arreglo,int i,int j);
char *leerCadenaExacta(ifstream& arch);
void imprimeLinea(char caracter, int cantidad, ofstream &archRep);

#endif /* FUNCIONES_H */

