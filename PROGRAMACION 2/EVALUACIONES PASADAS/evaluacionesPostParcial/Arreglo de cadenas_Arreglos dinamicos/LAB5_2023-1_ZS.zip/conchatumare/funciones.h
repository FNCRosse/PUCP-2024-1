

/* 
 * File:   funciones.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 29 de mayo de 2023, 10:42 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void leerDatosProductos(int *arrCodProducto,int *arrCodAlmacenProducto,
        int *arrStockInicial,int &numProductos);
void solicitudFecha(int &diaInicial,int &mesInicial,int &anioInicial,
        int &diaFinal,int &mesFinal,int &anioFinal);
void leerTransacciones(int diaInicial,int mesInicial,int anioInicial,
        int diaFinal,int mesFinal,int anioFinal,int *arrCodProducto,
        int *arrCodAlmacenProducto,int numProductos,int *arrIngresos,
        int *arrSalidas,int *arrEnviados,int *arrRecibidos);
void almacenarDatosTransacciones(int codigo_almacen,int *arrCodAlmacenProducto,
        int *arrCodProducto,int numProductos,int *arrIngresos,int *arrSalidas,
        int *arrEnviados,int *arrRecibidos,ifstream &archTransacciones);
void actualizarStockFinal(int *arrStockFinal,int *arrStockInicial,
        int *arrIngresos,int *arrSalidas,int *arrEnviados,int *arrRecibidos,
        int numProductos);
void ordenarArreglos(int *arrCodProducto,int *arrCodAlmacenProducto,
        int *arrStockInicial,int *arrStockFinal,int *arrIngresos,
        int *arrSalidas,int *arrEnviados,int *arrRecibidos,int numProductos);
void cambiarInt(int* arreglo, int i, int j);
void emiteReporte(int diaInicial,int mesInicial,int anioInicial,int diaFinal,
        int mesFinal,int anioFinal,int *arrCodProducto,int *arrCodAlmacenProducto,
        int *arrStockInicial,int *arrStockFinal,int *arrIngresos,
        int *arrSalidas,int *arrEnviados,int *arrRecibidos,int numProductos);
void buscaImprimeProducto(int codigo_producto,ofstream &archReporte);
int longitud(char *cadena);
void modificarNombre(char *nombre,char *nombreModificado);
void copiar(char *destino, char *fuente);
int buscaProducto(int *arrCodAlmacenProducto,int *arrCodProducto,
        int codigoProducto,int codigoAlmacen,int numProductos);
int buscarPosicion(int *arreglo, int elemento, int numDatos);
int juntarFecha(int dia,int mes,int anio);
void imprimeLinea(char caracter, int cantidad, ofstream& archRep);

#endif /* FUNCIONES_H */

