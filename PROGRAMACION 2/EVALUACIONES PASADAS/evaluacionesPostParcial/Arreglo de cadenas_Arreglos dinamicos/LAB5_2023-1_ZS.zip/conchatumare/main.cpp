

/* 
 * File:   main.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 29 de mayo de 2023, 10:41 PM
 */

#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

#define MAX_PRODUCTOS 300
#include "funciones.h"

/*
 * 
 */
int main(int argc, char** argv) {
    
    
    int arrCodProducto[MAX_PRODUCTOS],arrCodAlmacenProducto[MAX_PRODUCTOS],
            arrStockInicial[MAX_PRODUCTOS],numProductos;
    int arrIngresos[MAX_PRODUCTOS]{},arrSalidas[MAX_PRODUCTOS]{},
            arrEnviados[MAX_PRODUCTOS]{},arrRecibidos[MAX_PRODUCTOS]{},
            arrStockFinal[MAX_PRODUCTOS];
    
    leerDatosProductos(arrCodProducto,arrCodAlmacenProducto,arrStockInicial,
            numProductos);
    int diaInicial,mesInicial,anioInicial,diaFinal,mesFinal,anioFinal;
    solicitudFecha(diaInicial,mesInicial,anioInicial,diaFinal,mesFinal,
            anioFinal);
    leerTransacciones(diaInicial,mesInicial,anioInicial,diaFinal,mesFinal,
            anioFinal,arrCodProducto,arrCodAlmacenProducto,numProductos,
            arrIngresos,arrSalidas,arrEnviados,arrRecibidos);
    actualizarStockFinal(arrStockFinal,arrStockInicial,arrIngresos,arrSalidas,
            arrEnviados,arrRecibidos,numProductos);
    ordenarArreglos(arrCodProducto,arrCodAlmacenProducto,arrStockInicial,
            arrStockFinal,arrIngresos,arrSalidas,arrEnviados,arrRecibidos,
            numProductos);
    emiteReporte(diaInicial,mesInicial,anioInicial,diaFinal,mesFinal,
            anioFinal,arrCodProducto,arrCodAlmacenProducto,arrStockInicial,
            arrStockFinal,arrIngresos,arrSalidas,arrEnviados,arrRecibidos,
            numProductos);
    return 0;
}

