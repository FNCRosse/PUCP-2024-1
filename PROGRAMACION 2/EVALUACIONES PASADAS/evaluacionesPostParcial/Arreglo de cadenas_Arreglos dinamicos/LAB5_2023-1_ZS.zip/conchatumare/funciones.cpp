

/* 
 * File:   funciones.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 29 de mayo de 2023, 10:42 PM
 */


#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

#define MAX_CAR 60
#define MAX_LINE 200
#define NO_ENCONTRADO -1
#include "funciones.h"


void leerDatosProductos(int *arrCodProducto,int *arrCodAlmacenProducto,
        int *arrStockInicial,int &numProductos){
    
    ifstream archProductos("StockProductos.txt",ios::in);
    if(not archProductos.is_open()){
        cout<<"ERROR al abrir el archivo de StockProductos"<<endl;
        exit(1);
    }
    
    int codigo_producto,codigoAlmacen_producto,stock;
    numProductos=0;
    while(true){
        archProductos>>codigo_producto;
        if(archProductos.eof())break;
        archProductos>>codigoAlmacen_producto>>stock;
        
        arrCodProducto[numProductos]=codigo_producto;
        arrCodAlmacenProducto[numProductos]=codigoAlmacen_producto;
        arrStockInicial[numProductos]=stock;
        numProductos++;
    }
}

void solicitudFecha(int &diaInicial,int &mesInicial,int &anioInicial,
        int &diaFinal,int &mesFinal,int &anioFinal){
    char c;
    cout<<"Ingrese el rango de fechas en el siguiente formato (DD/MM/AA):"<<endl;
    cin>>diaInicial>>c>>mesInicial>>c>>anioInicial;
    cin>>diaFinal>>c>>mesFinal>>c>>anioFinal;
}

void leerTransacciones(int diaInicial,int mesInicial,int anioInicial,
        int diaFinal,int mesFinal,int anioFinal,int *arrCodProducto,
        int *arrCodAlmacenProducto,int numProductos,int *arrIngresos,
        int *arrSalidas,int *arrEnviados,int *arrRecibidos){
    
    ifstream archTransacciones("Transacciones.txt",ios::in);
    if(not archTransacciones.is_open()){
        cout<<"ERROR al abrir el archivo de Transacciones"<<endl;
        exit(1);
    }
    
    int codigoAlmacen_evaluar,dia,mes,anio,fechaAux,posAlmacen;
    int fechaInicial=juntarFecha(diaInicial,mesInicial,anioInicial);
    int fechaFinal=juntarFecha(diaFinal,mesFinal,anioFinal);
    char c;
    while(true){
        archTransacciones>>codigoAlmacen_evaluar;
        if(archTransacciones.eof())break;
        archTransacciones>>dia>>c>>mes>>c>>anio;
        fechaAux=juntarFecha(dia,mes,anio);
        if(fechaAux>=fechaInicial and fechaAux<=fechaFinal){
            posAlmacen=buscarPosicion(arrCodAlmacenProducto,
                    codigoAlmacen_evaluar,numProductos);
            if(posAlmacen!=NO_ENCONTRADO){
                while(true){
                    almacenarDatosTransacciones(arrCodAlmacenProducto[posAlmacen],
                            arrCodAlmacenProducto,arrCodProducto,
                            numProductos,arrIngresos,arrSalidas,
                            arrEnviados,arrRecibidos,archTransacciones);
                    if(archTransacciones.get()=='\n')break;
                }
            }else while(archTransacciones.get()!='\n');
        }else while(archTransacciones.get()!='\n');
    }
}

void almacenarDatosTransacciones(int codigo_almacen,int *arrCodAlmacenProducto,
        int *arrCodProducto,int numProductos,int *arrIngresos,int *arrSalidas,
        int *arrEnviados,int *arrRecibidos,ifstream &archTransacciones){   
    int hora,minuto,segundo,codigoAlmacen_adicional,codProducto_evaluar,
            cantidad,posProducto,posProducto_otroAlmacen;
    char c,tipo_transaccion;
    archTransacciones>>hora>>c>>minuto>>c>>segundo;
    archTransacciones>>codProducto_evaluar>>cantidad;
    archTransacciones>>tipo_transaccion;
    /*se realiza la busqueda del producto mediante dos arreglos, es decir,
     evaluando el producto y el almacen al cual pertenece*/
    posProducto=buscaProducto(arrCodAlmacenProducto,arrCodProducto,
            codProducto_evaluar,codigo_almacen,numProductos);
    if(posProducto!=NO_ENCONTRADO){
        if(tipo_transaccion=='I'){
            arrIngresos[posProducto]+=cantidad;
        }else if(tipo_transaccion=='S'){
            arrSalidas[posProducto]+=cantidad;
        }else if(tipo_transaccion=='T'){
            archTransacciones>>codigoAlmacen_adicional;            
            posProducto_otroAlmacen=buscaProducto(arrCodAlmacenProducto,
                    arrCodProducto,codProducto_evaluar,codigoAlmacen_adicional,
                    numProductos);
            if(posProducto_otroAlmacen!=NO_ENCONTRADO){
                //Si se envia a otro almacen
                if(codigoAlmacen_adicional!=codigo_almacen){
                    arrEnviados[posProducto]+=cantidad;
                    arrRecibidos[posProducto_otroAlmacen]+=cantidad;
                }else if(codigoAlmacen_adicional==codigo_almacen){
                    //Si se recibe de otro almacen
                    arrRecibidos[posProducto]+=cantidad;
                }   
            }else return;
        }
    }
}

void actualizarStockFinal(int *arrStockFinal,int *arrStockInicial,
        int *arrIngresos,int *arrSalidas,int *arrEnviados,int *arrRecibidos,
        int numProductos){
    for(int i=0;i<numProductos;i++)
        arrStockFinal[i]=arrStockInicial[i]+arrIngresos[i]-arrSalidas[i]-
                arrEnviados[i]+arrRecibidos[i];
}

void ordenarArreglos(int *arrCodProducto,int *arrCodAlmacenProducto,
        int *arrStockInicial,int *arrStockFinal,int *arrIngresos,
        int *arrSalidas,int *arrEnviados,int *arrRecibidos,int numProductos){
    for(int i=0;i<numProductos-1;i++)
        for(int k=i+1;k<numProductos;k++)
            if(arrCodAlmacenProducto[i]>arrCodAlmacenProducto[k] or
                    arrCodAlmacenProducto[i]==arrCodAlmacenProducto[k] and
                    arrCodProducto[i]<arrCodProducto[k]){
                cambiarInt(arrCodProducto,i,k);
                cambiarInt(arrCodAlmacenProducto,i,k);
                cambiarInt(arrStockInicial,i,k);
                cambiarInt(arrIngresos,i,k);
                cambiarInt(arrSalidas,i,k);
                cambiarInt(arrEnviados,i,k);
                cambiarInt(arrRecibidos,i,k);
                cambiarInt(arrStockFinal,i,k);
            }
}

void cambiarInt(int *arreglo,int i,int j){
    int aux;
    aux=arreglo[i];
    arreglo[i]=arreglo[j];
    arreglo[j]=aux;
}

void emiteReporte(int diaInicial,int mesInicial,int anioInicial,int diaFinal,
        int mesFinal,int anioFinal,int *arrCodProducto,int *arrCodAlmacenProducto,
        int *arrStockInicial,int *arrStockFinal,int *arrIngresos,
        int *arrSalidas,int *arrEnviados,int *arrRecibidos,int numProductos){
    ofstream archReporte("ReporteStocksxAlmacen.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR al abrir el archivo de ReporteStocksxAlmacen.txt"<<endl;
        exit(1);
    }
    archReporte<<setw(50)<<' '<<"CONSOLIDADO DE STOCKS DE PRODUCTOS POR "
            "ALMACEN"<<endl;
    archReporte<<setw(56)<<' '<<"DEL "<<setfill('0')<<setw(2)<<diaInicial
            <<'/'<<setw(2)<<mesInicial<<'/'<<anioInicial<<setfill(' ')
            <<" AL "<<setfill('0')<<setw(2)<<diaFinal<<'/'<<setw(2)<<mesFinal
            <<'/'<<anioFinal<<setfill(' ')<<endl;
    for(int i=0;i<numProductos;i++){
        if(arrCodAlmacenProducto[i]!=arrCodAlmacenProducto[i+1]){
            imprimeLinea('=',MAX_LINE,archReporte);
            archReporte<<"Almacen: "<<arrCodAlmacenProducto[i]<<endl;
            imprimeLinea('-',MAX_LINE,archReporte);
            archReporte<<"PRODUCTO"<<setw(75)<<' '<<"STOCK INICIAL"
                        <<setw(10)<<' '<<"INGRESOS"<<setw(10)<<' '<<"SALIDAS"
                        <<setw(20)<<"ENVIADOS A ALM."<<setw(25)<<"RECIBIDOS "
                        "DE ALM."<<setw(20)<<"STOCK FINAL"<<setw(25)
                        <<"OBSERVACION"<<endl;
            for(int k=0;k<numProductos;k++){
                if(arrCodAlmacenProducto[i]==arrCodAlmacenProducto[k]){                
                    archReporte<<arrCodProducto[k];
                    buscaImprimeProducto(arrCodProducto[k],archReporte);
                    archReporte<<setw(25)<<arrStockInicial[k]<<setw(20)
                                <<arrIngresos[k]<<setw(18)<<arrSalidas[k]<<setw(15)
                                <<arrEnviados[k]<<setw(24)<<arrRecibidos[k];
                        if(arrStockFinal[k]<0)archReporte<<setw(24)<<arrStockFinal[k]
                                <<setw(15)<<' '<<"Trans. Incorrectas"<<endl;
                        else archReporte<<setw(24)<<arrStockFinal[k]<<endl;
                }
            }
        }
    }
}

void buscaImprimeProducto(int codigo_producto,ofstream &archReporte){
    
    ifstream archProducto("Productos.txt",ios::in);
    if(not archProducto.is_open()){
        cout<<"ERROR al abrir el archivo de Productos"<<endl;
        exit(1);
    }
    int codigoProducto_evaluar,tam;
    char nombre[60],nombreModificado[60];
    while(true){
        archProducto>>codigoProducto_evaluar;
        if(archProducto.eof())break;
        if(codigoProducto_evaluar==codigo_producto){
            archProducto>>nombre;
            modificarNombre(nombre,nombreModificado);
            archReporte<<nombreModificado;
            tam=longitud(nombreModificado);
            archReporte<<setw(MAX_CAR-tam)<<' ';
            return;
        }else while(archProducto.get()!='\n');
    }
}

int longitud(char *cadena){
    int nCar;
    for(nCar=0;cadena[nCar];nCar++);
    return nCar;
}

void modificarNombre(char *nombre,char *nombreModificado){
    
    for(int i=0;nombre[i];i++)
        if(nombre[i]=='(' or nombre[i]==')' or nombre[i]=='-')nombre[i]=' ';
    
    copiar(nombreModificado,nombre);
}

void copiar(char *destino,char *fuente){
    int i=0;
    while(true){
        destino[i]=fuente[i];
        if(fuente[i]==0)break;
        i++;
    }
}

int buscaProducto(int *arrCodAlmacenProducto,int *arrCodProducto,
        int codigoProducto,int codigoAlmacen,int numProductos){
    
    for(int i=0;i<numProductos;i++)
        if(arrCodProducto[i]==codigoProducto and 
                arrCodAlmacenProducto[i]==codigoAlmacen)return i;
    return NO_ENCONTRADO;
}

int buscarPosicion(int *arreglo, int elemento, int numDatos){
    for(int i=0;i<numDatos;i++)
        if(arreglo[i]==elemento)return i;
    return NO_ENCONTRADO;
}

int juntarFecha(int dia,int mes,int anio){
    
    int fechaJuntada=anio*10000+mes*100+dia;
    return fechaJuntada;
}

void imprimeLinea(char caracter, int cantidad, ofstream &archRep){
    for(int i=0;i<cantidad;i++)archRep<<caracter;
    archRep<<endl;
}
