

/* 
 * File:   funciones.cpp
 * Author: alguien de ahi
 *
 * Created on 28 de mayo de 2023, 09:59 AM
 */


#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

#define NO_ENCONTRADO -1
#define MAX_CARAC 30
#define MAX_LINE 150
#include "funciones.h"

void leerProductos(int *arrCodProducto,int *arrStockProducto,
        double *arrPrecioProducto,int &numProductos){
    
    ifstream archProductos("StockDeProductosAlmacenados.txt",ios::in);
    if(not archProductos.is_open()){
        cout<<"ERROR al abrir el archivo de StockDeProductosAlmacenados"<<endl;
        exit(1);
    }
    
    int codigo_producto,stock;
    double precio;
    numProductos=0;
    
    while(true){
        archProductos>>codigo_producto;
        if(archProductos.eof())break;
        archProductos>>stock>>precio;
        
        arrCodProducto[numProductos]=codigo_producto;
        arrStockProducto[numProductos]=stock;
        arrPrecioProducto[numProductos]=precio;
        
        numProductos++;
    }
}

void ordenarProductos(int *arrCodProducto,int *arrStockProducto,
        double *arrPrecioProducto,int numProductos){
    
    for(int i=0;i<numProductos-1;i++)
        for(int k=i+1;k<numProductos;k++)
            if(arrCodProducto[i]>arrCodProducto[k]){
                cambiarInt(arrCodProducto,i,k);
                cambiarInt(arrStockProducto,i,k);
                cambiarDouble(arrPrecioProducto,i,k);
            }
}

void leerPedidos(int *arrCodPedido,int *arrFechaPedidos,int *arrHoraPedidos,
        int *arrDniPedido,int &numPedidos){
    
    ifstream archPedidos("Pedidos.txt",ios::in);
    if(not archPedidos.is_open()){
        cout<<"ERROR al abrir el archivo de Pedidos"<<endl;
        exit(1);
    }
    
    int codigo_pedido,dia,mes,anio,hora,minuto,segundo,dni_pedido,
            numeroHora,numeroFecha;
    char c;
    numPedidos=0;
    while(true){
        archPedidos>>codigo_pedido;
        if(archPedidos.eof())break;
        archPedidos>>dia>>c>>mes>>c>>anio;
        archPedidos>>hora>>c>>minuto>>c>>segundo;
        archPedidos>>dni_pedido;
        numeroFecha=juntarDatos(anio,mes,dia);
        numeroHora=juntarDatos(hora,minuto,segundo);
        
        arrCodPedido[numPedidos]=codigo_pedido;
        arrFechaPedidos[numPedidos]=numeroFecha;
        arrHoraPedidos[numPedidos]=numeroHora;
        arrDniPedido[numPedidos]=dni_pedido;
        numPedidos++;
    }
}

void ordenarArreglos(int *arrCodPedido,int *arrFechaPedidos,int *arrHoraPedidos,
        int *arrDniPedido,int numPedidos){
    
    for(int i=0;i<numPedidos-1;i++)
        for(int k=i+1;k<numPedidos;k++)
            if(arrFechaPedidos[i]>arrFechaPedidos[k] or 
                    arrFechaPedidos[i]==arrFechaPedidos[k] and 
                    arrHoraPedidos[i]>arrHoraPedidos[k] or 
                    arrFechaPedidos[i]==arrFechaPedidos[k] and 
                    arrHoraPedidos[i]==arrHoraPedidos[k] and
                    arrCodPedido[i]>arrCodPedido[k]){
                cambiarInt(arrCodPedido,i,k);
                cambiarInt(arrFechaPedidos,i,k);
                cambiarInt(arrHoraPedidos,i,k);
                cambiarInt(arrDniPedido,i,k);
            }
}

void cambiarDouble(double *arreglo,int i,int j){
    double aux;
    aux=arreglo[i];
    arreglo[i]=arreglo[j];
    arreglo[j]=aux;
}

void cambiarInt(int *arreglo,int i,int j){
    int aux;
    aux = arreglo[i];
    arreglo[i]=arreglo[j];
    arreglo[j]=aux;
}

void leerDetalles(int *arrPedidoDetalle,int *arrProdDetalle,int *arrCantDetalle,
        int &numDetalles){
    
    ifstream archDetalles("DetalleDeLosPedidos.txt",ios::in);
    if(not archDetalles.is_open()){
        cout<<"ERROR al abrir el archivo de DetalleDeLosPedidos"<<endl;
        exit(1);
    }
    
    int codPedido_detalle,producto_detalle,cantidad_detalle;
    numDetalles=0;
    
    while(true){
        archDetalles>>codPedido_detalle;
        if(archDetalles.eof())break;
        archDetalles>>producto_detalle;
        archDetalles>>cantidad_detalle;
        
        arrPedidoDetalle[numDetalles]=codPedido_detalle;
        arrProdDetalle[numDetalles]=producto_detalle;
        arrCantDetalle[numDetalles]=cantidad_detalle;
        numDetalles++;
    }
}

void emiteReporte(int *arrCodProducto,int *arrStockProducto,
        double *arrPrecioProducto,int numProductos,int *arrCodPedido,
        int *arrFechaPedidos,int *arrHoraPedidos,int *arrDniPedido,
        int numPedidos,int *arrPedidoDetalle,int *arrProdDetalle,
        int *arrCantDetalle,int numDetalles){
    
    ofstream archReporte("ReporteDepedidos.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR al abrir el archivo de ReporteDepedidos"<<endl;
        exit(1);
    }
    archReporte<<setprecision(2);
    archReporte<<fixed;
    imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<setw(50)<<' '<<"TIENDA VIRTUAL LA MAGNIFICA"<<endl;
    archReporte<<setw(49)<<' '<<"REPORTE DE ATENCION DE PEDIDOS"<<endl;
    imprimeLinea('-',MAX_LINE,archReporte);
    int dia,mes,anio,hora,min,segundo;
    for(int i=0;i<numPedidos;i++){
        archReporte<<"No. de pedido"<<setw(10)<<' '<<"DNI"<<setw(10)<<' '
                <<"Nombre"<<setw(23)<<' '<<"Fecha:"<<setw(10)<<' '<<"Hora"<<endl;
        archReporte<<setw(4)<<' '<<arrCodPedido[i]<<setw(10)<<' '
                <<arrDniPedido[i]<<setw(5)<<' ';
        buscaImprimeNombre(arrDniPedido[i],archReporte);
        separaDatos(arrFechaPedidos[i],anio,mes,dia);
        separaDatos(arrHoraPedidos[i],hora,min,segundo);
        archReporte<<setfill('0')<<setw(2)<<dia<<'/'<<setw(2)
                <<mes<<'/'<<setw(4)<<anio<<setfill(' ')<<setw(6)<<' '
                <<setfill('0')<<setw(2)<<hora<<':'<<setw(2)<<min<<':'
                <<setw(2)<<segundo<<setfill(' ')<<endl;
        imprimeLinea('-',MAX_LINE,archReporte);
        imprimeProductos(arrCodPedido[i],arrCodProducto,arrStockProducto,
                arrPrecioProducto,numProductos,arrPedidoDetalle,
                arrProdDetalle,arrCantDetalle,numDetalles,archReporte);
    }
}

void imprimeProductos(int codigoPedido,int *arrCodProducto,int *arrStockProducto,
        double *arrPrecioProducto,int numProductos,int *arrPedidoDetalle,
        int *arrProdDetalle,int *arrCantDetalle,int numDetalles,
        ofstream &archReporte){
    int contador=0,posProducto,cantSolicitada=0,cantAtendida=0;
    double total=0;
    archReporte<<setw(5)<<' '<<"Producto"<<setw(5)<<' '<<"CANTIDAD SOLICITADA"
            <<setw(5)<<' '<<"CANTIDAD ATENDIDA"<<setw(5)<<' '<<"Precio"
            <<setw(5)<<' '<<"SubTotal"<<endl;
    for(int i=0;i<numDetalles;i++){
        if(arrPedidoDetalle[i]==codigoPedido){
            posProducto=busquedaBinaria(arrCodProducto,arrProdDetalle[i],
                    numProductos);
            if(posProducto!=NO_ENCONTRADO){
                cantSolicitada=arrCantDetalle[i];
                if(arrStockProducto[posProducto]>=cantSolicitada){
                    cantAtendida = cantSolicitada;
                    arrStockProducto[posProducto] -= cantSolicitada;
                }else {
                    cantAtendida = arrStockProducto[posProducto];
                    arrStockProducto[posProducto] = 0;
                }
                contador++;
                archReporte<<setw(4)<<contador<<") "<<arrProdDetalle[i]
                        <<setw(15)<<' '<<setw(3)<<cantSolicitada<<setw(20)
                        <<' '<<setw(3)<<cantAtendida<<setw(13)<<' '
                        <<setw(5)<<arrPrecioProducto[posProducto]<<setw(7)
                        <<' '<<setw(6)<<arrPrecioProducto[posProducto]*
                        cantAtendida<<endl;
                total+=arrPrecioProducto[posProducto]*cantAtendida;
            } 
        }
    }
    imprimeLinea('-',MAX_LINE,archReporte);
    archReporte<<"Total a cobrar: "<<setw(12)<<total<<endl;
    imprimeLinea('=',MAX_LINE,archReporte);
}

void buscaImprimeNombre(int dni,ofstream &archReporte){
    
    ifstream archClientes("ClientesRegistrados.txt",ios::in);
    if(not archClientes.is_open()){
        cout<<"ERROR al abrir el archivo de ClientesRegistrados"<<endl;
        exit(1);
    }
    
    int tam;
    char nombre[60],nombreModificado[60];
    int dni_evaluar;
    while(true){
        archClientes>>nombre;
        if(archClientes.eof())break;
        archClientes>>dni_evaluar;
        if(dni_evaluar==dni){
            modificarNombre(nombre,nombreModificado);
            pasarMinusMayus(nombreModificado);
            archReporte<<nombreModificado;
            tam=longitd(nombreModificado);
            archReporte<<setw(MAX_CARAC-tam)<<' ';
            return;
        }
    }
    
}

void pasarMinusMayus(char *nombreModificado){
    
    int primeraLetra=0;
    for(int i=0;nombreModificado[i];i++){ 
        if(nombreModificado[i]==' ')primeraLetra=0;//Se viene otro primer caracter
        else
            if(primeraLetra)nombreModificado[i] +='a'-'A'; 
            else primeraLetra = 1;  /*Ya pasó la primera letra*/
    }
}

void modificarNombre(char *nombre,char *nombreModificado){
    int j,primerSeparador=1;
    for(int i=0;nombre[i];i++){
        if(nombre[i]=='/' and primerSeparador){
            i++;
            primerSeparador=0;
            for(j=0;nombre[i]!='/';j++){
                nombreModificado[j]=nombre[i];
                i++;
            }
        }
    }
    nombreModificado[j]=' ';
    j++;
    for(int i=0;!primerSeparador;i++){
        if(nombre[i]=='-' or nombre[i]=='/')primerSeparador=1;
        else {
            nombreModificado[j]=nombre[i];
            j++;
        }
    } 
    nombreModificado[j]='\0';
}

int longitd(char *cadena){
    int numCar;
    for(numCar=0;cadena[numCar];numCar++);
    return numCar;
}

int busquedaBinaria(int *arreglo,int dato,int numDatos){
    int limiteInferior,limiteSuperior,puntoMedio;
    limiteInferior=0;
    limiteSuperior=numDatos-1;
    
    while(true){
        if(limiteInferior>limiteSuperior)return NO_ENCONTRADO;
        puntoMedio=(limiteInferior+limiteSuperior)/2;
        if(dato==arreglo[puntoMedio])return puntoMedio;
        if(dato < arreglo[puntoMedio])
            limiteSuperior=puntoMedio-1;
        else
            limiteInferior=puntoMedio+1;
    }
}

void separaDatos(int numero,int &a,int &b,int &c){
    
    a = numero/10000;
    b = (numero%10000)/100;
    c = (numero%10000)%100;
}

int juntarDatos(int c,int b,int a){
    
    int numero= c*10000 + b*100+a;
    return numero;
}

void imprimeLinea(char caracter, int cantidad, ofstream &archReporte){
    for(int i=0;i<cantidad;i++)archReporte<<caracter;
    archReporte<<endl;
}

