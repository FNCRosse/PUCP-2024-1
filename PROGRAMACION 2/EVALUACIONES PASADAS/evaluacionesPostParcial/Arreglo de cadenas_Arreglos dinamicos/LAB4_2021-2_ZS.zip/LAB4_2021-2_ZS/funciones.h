

/* 
 * File:   funciones.h
 * Author: alguien de ahi
 *
 * Created on 28 de mayo de 2023, 09:59 AM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void leerProductos(int *arrCodProducto,int *arrStockProducto,
        double *arrPrecioProducto,int &numProductos);
void ordenarProductos(int *arrCodProducto,int *arrStockProducto,
        double *arrPrecioProducto,int numProductos);
void leerPedidos(int* arrCodPedido, int* arrFechaPedidos, int* arrHoraPedidos,
        int* arrDniPedido, int& numPedidos);
void ordenarArreglos(int* arrCodPedido, int* arrFechaPedidos,
        int* arrHoraPedidos, int* arrDniPedido, int numPedidos);
void cambiarInt(int *arreglo,int i,int j);
void cambiarDouble(double* arreglo, int i, int j);
void leerDetalles(int *arrPedidoDetalle,int *arrProdDetalle,int *arrCantDetalle,
        int &numDetalles);
void emiteReporte(int *arrCodProducto,int *arrStockProducto,
        double *arrPrecioProducto,int numProductos,int *arrCodPedido,
        int *arrFechaPedidos,int *arrHoraPedidos,int *arrDniPedido,
        int numPedidos,int *arrPedidoDetalle,int *arrProdDetalle,
        int *arrCantDetalle,int numDetalles);
void imprimeProductos(int codigoPedido,int *arrCodProducto,int *arrStockProducto,
        double *arrPrecioProducto,int numProductos,int *arrPedidoDetalle,
        int *arrProdDetalle,int *arrCantDetalle,int numDetalles,
        ofstream &archReporte);
void buscaImprimeNombre(int dni,ofstream &archReporte);
void pasarMinusMayus(char *nombreModificado);
void modificarNombre(char *nombre,char *nombreModificado);
int longitd(char *cadena);
int busquedaBinaria(int *arreglo,int dato,int numDatos);
void separaDatos(int numero,int &a,int &b,int &c);
int juntarDatos(int c,int b,int a);
void imprimeLinea(char caracter, int cantidad, ofstream &archReporte);

#endif /* FUNCIONES_H */

