

/* 
 * File:   main.cpp
 * Author: alguien de ahi
 *
 * Created on 28 de mayo de 2023, 09:59 AM
 */

#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

#define MAX_DETALLES 500
#define MAX_PEDIDOS 50
#define MAX_PRODUCTOS 100
#include "funciones.h"
/*
 * 
 */
int main(int argc, char** argv) {
    
    int arrCodProducto[MAX_PRODUCTOS],arrStockProducto[MAX_PRODUCTOS],
            numProductos;
    double arrPrecioProducto[MAX_PRODUCTOS];
    
    int arrCodPedido[MAX_PEDIDOS],arrFechaPedidos[MAX_PEDIDOS],
            arrHoraPedidos[MAX_PEDIDOS],arrDniPedido[MAX_PEDIDOS],numPedidos;
    
    int arrPedidoDetalle[MAX_DETALLES],arrProdDetalle[MAX_DETALLES],
            arrCantDetalle[MAX_DETALLES],numDetalles;
    leerProductos(arrCodProducto,arrStockProducto,arrPrecioProducto,
            numProductos);
    ordenarProductos(arrCodProducto,arrStockProducto,arrPrecioProducto,
            numProductos);
    leerPedidos(arrCodPedido,arrFechaPedidos,arrHoraPedidos,
            arrDniPedido,numPedidos);
    ordenarArreglos(arrCodPedido,arrFechaPedidos,arrHoraPedidos,arrDniPedido,
            numPedidos);
    leerDetalles(arrPedidoDetalle,arrProdDetalle,arrCantDetalle,numDetalles);
    emiteReporte(arrCodProducto,arrStockProducto,arrPrecioProducto,
            numProductos,arrCodPedido,arrFechaPedidos,arrHoraPedidos,
            arrDniPedido,numPedidos,arrPedidoDetalle,arrProdDetalle,
            arrCantDetalle,numDetalles);
    return 0;
}

