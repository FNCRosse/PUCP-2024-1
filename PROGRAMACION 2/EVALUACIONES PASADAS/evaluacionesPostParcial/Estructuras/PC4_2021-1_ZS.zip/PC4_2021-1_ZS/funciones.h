

/* 
 * File:   funciones.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 7 de junio de 2023, 11:28 AM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

#include "Bus.h"
#include "Pasajero.h"

void leerDatosBuses(struct Buses *bus,int &numBuses);
void leerBuses(ifstream &archBuses, struct Buses &bus);
void ordenarBuses(struct Buses *bus,int numBuses);
void cambiar(Buses& busI, Buses& busK);
void leerDatosPasajeros(struct Buses *bus,int numBuses,
        struct Pasajeros *listaDeEspera,int &numEspera);
void leerPasajeros(ifstream &archPasajeros,struct Buses *bus,int numBuses,
        struct Pasajeros *listaDeEspera,int &numEspera);
void modificaNombre(char *cadena);
void emiteReporte(struct Buses *bus,int numBuses,
        struct Pasajeros *listaDeEspera,int numEspera);
void imprimeLinea(char caracter, int cantidad, ofstream &archRep);
int buscarPosicion(struct Buses *bus,char *destino,int numBuses);
char *leerCadenaExacta(ifstream &arch);
#endif /* FUNCIONES_H */

