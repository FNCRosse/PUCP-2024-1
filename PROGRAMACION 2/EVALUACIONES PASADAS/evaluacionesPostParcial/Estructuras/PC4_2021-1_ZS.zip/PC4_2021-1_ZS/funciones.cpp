

/* 
 * File:   funciones.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 7 de junio de 2023, 11:28 AM
 */


#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>

using namespace std;

#include "Bus.h"
#include "Pasajero.h"
#include "funciones.h"


void leerDatosBuses(struct Buses *bus,int &numBuses){
    
    ifstream archBuses("Buses.csv",ios::in);
    if(not archBuses.is_open()){
        cout<<"ERROR al abrir el archivo de Buses.csv"<<endl;
        exit(1);
    }
    numBuses=0;
    while(true){
        leerBuses(archBuses,bus[numBuses]);
        if(archBuses.eof())break;
        numBuses++;
    }
}

void leerBuses(ifstream &archBuses, struct Buses &bus){
    
    int numCiudades=0;
    bus.placa=leerCadenaExacta(archBuses);
    if(archBuses.eof())return;
    bus.chofer=leerCadenaExacta(archBuses);
    while(true){
        archBuses>>bus.numeroDeAsientos;
        if(archBuses.fail()){
            archBuses.clear();
            bus.ciudadesDestino[numCiudades]=leerCadenaExacta(archBuses);
            numCiudades++;
        }else break;
    }
    archBuses.get();
    bus.numeroDeCiudades=numCiudades;
    bus.pasajeros= new struct Pasajeros[bus.numeroDeAsientos];
    bus.numeroDePasajeros=0;
    
}

void ordenarBuses(struct Buses *bus,int numBuses){
    
    for(int i=0;i<numBuses-1;i++)
        for(int k=i+1;k<numBuses;k++)
            if(bus[i].numeroDeCiudades<bus[k].numeroDeCiudades or 
                    bus[i].numeroDeCiudades==bus[k].numeroDeCiudades and
                    bus[i].numeroDeAsientos>bus[k].numeroDeAsientos){
                cambiar(bus[i],bus[k]);
            }
}

void cambiar(struct Buses &busI,struct Buses &busK){
    struct Buses aux;
    aux = busI;
    busI=busK;
    busK=aux;
    
}

void leerDatosPasajeros(struct Buses *bus,int numBuses,
        struct Pasajeros *listaDeEspera,int &numEspera){    
    ifstream archPasajeros("Pasajeros.csv",ios::in);
    if(not archPasajeros.is_open()){
        cout<<"ERROR al abrir el archivo de pasajeros"<<endl;
        exit(1);
    } 
    numEspera=0;
    while(true){
        leerPasajeros(archPasajeros,bus,numBuses,listaDeEspera,numEspera);
        if(archPasajeros.eof())break;       
    }    
}

void leerPasajeros(ifstream &archPasajeros,struct Buses *bus,int numBuses,
        struct Pasajeros *listaDeEspera,int &numEspera){
    
    int dni,posBus;
    char *ptr_pasajero;
    char lugar[20],*ptr_lugar;
    archPasajeros>>dni;
    if(archPasajeros.eof())return;
    archPasajeros.get();
    ptr_pasajero=leerCadenaExacta(archPasajeros);
    archPasajeros.getline(lugar,20);    
    ptr_lugar=new char[strlen(lugar)+1];
    strcpy(ptr_lugar,lugar);       
    posBus=buscarPosicion(bus,ptr_lugar,numBuses);
    modificaNombre(ptr_pasajero);
    if(posBus!=-1){
        bus[posBus].pasajeros[bus[posBus].numeroDePasajeros].dni=dni;
        bus[posBus].pasajeros[bus[posBus].numeroDePasajeros].nombre=ptr_pasajero;
        bus[posBus].pasajeros[bus[posBus].numeroDePasajeros].destino=ptr_lugar;
        bus[posBus].numeroDePasajeros++;
    }else{
        listaDeEspera[numEspera].dni=dni;
        listaDeEspera[numEspera].nombre=ptr_pasajero;
        listaDeEspera[numEspera].destino=ptr_lugar;
        numEspera++;
    }
}

void modificaNombre(char *cadena){
    for(int i=0;cadena[i];i++){
        if(cadena[i]=='/')cadena[i]=' ';          
        if(cadena[i]>='A' and cadena[i]<='Z')cadena[i]+='a'-'A';          
        if(i==0 or cadena[i-1]=='/' or cadena[i-1]==' ')
            if(cadena[i]>='a' and cadena[i]<='z')cadena[i]-='a'-'A';      

    }
}

void emiteReporte(struct Buses *bus,int numBuses,
        struct Pasajeros *listaDeEspera,int numEspera){ 
    ofstream archReporte("reporte.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR al abrir el archivo de reporte"<<endl;
        exit(1);
    }
    int contador;
    imprimeLinea('=',150,archReporte);
    for(int i=0;i<numBuses;i++){
        archReporte<<"Vehiculo No."<<setw(2)<<i+1<<endl;
        archReporte<<"Placa: "<<bus[i].placa<<endl;
        archReporte<<"Chofer: "<<bus[i].chofer<<endl;
        archReporte<<"Ruta: ";
        for(int j=0;j<bus[i].numeroDeCiudades;j++){
            if(j==bus[i].numeroDeCiudades-1)
                archReporte<<bus[i].ciudadesDestino[j]<<endl;
            else archReporte<<bus[i].ciudadesDestino[j]<<" - ";
        }
        archReporte<<"Pasajeros: "<<endl;
        for(int k=0;k<bus[i].numeroDeCiudades;k++){
            archReporte<<bus[i].ciudadesDestino[k]<<':'<<endl;
            archReporte<<"No."<<setw(5)<<' '<<"DNI"<<setw(20)<<' '<<"Nombre"<<endl;
            contador=0;
            for(int n=0;n<bus[i].numeroDePasajeros;n++){
                if(strcmp(bus[i].ciudadesDestino[k],bus[i].pasajeros[n].destino)
                        ==0){
                    archReporte<<setw(2)<<contador+1<<setw(5)<<' ';
                    archReporte<<bus[i].pasajeros[n].dni<<setw(10)<<' ';
                    archReporte<<bus[i].pasajeros[n].nombre<<endl;
                    contador++;
                }
            }
        }
        imprimeLinea('-',150,archReporte);
    }
    imprimeLinea('=',150,archReporte);
    archReporte<<"PASAJEROS EN LISTA DE ESPERA"<<endl;
    imprimeLinea('-',150,archReporte);
    archReporte<<"No. "<<setw(5)<<' '<<"DNI"<<setw(18)<<' '<<"NOMBRE"
            <<setw(39)<<' '<<"Destino"<<endl;
    for(int i=0;i<numEspera;i++){
        archReporte<<setw(2)<<i+1<<setw(5)<<' '<<listaDeEspera[i].dni
                <<setw(10)<<' '<<left<<setw(50)<<listaDeEspera[i].nombre
                <<right<<listaDeEspera[i].destino<<endl;
    }
}

void imprimeLinea(char caracter, int cantidad, ofstream &archRep){
    for(int i=0;i<cantidad;i++)archRep<<caracter;
    archRep<<endl;
}

int buscarPosicion(struct Buses *bus,char *destino,int numBuses){
    for(int i=0;i<numBuses;i++)
        for(int j=0;j<bus[i].numeroDeCiudades;j++){
            if(strcmp(bus[i].ciudadesDestino[j],destino)==0  and
               bus[i].numeroDePasajeros<bus[i].numeroDeAsientos)
               return i;
        }
    return -1;
}


char *leerCadenaExacta(ifstream &arch){
    char buffer[500],*cadena;
    int longitud;
    
    arch.getline(buffer,500,',');
    if(arch.eof())return nullptr;
    longitud=strlen(buffer);
    cadena = new char[longitud+1];
    strcpy(cadena,buffer);
    
    return cadena;
}
