

/* 
 * File:   Pasajeros.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 7 de junio de 2023, 11:41 AM
 */

#ifndef PASAJEROS_H
#define PASAJEROS_H

struct Pasajeros{
    int dni;
    char *nombre;
    char *destino;
};

#endif /* PASAJEROS_H */

