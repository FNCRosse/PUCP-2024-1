

/* 
 * File:   main.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 7 de junio de 2023, 10:41 AM
 */

#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;


#include "Bus.h"
#include "Pasajero.h"
#include "funciones.h"
/*
 * 
 */
int main(int argc, char** argv) {
    
    struct Buses bus[30];
    int numBuses;
    
    struct Pasajeros listaDeEspera[300];
    int numEspera;
    leerDatosBuses(bus,numBuses);
    ordenarBuses(bus,numBuses);
//    for(int i=0;i<numBuses;i++)
//        cout<<bus[i].chofer<<endl;
    leerDatosPasajeros(bus,numBuses,listaDeEspera,numEspera);
    emiteReporte(bus,numBuses,listaDeEspera,numEspera);
    return 0;
}

