

/* 
 * File:   Buses.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 7 de junio de 2023, 11:41 AM
 */

#ifndef BUSES_H
#define BUSES_H

#include "Pasajero.h"

struct Buses{
    char *placa;
    char *chofer;
    int numeroDeAsientos;
    char *ciudadesDestino[10];
    int numeroDeCiudades;
    struct Pasajeros *pasajeros;
    int numeroDePasajeros;
};

#endif /* BUSES_H */

