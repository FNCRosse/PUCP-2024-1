

/* 
 * File:   main.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 10 de junio de 2023, 03:31 PM
 */

#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;
#include "Autor.h"
#include "Libro.h"
#include "Regalia.h"
#include "funciones.h"
/*
 * 
 */
int main(int argc, char** argv) {
    
    struct Autor autores[60];
    struct Libro libros[300];
    int numAutores,numLibros;
    leerAutores(autores,numAutores);
    leerLibros(autores,numAutores,libros,numLibros);
    calcularRegalias(autores,numAutores,libros,numLibros);
    ordenarAutores(autores,numAutores);
    ordenarLibros(libros,numLibros);
    
    emiteReporteLibros(autores,numAutores,libros,numLibros);
    emiteReporteAutores(autores,numAutores);
    return 0;
}

