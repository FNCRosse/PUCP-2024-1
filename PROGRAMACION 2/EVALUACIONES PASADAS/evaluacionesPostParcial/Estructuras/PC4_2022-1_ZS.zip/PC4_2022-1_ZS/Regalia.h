

/* 
 * File:   Regalia.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 11 de junio de 2023, 10:42 AM
 */

#ifndef REGALIA_H
#define REGALIA_H

struct Regalia{
    char *codigoAutor;
    double porcentaje;
};

#endif /* REGALIA_H */

