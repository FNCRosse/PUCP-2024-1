

/* 
 * File:   funciones.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 10 de junio de 2023, 05:00 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void leerAutores(struct Autor *autores,int &numAutores);
void leerLibros(struct Autor *autores,int numAutores,struct Libro *libros,int &numLibros);
void asignarRegalias(struct Autor *autores,int numAutores,struct Libro &libros,
        int &cantVendida,ifstream &archLibros);
void calcularRegalias(struct Autor *autores,int numAutores,struct Libro *libros,
        int numLibros);
void ordenarAutores(struct Autor *autores,int numAutores);
void ordenarLibros(struct Libro *libros,int numLibros);
void cambiar(struct Libro &libroI,struct Libro &libroJ);
void cambiar(Autor& autorI, Autor& autorJ);
void emiteReporteLibros(struct Autor *autores,int numAutores,struct Libro *libros,
        int numLibros);
void emiteReporteAutores(struct Autor *autores,int numAutores);
void buscaImprimeNombre(struct Autor *autores, int numAutores,char *codigo,
        ofstream &archReporte);
int buscarPosicion(struct Autor *autores,char *codigo, int numDatos);
void imprimeLinea(char caracter, int cantidad, ofstream &archReporte);
char *leerCadenaExacta(ifstream& arch);


#endif /* FUNCIONES_H */

