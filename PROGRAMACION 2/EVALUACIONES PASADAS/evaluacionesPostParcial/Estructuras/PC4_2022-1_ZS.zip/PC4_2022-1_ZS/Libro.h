

/* 
 * File:   Libro.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 11 de junio de 2023, 10:42 AM
 */

#ifndef LIBRO_H
#define LIBRO_H
#include "Regalia.h"

struct Libro{
    char *codigo;
    char *nombre;
    double precioVenta;
    int cantidadVendida;
    double totalRecaudado;
    struct Regalia *regalias;
    int cantAutores;
};

#endif /* LIBRO_H */

