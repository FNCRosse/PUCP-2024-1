

/* 
 * File:   Autor.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 11 de junio de 2023, 10:41 AM
 */

#ifndef AUTOR_H
#define AUTOR_H

struct Autor{
    char *codigo;
    char *nombre;
    int numLibrosVendidos;
    double montoRegalias;
};

#endif /* AUTOR_H */

