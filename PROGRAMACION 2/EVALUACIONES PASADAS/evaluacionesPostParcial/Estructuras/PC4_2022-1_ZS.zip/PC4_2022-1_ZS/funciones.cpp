

/* 
 * File:   funciones.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 10 de junio de 2023, 05:00 PM
 */


#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>

using namespace std;
#define MAX_LINE 150
#include "Autor.h"
#include "Libro.h"
#include "Regalia.h"
#include "funciones.h"


void leerAutores(struct Autor *autores,int &numAutores){
    
    ifstream archAutores("Autores.csv",ios::in);
    if(not archAutores.is_open()){
        cout<<"ERROR al abrir el archivo de autores"<<endl;
        exit(1);
    }
    
    char nombreAutor[60],*ptr_nombAutor;
    char *ptr_codAutor;
    numAutores=0;
    while(true){
        ptr_codAutor=leerCadenaExacta(archAutores);
        if(archAutores.eof())break;
        archAutores.getline(nombreAutor,60);
        ptr_nombAutor = new char[strlen(nombreAutor)+1];
        strcpy(ptr_nombAutor,nombreAutor);
        
        autores[numAutores].codigo = ptr_codAutor;
        autores[numAutores].nombre = ptr_nombAutor;
        autores[numAutores].montoRegalias=0;
        autores[numAutores].numLibrosVendidos=0;
        numAutores++;
    }
//    for(int i=0;i<numAutores;i++)
//        cout<<autores[i].codigo<<' '<<autores[i].nombre<<endl;
}

void leerLibros(struct Autor *autores,int numAutores,struct Libro *libros,
        int &numLibros){
    
    ifstream archLibros("Libros.csv",ios::in);
    if(not archLibros.is_open()){
        cout<<"ERROR al abrir el archivo de libros"<<endl;
        exit(1);
    }
    int cantVendida;
    double precioVenta;
    char *codLibro, *nombLibro;
    numLibros=0;
    while(true){
        codLibro=leerCadenaExacta(archLibros);
        if(archLibros.eof())break;
        nombLibro=leerCadenaExacta(archLibros);
        archLibros>>precioVenta;
        archLibros.get();
        libros[numLibros].codigo=codLibro;
        libros[numLibros].nombre=nombLibro;
        libros[numLibros].precioVenta=precioVenta;
        libros[numLibros].cantAutores=0;
        libros[numLibros].regalias = new struct Regalia[10];
        asignarRegalias(autores,numAutores,libros[numLibros],cantVendida,archLibros);
        libros[numLibros].totalRecaudado=precioVenta*cantVendida;
        numLibros++;
    }
    for(int i=0;i<numLibros;i++)
        for(int k=0;k<libros[i].cantAutores;k++){
            for(int j=0;j<numAutores;j++)
                if(strcmp(libros[i].regalias[k].codigoAutor,autores[j].codigo)==0)
                    autores[j].numLibrosVendidos+=libros[i].cantidadVendida;
        }
}

void asignarRegalias(struct Autor *autores,int numAutores,struct Libro &libros,
        int &cantVendida,ifstream &archLibros){
    int posAutor;
    char *ptr_autor;
    double porcentajeRegalia;
    while(true){
        archLibros>>cantVendida;
        if(archLibros.fail()){
            archLibros.clear();
            ptr_autor = leerCadenaExacta(archLibros);
            archLibros>>porcentajeRegalia;
            posAutor=buscarPosicion(autores,ptr_autor,numAutores);
            if(posAutor!=-1){
                libros.regalias[libros.cantAutores].codigoAutor=ptr_autor;
                libros.regalias[libros.cantAutores].porcentaje=porcentajeRegalia;
                libros.cantAutores++;
            }
            archLibros.get();
        }else{
            archLibros.get();
            libros.cantidadVendida=cantVendida;
            break;
        }
    }  
}

void calcularRegalias(struct Autor *autores,int numAutores,struct Libro *libros,
        int numLibros){
    
    for(int i=0;i<numLibros;i++){
        for(int k=0;k<libros[i].cantAutores;k++){
            libros[i].regalias[k].porcentaje = libros[i].totalRecaudado/
                    libros[i].regalias[k].porcentaje;
            for(int j=0;j<numAutores;j++){
                if(strcmp(autores[j].codigo,libros[i].regalias[k].codigoAutor)==0)
                    autores[j].montoRegalias+=libros[i].regalias[k].porcentaje;                
            }          
        }
    }
}

void ordenarAutores(struct Autor *autores,int numAutores){
    
    for(int i=0;i<numAutores-1;i++){
        for(int k=i+1;k<numAutores;k++){
            if(strcmp(autores[i].codigo,autores[k].codigo)>0){
                cambiar(autores[i],autores[k]);
            }
        }
    }
}

void ordenarLibros(struct Libro *libros,int numLibros){
    for(int i=0;i<numLibros-1;i++)
        for(int k=i+1;k<numLibros;k++)
            if(libros[i].cantidadVendida>libros[k].cantidadVendida or 
                    libros[i].cantidadVendida==libros[k].cantidadVendida and
                    libros[i].totalRecaudado < libros[k].totalRecaudado){
                cambiar(libros[i],libros[k]);
            }
}

void cambiar(struct Libro &libroI,struct Libro &libroJ){
    struct Libro aux;
    aux = libroI;
    libroI=libroJ;
    libroJ = aux;
}

void cambiar(struct Autor &autorI,struct Autor &autorJ){
    struct Autor aux;
    aux = autorI;
    autorI=autorJ;
    autorJ = aux;
}

void emiteReporteLibros(struct Autor *autores,int numAutores,struct Libro *libros,
        int numLibros){
    ofstream archReporte("RecaudacionLibrosVendidos.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROr al abrir el archivo de RecaudacionLibrosVendidos"<<endl;
        exit(1);
    }
    int totalLibrosVendidos=0;
    double totalRecaudado=0;
    archReporte<<setprecision(2);
    archReporte<<fixed;
    archReporte<<setw(50)<<' '<<"RECAUDACION POR LIBROS VENDIDOS"<<endl;
    imprimeLinea('=',MAX_LINE,archReporte);
    for(int i=0;i<numLibros;i++){
        archReporte<<"CODIGO"<<setw(12)<<' '<<"TITULO"<<setw(50)<<' '
                <<"LIBROS VENDIDOS"<<setw(10)<<' '<<"TOTAL RECAUDADO"<<endl;
        imprimeLinea('-',MAX_LINE,archReporte);
        archReporte<<libros[i].codigo<<setw(10)<<' '<<left<<setw(60)
                <<libros[i].nombre<<right<<libros[i].cantidadVendida
                <<setw(30)<<libros[i].totalRecaudado<<endl;
        totalLibrosVendidos+=libros[i].cantidadVendida;
        totalRecaudado+=libros[i].totalRecaudado;
        imprimeLinea('-',MAX_LINE,archReporte);
        archReporte<<"Autores:"<<endl;
        imprimeLinea('-',MAX_LINE,archReporte);
        archReporte<<"CODIGO"<<setw(11)<<' '<<"NOMBRE"<<setw(56)<<' '<<"REGALIAS"<<endl;
        imprimeLinea('-',MAX_LINE,archReporte);
        for(int k=0;k<libros[i].cantAutores;k++){
            archReporte<<libros[i].regalias[k].codigoAutor<<setw(10)<<' ';
            buscaImprimeNombre(autores,numAutores,
                    libros[i].regalias[k].codigoAutor,archReporte);
            archReporte<<setw(20)<<libros[i].regalias[k].porcentaje<<endl;
        }
        imprimeLinea('=',MAX_LINE,archReporte);
    }
    archReporte<<"Total de libross vendidos:"<<setw(10)<<totalLibrosVendidos<<endl;
    archReporte<<"Total recaudado: S/."<<setw(15)<<totalRecaudado<<endl;
}

void emiteReporteAutores(struct Autor *autores,int numAutores){
    ofstream archReporte("RegaliasAutores.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR al abrir el archivo de RegaliasAutores.txt"<<endl;
        exit(1);
    }
    double totalMonto=0;
    archReporte<<setprecision(2);
    archReporte<<fixed;
    archReporte<<"REGALIAS POR AUTORES"<<endl;
    imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<"CODIGO"<<setw(11)<<' '<<"NOMBRE"<<setw(50)<<' '
                <<"TOTAL DE LIBROS VENDIDOS"<<setw(15)<<' '<<"REGALIAS"<<endl;
    imprimeLinea('-',MAX_LINE,archReporte);
    for(int i=0;i<numAutores;i++){
        archReporte<<autores[i].codigo<<setw(10)<<' '<<left<<setw(50)
                <<autores[i].nombre<<right<<setw(16)<<autores[i].numLibrosVendidos
                <<setw(37)<<autores[i].montoRegalias<<endl;
        totalMonto+=autores[i].montoRegalias;
    }
    imprimeLinea('-',MAX_LINE,archReporte);
    archReporte<<"Total a pagar por regalias:"<<setw(15)<<totalMonto<<endl;
    imprimeLinea('=',MAX_LINE,archReporte);
}

void buscaImprimeNombre(struct Autor *autores, int numAutores,char *codigo,
        ofstream &archReporte){
    for(int i=0;i<numAutores;i++){
        if(strcmp(autores[i].codigo,codigo)==0)archReporte<<left<<setw(50)
                <<autores[i].nombre<<right;
    }
}

int buscarPosicion(struct Autor *autores,char *codigo, int numDatos){
    for(int i=0;i<numDatos;i++)
        if(strcmp(autores[i].codigo,codigo)==0)return i;
    return -1;
}

void imprimeLinea(char caracter, int cantidad, ofstream &archReporte){
    for(int i=0;i<cantidad;i++)archReporte<<caracter;
    archReporte<<endl;
}

char *leerCadenaExacta(ifstream &arch){
    char buffer[500],*cadena;
    int longitud;
    
    arch.getline(buffer,500,',');
    if(arch.eof())return nullptr;
    longitud=strlen(buffer);
    cadena = new char[longitud+1];
    strcpy(cadena,buffer);
    
    return cadena;
}


