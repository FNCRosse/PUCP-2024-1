

/* 
 * File:   funciones.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 11 de junio de 2023, 10:43 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void leerMiembros(struct Alumno *alumnos,int &numAlumnos,
        struct Administrativo *admins,int &numAdmins);
void leerAlumnos(struct Alumno &alumnos,ifstream &archMiembros);
void leerAdmins(struct Administrativo &admins,ifstream &archMiembros);
void modificarNombre(char *cadena);
void emiteReporte(struct Alumno *alumnos,int numAlumnos,
        struct Administrativo *admins,int numAdmins);
void imprimeBalancePersonalAdministrativo(struct Administrativo *admins,
        int numAdmins,int totalIngresos,ofstream &archReporte);
void imprimeEncabezado(ofstream &archReporte);
char *leerCadenaExacta(ifstream &arch);
void imprimeLinea(char caracter, int cantidad, ofstream& archRep);

#endif /* FUNCIONES_H */

