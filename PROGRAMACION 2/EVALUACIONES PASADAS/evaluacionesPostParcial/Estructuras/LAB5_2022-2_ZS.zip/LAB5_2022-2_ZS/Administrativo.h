

/* 
 * File:   Miembro.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 11 de junio de 2023, 10:49 PM
 */

#ifndef MIEMBRO_H
#define MIEMBRO_H

struct Administrativo{
    char nombre[60];
    int codigo;
    char distrito[50];
    char puesto[30];
    char gradoInstruccion[30];
    int aniosServicio;
    double sueldo;
};

#endif /* MIEMBRO_H */

