

/* 
 * File:   funciones.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 11 de junio de 2023, 10:43 PM
 */


#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>

using namespace std;

#define MAX_LINE 200
#include "Alumno.h"
#include "Administrativo.h"
#include "funciones.h"

void leerMiembros(struct Alumno *alumnos,int &numAlumnos,
        struct Administrativo *admins,int &numAdmins){
    
    ifstream archMiembros("MiembrosDeTP2.csv",ios::in);
    if(not archMiembros.is_open()){
        cout<<"ERROR al abrir el archivo MiembrosDeTP2"<<endl;
        exit(1);
    }
    
    char tipo_miembro;
    numAlumnos = numAdmins =0;
    while(true){
        archMiembros>>tipo_miembro;
        if(archMiembros.eof())break;
        archMiembros.get();
        if(tipo_miembro=='A'){
            leerAlumnos(alumnos[numAlumnos],archMiembros);
            numAlumnos++;
        }else if(tipo_miembro=='a'){
            leerAdmins(admins[numAdmins],archMiembros);
            numAdmins++;
        }else while(archMiembros.get()!='\n');      
    }
}

void leerAlumnos(struct Alumno &alumnos,ifstream &archMiembros){
    char apellido1[50],apellido2[50],nombre[50];
//    archMiembros.getline(alumnos.nombre,60,',');
    archMiembros.getline(apellido1,50,'/');
    archMiembros.getline(apellido2,50,'/');
    archMiembros.getline(nombre,50,',');
    modificarNombre(apellido2);
    strcpy(alumnos.nombre,nombre);
    strcat(alumnos.nombre," ");
    strcat(alumnos.nombre,apellido1);
    strcat(alumnos.nombre," ");
    strcat(alumnos.nombre,apellido2);
    archMiembros>>alumnos.codigo;
    archMiembros.get();
    archMiembros.getline(alumnos.distrito,50,',');
    archMiembros.getline(alumnos.especialidad,30,',');
    archMiembros.getline(alumnos.facultad,30,',');
    archMiembros>>alumnos.escalaPago;
    archMiembros.get();
    archMiembros>>alumnos.valorCredito;
    archMiembros.get();
    archMiembros>>alumnos.creditosMatriculados;
}

void leerAdmins(struct Administrativo &admins,ifstream &archMiembros){
    char apellido1[50],apellido2[50],nombre[50];
//    archMiembros.getline(admins.nombre,60,',');
    archMiembros.getline(apellido1,50,'/');
    archMiembros.getline(apellido2,50,'/');
    archMiembros.getline(nombre,50,',');
    modificarNombre(apellido2);
    strcpy(admins.nombre,nombre);
    strcat(admins.nombre," ");
    strcat(admins.nombre,apellido1);
    strcat(admins.nombre," ");
    strcat(admins.nombre,apellido2);
    archMiembros>>admins.codigo;
    archMiembros.get();
    archMiembros.getline(admins.distrito,50,',');
    archMiembros.getline(admins.puesto,30,',');
    archMiembros.getline(admins.gradoInstruccion,30,',');
    archMiembros>>admins.aniosServicio;
    archMiembros.get();
    archMiembros>>admins.sueldo;
}

void modificarNombre(char *cadena){
    cadena[1]=0;
}

void emiteReporte(struct Alumno *alumnos,int numAlumnos,
        struct Administrativo *admins,int numAdmins){
    
    ofstream archReporte("Balance_de_Ingresos.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR al abrir el archivo de Balance_de_Ingresos"<<endl;
        exit(1);
    }
    double pago,totalIngresos=0;
    archReporte<<setprecision(2);
    archReporte<<fixed;
    imprimeEncabezado(archReporte);
    for(int i=0;i<numAlumnos;i++){
        archReporte<<alumnos[i].codigo<<setw(8)<<' '<<left<<setw(50)
                <<alumnos[i].nombre<<setw(30)<<alumnos[i].distrito
                <<setw(30)<<alumnos[i].especialidad<<setw(10)
                <<alumnos[i].facultad<<right<<setw(22)<<alumnos[i].escalaPago
                <<setw(17)<<alumnos[i].valorCredito<<setw(17)
                <<alumnos[i].creditosMatriculados;
        pago = alumnos[i].valorCredito * alumnos[i].creditosMatriculados;
        archReporte<<setw(14)<<pago<<endl;
        totalIngresos+=pago;
    }
    imprimeLinea('-',MAX_LINE,archReporte);
    archReporte<<"Total de ingresos por matriculas: "<<setw(20)
            <<totalIngresos<<endl;
    imprimeBalancePersonalAdministrativo(admins,numAdmins,
            totalIngresos,archReporte);
}

void imprimeBalancePersonalAdministrativo(struct Administrativo *admins,
        int numAdmins,int totalIngresos,ofstream &archReporte){
    double pago,totalPago=0,estadoDeGanancia;
    imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<"PAGO AL PERSONAL ADMINISTRATIVO"<<endl;
    imprimeLinea('-',MAX_LINE,archReporte);
    archReporte<<"CODIGO"<<setw(10)<<' '<<"NOMBRE"<<setw(44)<<' '<<"DISTRITO"
            <<setw(30)<<' '<<"PUESTO"<<setw(14)<<' '<<"GRADOINS"
            <<setw(10)<<' '<<"SERVICIO"<<setw(10)<<' '<<"PAGO"<<endl;
    for(int i=0;i<numAdmins;i++){
        archReporte<<admins[i].codigo<<setw(10)<<' '<<left<<setw(50)
                <<admins[i].nombre<<setw(38)<<admins[i].distrito<<setw(20)
                <<admins[i].puesto<<setw(24)<<admins[i].gradoInstruccion
                <<right<<setw(2)<<admins[i].aniosServicio;
        if(admins[i].aniosServicio>5){
            pago = (admins[i].sueldo)*12 + ((admins[i].sueldo)*1.5)*2;
        }else{
            pago = admins[i].sueldo*14;
        }
        archReporte<<setw(14)<<admins[i].sueldo<<endl;
        totalPago+=pago;
    }
    estadoDeGanancia= totalIngresos- totalPago;
    imprimeLinea('-',MAX_LINE,archReporte);
    archReporte<<"Total de Egresos por Sueldos:"<<setw(20)<<totalPago<<endl;
    imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<"Estado de las ganancias o perdidas: "<<setw(20)
            <<estadoDeGanancia<<endl;
    archReporte<<"Recomendacions: ";
    if(estadoDeGanancia>0)archReporte<<"DEBE INVERTIR SUS GANANCIAS"<<endl;
    else archReporte<<"DEBE BUSCAR INVERSIONISTAS"<<endl;
}

void imprimeEncabezado(ofstream &archReporte){
    archReporte<<setw(50)<<' '<<"Universidad TP"<<endl;
    imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<"RECAUDACION POR MATRICULAS: "<<endl;
    imprimeLinea('-',MAX_LINE,archReporte);
    archReporte<<"CODIGO"<<setw(10)<<' '<<"NOMBRE"<<setw(44)<<' '<<"DISTRITO"
            <<setw(22)<<' '<<"ESPCIALIDAD"<<setw(19)<<' '<<"FACULTAD"
            <<setw(20)<<' '<<"ESCALA"<<setw(10)<<' '<<"VCRED"<<setw(10)
            <<' '<<"CREDMAT"<<setw(10)<<' '<<"PAGO"<<endl;
    imprimeLinea('-',MAX_LINE,archReporte);
}

char *leerCadenaExacta(ifstream &arch){
    char buffer[500],*cadena;
    int longitud;
    
    arch.getline(buffer,500,',');
    if(arch.eof())return nullptr;
    longitud=strlen(buffer);
    cadena = new char[longitud+1];
    strcpy(cadena,buffer);
    
    return cadena;
}

void imprimeLinea(char caracter, int cantidad, ofstream &archRep){
    for(int i=0;i<cantidad;i++)archRep<<caracter;
    archRep<<endl;
}
