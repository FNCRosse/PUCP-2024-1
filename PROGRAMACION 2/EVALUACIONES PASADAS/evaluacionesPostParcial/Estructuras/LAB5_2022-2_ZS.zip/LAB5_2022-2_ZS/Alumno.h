

/* 
 * File:   Alumno.h
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 11 de junio de 2023, 10:53 PM
 */

#ifndef ALUMNO_H
#define ALUMNO_H

struct Alumno{
    char nombre[60];
    int codigo;
    char distrito[50];
    char especialidad[30];
    char facultad[30];
    int escalaPago;
    double valorCredito;
    double creditosMatriculados;
};

#endif /* ALUMNO_H */

