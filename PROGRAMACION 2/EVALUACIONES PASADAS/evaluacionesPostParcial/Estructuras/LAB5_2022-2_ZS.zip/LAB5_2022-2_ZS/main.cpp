

/* 
 * File:   main.cpp
 * Author: Derik Camacho Pastor 20191163
 *
 * Created on 11 de junio de 2023, 10:39 PM
 */

#include <iostream>
#include <fstream>
#include <iomanip>

using namespace std;

#include "Alumno.h"
#include "Administrativo.h"
#include "funciones.h"

/*
 * 
 */
int main(int argc, char** argv) {
    
    struct Alumno alumnos[100];
    struct Administrativo admins[100];
    int numAlumnos,numAdmins;
    
    leerMiembros(alumnos,numAlumnos,admins,numAdmins);
    emiteReporte(alumnos,numAlumnos,admins,numAdmins);
    
    return 0;
}

