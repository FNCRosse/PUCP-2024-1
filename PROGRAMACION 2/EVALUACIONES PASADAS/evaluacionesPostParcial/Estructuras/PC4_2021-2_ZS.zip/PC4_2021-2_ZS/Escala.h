/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Escala.h
 * Author: h413
 *
 * Created on 9 de junio de 2023, 01:37 PM
 */

#ifndef ESCALA_H
#define ESCALA_H

struct Escala{
    char *codigo;
    double valorCredito;
    int semestre;
};

#endif /* ESCALA_H */

