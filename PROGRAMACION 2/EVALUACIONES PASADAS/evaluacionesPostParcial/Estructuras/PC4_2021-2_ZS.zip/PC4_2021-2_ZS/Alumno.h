/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Alumno.h
 * Author: h413
 *
 * Created on 9 de junio de 2023, 01:35 PM
 */

#ifndef ALUMNO_H
#define ALUMNO_H
#include "CursoMatriculado.h"

struct Alumno{
    int codigo;
    char *nombre;
    char *escala;
    struct CursoMatriculado *cursos;
    int numCursos;
    double promedio;
    double creditos;
    double totalPagado;
};

#endif /* ALUMNO_H */

