/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: h413
 *
 * Created on 9 de junio de 2023, 01:29 PM
 */

#include <iostream>
#include <iomanip>
#include <fstream>

using namespace std;

#include "funciones.h"
#include "Curso.h"
#include "Escala.h"
#include "Alumno.h"


/*
 * 
 */
int main(int argc, char** argv) {
    
    struct Curso cursos[50];
    int numCursos;
    
    struct Escala escalas[200];
    int numEscalas;
    
    struct Alumno alumnos[100];
    int numAlumnos;
    
    leerCursos(cursos,numCursos);
    leerEscalas(escalas,numEscalas);
    leerAlumnos(alumnos,numAlumnos);
    leerNotas(alumnos,numAlumnos,cursos,numCursos,escalas,numEscalas);
    calculaPromedio(alumnos,numAlumnos,cursos,numCursos,escalas,numEscalas);
    emiteReporte(alumnos,numAlumnos,cursos,numCursos,escalas,numEscalas);
    return 0;
}

