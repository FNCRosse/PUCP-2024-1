/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.cc to edit this template
 */
#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>

using namespace std;

#include "funciones.h"
#include "Curso.h"
#include "Escala.h"
#include "Alumno.h"


void leerCursos(struct Curso *cursos,int &numCursos){
    
    ifstream archCursos("Cursos.csv",ios::in);
    if(not archCursos.is_open()){
        cout<<"ERROR al abrir el archivo de cursos"<<endl;
        exit(1);
    }
    
    numCursos=0;
    while(true){
        cursos[numCursos].codigo = leerCadenaExacta(archCursos);
        if(archCursos.eof())break;
        cursos[numCursos].nombre = leerCadenaExacta(archCursos);
        archCursos>>cursos[numCursos].creditos;
        archCursos.get();
        numCursos++;
    }
    
//    for(int i=0;i<numCursos;i++)
//        cout<<cursos[i].codigo<<' '<<cursos[i].nombre<<' '
//                <<cursos[i].creditos<<endl;
}

void leerEscalas(struct Escala *escalas,int &numEscalas){
    
    ifstream archEscalas("Escalas.txt",ios::in);
    if(not archEscalas.is_open()){
        cout<<"ERROR al abrir el archivo de escalas"<<endl;
        exit(1);
    }
    int anio,ciclo,codigo;
    char c,escala[3];
    numEscalas=0;
    while(true){
        archEscalas>>escala;
        escalas[numEscalas].codigo = new char[strlen(escala)+1];
        strcpy(escalas[numEscalas].codigo,escala);     
        if(archEscalas.eof())break;
        archEscalas>>escalas[numEscalas].valorCredito;
        archEscalas>>anio>>c>>ciclo;
        escalas[numEscalas].semestre = anio*10 + ciclo;
        numEscalas++;
    }
//    for(int i=0;i<numEscalas;i++)
//        cout<<escalas[i].codigo<<' '<<escalas[i].valorCredito<<' '
//                <<escalas[i].semestre<<endl;
}

void leerAlumnos(struct Alumno *alumnos,int &numAlumnos){   
    ifstream archAlumnos("Alumnos.csv",ios::in);
    if(not archAlumnos.is_open()){
        cout<<"ERROR al abrir el archivo de alumnos"<<endl;
        exit(1);
    }
    char escala[3];
    numAlumnos=0;
    while(true){
        archAlumnos>>alumnos[numAlumnos].codigo;
        if(archAlumnos.eof())break;
        archAlumnos.get();
        alumnos[numAlumnos].nombre = leerCadenaExacta(archAlumnos);
        archAlumnos>>escala;
        alumnos[numAlumnos].escala = new char[strlen(escala)+1];
        strcpy(alumnos[numAlumnos].escala,escala);
        alumnos[numAlumnos].cursos = new struct CursoMatriculado[20];
        alumnos[numAlumnos].numCursos=0;
        alumnos[numAlumnos].creditos=0;
        alumnos[numAlumnos].totalPagado=0;
        numAlumnos++;
    }
//    for(int i=0;i<numAlumnos;i++)
//        cout<<alumnos[i].codigo<<' '<<alumnos[i].nombre<<' '
//                <<alumnos[i].escala<<endl;
}

void leerNotas(struct Alumno *alumnos,int numAlumnos,struct Curso *cursos,
        int numCursos,struct Escala *escalas,int numEscalas){    
    ifstream archNotas("Notas.csv",ios::in);
    if(not archNotas.is_open()){
        cout<<"ERROR al abrir el archivo de notas"<<endl;
        exit(1);
    }
    char arrCurso[7],*ptr_curso,c;
    int codigo_alumno,posAlumno,posEscala,posCurso,nota,dia,mes,anio,fecha; 
    while(true){
        archNotas>>codigo_alumno;
        if(archNotas.eof())break;
        archNotas.get();
        posAlumno=buscarPosAlumno(alumnos,codigo_alumno,numAlumnos);
        if(posAlumno!=-1){
//            archNotas>>arrCurso;
            ptr_curso = leerCadenaExacta(archNotas);
//            strcpy(ptr_curso,arrCurso);
            posCurso=buscarCurso(cursos,ptr_curso,numCursos);
            if(posCurso!=-1){
//                archNotas.get();
                archNotas>>nota;
                archNotas.get();
                archNotas>>dia>>c>>mes>>c>>anio;
                fecha = anio*10000+mes*100+dia;
                posEscala=buscarEscala(escalas,alumnos[posAlumno].escala,
                        fecha,numEscalas);
                alumnos[posAlumno].cursos[alumnos[posAlumno].numCursos].
                        codigo=ptr_curso;
                alumnos[posAlumno].cursos[alumnos[posAlumno].numCursos].
                        nota=nota;
                alumnos[posAlumno].cursos[alumnos[posAlumno].numCursos].
                        fecha=fecha;
                alumnos[posAlumno].numCursos++;
            }else while(archNotas.get()!='\n');
        }else while(archNotas.get()!='\n');
    }
}

void calculaPromedio(struct Alumno *alumnos,int numAlumnos,struct Curso *cursos,
        int numCursos,struct Escala *escalas,int numEscalas){
    int posCurso,posEscala;
    double sumaPesos=0,sumaCreditos=0;
    for(int i=0;i<numAlumnos;i++){
        for(int j=0;j<alumnos[i].numCursos;j++){
            posCurso=buscarCurso(cursos,alumnos[i].cursos[j].codigo,numCursos);
            if(posCurso!=-1){
                posEscala=buscarEscala(escalas,alumnos[i].escala,
                        alumnos[i].cursos[j].fecha,numEscalas);
                if(posEscala!=-1){
                    sumaPesos+=alumnos[i].cursos[j].nota*cursos[posCurso].creditos;
                    sumaCreditos+=cursos[posCurso].creditos;
                    alumnos[i].promedio=sumaPesos/sumaCreditos;
                    if(alumnos[i].cursos[j].nota>10)alumnos[i].creditos+=
                            cursos[posCurso].creditos;
                    posEscala=buscarEscala(escalas,alumnos[i].escala,
                            alumnos[i].cursos[j].fecha,numEscalas);
                }
            }
        }
        alumnos[i].totalPagado=escalas[posEscala].valorCredito*sumaCreditos;          
   }
}

void emiteReporte(struct Alumno *alumnos,int numAlumnos,struct Curso *cursos,
        int numCursos,struct Escala *escalas,int numEscalas){
    
    ofstream archReporte("reporte.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR al abrir el archivo de reporte"<<endl;
        exit(1);
    }
    int totalRecaudado=0;
    archReporte<<setprecision(2);
    archReporte<<fixed;
    archReporte<<setw(50)<<' '<<"INSTITUTO ABC"<<endl;
    archReporte<<setw(44)<<' '<<"Estado de cuenta de los alumnos"<<endl;
    imprimeLinea('=',150,archReporte);
    archReporte<<setw(5)<<' '<<"Codigo"<<setw(12)<<' '<<"Nombre"<<setw(53)
            <<' '<<"Escala"<<setw(6)<<' '<<"Promedio"<<setw(4)<<' '
            <<"Creditos Aprobados"<<setw(10)<<' '<<"Total pagado"<<endl;
    for(int i=0;i<numAlumnos;i++){
        archReporte<<setw(3)<<i+1<<") "<<alumnos[i].codigo<<setw(10)<<' '
                <<left<<setw(50)<<alumnos[i].nombre<<right<<setw(10)<<' '
                <<alumnos[i].escala<<setw(10)<<' '<<alumnos[i].promedio
                <<setw(10)<<' '<<alumnos[i].creditos<<setw(10)<<' '
                <<setw(20)<<alumnos[i].totalPagado<<endl;
        totalRecaudado+=alumnos[i].totalPagado;
    }
    imprimeLinea('-',150,archReporte);
    archReporte<<"Total recaudado: "<<totalRecaudado<<endl;
}

void imprimeLinea(char caracter, int cantidad, ofstream &archReporte){
    for(int i=0;i<cantidad;i++)archReporte<<caracter;
    archReporte<<endl;
}


int buscarEscala(struct Escala *escalas,char *escala,int fecha,int numDatos){
    int anio = fecha/10000;
    int mes = (fecha%10000)/100;
    int semestre;
    
    if(mes>=1 and mes<=3)semestre= anio*10;
    else if(mes>=4 and mes<=7)semestre = anio*10+1;
    else if(mes>=8 and mes<=12)semestre = anio*10+2;
    
    for(int i=0;i<numDatos;i++)
        if(strcmp(escalas[i].codigo,escala)==0 and 
                escalas[i].semestre == semestre) return i;
    return -1;
}

int buscarCurso(struct Curso *cursos, char *codCurso, int numDatos){
    for(int i=0;i<numDatos;i++)
        if(strcmp(cursos[i].codigo,codCurso)==0)return i;
    return -1;
}

int buscarPosAlumno(struct Alumno *alumnos,int codigo, int numDatos){
    for(int i=0;i<numDatos;i++)
        if(alumnos[i].codigo == codigo)return i;
    return -1;
}

char *leerCadenaExacta(ifstream &arch){
    char buffer[500],*cadena;
    int longitud;
    
    arch.getline(buffer,500,',');
    if(arch.eof())nullptr;
    longitud=strlen(buffer);
    cadena = new char[longitud+1];
    strcpy(cadena,buffer);
    
    return cadena;
}