/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Curso.h
 * Author: h413
 *
 * Created on 9 de junio de 2023, 01:34 PM
 */

#ifndef CURSO_H
#define CURSO_H

struct Curso{
    char *codigo;
    char *nombre;
    double creditos;
};

#endif /* CURSO_H */

