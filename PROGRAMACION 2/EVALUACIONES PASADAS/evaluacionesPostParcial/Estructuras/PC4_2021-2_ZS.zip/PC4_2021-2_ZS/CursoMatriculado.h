/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   CursoMatriculado.h
 * Author: h413
 *
 * Created on 9 de junio de 2023, 01:36 PM
 */

#ifndef CURSOMATRICULADO_H
#define CURSOMATRICULADO_H

struct CursoMatriculado{
    char *codigo;
    int nota;
    int fecha;
};

#endif /* CURSOMATRICULADO_H */

