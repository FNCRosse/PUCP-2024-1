/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   funciones.h
 * Author: h413
 *
 * Created on 9 de junio de 2023, 01:33 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

void leerCursos(struct Curso *cursos,int &numCursos);
void leerEscalas(struct Escala *escalas,int &numEscalas);
void leerAlumnos(struct Alumno *alumnos,int &numAlumnos);
void leerNotas(struct Alumno *alumnos,int numAlumnos,struct Curso *cursos,
        int numCursos,struct Escala *escalas,int numEscalas);
void calculaPromedio(struct Alumno *alumnos,int numAlumnos,struct Curso *cursos,
        int numCursos,struct Escala *escalas,int numEscalas);
void emiteReporte(struct Alumno *alumnos,int numAlumnos,struct Curso *cursos,
        int numCursos,struct Escala *escalas,int numEscalas);
void imprimeLinea(char caracter, int cantidad, ofstream &archReporte);
int buscarEscala(struct Escala* escalas, char* escala, int fecha, int numDatos);
int buscarCurso(struct Curso *cursos, char *codCurso, int numDatos);
int buscarPosAlumno(struct Alumno *alumnos,int codigo, int numDatos);
char *leerCadenaExacta(ifstream& arch);

#endif /* FUNCIONES_H */

