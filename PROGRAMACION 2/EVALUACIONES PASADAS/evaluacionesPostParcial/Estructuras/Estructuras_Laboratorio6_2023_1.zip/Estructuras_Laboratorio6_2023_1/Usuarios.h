/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Usuario.h
 * Author: aml
 *
 * Created on 12 de junio de 2023, 01:09 PM
 */

#ifndef USUARIO_H
#define USUARIO_H

struct Usuario{
    int dni;
    char nombre[60];
    char categoria;
    double calificacion;
    int cantidadPrestada;
};

#endif /* USUARIO_H */

