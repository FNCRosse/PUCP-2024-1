/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   funciones.h
 * Alumno: Derik Camacho Pastor 20191163
 *
 * Created on 12 de junio de 2023, 01:07 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H

#include "Libros.h"
#include "Usuarios.h"
#include "Solicitudes.h"

void leerLibros(struct Libro *libros,int &numLibros);
void leerUsuarios(struct Usuario *usuarios,int &numUsuarios);
void leerSolicitudes(struct Solicitud *solicitudes,int &numSolicitudes);
void imprimirDatosArreglos(struct Libro *libros,int numLibros,
        struct Usuario *usuarios,int numUsuarios,struct Solicitud *solicitudes,
        int numSolicitudes);
void ordenarUsuarios(struct Usuario *usuarios,int numUsuarios);
void cambiarEstructura(Usuario& usuarioI, Usuario& usuarioK);
void atenderSolicitudes(struct Libro *libros,int numLibros,
        struct Usuario *usuarios,int numUsuarios,struct Solicitud *solicitudes,
        int numSolicitudes);
int buscarPosicionUsuario(struct Usuario *usuarios,int dni,int numDatos);
int buscarPosicionLibro(Libro* libros, char* codigo, int numDatos);
void imprimeReporteSolicitudesProcesadas(struct Libro *libros,int numLibros,
        struct Usuario *usuarios,int numUsuarios,struct Solicitud *solicitudes,
        int numSolicitudes);
void imprimeEncabezadoLibros(ofstream &archReporte);
void imprimeEncabezadoUsuarios(ofstream& archReporte);
void imprimeEncabezadoSolicitudes(ofstream &archReporte);
void imprimeLinea(char caracter, int cantidad, ofstream &archReporte);


#endif /* FUNCIONES_H */

