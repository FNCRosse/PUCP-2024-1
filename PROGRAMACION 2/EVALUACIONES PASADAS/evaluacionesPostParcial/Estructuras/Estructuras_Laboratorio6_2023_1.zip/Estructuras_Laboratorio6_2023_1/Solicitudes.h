/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Solicitudes.h
 * Author: aml
 *
 * Created on 12 de junio de 2023, 01:13 PM
 */

#ifndef SOLICITUDES_H
#define SOLICITUDES_H

struct Solicitud{
    int dni;
    char codigoLibro[8];
};

#endif /* SOLICITUDES_H */

