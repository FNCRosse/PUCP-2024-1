/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   Libro.h
 * Author: aml
 *
 * Created on 12 de junio de 2023, 01:09 PM
 */

#ifndef LIBRO_H
#define LIBRO_H

struct Libro{
    char codigo[8];
    char titulo[60];
    char autor[50];
    int cantidadVolumenes;
    double precio;
    int cantidadPrestado;
};

#endif /* LIBRO_H */

