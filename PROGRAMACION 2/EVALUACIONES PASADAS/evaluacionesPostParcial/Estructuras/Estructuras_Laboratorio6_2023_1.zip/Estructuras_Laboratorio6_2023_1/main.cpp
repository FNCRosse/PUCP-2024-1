/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Alumno: Derik Camacho Pastor 20191163
 *
 * Created on 12 de junio de 2023, 01:06 PM
 */

#include <iostream>
#include <iomanip>
#include <fstream>

using namespace std;

#include "Libros.h"
#include "Usuarios.h"
#include "Solicitudes.h"
#include "funciones.h"
/*
 * 
 */
int main(int argc, char** argv) {
    
    struct Libro libros[40];
    struct Usuario usuarios[70];
    struct Solicitud solicitudes[300];
    
    int numLibros,numUsuarios,numSolicitudes;
    /*Lectura de datos de los 3 archivos*/
    leerLibros(libros,numLibros);
    leerUsuarios(usuarios,numUsuarios);
    leerSolicitudes(solicitudes,numSolicitudes);
    /*Impresion de los datos iniciales por cada archivo*/
    imprimirDatosArreglos(libros,numLibros,usuarios,numUsuarios,solicitudes,
            numSolicitudes);
    /*Ordenacion según la politica de la biblioteca*/
    ordenarUsuarios(usuarios,numUsuarios);
    /*Se realiza la operacion de las solicitudes modificando los 
     datos de los arreglos*/
    atenderSolicitudes(libros,numLibros,usuarios,numUsuarios,solicitudes,
            numSolicitudes);
    /*Impresion de las solicitudes ya registradas y modificadas*/
    imprimeReporteSolicitudesProcesadas(libros,numLibros,usuarios,numUsuarios,
            solicitudes,numSolicitudes);
    return 0;
}

