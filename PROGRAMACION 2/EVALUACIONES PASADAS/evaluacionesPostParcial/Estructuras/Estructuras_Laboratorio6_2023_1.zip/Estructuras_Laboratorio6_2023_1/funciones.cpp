/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.cc to edit this template
 */

/*
 * 
 * 
  Alumno: Derik Camacho Pastor 20191163
 
 */


#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>

using namespace std;

#define NO_ENCONTRADO -1
#define MAX_LINE 200
#include "Libros.h"
#include "Usuarios.h"
#include "Solicitudes.h"
#include "funciones.h"

void leerLibros(struct Libro *libros,int &numLibros){
    
    ifstream archLibros("Libros.csv",ios::in);
    if(not archLibros.is_open()){
        cout<<"ERROR al abrir el archivo de libros"<<endl;
        exit(1);
    }
    char codigoLibro[8],nombreLibro[60],nombreAutor[60];
    int cantidadVolumenes;
    double precio;
    numLibros=0;
    while(true){
        archLibros.getline(codigoLibro,8,',');
        if(archLibros.eof())break;
        archLibros.getline(nombreLibro,60,',');
        archLibros.getline(nombreAutor,60,',');
        archLibros>>cantidadVolumenes;
        archLibros.get();
        archLibros>>precio;
        archLibros.get();
        strcpy(libros[numLibros].codigo,codigoLibro);
        strcpy(libros[numLibros].titulo,nombreLibro);
        strcpy(libros[numLibros].autor,nombreAutor);
        libros[numLibros].cantidadVolumenes=cantidadVolumenes;
        libros[numLibros].precio=precio;
        libros[numLibros].cantidadPrestado=0;
        numLibros++;       
    }  
//    for(int i=0;i<numLibros;i++)
//        cout<<libros[i].codigo<<' '<<libros[i].titulo<<' '
//                <<libros[i].cantidadVolumenes<<' '<<libros[i].precio
//                <<' '<<libros[i].autor<<endl;
}

void leerUsuarios(struct Usuario *usuarios,int &numUsuarios){   
    ifstream archUsuarios("Usuarios.csv",ios::in);
    if(not archUsuarios.is_open()){
        cout<<"ERROR al abrir el archivo de usuarios"<<endl;
        exit(1);
    }
    char nombreUsuario[60],categoria;
    int dni;
    double tipo_calificacion;
    numUsuarios=0;
    while(true){
        archUsuarios>>dni;
        if(archUsuarios.eof())break;
        archUsuarios.get();
        archUsuarios.getline(nombreUsuario,60,',');
        archUsuarios>>categoria;
        archUsuarios.get();
        archUsuarios>>tipo_calificacion;
        
        usuarios[numUsuarios].dni =dni;
        strcpy(usuarios[numUsuarios].nombre,nombreUsuario);
        usuarios[numUsuarios].categoria = categoria;
        usuarios[numUsuarios].calificacion = tipo_calificacion;
        usuarios[numUsuarios].cantidadPrestada=0;
        numUsuarios++;
    }
//    for(int i=0;i<numUsuarios;i++)
//        cout<<usuarios[i].dni<<' '<<usuarios[i].nombre<<' '
//                <<usuarios[i].categoria<<' '<<usuarios[i].calificacion<<endl;
}

void leerSolicitudes(struct Solicitud *solicitudes,int &numSolicitudes){
    
    ifstream archSolicitudes("SolicitudesDePrestamo.txt",ios::in);
    if(not archSolicitudes.is_open()){
        cout<<"ERROR al abrir el archivo de SolicitudesDePrestamo"<<endl;
        exit(1);
    }
    int dni;
    char codigoLibro[8];
    numSolicitudes=0;
    while(true){
        archSolicitudes>>dni;
        if(archSolicitudes.eof())break;
        archSolicitudes>>codigoLibro;
        
        strcpy(solicitudes[numSolicitudes].codigoLibro,codigoLibro);
        solicitudes[numSolicitudes].dni=dni;
        
        numSolicitudes++;
    }
//    for(int i=0;i<numSolicitudes;i++)
//        cout<<solicitudes[i].dni<<' '<<solicitudes[i].codigoLibro<<endl;
}

void imprimirDatosArreglos(struct Libro *libros,int numLibros,
        struct Usuario *usuarios,int numUsuarios,struct Solicitud *solicitudes,
        int numSolicitudes){
    
    ofstream archReporte("ReporteDatosIniciales.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR al abrir el archivo de ReporteDatosIniciales.txt"<<endl;
        exit(1);
    }
    archReporte<<setprecision(2);
    archReporte<<fixed;
    imprimeEncabezadoLibros(archReporte);
    for(int i=0;i<numLibros;i++)
        archReporte<<libros[i].codigo<<setw(9)<<' '<<left<<setw(50)
                <<libros[i].titulo<<' '<<setw(50)<<libros[i].autor<<right
                <<setw(3)<<libros[i].cantidadVolumenes<<setw(25)
                <<libros[i].precio<<setw(15)<<libros[i].cantidadPrestado<<endl;
    imprimeEncabezadoUsuarios(archReporte);
    for(int i=0;i<numUsuarios;i++)
        archReporte<<usuarios[i].dni<<setw(9)<<' '<<left<<setw(50)
                <<usuarios[i].nombre<<setw(20)<<usuarios[i].categoria
                <<right<<setw(5)<<usuarios[i].calificacion
                <<setw(25)<<usuarios[i].cantidadPrestada<<endl;
    imprimeEncabezadoSolicitudes(archReporte);
    for(int i=0;i<numSolicitudes;i++)
        archReporte<<solicitudes[i].dni<<setw(10)<<solicitudes[i].codigoLibro
                <<endl;
    imprimeLinea('=',MAX_LINE,archReporte);
}

void ordenarUsuarios(struct Usuario *usuarios,int numUsuarios){
    for(int i=0;i<numUsuarios-1;i++)
        for(int k=i+1;k<numUsuarios;k++)
            if(usuarios[i].categoria>usuarios[k].categoria or
                    usuarios[i].categoria==usuarios[k].categoria
                    and usuarios[i].calificacion < usuarios[k].calificacion){
                cambiarEstructura(usuarios[i],usuarios[k]);
            }
}

void cambiarEstructura(struct Usuario &usuarioI,struct Usuario &usuarioK){
    struct Usuario aux;
    
    aux = usuarioI;
    usuarioI = usuarioK;
    usuarioK = aux;
}

void atenderSolicitudes(struct Libro *libros,int numLibros,
        struct Usuario *usuarios,int numUsuarios,struct Solicitud *solicitudes,
        int numSolicitudes){
    int posLibro;
    for(int i=0;i<numUsuarios;i++){
        for(int k=0;k<numSolicitudes;k++)
            if(usuarios[i].dni==solicitudes[k].dni){
                posLibro = buscarPosicionLibro(libros,solicitudes[k].codigoLibro
                        ,numLibros);
                if(posLibro!=NO_ENCONTRADO){
                    if(libros[posLibro].cantidadVolumenes>0){
                        if(usuarios[i].categoria=='A' and
                                usuarios[i].cantidadPrestada <4 or
                                usuarios[i].categoria=='D' and
                                usuarios[i].cantidadPrestada < 6 or
                                usuarios[i].categoria=='V' and
                                usuarios[i].cantidadPrestada < 2){
                            usuarios[i].cantidadPrestada++;
                            libros[posLibro].cantidadVolumenes--;
                            libros[posLibro].cantidadPrestado++;
                        }else {
                            usuarios[i].cantidadPrestada++;
                            usuarios[i].calificacion-=
                                (usuarios[i].calificacion)*0.1;
                        }
                    }
                }
            }
    }
}

/*Se realiza la busqueda del usuario con su respectiva posicion*/
int buscarPosicionUsuario(struct Usuario *usuarios,int dni,int numDatos){
    for(int i=0;i<numDatos;i++)
        if(usuarios[i].dni==dni)return i;
    return NO_ENCONTRADO;
}
/*Se realiza la busqueda del libro con su respectiva posicion*/
int buscarPosicionLibro(struct Libro *libros,char *codigo, int numDatos){
    for(int i=0;i<numDatos;i++)
        if(strcmp(libros[i].codigo,codigo)==0)return i;
    return NO_ENCONTRADO;
}
/*Impresion de las solicitudes registradas dadas el archivo de 
 SolicitudesDePrestamo.txt*/
void imprimeReporteSolicitudesProcesadas(struct Libro *libros,int numLibros,
        struct Usuario *usuarios,int numUsuarios,struct Solicitud *solicitudes,
        int numSolicitudes){
    
    ofstream archReporte("ReporteSolicitudesAtendidas.txt",ios::out);
    if(not archReporte.is_open()){
        cout<<"ERROR al abrir el archivo de ReporteSolicitudesAtendidas"<<endl;
        exit(1);
    }
    archReporte<<setprecision(2);
    archReporte<<fixed;
    imprimeEncabezadoLibros(archReporte);
    for(int i=0;i<numLibros;i++)
        archReporte<<libros[i].codigo<<setw(9)<<' '<<left<<setw(50)
                <<libros[i].titulo<<' '<<setw(50)<<libros[i].autor<<right
                <<setw(3)<<libros[i].cantidadVolumenes<<setw(25)
                <<libros[i].precio<<setw(15)<<libros[i].cantidadPrestado<<endl;
    imprimeEncabezadoUsuarios(archReporte);
    for(int i=0;i<numUsuarios;i++)
        archReporte<<usuarios[i].dni<<setw(9)<<' '<<left<<setw(50)
                <<usuarios[i].nombre<<setw(20)<<usuarios[i].categoria
                <<right<<setw(5)<<usuarios[i].calificacion
                <<setw(25)<<usuarios[i].cantidadPrestada<<endl;
    imprimeEncabezadoSolicitudes(archReporte);
    for(int i=0;i<numSolicitudes;i++)
        archReporte<<solicitudes[i].dni<<setw(10)<<solicitudes[i].codigoLibro
                <<endl;
    imprimeLinea('=',MAX_LINE,archReporte);
}

void imprimeEncabezadoLibros(ofstream &archReporte){
        archReporte<<setw(50)<<' '<<"DATOS DE LIBROS ALMACENADOS"<<endl;
    imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<"Codigo"<<setw(10)<<' '<<"Titulo"<<setw(45)<<' '<<"Autor"
            <<setw(40)<<' '<<"Cantidad Volumenes"<<setw(9)<<' '<<"Precio"
            <<setw(10)<<' '<<"Veces Prestado"<<endl;
    imprimeLinea('-',MAX_LINE,archReporte);
}

void imprimeEncabezadoUsuarios(ofstream &archReporte){
        imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<endl<<setw(50)<<' '<<"DATOS DE USUARIOS"<<endl;
    imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<"DNI"<<setw(20)<<"Nombre"<<setw(50)<<"Categoria"
            <<setw(30)<<"Calificacion como usuario"<<setw(20)
            <<"Libros Prestados"<<endl;
    imprimeLinea('-',MAX_LINE,archReporte);
}

void imprimeEncabezadoSolicitudes(ofstream &archReporte){
    imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<endl<<setw(50)<<' '<<"DATOS DE SOLICITUDES DE PRESTAMO"<<endl;
    imprimeLinea('=',MAX_LINE,archReporte);
    archReporte<<"DNI"<<setw(8)<<' '<<"Codigo Libro"<<endl;
    imprimeLinea('-',MAX_LINE,archReporte);
}



void imprimeLinea(char caracter, int cantidad, ofstream &archReporte){
    for(int i=0;i<cantidad;i++)archReporte<<caracter;
    archReporte<<endl;
}


