/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.cc to edit this template
 */

#include<iomanip>
#include "sobreCargaOperadores.h"

bool operator >>(ifstream &in, struct Cliente &cliente){
    char c;    
    in>>cliente.dni>>c;
    if(in.eof()) return false;
    in.getline(cliente.nombre, 100, ',');
    in>>cliente.telefono;    
    cliente.cantidadProductosEntrgados=0;
    cliente.montoTotal=0;   
    return true;
}

bool operator >>(ifstream &in, struct Producto &producto){
    char c;    
    in.getline(producto.codigo, 8, ',');
    if(in.eof()) return false;
    in.getline(producto.descripcion, 60, ',');
    in>>producto.precio>>c>>producto.stock>>c; // el salto de linea tambien se puede leer con in.get() por que en la proxima linea el siguiente es una cadena   
    producto.cantidadClientesNoServidos = 0;
    producto.cantidadClientesServidos = 0;
    return true;
}

bool operator >>(ifstream &in, struct Pedido &pedido){
    in.getline(pedido.CodigoProducto, 8,',');
    if(in.eof()) return false;
    in>>pedido.dniCliente;
    in.get();//elimino el salto de linea    
    pedido.precioProducto = 0;
    return true;
}


void operator +=(struct Cliente *arrClientes, struct Pedido pedido){
    //ubicar cliente
    int i=0;
    while(true){
        if(arrClientes[i].dni == 0) break;     
        
        if( pedido.dniCliente == arrClientes[i].dni ){         
            int indice = arrClientes[i].cantidadProductosEntrgados;
           
            struct ProductoEntregado prodEntregado;
            prodEntregado.precio = pedido.precioProducto;
            strcpy(prodEntregado.codigo, pedido.CodigoProducto);
            
            arrClientes[i].productosEntregados[indice] = prodEntregado;//producto 
            arrClientes[i].cantidadProductosEntrgados++;
            
            arrClientes[i].montoTotal += pedido.precioProducto;
            
            break;
        }              
        i++;
    }
}

bool operator +=(struct Producto *arrProductos, struct Pedido pedido){
    //ubicar producto
    int i=0;
    while(true){
        if(arrProductos[i].codigo ==  "XXXXXXX") break;     
        
        if( strcmp(arrProductos[i].codigo , pedido.CodigoProducto) == 0 ){   
            
            pedido.precioProducto = arrProductos[i].precio;
            
           if( arrProductos[i].stock > 0 ){
               int indice = arrProductos[i].cantidadClientesServidos;
               arrProductos[i].clientesServidos[indice] = pedido.dniCliente;
               arrProductos[i].cantidadClientesServidos++;
               return true;
           }else{
               int indice = arrProductos[i].cantidadClientesNoServidos;
               arrProductos[i].clientesNoServidos[indice] = pedido.dniCliente;
               arrProductos[i].cantidadClientesNoServidos++;
               return false;
           }
            
            break;
        }              
        i++;
    }
}


void operator <<(ostream &out, struct Cliente &cliente){
    out<<setw(10)<<left<<cliente.dni;
    out<<setw(40)<<left<<cliente.nombre;
    out<<setw(14)<<left<<cliente.telefono;
    out<<setw(8)<<left<<cliente.montoTotal;
    
    out<<"Productos entregados: ";
    if( cliente.cantidadProductosEntrgados==0){
        out<<"NO SE LE ENTREGARON PRODUCTOS";
    }else{
        for(int i=0 ; i<cliente.cantidadProductosEntrgados ; i++){
            struct ProductoEntregado prodEntre;
            prodEntre = cliente.productosEntregados[i];
            out<<prodEntre.codigo<<"  ";
        }
        out<<endl;
    }
}

void operator <<(ostream &out, struct Producto &producto){
    out<<setw(10)<<left<<producto.codigo;
    out<<setw(40)<<left<<producto.descripcion;
    out<<setw(8)<<left<<producto.precio;
    out<<setw(8)<<left<<producto.stock<<endl;
    
    out<<"Clientes atendidos: ";
    if( producto.cantidadClientesServidos==0){
        out<<"NO SE ATENDIERON PEDIDOS";
    }else{
        for(int i=0 ; i<producto.cantidadClientesServidos ; i++){           
            out<<producto.clientesServidos[i]<<"  ";
        }
        out<<endl;
    }
    
    out<<"Clientes no atendidos: ";
    if( producto.cantidadClientesNoServidos==0){
        out<<"NO HAY CLIENTES SIN ATENDER";
    }else{
        for(int i=0 ; i<producto.cantidadClientesNoServidos ; i++){           
            out<<producto.clientesNoServidos[i]<<"  ";
        }
        out<<endl;
    }
}






















