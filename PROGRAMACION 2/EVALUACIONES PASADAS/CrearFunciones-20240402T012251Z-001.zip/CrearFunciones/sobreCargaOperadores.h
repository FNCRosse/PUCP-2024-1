/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file.h to edit this template
 */

/* 
 * File:   sobreCargaOperadores.h
 * Author: Jean Carlos
 *
 * Created on 28 de marzo de 2024, 22:32
 */

#ifndef SOBRECARGAOPERADORES_H
#define SOBRECARGAOPERADORES_H
#include<iostream>
#include<fstream>
using namespace std;

#include "Estructuras.h"

#include<cstring>

bool operator >>(ifstream &, struct Cliente &);
bool operator >>(ifstream &, struct Producto &);
bool operator >>(ifstream &, struct Pedido &);

void operator +=(struct Cliente *, struct Pedido);
bool operator +=(struct Producto *arrProductos, struct Pedido pedido);

void operator <<(ostream &out, struct Cliente &cliente);
void operator <<(ostream &out, struct Producto &producto);

#endif /* SOBRECARGAOPERADORES_H */

