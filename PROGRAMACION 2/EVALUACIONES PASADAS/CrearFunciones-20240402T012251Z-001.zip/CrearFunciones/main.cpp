/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: Jean Carlos
 *
 * Created on 28 de marzo de 2024, 22:30
 */

#include <cstdlib>
#include<fstream>
#include<iostream>
using namespace std;

#include "Estructuras.h"
#include "sobreCargaOperadores.h"

int main(int argc, char** argv) {
    /*
    ifstream archCli("Clientes.csv", ios::in);
    if( not archCli.is_open()){
        cout<<"ERROR, al abrir archivo Clientes.csv";
        exit(1);
    }
    
    struct Cliente cliente;
    archCli>>cliente;
    
    cout<<"DNI: "<<cliente.dni<<endl;
    cout<<"NOMBRE: "<<cliente.nombre<<endl;
    cout<<"TELEFONO: "<<cliente.telefono<<endl;
    cout<<"CANTIDAD: "<<cliente.cantidadProductosEntrgados<<endl;
    cout<<"MONTO: "<<cliente.montoTotal<<endl;
    
    struct Pedido pedido1;
    pedido1.dniCliente = 79464412;
    pedido1.precioProducto = 456.7;
    strcpy(pedido1.CodigoProducto, "ABC7364");
    
    struct Pedido pedido2;
    pedido2.dniCliente = 79464412;
    pedido2.precioProducto = 34.7;
    strcpy(pedido2.CodigoProducto, "ART4754");
    
    
    struct Cliente ArrClientes[10];
    ArrClientes[0] = cliente; 
    ArrClientes[1].dni = 0;
    
    ArrClientes += pedido1;
    ArrClientes += pedido2;
    
    cliente = ArrClientes[0];  
    cout<<"--------------------------------"<<endl;
    cout<<"DNI: "<<cliente.dni<<endl;
    cout<<"NOMBRE: "<<cliente.nombre<<endl;
    cout<<"TELEFONO: "<<cliente.telefono<<endl;
    cout<<"CANTIDAD: "<<cliente.cantidadProductosEntrgados<<endl;
    cout<<"MONTO: "<<cliente.montoTotal<<endl;
    
    cliente = ArrClientes[0];    
    cout<<cliente;
     * 
     * 
     * */
    
    
    /*
    cout<<"DNI: "<<cliente.dni<<endl;
    cout<<"NOMBRE: "<<cliente.nombre<<endl;
    cout<<"TELEFONO: "<<cliente.telefono<<endl;
    cout<<"CANTIDAD: "<<cliente.cantidadProductosEntrgados<<endl;
    cout<<"MONTO: "<<cliente.montoTotal<<endl;
     */
    
    /*
    ifstream archPedidos("Pedidos.csv", ios::in);
    if( not archPedidos.is_open()){
        cout<<"ERROR, al abrir archivo Pedidos.csv";
        exit(1);
    }
    struct Pedido pedido;
    archPedidos>>pedido;
    
    cout<<"Codigo Producto: "<<pedido.CodigoProducto<<endl;
    cout<<"DNI Cliente: "<<pedido.dniCliente<<endl;
    cout<<"Precio Producto: "<<pedido.precioProducto<<endl;    
    */
    
    
    
    
    ifstream archProductos("Productos.csv", ios::in);
    if( not archProductos.is_open()){
        cout<<"ERROR, al abrir archivo Productos.csv";
        exit(1);
    }
    struct Producto producto;
    archProductos>>producto;
    /*
    cout<<"Codigo Producto: "<<producto.codigo<<endl;
    cout<<"Descripcion Producto: "<<producto.descripcion<<endl;
    cout<<"Precio Producto: "<<producto.precio<<endl;    
    cout<<"Stock Producto: "<<producto.stock<<endl;    
    cout<<"Cantidad de Clientes Servidos: "<<producto.cantidadClientesServidos<<endl;    
    for(int i=0 ; i<producto.cantidadClientesServidos ; i++) cout<<producto.clientesServidos[i]<<" "; 
    cout<<"Cantidad de Clientes No Servidos: "<<producto.cantidadClientesNoServidos<<endl;    
    for(int i=0 ; i<producto.cantidadClientesNoServidos ; i++) cout<<producto.clientesNoServidos[i]<<" ";    
    */
    
     
    struct Producto ArrProductos[10];
    ArrProductos[0] = producto; 
    strcpy(ArrProductos[1].codigo , "XXXXXXX" );
    
    struct Pedido pedido1;
    pedido1.dniCliente = 79464412;
    pedido1.precioProducto = 0;
    strcpy(pedido1.CodigoProducto, "BIT-434");
    
    struct Pedido pedido2;
    pedido2.dniCliente = 34667646;
    pedido2.precioProducto = 0;
    strcpy(pedido2.CodigoProducto, "BIT-434");
    
    ArrProductos += pedido1;
    ArrProductos += pedido2;
    
    producto = ArrProductos[0];
    
    cout<<producto;
    /*
    cout<<"Codigo Producto: "<<producto.codigo<<endl;
    cout<<"Descripcion Producto: "<<producto.descripcion<<endl;
    cout<<"Precio Producto: "<<producto.precio<<endl;    
    cout<<"Stock Producto: "<<producto.stock<<endl;    
    cout<<"Cantidad de Clientes Servidos: "<<producto.cantidadClientesServidos<<endl;    
    for(int i=0 ; i<producto.cantidadClientesServidos ; i++) cout<<producto.clientesServidos[i]<<" "; 
    cout<<"Cantidad de Clientes No Servidos: "<<producto.cantidadClientesNoServidos<<endl;    
    for(int i=0 ; i<producto.cantidadClientesNoServidos ; i++) cout<<producto.clientesNoServidos[i]<<" ";    
*/
    
    return 0;
}

