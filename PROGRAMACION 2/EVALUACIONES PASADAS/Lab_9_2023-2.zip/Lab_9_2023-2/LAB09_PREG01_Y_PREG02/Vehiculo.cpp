/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Vehiculo.cpp
 * Author: Usuario
 * 
 * Created on 16 de junio de 2024, 01:28 PM
 */

#include <string.h>

#include "Vehiculo.h"

Vehiculo::Vehiculo() {
    actcarga=0;
    cliente=0;
    maxcarga=0;
    placa=nullptr;
}

Vehiculo::~Vehiculo() {
    if(placa)delete[] placa;
}

void Vehiculo::SetActcarga(double actcarga) {
    this->actcarga = actcarga;
}

double Vehiculo::GetActcarga() const {
    return actcarga;
}

void Vehiculo::SetMaxcarga(double maxcarga) {
    this->maxcarga = maxcarga;
}

double Vehiculo::GetMaxcarga() const {
    return maxcarga;
}

void Vehiculo::SetPlaca(char* placa) {
    this->placa = new char[strlen(placa)+1];
    strcpy(this->placa,placa);
}

char* Vehiculo::GetPlaca() const {
    return placa;
}

void Vehiculo::SetCliente(int cliente) {
    this->cliente = cliente;
}

int Vehiculo::GetCliente() const {
    return cliente;
}

//F,79464412,K0D-676,300,1,3
void Vehiculo::lee(ifstream& arch) {
    char c,_placa[10];
    
    arch>>cliente>>c;
    arch.getline(_placa,10,',');
    arch>>maxcarga>>c;
    
    SetPlaca(_placa);
}

void Vehiculo::imprime(ofstream& arch) {
    arch<<endl;
    arch<<left<<setw(16)<<"Codigo Cliente:"<<cliente<<endl;
    arch<<left<<setw(16)<<"Placa:"<<placa<<endl;
    arch<<left<<setw(16)<<"Carga Maxima:"<<maxcarga<<endl;
    arch<<left<<setw(16)<<"Carga Actual:"<<actcarga<<endl;
}