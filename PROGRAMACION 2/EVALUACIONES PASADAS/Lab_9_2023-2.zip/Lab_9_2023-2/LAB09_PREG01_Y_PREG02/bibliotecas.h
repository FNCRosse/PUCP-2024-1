/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   bibliotecas.h
 * Author: Usuario
 *
 * Created on 16 de junio de 2024, 01:25 PM
 */

#ifndef BIBLIOTECAS_H
#define BIBLIOTECAS_H

#include <fstream>
#include <cstring>
#include <iostream>
#include <iomanip>
#include <map>
#include <list>
#include <vector>
#include <iterator>
#include <algorithm>

using namespace std;

#endif /* BIBLIOTECAS_H */

