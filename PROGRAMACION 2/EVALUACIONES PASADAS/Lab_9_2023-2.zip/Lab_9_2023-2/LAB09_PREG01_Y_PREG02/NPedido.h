/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NPedido.h
 * Author: Usuario
 *
 * Created on 16 de junio de 2024, 01:26 PM
 */

#ifndef NPEDIDO_H
#define NPEDIDO_H

#include "bibliotecas.h"

class NPedido {
public:
    NPedido();
    ~NPedido();
    void SetPeso(double peso);
    double GetPeso() const;
    void SetCantidad(int cantidad);
    int GetCantidad() const;
    void SetCodigo(char* codigo);
    char* GetCodigo() const;
    
    void imprimePedido(int i,ofstream &arch);
    void imprimePedido(ofstream &arch);
    void leePedido(ifstream &arch);
private:
    char *codigo;
    int cantidad;
    double peso;
};

#endif /* NPEDIDO_H */

