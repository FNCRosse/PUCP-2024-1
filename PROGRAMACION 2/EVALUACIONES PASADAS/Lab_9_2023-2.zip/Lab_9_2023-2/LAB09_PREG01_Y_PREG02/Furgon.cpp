/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Furgon.cpp
 * Author: Usuario
 * 
 * Created on 16 de junio de 2024, 01:35 PM
 */

#include "Furgon.h"

Furgon::Furgon() {
    filas=0;
    puertas=0;
}

Furgon::~Furgon() {
}

void Furgon::lee(ifstream& arch) {
    Vehiculo::lee(arch);
    
    char c;
    
    arch>>filas>>c>>puertas;
}

void Furgon::imprime(ofstream& arch) {
    Vehiculo::imprime(arch);
    
    arch<<left<<setw(16)<<"#filas:"<<filas<<endl;
    arch<<left<<setw(16)<<"#puertas:"<<puertas<<endl;
    arch<<left<<setw(17)<<"Lista de Pedidos:"<<endl;
    if(pdeposito.empty())
        arch<<"No hay pedidos para el cliente"<<endl;
    else{
        for(NPedido aux:pdeposito)
            aux.imprimePedido(arch);
    }
}

void Furgon::cargadeposito(NPedido& pedido) {
    if(pedido.GetPeso()+GetActcarga()<=GetMaxcarga()){
        pdeposito.push_front(pedido);
        double actcarga=GetActcarga();
        actcarga+=pedido.GetPeso();
        SetActcarga(actcarga);
    }
}
