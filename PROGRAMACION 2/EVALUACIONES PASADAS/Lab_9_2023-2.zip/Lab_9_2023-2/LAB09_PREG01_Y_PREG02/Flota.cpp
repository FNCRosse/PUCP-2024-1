/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Flota.cpp
 * Author: Usuario
 * 
 * Created on 16 de junio de 2024, 01:38 PM
 */

#include <fstream>

#include "Flota.h"
#include "NPedido.h"

Flota::Flota() {
}

Flota::~Flota() {
}

//F,79464412,K0D-676,300,1,3
void Flota::cargaflota() {
    ifstream arch("Vehiculos.csv");
    if(not arch.is_open()){
        cout<<"Error, no se pudo abrir el archivo Vehiculos.csv"<<endl;
        exit(1);
    }
    
    char tipo;
    NVehiculo aux;
    while(true){
        arch>>tipo;
        if(arch.eof())break;
        arch.get();
        
        if(tipo=='F' or tipo=='C'){
            aux.asignarMemoria(tipo);
            aux.leeRegistro(arch);
            vflota.push_back(aux);
        }else
            while(arch.get()!='\n');
    }
    
    sort(vflota.begin(),vflota.end());
//    
//    for(int i=0;i<vflota.size();i++){
//        aux=vflota[i];
//        cout<<aux.GetUnidad()->GetPlaca()<<endl;
//    }
}

void Flota::muestracarga() {
    ofstream arch("PuntoDEINsicionDElEsternocleidoMAstoideo.txt");
    
    arch<<right<<setw(30)<<"REPORTE DE FLOTA"<<endl;
    for(int i=0;i<100;i++)arch<<'=';
    arch<<endl;
    
    for(auto aux: vflota)
        aux.imprimeRegistro(arch);
}

//50375303,CRU.009,5,200
void Flota::cargapedidos() {
    ifstream arch("Pedidos3.csv");
    if(not arch.is_open()){
        cout<<"Error, no se pudo abrir el archivo Pedidos3.csv"<<endl;
        exit(1);
    }
    
    NPedido pedido;
    int cliente;
    while(true){
        arch>>cliente;
        if(arch.eof())break;
        arch.get();
        pedido.leePedido(arch);
        
        auto aux=find(vflota.begin(),vflota.end(),cliente);
        if(aux!=vflota.end())
            aux->insertaPedido(pedido);
    }
}
