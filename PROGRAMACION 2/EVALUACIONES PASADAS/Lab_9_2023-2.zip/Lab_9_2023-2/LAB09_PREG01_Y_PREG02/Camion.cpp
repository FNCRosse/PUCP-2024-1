/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Camion.cpp
 * Author: Usuario
 * 
 * Created on 16 de junio de 2024, 01:30 PM
 */

#include "Camion.h"

Camion::Camion() {
    ejes=0;
    llantas=0;
}

Camion::~Camion() {
}

void Camion::lee(ifstream& arch) {
    Vehiculo::lee(arch);
    
    char c;
    
    arch>>ejes>>c>>llantas;
}

void Camion::imprime(ofstream& arch) {
    Vehiculo::imprime(arch);
    
    arch<<left<<setw(16)<<"#Ejes:"<<ejes<<endl;
    arch<<left<<setw(16)<<"#Llantas:"<<llantas<<endl;
    arch<<left<<setw(17)<<"Lista de Pedidos:"<<endl;
    if(mdeposito.empty())
        arch<<"No hay pedidos para el cliente"<<endl;
    else{
        NPedido aux;
        for(int i=0;i<mdeposito.size();i++){
            aux=mdeposito[i];
            aux.imprimePedido(i+1,arch);
        }
    }
}

void Camion::cargadeposito(NPedido& pedido) {
    if(pedido.GetPeso()+GetActcarga()<=GetMaxcarga() and mdeposito.size()<5){
        int i=mdeposito.size();
        mdeposito[i]=pedido;
        double actcarga=GetActcarga();
        actcarga+=pedido.GetPeso();
        SetActcarga(actcarga);
    }
}
