/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NVehiculo.cpp
 * Author: Usuario
 * 
 * Created on 16 de junio de 2024, 01:37 PM
 */

#include "NVehiculo.h"
#include "Camion.h"
#include "Furgon.h"

NVehiculo::NVehiculo() {
    unidad=nullptr;
}

NVehiculo::~NVehiculo() {
//    if(unidad)delete unidad;
}

void NVehiculo::SetUnidad(Vehiculo* unidad) {
    this->unidad = unidad;
}

Vehiculo* NVehiculo::GetUnidad() const {
    return unidad;
}

void NVehiculo::asignarMemoria(char tipo) {
    switch(tipo){
        case 'C':
            unidad=new Camion;
            break;
        case 'F':
            unidad=new Furgon;
            break;
    }
}

void NVehiculo::leeRegistro(ifstream& arch) {
    unidad->lee(arch);
}

void NVehiculo::imprimeRegistro(ofstream& arch) {
    unidad->imprime(arch);
}

bool NVehiculo::operator<(const NVehiculo& aux) const {
    return unidad->GetCliente()<aux.GetUnidad()->GetCliente();
}

bool NVehiculo::operator==(int _cliente) {
    return unidad->GetCliente()==_cliente;
}

void NVehiculo::insertaPedido(NPedido& pedido) {
    unidad->cargadeposito(pedido);
}
