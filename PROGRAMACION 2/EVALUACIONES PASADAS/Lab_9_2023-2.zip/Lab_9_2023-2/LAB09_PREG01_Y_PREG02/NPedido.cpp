/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NPedido.cpp
 * Author: Usuario
 * 
 * Created on 16 de junio de 2024, 01:26 PM
 */

#include "NPedido.h"

NPedido::NPedido() {
    cantidad=0;
    codigo=nullptr;
    peso=0;
}

NPedido::~NPedido() {
    if(codigo)delete[] codigo;
}

void NPedido::SetPeso(double peso) {
    this->peso = peso;
}

double NPedido::GetPeso() const {
    return peso;
}

void NPedido::SetCantidad(int cantidad) {
    this->cantidad = cantidad;
}

int NPedido::GetCantidad() const {
    return cantidad;
}

void NPedido::SetCodigo(char* codigo) {
    this->codigo = new char[strlen(codigo)+1];
    strcpy(this->codigo,codigo);
}

char* NPedido::GetCodigo() const {
    return codigo;
}

void NPedido::imprimePedido(int i, ofstream& arch) {
    arch<<right<<setw(3)<<i<<setw(10)<<codigo<<setw(4)<<cantidad<<setw(10)<<peso<<endl;
}

void NPedido::imprimePedido(ofstream& arch) {
    arch<<right<<setw(10)<<codigo<<setw(4)<<cantidad<<setw(10)<<peso<<endl;
}

void NPedido::leePedido(ifstream& arch) {
    char c,cod[10];
    arch.getline(cod,10,',');
    arch>>cantidad>>c>>peso;
    SetCodigo(cod);
}
