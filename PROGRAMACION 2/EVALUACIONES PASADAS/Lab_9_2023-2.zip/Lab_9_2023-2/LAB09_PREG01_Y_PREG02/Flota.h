/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Flota.h
 * Author: Usuario
 *
 * Created on 16 de junio de 2024, 01:38 PM
 */

#ifndef FLOTA_H
#define FLOTA_H

#include "bibliotecas.h"
#include "NVehiculo.h"

class Flota {
public:
    Flota();
    ~Flota();
    
    void cargaflota();
    void muestracarga();
    
    void cargapedidos();
private:
    vector<NVehiculo> vflota;
};

#endif /* FLOTA_H */

