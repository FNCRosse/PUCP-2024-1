/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   NVehiculo.h
 * Author: Usuario
 *
 * Created on 16 de junio de 2024, 01:37 PM
 */

#ifndef NVEHICULO_H
#define NVEHICULO_H

#include "Vehiculo.h"
#include "NPedido.h"

class NVehiculo {
public:
    NVehiculo();
    ~NVehiculo();
    void SetUnidad(Vehiculo* unidad);
    Vehiculo* GetUnidad() const;
    
    void asignarMemoria(char tipo);
    void leeRegistro(ifstream &arch);
    void imprimeRegistro(ofstream &arch);
    
    bool operator<(const NVehiculo &aux)const;
    bool operator==(int _cliente);
    void insertaPedido(NPedido &pedido);
private:
    Vehiculo *unidad;
};

#endif /* NVEHICULO_H */

