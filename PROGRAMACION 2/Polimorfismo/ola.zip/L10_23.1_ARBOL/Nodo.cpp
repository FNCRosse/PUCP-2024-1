
/* 
 * File:   Nodo.cpp
 * Author: mell1
 * 
 * Created on 9 de junio de 2024, 22:24
 */

#include "Nodo.h"

Nodo::Nodo() {
    der = nullptr;
    izq = nullptr;
}
