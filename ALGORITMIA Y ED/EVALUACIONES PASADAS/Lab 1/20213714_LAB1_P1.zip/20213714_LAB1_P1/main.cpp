/* 
 * File:   main.cpp
 * Author: Rosa Cristina La Cruz Musayon
 * codigo: 20213714
 * Created on 16 de septiembre de 2023, 08:02 AM
 */

#include <cstdlib>
#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
#define MAX 4
#define MAXC 10

void LeerDatos(int TortuNinja[][MAX],int Mapa[][MAXC]){
    fstream arch ("datos.txt",ios::in);
    char direccion;
    for(int i=0;i<4;i++){
        arch>>TortuNinja[0][i];
        arch>>direccion;
        // como Arriba inican con A, 
        //pongo la siguiente letra que los diferencia
        if(direccion == 'D') TortuNinja[1][i] =1;//Derecha
        if(direccion == 'I') TortuNinja[1][i] =2;//Izquierda
        if(direccion == 'A') TortuNinja[1][i] =3;//Abajo
        if(direccion == 'R') TortuNinja[1][i] =4;//Arriba
    }
    for(int i=0;i<MAXC;i++){
        for(int j=0;j<MAXC;j++){
            arch>>Mapa[i][j];
        }
    }
}
void EncontrarDir(int TortuNinja[][MAX],int &DirX,int &DirY,int tortuga){
    //Derecha
    if(TortuNinja[1][tortuga]==1){
        DirX = 0;
        DirY = 1;
    }
    //Izquierda
    if(TortuNinja[1][tortuga]==2){
        DirX = 0;
        DirY = -1;
    }
    //Abajo
    if(TortuNinja[1][tortuga]==3){
        DirX = 1;
        DirY = 0;
    }
    //Arriba
    if(TortuNinja[1][tortuga]==4){
        DirX = -1;
        DirY = 0;
    }
}
bool CumplirMision(int TortuNinja[][MAX],int Mapa[][MAXC],int DirX,int DirY,
                    int x,int y,int valor,int CantTortugas){
    //Caso base
    //Que el valor no se pase de el total de casillas de la matriz
    // y que si las 4 tortuninjas mueren pues 
    //no cumple la mision y retorna falso
    if(valor>MAX*MAX || CantTortugas>MAX) return false;
    //casos Recursivos
    //Mover derecha
    if(DirX==0 && DirY==1){// Camina si hay 0
        if(y<MAXC && Mapa[x][y]==0){
            CumplirMision(TortuNinja,Mapa,DirX,DirY,x+DirX,y+DirY,valor+1,CantTortugas);
        }
        else{//encuentra pelea y gana
            b=TortuNinja[0][CantTortugas];
            if(Mapa[x][y]!=0 && TortuNinja[0][CantTortugas]>=Mapa[x][y]){
                // si pelea con SuperFly y gana cumplio su mision y retorna true
                if(Mapa[x][y]==50 && TortuNinja[0][CantTortugas]>=Mapa[x][y])return true;
                TortuNinja[0][CantTortugas]-=Mapa[x][y];
                CumplirMision(TortuNinja,Mapa,DirX,DirY,x+DirX,y+DirY,valor+1,CantTortugas);
            }
            else{//Perdio y cambia de sentido a la siguiente tortuninja
                CantTortugas++;
                EncontrarDir(TortuNinja,DirX,DirY,CantTortugas);
                //Le agrego el -1 al y+DirY para que vuelva al lugar q estaba 
                //para asi cambiar de sentido a la siguiente tortuninja
                CumplirMision(TortuNinja,Mapa,DirX,DirY,x+DirX,y+DirY-1,valor+1,CantTortugas);
            }
        }
    }//Mover Abajo
    else if(DirX==1 && DirY==0){
        if(x+1<MAXC && Mapa[x][y]==0){// Camina si hay 0
            CumplirMision(TortuNinja,Mapa,DirX,DirY,x+DirX,y+DirY,valor+1,CantTortugas);
        }
        else{//encuentra pelea y gana
            if(Mapa[x][y]!=0 && TortuNinja[0][CantTortugas]>=Mapa[x][y]){
                // si pelea con SuperFly y gana cumplio su mision y retorna true
                if(Mapa[x][y]==50 && TortuNinja[0][CantTortugas]>=Mapa[x][y])return true;
                TortuNinja[0][CantTortugas]-=Mapa[x][y];
                CumplirMision(TortuNinja,Mapa,DirX,DirY,x+DirX,y+DirY,valor+1,CantTortugas);
            }
            else{//Perdio y cambia de sentido a la siguiente tortuninja
                CantTortugas++;
                EncontrarDir(TortuNinja,DirX,DirY,CantTortugas);
                //Le agrego el -1 al x+DirX para que vuelva al lugar q estaba 
                //para asi cambiar de sentido a la siguiente tortuninja
                CumplirMision(TortuNinja,Mapa,DirX,DirY,x+DirX-1,y+DirY,valor+1,CantTortugas);
            }
        }
    }//mover Izquierda
    else if(DirX==0 && DirY==-1){
        if(y-1>=0 && Mapa[x][y]==0){// Camina si hay 0
            CumplirMision(TortuNinja,Mapa,DirX,DirY,x+DirX,y+DirY,valor+1,CantTortugas);
        }
        else{//encuentra pelea y gana
            if(Mapa[x][y]!=0 && TortuNinja[0][CantTortugas]>=Mapa[x][y]){
                // si pelea con SuperFly y gana cumplio su mision y retorna true
                if(Mapa[x][y]==50 && TortuNinja[0][CantTortugas]>=Mapa[x][y])return true;
                TortuNinja[0][CantTortugas]-=Mapa[x][y];
                CumplirMision(TortuNinja,Mapa,DirX,DirY,x+DirX,y+DirY,valor+1,CantTortugas);
            }
            else{//Perdio y cambia de sentido a la siguiente tortuninja
                CantTortugas++;
                EncontrarDir(TortuNinja,DirX,DirY,CantTortugas);
                //Le agrego el +1 al y+DirY para que vuelva al lugar q estaba 
                //para asi cambiar de sentido a la siguiente tortuninja
                CumplirMision(TortuNinja,Mapa,DirX,DirY,x+DirX,y+DirY+1,valor+1,CantTortugas);
            }
        }
    }
    //mover Arriba
    else if(DirX==-1 && DirY==0){
        if(x-1>=0 && Mapa[x][y]==0){// Camina si hay 0
            CumplirMision(TortuNinja,Mapa,DirX,DirY,x+DirX,y+DirY,valor+1,CantTortugas);
        }
        else{//encuentra pelea y gana
            if(Mapa[x][y]!=0 && TortuNinja[0][CantTortugas]>=Mapa[x][y]){
                // si pelea con SuperFly y gana cumplio su mision y retorna true
                if(Mapa[x][y]==50 && TortuNinja[0][CantTortugas]>=Mapa[x][y])return true;
                TortuNinja[0][CantTortugas]-=Mapa[x][y];
                CumplirMision(TortuNinja,Mapa,DirX,DirY,x+DirX,y+DirY,valor+1,CantTortugas);
            }
            else{//Perdio y cambia de sentido a la siguiente tortuninja
                CantTortugas++;
                EncontrarDir(TortuNinja,DirX,DirY,CantTortugas);
                //Le agrego el +1 al x+DirX para que vuelva al lugar q estaba 
                //para asi cambiar de sentido a la siguiente tortuninja
                CumplirMision(TortuNinja,Mapa,DirX,DirY,x+DirX+1,y+DirY,valor+1,CantTortugas);
            }
        }
    }
    
    
}
int main(int argc, char** argv) {
    // declaracion de variables
    int DirX,DirY,valor=1,CantTortugas=0;
    int TortuNinja [2][MAX];
    bool Bandera=true;
    int Mapa[MAXC][MAXC];
    LeerDatos(TortuNinja,Mapa);
    //Direccion 
    //      x    y
    //Der   0    1
    //izq   0   -1
    //Ar   -1    0
    //Ab    1    0
    //Encontrar la primera direccion
     EncontrarDir(TortuNinja,DirX,DirY,0);
    Bandera = CumplirMision(TortuNinja,Mapa,DirX,DirY,0,0,valor,CantTortugas);
    if(Bandera){
        cout<<" Las tortuninjas lograron vencer a SuperFly";
    }
    else{
        cout<<" Las tortuninjas NO lograron vencer a SuperFly";
    }
    
    return 0;
}

