
/* 
 * File:   Camion.h
 * Author: Usuario
 */

#ifndef CAMION_H
#define CAMION_H

struct Camion{
    int capacidad;
};


#endif /* CAMION_H */

