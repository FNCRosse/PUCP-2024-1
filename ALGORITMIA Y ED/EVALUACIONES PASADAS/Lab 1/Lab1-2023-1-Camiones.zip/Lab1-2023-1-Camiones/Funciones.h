/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.h to edit this template
 */

/* 
 * File:   Funciones.h
 * Author: Usuario
 *
 * Created on 6 de abril de 2024, 09:00 PM
 */

#ifndef FUNCIONES_H
#define FUNCIONES_H


void solucionOptima(struct Camion *camiones,struct Paquete *paquetes, int M, int N);
void cargarBinario(int *combinaciones,int numOpcion, int N);
#endif /* FUNCIONES_H */
