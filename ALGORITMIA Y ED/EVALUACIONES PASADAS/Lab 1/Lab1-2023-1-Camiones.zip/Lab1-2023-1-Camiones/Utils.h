
/* 
 * File:   Utils.h
 * Author: Usuario
 */

#ifndef UTILS_H
#define UTILS_H

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
#include <cmath>

#endif /* UTILS_H */

