/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/file_header.cc to edit this template
 */

/* 
 * File:   Funciones.cpp
 * Author: Usuario
 * 
 * Created on 6 de abril de 2024, 09:00 PM
 */

#include "Utils.h"
#include "Camion.h"
#include "Paquete.h"
#include "Funciones.h"
using namespace std;

void solucionOptima(struct Camion *camiones,struct Paquete *paquetes, int M, int N){
//    int i=0;
    for(int i=0;i<M;i++){
        //Consideramos como MAX_CAPIDAD la capacidad de cada camion
        int maxCapacidad=camiones[i].capacidad;
        
        //Definimos
        int totalOpciones=(int)pow(2,N);
        int combinaciones[N];//arreglo binario
        int numOpcion;
        int posMinDiferencia,minDiferencia=99999;
        for(int j=0;j<totalOpciones;j++){
            //Tomamos en cuenta el n° de opcion y peso parcial
            numOpcion=j;
            int pesoParcial=0;
            int diferencia;
            //Convertimos a binario el n° de opcion
            cargarBinario(combinaciones,numOpcion,N);
            for(int k=0;k<N;k++){
                pesoParcial+=paquetes[k].peso*combinaciones[k]; //Solamente si la bandera está levantada, sumo
            }
            
            //Determinamos la diferencia que se da con esta combinacion
            int espacioUtilizado,espacioNoUtilizado;
            espacioUtilizado=maxCapacidad-pesoParcial;
            espacioNoUtilizado=maxCapacidad-espacioUtilizado;
                    
            diferencia=abs(espacioUtilizado-espacioNoUtilizado);
            //Analizamos si es eficiente: si la diferencia es minima
            if(pesoParcial<=maxCapacidad and diferencia<minDiferencia and pesoParcial>0){
                minDiferencia=diferencia;
                posMinDiferencia=numOpcion;
            }
        }
        //Tomamos en cuenta la opcion con diferencia minima
        cargarBinario(combinaciones,posMinDiferencia,N);
        cout<<"Camion "<<i+1<<": ";
        for(int j=0;j<N;j++){
            if(combinaciones[j]==1){
                cout<<"Paquete "<<j+1<<" ";
                //Como ya no quiero que se cuente el paquete en la siguiente iteracion, incializamos su valor en cero
                paquetes[j].peso=0;
            }
        }
        cout<<endl;
        
    }
    
    
    
    
}

void cargarBinario(int *combinaciones,int numOpcion, int N){
    int i=0;
    //Como vamos a leer varios camiones, tenemos que bajar las banderas de "1" q se quedan al leer el primer camion
    for(int j=0;j<N;j++){
        combinaciones[j]=0;
    }
    while(numOpcion>0){
        combinaciones[i]=numOpcion%2;
        i++;
        numOpcion=numOpcion/2;
    }
}