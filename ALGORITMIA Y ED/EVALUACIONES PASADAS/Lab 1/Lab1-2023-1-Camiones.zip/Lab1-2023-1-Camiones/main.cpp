
/* 
 * File:   main.cpp
 * Author: Usuario
 */

#include "Utils.h"
#include "Camion.h"
#include "Paquete.h"
#include "Funciones.h"
using namespace std;

int main(int argc, char** argv) {
    int M,N;
//    int num1=20,num2=30;
//    cout<<abs(num2-num1);
    cout<<"Ingrese el n° de camiones: ";
    cin>>M;
    cout<<"Ingrese el n° de paquetes a transportar: ";
    cin>>N;
    cout<<M<<" - "<<N<<endl;
    //Una vez con estos datos trabajamos, definimos los arreglos de camiones y paquetes
    struct Camion camiones[M]={};
    for(int i=0;i<M;i++){
        cout<<"Ingrese la capacidad del camion "<<i+1<<":";
        cin>>camiones[i].capacidad;
    }
    
    struct Paquete paquetes[N]={};
    for(int i=0;i<N;i++){
        cout<<"Ingrese el peso del paquete "<<i+1<<":";
        cin>>paquetes[i].peso;
    }
    
    solucionOptima(camiones,paquetes,M,N);
    
    
    
    return 0;
}

