
/* 
 * File:   Paquete.h
 * Author: Usuario
 */

#ifndef PAQUETE_H
#define PAQUETE_H

struct Paquete{
    int peso;
};


#endif /* PAQUETE_H */

