
/* 
 * File:   main.cpp
 * Author: Rosa Cristina La Cruz
 * Codigo:20213714
 * Created on 2 de septiembre de 2023, 08:01 AM
 */

#include <iostream>
#include <fstream>
#include <cmath>
using namespace std;
#define MAXCONTROL 10
struct Datos {
    int control;
    int inversion;
    int Requisitos[3];
    int Beneficios;
};
void LeerDatos(Datos dato[],int CantControSeg){
    fstream arch ("Datos.txt",ios::in);
    for(int i =0;i<CantControSeg;i++){
        arch>>dato[i].control>>dato[i].inversion>>dato[i].Beneficios;
        int j=0;
        while(true){
            arch>>dato[i].Requisitos[j];
            if(dato[i].Requisitos[j]==0)break;
            j++;
        }
    }
}
void CargaBin(int *cromo,int num){
    int i=0,resto;
    while(num>0){
        resto=num%2;
        cromo[i]=resto;
        num=num/2;
        i++;
    }
}
void ImprimirRespuesta(int cromo[],int CantControSeg,int Datos[][4]){
    for(int i=0;i<CantControSeg;i++){
        if(cromo[i]==0)continue;
        cout<<Datos[i][0]<<" ";
    }
    cout<<endl;
}
bool BuscarRequisito(int Requisito,int cromo[],int CantControSeg,int Datos[][4]){
    for(int i=0;i<CantControSeg;i++){
        if(Requisito==cromo[i]*Datos[i][0])return true;
    }
    //si busco en todo y no encontro entonces retorna false
    return false;
}
bool CumpleRequistos(int pos,int Datos[][4],int cromo[],int CantControSeg){
    //Esto es si inician con 0 los requisitos es que no tienen
    //Entonces pueden la opcion del cromo
    if(Datos[pos][2]==0)return true;
    //contar cuantos Requisitos hay
    int cantRequistos=0,Requisitos[3],num;
    //como los requisitos los guarde como numero ahora los paso a un arreglo
    while(Datos[pos][2]>0){
        num = Datos[pos][2]%10;
        Requisitos[cantRequistos]=num;
        Datos[pos][2] = Datos[pos][2]/10;
        cantRequistos++;
    }
    for(int i=0;i<cantRequistos;i++){
        //Los controles que si tienen requisitos necesitamos buscar
        //si ese cromo tiene los controles que necesita
        //Si no encuentra retorna false y obvia esa solucion
        if(!BuscarRequisito(Requisitos[i],cromo,CantControSeg,Datos))return false;           
    }
    //si cumple todos los requisitos, es solucion valida
    return true;
}
int main(int argc, char** argv) {
    //Declaracion de variables
    int Presupuesto=100000,CantControSeg=8;
    int Datos[CantControSeg][4]= {{1,32000,0,60000},
                                 {2,8000,0,32000},
                                 {3,40000,12,120000},
                                 {4,40000,0,60000},
                                 {5,20000,0,32000},
                                 {6,4000,2,20000},
                                 {7,16000,6,48000},
                                 {8,16000,6,60000}};
    //Datos dato[CantControSeg];
    int BeneficioMAX=0;
    //LeerDatos
   // LeerDatos(dato,CantControSeg);
    //Opciones
    int opciones = pow(2,CantControSeg);
    int soluciones=1,solucionItemB,MatrizSolB[CantControSeg]={0};
    //Recorrer opciones
    for(int i=25;i<opciones;i++){
        //Crear cromosoma
        int cromo[CantControSeg]={0};
        CargaBin(cromo,i);
        //nuevas variables Pregunta A
        int InversionParcial=0;
        //nuevas variables Pregunta B
        int BeneficioParcial =0;
        for(int j=0;j<CantControSeg;j++){
            if(cromo[j]==0)continue;
            //si no cumple con los requerimientos me no es opcion valida
            if(!CumpleRequistos(j,Datos,cromo,CantControSeg))break;
            InversionParcial+=Datos[j][1];
            BeneficioParcial+=Datos[j][3];
        }
        //requerimientos Pregunta A
        if(InversionParcial==Presupuesto){
            cout<<"Solucion: "<<soluciones<<" y i: "<<i<<endl;
            ImprimirRespuesta(cromo,CantControSeg,Datos);
            soluciones++;
        }
        //Requerimiento Pregunta B
        if(InversionParcial<=Presupuesto && BeneficioParcial>BeneficioMAX){
            BeneficioMAX = BeneficioParcial;
            solucionItemB=i;
            
        }
    }
    cout<<endl<<"Solucion Item B: "<<endl;
    CargaBin(MatrizSolB,solucionItemB);
    ImprimirRespuesta(MatrizSolB,CantControSeg,Datos);
    return 0;
}

