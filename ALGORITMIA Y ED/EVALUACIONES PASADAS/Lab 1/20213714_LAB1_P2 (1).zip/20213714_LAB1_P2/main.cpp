
/* 
 * File:   main.cpp
 * Author: Rosa Cristina La Cruz Musayon
 * codigo: 20213714
 * Created on 16 de septiembre de 2023, 08:02 AM
 */

#include <cstdlib>
#include <iostream>
using namespace std;
#define MAX 7

int BuscarPosible(int Mapa[][MAX],int Servidores,int x, int y,
                    int Cumplex,int Cumpley,int contX,int contY){
    //caso base
    //Que no se salga del limite
    if(x>=Servidores || y>=Servidores || x<0 || x<0 )return -1; //no encontro
    //Direccion 
    //      x    y
    //Der   0    1
    //izq   0   -1
    //Ar   -1    0
    //Ab    1    0
    //como el servidor no puede enviar paquetes y no puede recibir
    // entonces Mapa[0][0] tiene que ser 0 y Mapa[1][1] tiene que ser 0
    // asi sucesivamente
    cout<<Mapa[x][y]<<"";
    if(x==y && Mapa[x][y]== 0){
        //MOVER ARRIBA
        // si es que cumple reviso arriba que sea todo 0
        /*for(int i=x;i>0;i++){
            if(Mapa[i][y]!=0)contX++
        }*/
        if(x-1>=0 && Mapa[x-1][y]== 0){
            if(contX==Servidores-(x+1)){
                Cumplex=1;
                contX=0;
            }
            // y sigo buscando hasta el limite de la matriz
            contX++;
            BuscarPosible(Mapa,Servidores,x-1,y,Cumplex,Cumpley,contX,contY);
        }
        else{// si lo que encuentra arriba es diferente a 0, obvio opcion
            BuscarPosible(Mapa,Servidores,x+1,y+1,Cumplex,Cumpley,contX,contY);
        }
        //MOVER IZQUIERDA
        //y izquierda sea todos diferente de 0
        if(y-1>=0 && Mapa[x][y-1]!= 0){
            if(contX==Servidores-(x+1)){
                Cumplex=1;
                contX=0;
            }
            // y sigo buscando hasta el limite de la matriz
            contX++;
            BuscarPosible(Mapa,Servidores,x,y-1,Cumplex,Cumpley,contX,contY);
        }
        else{// si lo que encuentra izq es igual a 0, obvio opcion
            BuscarPosible(Mapa,Servidores,x+1,y+1,Cumplex,Cumpley,contX,contY);
        }
        
    }
    else{// si paso al siguiente matriz que sea x==y
        BuscarPosible(Mapa,Servidores,x+1,y+1,Cumplex,Cumpley,contX,contY);
    }
    // comprobar que cumpla tanto en x como y, y retornar el servidor posible
    if(Cumplex==1 && Cumpley==1){
        
    }
    
    
}
bool VerificarPosibleSolucion(int posible,int Mapa[][MAX],int Servidores){
    int x,y;
    for(int i=0;i<Servidores;i++){
        x=Mapa[posible-1][i];
        y=Mapa[i][posible-1];
        //Que de la derecha y izquierda sean diferentes de 0
        //y no contar el mismo sitio por xq va ser 0
        if(x==0 && i!=posible-1) return false;
        //Toda la columan tiene que ser 0 
        //por que Ningún servidor de la red puede enviar paquetes a SKYNERD
        if(y!=0)return false;
    }
    // si todos conformea las caracteristicas, retornar verdadero
    return true;
}

int main(int argc, char** argv) {
    // declaracion de variables
    int Servidores = 7,posible;
    int Mapa[MAX][MAX]= {{  0, 0, 0, 0,0,  0, 0},
                        { 10, 0,20,30,0, 20,40},
                        {  0, 0, 0, 0,0,100, 0},
                        {  0, 0, 0, 0,0, 80, 0},
                        { 50,10, 5,10,0,100, 4},
                        {100, 0, 0, 0,0,  0, 0},
                        {  0, 0, 0, 0,0,  0, 0}};
    //Buscar un posible servidor que sea SKYNERD
    // es decir que de esa posicion,verticalmente para arriba
    //sea puros 0 y horizontalmente para la izq son todos diferentes de 0
    int x=0,y=0;
    int Cumplex=0,Cumpley=0;
    int contX=0,contY=0;
    posible = BuscarPosible(Mapa,Servidores,x,y,Cumplex,Cumpley,contX,contY);
    //revisar en cruz esta posible solucion cumple todos las caracteristicas
    bool bandera = VerificarPosibleSolucion(posible,Mapa,Servidores);
    if(bandera){
        cout<<"SkyNerd ha sido detectado en el servidor: "<<posible;
    }
    else{
        cout<<"SkyNerd no está en la red ";
    }

    return 0;
}

