/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Usuario
 *
 * Created on 2 de julio de 2024, 08:39 PM
 */

#include "funcionesGrafo.h"
#include "funcionesGrafosConPeso.h"

void recorridos();

/*  M=999999
 * matriz que representa al grafo, cada posicion es la distancia que hay de un vertice a otro
 * si la distancia es M es porque no se pueden alcanzar
 *  0 1 2 3 4 5
 --------------
 0| 0 2 4 M M M
 1| M 0 1 M M M
 2| M M 0 2 3 M
 3| M M M 0 M 1
 4| M M M M 0 2
 5| M M M M M 0
 */

int main(int argc, char** argv) {
    vector<vector<double>> grafo = {
        {0, 2, 4, MAXDOUBLE, MAXDOUBLE, MAXDOUBLE},
        {MAXDOUBLE, 0, 1, MAXDOUBLE, MAXDOUBLE, MAXDOUBLE},
        {MAXDOUBLE, MAXDOUBLE, 0, 2, 3, MAXDOUBLE},
        {MAXDOUBLE, MAXDOUBLE, MAXDOUBLE, 0, MAXDOUBLE, 1},
        {MAXDOUBLE, MAXDOUBLE, MAXDOUBLE, MAXDOUBLE, 0, 2},
        {MAXDOUBLE, MAXDOUBLE, MAXDOUBLE, MAXDOUBLE, MAXDOUBLE, 0}
    };
    
    minimaDistancia(grafo);
    //Este algoritmo te da como resultado una matriz de la distancia mas corta de un vertice a otro
    //por ejemplo, esta es la salida:
/*     0             1             2             3             4             5
 *  -------------------------------------------------------------------------------
    0| 0             2             3             5             6             6             
    1| No alcanzable 0             1             3             4             4             
    2| No alcanzable No alcanzable 0             2             3             3             
    3| No alcanzable No alcanzable No alcanzable 0             No alcanzable 1             
    4| No alcanzable No alcanzable No alcanzable No alcanzable 0             2             
    5| No alcanzable No alcanzable No alcanzable No alcanzable No alcanzable 0  */
    
    //Se lee de la siguiente manera, la distancia mas corta para llegar del vertice 0 al vertice 1 es 2
    //Se lee de la siguiente manera, la distancia mas corta para llegar del vertice 0 al vertice 2 es 3
    //Se lee de la siguiente manera, la distancia mas corta para llegar del vertice 0 al vertice 3 es 5
    //Se lee de la siguiente manera, la distancia mas corta para llegar del vertice 0 al vertice 4 es 6
    //Se lee de la siguiente manera, la distancia mas corta para llegar del vertice 0 al vertice 5 es 6
    return 0;
}

void recorridos(){
    vector<vector<int>> grafo={
        {1,2},//vertice 0 conectado con: 1, 2
        {2},//vertice 1 conectado con: 2
        {3,4},//vertice 2 conectado con: 3, 4
        {5},//vertice 3 conectado con: 5
        {5},//vertice 4 conectado con: 5
        {} //vertice 5 conectado con:
    };
    
    cout<<"Grafo: "<<endl;
    imprime(grafo);
    
    cout<<"Recorrido BFS(con cola): ";
    recorridoBFS(grafo,0);
    cout<<endl;
    
    cout<<"Recorrido DFS(con pila): ";
    recorridoDFS(grafo,0);
    cout<<endl;
    
    cout<<"Recorrido DFS Recursivo (la recursividad reemplaza la pila): ";
    recorridoDFSRecursivo(grafo,0);
    cout<<endl;
}