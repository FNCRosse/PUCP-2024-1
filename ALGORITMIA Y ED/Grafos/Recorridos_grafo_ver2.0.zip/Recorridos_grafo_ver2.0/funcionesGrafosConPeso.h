/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   funcionesGrafosConPeso.h
 * Author: Usuario
 *
 * Created on 3 de julio de 2024, 09:18 AM
 */

#ifndef FUNCIONESGRAFOSCONPESO_H
#define FUNCIONESGRAFOSCONPESO_H

#define MAXDOUBLE 9999
#include <iomanip>

void minimaDistancia(vector<vector<double>> &grafo){
    int n = grafo.size();

    vector<vector<double>> distancias = grafo;//matriz de distancias

    for (int k = 0; k < n; k++) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (distancias[i][k] != MAXDOUBLE and distancias[k][j] != MAXDOUBLE and 
                        distancias[i][k] + distancias[k][j] < distancias[i][j]) {
                    
                    distancias[i][j] = distancias[i][k] + distancias[k][j];
                }
            }
        }
    }

    cout << "Matriz de distancias más cortas entre todos los pares de vértices:" << endl;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (distancias[i][j] == MAXDOUBLE) {
                cout << "No alcanzable ";
            } else {
                cout << setw(14)<<left<<distancias[i][j];
            }
        }
        cout << endl;
    }
}
#endif /* FUNCIONESGRAFOSCONPESO_H */

