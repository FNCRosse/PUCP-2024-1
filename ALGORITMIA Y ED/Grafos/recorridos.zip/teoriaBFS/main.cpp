/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: julia
 *
 * Created on 1 de julio de 2024, 18:47
 */

#include <iostream>
#include <iomanip>
#define N 5
#define RANDOM 23

using namespace std;
#include "Nodo.h"
#include "Lista.h"
#include "Cola.h"
#include "funcionesCola.h"
#include "funcionesLista.h"

bool esVisitado(Lista &visitados,int indice){
    Nodo *recorrido = visitados.cabeza;
    while(recorrido){
        if(recorrido->elemento==indice) return true;
        recorrido = recorrido->siguiente;
    }
    return false;
}

void BFS(int grafo[N][N],int inicio,int fin){
    Lista visitados;
    Cola cola;
    construir(visitados);
    construir(cola);
    encolar(cola,inicio);
    int p=RANDOM;
    while(!esColaVacia(cola) and p!=fin){
        p=desencolar(cola);
        //acá se procesa p
        insertarAlFinal(visitados,p);
        for(int i=0;i<N;i++){
            if(!esVisitado(visitados,i) and grafo[p][i] and !esVisitado(cola.lista,i)){
                //insertarAlFinal(visitados,i);
                encolar(cola,i);
            }
        }
    }
    imprime(visitados);
}

int main(int argc, char** argv) {
    int grafo[N][N]={{0,1,1,0,0},
                     {1,0,1,1,0},
                     {1,1,0,0,1},
                     {0,1,0,0,1},
                     {0,0,1,1,0}};
    BFS(grafo,0,4);
    return 0;
}

