/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: julia
 *
 * Created on 1 de julio de 2024, 19:32
 */

#include <iostream>
#include <iomanip>
#define N 5
#define RANDOM 51
using namespace std;
#include "Nodo.h"
#include "Lista.h"
#include "Pila.h"
#include "funcionesLista.h"
#include "funcionesPila.h"

bool esVisitado(Lista &visitados,int indice){
    Nodo *recorrido = visitados.cabeza;
    while(recorrido){
        if(recorrido->elemento==indice) return true;
        recorrido = recorrido->siguiente;
    }
    return false;
}

void DFS(int grafo[N][N],int inicio,int fin){
    Lista visitados;
    Pila pila;
    construir(visitados);
    construir(pila);
    insertarAlFinal(visitados,inicio);
    for(int i=N-1;i>=0;i--){
        if(grafo[inicio][i]) apilar(pila,i);
    }
    int p=RANDOM;
    while(!esPilaVacia(pila) and p!=fin){
        p=desapilar(pila);
        //acá se procesa p
        insertarAlFinal(visitados,p);
        for(int i=0;i<N;i++){
            if(!esVisitado(visitados,i) and grafo[p][i]){
                //insertarAlFinal(visitados,i);
                apilar(pila,i);
            }
        }
    }
    imprime(visitados);
}

int main(int argc, char** argv) {
    int grafo[N][N]={{0,1,1,1,0},
                     {1,0,0,0,0},
                     {1,0,0,1,1},
                     {1,0,1,0,1},
                     {0,0,1,0,0}};
    DFS(grafo,0,3);
    return 0;
}

