/* 
 * File:   Cliente.h
 * Author: ANA RONCAL
 * Created on 4 de octubre de 2023, 10:15 AM
 */

#ifndef CLIENTE_H
#define CLIENTE_H

struct Cliente{
    int clave;
    char nombre[50];
    char sexo;
    int celular;

};

#endif /* CLIENTE_H */

