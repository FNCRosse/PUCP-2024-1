/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: cueva.r
 *
 * Created on 9 de mayo de 2023, 10:45 AM
 */

#include <cstdlib>

#include "pila.h"

using namespace std;

void ordenarec(Pila &pila1,int n){
    int min,valor,i;
    Pila pila2;
    
    construir(pila2);
    if(n==0) return;
    min = desapilar(pila1);
    i=n-1;
    while(i>0){
        valor = desapilar(pila1);
        if(min > valor){
            apilar(pila2,min);
            min = valor;
        }
        else
            apilar(pila2,valor);
        i--;
    }
    apilar(pila1,min);
    while(!esPilaVacia(pila2)){
        valor = desapilar(pila2);
        apilar(pila1,valor);
    }
    ordenarec(pila1,n-1);
}


int main(int argc, char** argv) {
    Pila Ppila;
    
    construir(Ppila);
    
    apilar(Ppila,15);
    apilar(Ppila,20);
    apilar(Ppila,5);
    apilar(Ppila,10);
    mostrar(Ppila);
    
    ordenarec(Ppila,Ppila.longitud);
    mostrar(Ppila);
    return 0;
}

