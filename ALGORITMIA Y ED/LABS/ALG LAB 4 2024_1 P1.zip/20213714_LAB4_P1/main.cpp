/* 
 * File:   main.cpp
 * Author: Rosa Cristina La Cruz Musayon
 * Created on 1 de junio de 2024, 08:13 PM
 */

#include <iostream>
#include "ArbolBinarioBusqueda.h"
using namespace std;
#include "funcionesArbolesBB.h"
#include "funcionesArbolesBinarios.h"
void aplicar_arbol_Recursivo(NodoArbol *RaizPaq,NodoArbol *&Raiz_Sis){
    if(esNodoVacio(Raiz_Sis) or esNodoVacio(RaizPaq)) return;
    if(!esNodoVacio(RaizPaq)){
        RaizPaq->elemento += numeroNodosRecursivo(Raiz_Sis)
                -numeroHojasRecursivo(Raiz_Sis);
    }
    aplicar_arbol_Recursivo(RaizPaq->izquierda,Raiz_Sis->izquierda);
    aplicar_arbol_Recursivo(RaizPaq->derecha,Raiz_Sis->derecha);
}
ArbolBinario aplicar_arbol(ArbolBinarioBusqueda &arbol_paquete,
        ArbolBinario &arbol_sistema){
    ArbolBinario resultado;
    aplicar_arbol_Recursivo(arbol_paquete.arbolBinario.raiz,arbol_sistema.raiz);
    resultado.raiz = arbol_paquete.arbolBinario.raiz;
    return resultado;
}
bool VerificarABBRecursivo(NodoArbol *resultado,NodoArbol *Prev){
    if(esNodoVacio(resultado)) return true;
    if(!VerificarABBRecursivo(resultado->izquierda,Prev))return false;
    if(!esNodoVacio(Prev) and resultado->elemento <= Prev->elemento) return false;
    Prev = resultado;
    return VerificarABBRecursivo(resultado->derecha,Prev);
}
bool VerificarABB(ArbolBinario arbol_resultado){
    NodoArbol *Prev=nullptr;
    return VerificarABBRecursivo(arbol_resultado.raiz,Prev);
}
bool determinar_anomalia(ArbolBinario &arbol_resultado){
    if (VerificarABB(arbol_resultado) and (sumarNodos(arbol_resultado)%2==0)){
        return true;
    }else{
        return false;
    }
}
int main(int argc, char** argv) {
    //Ejemplo 1
   struct ArbolBinarioBusqueda arbol_paquete;
   struct ArbolBinario arbol_sistema,arbol_resultado;
   construir(arbol_sistema);
   construir(arbol_paquete);
   construir(arbol_resultado);
   //Parte A construir arboles
   //insetar elementos del arbol paquete
   insertar(arbol_paquete,5);
   insertar(arbol_paquete,3);
   insertar(arbol_paquete,9);
   //inserta elemenyos del arbol sistema
   struct ArbolBinario arbol1,arbol2,arbol3,arbol4;
   plantarArbolBinario(arbol1,nullptr,8,nullptr);
   plantarArbolBinario(arbol2,nullptr,2,nullptr);
   plantarArbolBinario(arbol3,nullptr,3,nullptr);
   plantarArbolBinario(arbol4,arbol2,7,arbol3);
   plantarArbolBinario(arbol_sistema,arbol4,1,arbol1);
   //Parte B
   arbol_resultado = aplicar_arbol(arbol_paquete,arbol_sistema);
   //Parte C
   if(determinar_anomalia(arbol_resultado)){
       cout<<"Sin eventos sospechosos"<<endl;
   }else{
       cout<<"Anomalia detectada";
   }
      
    return 0;
}

