/* 
 * File:   main.cpp
 * Author: Rosa Cristina La Cruz Musayon
 * Created on 1 de junio de 2024, 08:15 PM
 */

#include <iostream>
#include <cstring>
#include <cmath>
#include "ArbolBinario.h"
using namespace std;
#include "funcionesArbolesBinarios.h"
#include "funcionesCola.h"
#include "Cola.h"

void RecorrerPorAmplitud(ArbolBinario libro, int &nivel) {
    if (esArbolVacio(libro)) return;
    int altura=0,alturacont = 0,cont=0;
    struct Cola aux;
    construir(aux);
    encolar(aux, libro.raiz);
    while (!esColaVacia(aux)) {
        NodoArbol *nodo = desencolar(aux);
        imprimeNodo(nodo);
        cont++;
        if (strcmp(nodo->elemento.titulo, "Principal") == 0) {
            nivel = altura;
        }
        if (!esNodoVacio(nodo->izquierda)) encolar(aux, nodo->izquierda);
        if (!esNodoVacio(nodo->derecha)) encolar(aux, nodo->derecha);
        if(cont == pow(2,alturacont)){
            cout<<endl;
            altura++;
            cont=0;
        }
        if(cont == 0 )alturacont++;
    }
    destruirCola(aux);
    cout<<endl;
}

NodoArbol* obtenerRaiz(ArbolBinario libro) {
    return libro.raiz;
}

void BorrarCapitulos(ArbolBinario &libro, char direccion) {
    NodoArbol* nodoInicioBorrar;
    NodoArbol *RaizLibro = obtenerRaiz(libro);
    if(direccion == 'D') nodoInicioBorrar = RaizLibro->derecha;
    else if(direccion == 'I') nodoInicioBorrar = RaizLibro->izquierda;
    destruirRecursivo(nodoInicioBorrar);
    if(direccion == 'D') libro.raiz->derecha = nullptr;
    else if(direccion == 'I') libro.raiz->izquierda = nullptr;
}

int main(int argc, char** argv) {
    struct ArbolBinario libro;
    construir(libro);
    //Parte A :contruir arbol dela descripcion
    struct ArbolBinario arbol1, arbol2, arbol3, arbol4, arbol5;
    struct Capitulo dato1 = {"Seccion1.1.1", 4};
    plantarArbolBinario(arbol1, nullptr, dato1, nullptr);
    struct Capitulo dato2 = {"Seccion1.1.2", 2};
    plantarArbolBinario(arbol2, nullptr, dato2, nullptr);
    struct Capitulo dato3 = {"Seccion1.1", 6};
    plantarArbolBinario(arbol3, arbol1, dato3, arbol2);
    struct Capitulo dato4 = {"Principal", 10};
    plantarArbolBinario(arbol4, nullptr, dato4, nullptr);
    struct Capitulo dato5 = {"Capitulo1", 8};
    plantarArbolBinario(arbol5, arbol3, dato5, arbol4);

    struct ArbolBinario arbol6, arbol7, arbol8, arbol9;
    struct Capitulo dato6 = {"Seccion2.1", 3};
    plantarArbolBinario(arbol6, nullptr, dato6, nullptr);
    struct Capitulo dato7 = {"Seccion2.2", 4};
    plantarArbolBinario(arbol7, nullptr, dato7, nullptr);
    struct Capitulo dato8 = {"Capitulo2", 5};
    plantarArbolBinario(arbol8, arbol6, dato8, arbol7);
    struct Capitulo dato9 = {"Titulo", 7};
    plantarArbolBinario(libro, arbol5, dato9, arbol8);
    //Parte B
    int nivel = 0;
    RecorrerPorAmplitud(libro, nivel);
    if (nivel != 0) cout << "El nivel es " << nivel << endl;
    //Parte C
    //Paso el parametro si quiero borrar derechar ('D') o izquierda('I')
    BorrarCapitulos(libro, 'D');
    RecorrerPorAmplitud(libro, nivel);


    return 0;
}

